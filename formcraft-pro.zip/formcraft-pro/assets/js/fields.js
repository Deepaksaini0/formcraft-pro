/* ============================================================
   FormCraft Pro - Field Definitions & Renderer
   Used by builder, preview, and public-facing form.
   ============================================================ */
(function (global) {
    "use strict";

    /* ----------------------------------------------------------
       Country / State / City data
       Country list is bundled (~190 entries, tiny). States and
       cities are fetched lazily from a free public API and cached
       in memory + sessionStorage so re-selects are instant.
       ---------------------------------------------------------- */
    const FCP_COUNTRIES = [
        "Afghanistan","Albania","Algeria","Andorra","Angola","Antigua and Barbuda","Argentina","Armenia","Australia","Austria","Azerbaijan",
        "Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin","Bhutan","Bolivia","Bosnia and Herzegovina","Botswana","Brazil","Brunei","Bulgaria","Burkina Faso","Burundi",
        "Cambodia","Cameroon","Canada","Cape Verde","Central African Republic","Chad","Chile","China","Colombia","Comoros","Congo","Costa Rica","Croatia","Cuba","Cyprus","Czech Republic",
        "Denmark","Djibouti","Dominica","Dominican Republic",
        "Ecuador","Egypt","El Salvador","Equatorial Guinea","Eritrea","Estonia","Eswatini","Ethiopia",
        "Fiji","Finland","France",
        "Gabon","Gambia","Georgia","Germany","Ghana","Greece","Grenada","Guatemala","Guinea","Guinea-Bissau","Guyana",
        "Haiti","Honduras","Hungary",
        "Iceland","India","Indonesia","Iran","Iraq","Ireland","Israel","Italy",
        "Jamaica","Japan","Jordan",
        "Kazakhstan","Kenya","Kiribati","Kuwait","Kyrgyzstan",
        "Laos","Latvia","Lebanon","Lesotho","Liberia","Libya","Liechtenstein","Lithuania","Luxembourg",
        "Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands","Mauritania","Mauritius","Mexico","Micronesia","Moldova","Monaco","Mongolia","Montenegro","Morocco","Mozambique","Myanmar",
        "Namibia","Nauru","Nepal","Netherlands","New Zealand","Nicaragua","Niger","Nigeria","North Korea","North Macedonia","Norway",
        "Oman",
        "Pakistan","Palau","Palestine","Panama","Papua New Guinea","Paraguay","Peru","Philippines","Poland","Portugal",
        "Qatar",
        "Romania","Russia","Rwanda",
        "Saint Kitts and Nevis","Saint Lucia","Saint Vincent and the Grenadines","Samoa","San Marino","Sao Tome and Principe","Saudi Arabia","Senegal","Serbia","Seychelles","Sierra Leone","Singapore","Slovakia","Slovenia","Solomon Islands","Somalia","South Africa","South Korea","South Sudan","Spain","Sri Lanka","Sudan","Suriname","Sweden","Switzerland","Syria",
        "Taiwan","Tajikistan","Tanzania","Thailand","Timor-Leste","Togo","Tonga","Trinidad and Tobago","Tunisia","Turkey","Turkmenistan","Tuvalu",
        "Uganda","Ukraine","United Arab Emirates","United Kingdom","United States","Uruguay","Uzbekistan",
        "Vanuatu","Vatican City","Venezuela","Vietnam",
        "Yemen",
        "Zambia","Zimbabwe"
    ];

    const FCP_GEO_API   = "https://countriesnow.space/api/v0.1/countries";
    const FCP_GEO_CACHE = { states: {}, cities: {} };

    // Restore caches from sessionStorage so once the user selects India once
    // in a tab, every subsequent India-pick is instant.
    try {
        const ss = sessionStorage.getItem("fcp_geo_cache");
        if (ss) {
            const parsed = JSON.parse(ss);
            if (parsed && typeof parsed === "object") {
                Object.assign(FCP_GEO_CACHE.states, parsed.states || {});
                Object.assign(FCP_GEO_CACHE.cities, parsed.cities || {});
            }
        }
    } catch (e) {}
    function persistGeoCache() {
        try { sessionStorage.setItem("fcp_geo_cache", JSON.stringify(FCP_GEO_CACHE)); } catch (e) {}
    }

    function fetchStates(country) {
        if (!country) return Promise.resolve([]);
        if (FCP_GEO_CACHE.states[country]) return Promise.resolve(FCP_GEO_CACHE.states[country]);
        return fetch(FCP_GEO_API + "/states", {
            method:  "POST",
            headers: { "Content-Type": "application/json" },
            body:    JSON.stringify({ country })
        })
        .then(r => r.json())
        .then(d => {
            const list = ((d && d.data && d.data.states) || []).map(s => s.name).filter(Boolean);
            FCP_GEO_CACHE.states[country] = list;
            persistGeoCache();
            return list;
        });
    }
    function fetchCities(country, state) {
        if (!country || !state) return Promise.resolve([]);
        const key = country + "|" + state;
        if (FCP_GEO_CACHE.cities[key]) return Promise.resolve(FCP_GEO_CACHE.cities[key]);
        return fetch(FCP_GEO_API + "/state/cities", {
            method:  "POST",
            headers: { "Content-Type": "application/json" },
            body:    JSON.stringify({ country, state })
        })
        .then(r => r.json())
        .then(d => {
            const list = (d && d.data) || [];
            FCP_GEO_CACHE.cities[key] = list;
            persistGeoCache();
            return list;
        });
    }

    const FIELD_GROUPS = [
        { title: "Basic", fields: [
            { type: "text",     label: "Single Line Text",  icon: "type" },
            { type: "textarea", label: "Paragraph",         icon: "textarea" },
            { type: "email",    label: "Email",             icon: "atSign" },
            { type: "tel",      label: "Phone",             icon: "phone" },
            { type: "number",   label: "Number",            icon: "hash" },
            { type: "password", label: "Password",          icon: "lock" },
            { type: "url",      label: "URL",               icon: "link" },
            { type: "hidden",   label: "Hidden Field",      icon: "eyeoff2" }
        ]},
        { title: "Choice", fields: [
            { type: "select",   label: "Dropdown",          icon: "listDown" },
            { type: "multiselect", label: "Multi Select",   icon: "listDown" },
            { type: "radio",    label: "Radio Buttons",     icon: "radio" },
            { type: "checkbox", label: "Checkboxes",        icon: "checksq" },
            { type: "toggle",   label: "Toggle Switch",     icon: "toggle" },
            { type: "rating",   label: "Rating",            icon: "star" },
            { type: "yesno",    label: "Yes / No",          icon: "checksq" }
        ]},
        { title: "Survey & Poll", fields: [
            { type: "likert",   label: "Likert Scale",      icon: "trending" },
            { type: "nps",      label: "NPS Score (0-10)",  icon: "trending" },
            { type: "poll",     label: "Poll",              icon: "checksq" }
        ]},
        { title: "Advanced", fields: [
            { type: "file",     label: "File Upload",       icon: "file" },
            { type: "image",    label: "Image Upload",      icon: "image" },
            { type: "date",     label: "Date Picker",       icon: "calendar" },
            { type: "time",     label: "Time Picker",       icon: "clock" },
            { type: "datetime", label: "Date & Time",       icon: "calendar" },
            { type: "schedule", label: "Schedule / Booking", icon: "calendar" },
            { type: "range",    label: "Range Slider",      icon: "slider" },
            { type: "color",    label: "Color Picker",      icon: "palette" },
            { type: "signature",label: "Signature",         icon: "sign" },
            { type: "otp",      label: "OTP Verification",  icon: "otp" },
            { type: "captcha",  label: "CAPTCHA",           icon: "captcha" },
            { type: "video",    label: "Video Recording",   icon: "image" },
            // v2.67 — Map / location picker. Leaflet + OpenStreetMap (no
            // API key required). Visitor can type-search an address OR
            // click anywhere on the map to drop a pin; submission carries
            // the address text, latitude, and longitude.
            { type: "map",      label: "Map / Location",    icon: "pin" }
        ]},
        { title: "Business", fields: [
            { type: "name",     label: "Name",              icon: "type" },
            { type: "address",  label: "Address",           icon: "pin" },
            { type: "city",     label: "City",              icon: "building" },
            { type: "state",    label: "State / Region",    icon: "pin" },
            { type: "country",  label: "Country",           icon: "pin" },
            { type: "zip",      label: "Zip Code",          icon: "hash" },
            { type: "company",  label: "Company Name",      icon: "building" },
            { type: "gst",      label: "GST Number",        icon: "hash" }
        ]},
        { title: "Payment", fields: [
            { type: "product",     label: "Product Selector",  icon: "credit" },
            { type: "wc-products", label: "WooCommerce Products", icon: "credit" },
            { type: "pricing",     label: "Pricing Table",     icon: "credit" },
            { type: "coupon",      label: "Coupon Code",       icon: "credit" },
            { type: "calculation", label: "Calculation",       icon: "hash" },
            { type: "payment",     label: "Payment Method",    icon: "credit" },
            // "card" is intentionally NOT in the palette — capturing raw
            // card numbers requires PCI-DSS compliance which the plugin
            // doesn't provide. Use the Payment Method field with a real
            // gateway (Stripe / Razorpay / Cashfree) instead.
            { type: "bank",        label: "Bank Transfer",     icon: "credit" },
            { type: "upi",         label: "UPI Payment",       icon: "credit" }
        ]},
        { title: "Layout", fields: [
            { type: "section",  label: "Section Break",     icon: "layout" },
            { type: "divider",  label: "Divider",           icon: "divider" },
            { type: "html",     label: "HTML Block",        icon: "code" },
            { type: "columns",  label: "Columns",           icon: "layout" },
            { type: "repeater", label: "Repeater Group",    icon: "copy" },
            { type: "list",     label: "List (Dynamic Rows)", icon: "listDown" },
            { type: "gdpr",     label: "GDPR Consent",      icon: "shield" }
        ]}
    ];

    /**
     * Build the HTML panel shown beneath the selected payment method's
     * radio. Each method renders its own widget — UPI shows a QR + UPI ID,
     * Bank Transfer shows the account table, Card shows card inputs, etc.
     */
    function renderPaymentMethodPanel(method, f, name) {
        const safe = v => FCApp.escapeHtml(v == null ? "" : String(v));
        if (method === "upi") {
            const upi = f.upi || {};
            if (!upi.upiId) {
                return `<div class="text-muted text-sm" style="padding:14px;">UPI ID hasn't been configured for this form yet. Edit the field in the builder and add your UPI ID.</div>`;
            }
            const parts = [];
            parts.push("pa=" + encodeURIComponent(upi.upiId));
            if (upi.payeeName) parts.push("pn=" + encodeURIComponent(upi.payeeName));
            if (f.amount)      parts.push("am=" + encodeURIComponent(f.amount));
            parts.push("cu=" + encodeURIComponent(f.currency || "INR"));
            const upiUrl = "upi://pay?" + parts.join("&");
            const qrSrc  = "https://api.qrserver.com/v1/create-qr-code/?size=200x200&margin=4&data=" + encodeURIComponent(upiUrl);
            // v2.57 — When the parent Payment Method field has hidePaymentDetails,
            // the UPI ID + Payee + scan instructions block is skipped. The QR
            // and "Open in UPI app" link stay visible (those are the actionable
            // pieces — the textual UPI ID is the redundant "copy & paste" path).
            const hideUpiDetails = !!f.hidePaymentDetails;
            return `<div class="fcp-pay-card">
                <div class="fcp-upi-row${hideUpiDetails ? " fcp-upi-row-qr-only" : ""}">
                    <div class="fcp-upi-qr-wrap">
                        <img src="${qrSrc}" alt="UPI QR" class="fcp-upi-qr" loading="lazy">
                        <a href="${safe(upiUrl)}" class="fcp-upi-link">Open in UPI app →</a>
                    </div>
                    ${hideUpiDetails ? "" : `
                    <div class="fcp-upi-info">
                        <div class="text-muted text-sm" style="margin-bottom:4px;">UPI ID</div>
                        <div class="fcp-upi-id">
                            <code>${safe(upi.upiId)}</code>
                            <button type="button" class="fcp-copy" data-copy="${safe(upi.upiId)}" title="Copy">${FCApp.ICONS.copy}</button>
                        </div>
                        ${upi.payeeName ? `<div class="text-muted text-sm mt-2">Payee: <strong>${safe(upi.payeeName)}</strong></div>` : ""}
                        <p class="text-sm" style="margin-top:8px;line-height:1.5;">Scan with Google Pay / PhonePe / Paytm / BHIM, or tap "Open in UPI app" on mobile.</p>
                    </div>`}
                </div>
                <!-- UPI proof-of-payment: reference input + REQUIRED checkbox.
                     Identical pattern + wiring as the standalone UPI field
                     (data-fcp-payconfirm). Submit handler in form-engine
                     gates submission on both pieces being filled. -->
                <div class="fcp-pay-confirm" data-fcp-payconfirm data-min-ref="12">
                    <label class="fc-field" style="margin-top:14px;margin-bottom:0;">
                        <span style="font-weight:600;font-size:13px;color:var(--text);">UPI Reference / Transaction ID <span style="color:var(--danger);">*</span></span>
                        <input type="text" name="${name}__upi_ref" placeholder="12-digit UPI reference number" inputmode="numeric" minlength="12" maxlength="12" pattern="\\d{12}" data-fcp-payref autocomplete="off" required>
                        <div class="fcp-payref-hint" style="font-size:12px;color:var(--text-muted, #64748b);margin-top:4px;">Enter the 12-digit reference shown by your UPI app to confirm payment.</div>
                    </label>
                    <div class="fcp-payconfirm-callout" data-fcp-confirm-callout>
                        <label class="fc-choice-item fcp-payconfirm-row" title="Enter the 12-digit UPI Reference / Transaction ID first">
                            <input type="checkbox" name="${name}__upi_confirmed" value="1" data-fcp-payconfirm-cb disabled required>
                            <span class="fc-choice-label">
                                <strong>I have completed the UPI payment</strong>
                                <span class="fcp-payconfirm-required" style="background:#dc2626;color:#fff;padding:1px 7px;border-radius:999px;font-size:10px;font-weight:700;margin-left:6px;letter-spacing:0.05em;">REQUIRED</span>
                            </span>
                        </label>
                        <div class="fcp-payconfirm-hint" style="font-size:11.5px;color:#92400e;margin-top:6px;line-height:1.4;">
                            You must enter the 12-digit reference above AND tick this confirmation to submit the form.
                        </div>
                    </div>
                </div>
            </div>`;
        }
        if (method === "bank") {
            const bank = f.bank || {};
            const rows = [
                bank.accountHolder ? ["Account Holder", bank.accountHolder, false] : null,
                bank.bankName      ? ["Bank Name",      bank.bankName,      false] : null,
                bank.accountNumber ? ["Account Number", bank.accountNumber, true ] : null,
                bank.ifsc          ? ["IFSC Code",      bank.ifsc,          true ] : null,
                bank.swift         ? ["SWIFT / BIC",    bank.swift,         true ] : null,
                bank.branch        ? ["Branch",         bank.branch,        false] : null
            ].filter(Boolean);
            if (!rows.length) {
                return `<div class="text-muted text-sm" style="padding:14px;">Bank details haven't been configured for this form yet. Edit the field in the builder.</div>`;
            }
            // v2.57 — Hide the bank-account detail table when the parent
            // Payment Method field has hidePaymentDetails. Visitors still
            // see the reference-ID + confirmation checkbox below — they
            // already have the bank details from a previous email/invoice.
            const hideBankDetails = !!f.hidePaymentDetails;
            return `<div class="fcp-pay-card">
                ${hideBankDetails ? "" : `<table class="fcp-pay-table">
                    ${rows.map(r => `
                        <tr>
                            <td>${r[0]}</td>
                            <td><strong>${safe(r[1])}</strong>
                                ${r[2] ? `<button type="button" class="fcp-copy" data-copy="${safe(r[1])}" title="Copy">${FCApp.ICONS.copy}</button>` : ""}
                            </td>
                        </tr>`).join("")}
                </table>`}
                <!-- Bank transfer proof-of-payment: reference input + REQUIRED checkbox. -->
                <div class="fcp-pay-confirm" data-fcp-payconfirm data-min-ref="6">
                    <label class="fc-field" style="margin-top:14px;margin-bottom:0;">
                        <span style="font-weight:600;font-size:13px;color:var(--text);">Transaction / Reference ID <span style="color:var(--danger);">*</span></span>
                        <input type="text" name="${name}__bank_ref" placeholder="UTR / NEFT / IMPS reference" minlength="6" data-fcp-payref autocomplete="off" required>
                        <div class="fcp-payref-hint" style="font-size:12px;color:var(--text-muted, #64748b);margin-top:4px;">Enter the bank's reference ID to confirm payment.</div>
                    </label>
                    <div class="fcp-payconfirm-callout" data-fcp-confirm-callout>
                        <label class="fc-choice-item fcp-payconfirm-row" title="Enter the Transaction / Reference ID first">
                            <input type="checkbox" name="${name}__bank_confirmed" value="1" data-fcp-payconfirm-cb disabled required>
                            <span class="fc-choice-label">
                                <strong>I confirm I have made the payment</strong>
                                <span class="fcp-payconfirm-required" style="background:#dc2626;color:#fff;padding:1px 7px;border-radius:999px;font-size:10px;font-weight:700;margin-left:6px;letter-spacing:0.05em;">REQUIRED</span>
                            </span>
                        </label>
                        <div class="fcp-payconfirm-hint" style="font-size:11.5px;color:#92400e;margin-top:6px;line-height:1.4;">
                            You must enter the reference ID above AND tick this confirmation to submit the form.
                        </div>
                    </div>
                </div>
            </div>`;
        }
        if (method === "card") {
            return `<div class="fcp-pay-card">
                <div style="display:grid;gap:8px;">
                    <input type="text" placeholder="Cardholder name" name="${name}__card_holder" autocomplete="cc-name">
                    <input type="text" placeholder="Card number" name="${name}__card_num" inputmode="numeric" maxlength="19" autocomplete="cc-number">
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
                        <input type="text" placeholder="MM/YY" name="${name}__card_exp" maxlength="5" autocomplete="cc-exp">
                        <input type="text" placeholder="CVC" name="${name}__card_cvc" maxlength="4" autocomplete="cc-csc">
                    </div>
                </div>
                <div class="form-help" style="margin-top:8px;">Card details are captured here, but actual charging requires connecting Stripe or Razorpay in Settings → Integrations.</div>
            </div>`;
        }
        if (method === "cod") {
            return `<div class="fcp-pay-card">
                <p style="margin:0;line-height:1.55;display:flex;align-items:center;gap:8px;">
                    <span style="display:inline-flex;width:22px;height:22px;color:var(--brand-500,#6366f1);">${FCApp.ICONS.cash}</span>
                    Pay in cash when your order is delivered. No upfront payment needed — just submit the form and we'll be in touch.
                </p>
            </div>`;
        }
        // Online gateways — info text; the actual checkout opens
        // client-side after the visitor clicks Submit (see form-engine.js
        // handlePaymentThenSubmit).
        const labels = {
            razorpay:    "Razorpay",
            stripe:      "Stripe",
            cashfree:    "Cashfree",
            instamojo:   "Instamojo",
            paypal:      "PayPal",
            mollie:      "Mollie",
            paystack:    "Paystack",
            mercadopago: "Mercado Pago"
        };
        return `<div class="fcp-pay-card">
            <p style="margin:0 0 6px;">You'll complete the payment with <strong>${labels[method] || method}</strong> after clicking Submit. The form is only saved once the payment is confirmed.</p>
            <div class="form-help">Make sure ${labels[method] || method} is enabled and configured in <a href="payment-gateways.html" target="_top">Payment Gateways</a>.</div>
        </div>`;
    }

    function defaultsForType(type) {
        const base = { id: FCData.uid("f"), type, label: typeLabel(type), required: false };
        switch (type) {
            case "select": case "multiselect": case "radio":
                return { ...base, options: ["Option 1", "Option 2", "Option 3"] };
            case "checkbox":
                return { ...base, options: ["Choice A", "Choice B", "Choice C"] };
            case "yesno":
                return { ...base, options: ["Yes", "No"] };
            case "range":
                return { ...base, min: 0, max: 100, step: 1, defaultValue: 50 };
            case "rating":
                return { ...base, max: 5 };
            case "country":
                return { ...base, label: "Country" };
            // v2.67 — Map defaults. lat/lng default to Delhi (India-friendly)
            // since the plugin's strongest market is Indian sites; admin
            // overrides in field settings.
            // v2.67.1 — added mapProvider + mapApiKey + mapCustomUrl so the
            // admin can swap to Google Maps / Mapbox / MapTiler / Stadia
            // without code changes.
            case "map":
                return { ...base, label: "Location",
                    mapCenterLat: 28.6139, mapCenterLng: 77.2090, mapZoom: 5,
                    mapHeight: 320, mapSearch: true, mapClickToPin: true,
                    mapProvider: "osm", mapApiKey: "", mapCustomUrl: "",
                    // v2.67.2 — Business location. When the admin fills these
                    // in, the map renders with a pre-placed pin at the business
                    // address. `mapMode` decides whether the visitor can also
                    // drop their own pin, or the map is purely "find us here".
                    mapMode: "pin_visitor",          // pin_visitor | show_business | both
                    mapBusinessLabel: "",
                    mapBusinessAddress: "",
                    mapBusinessLat: "",
                    mapBusinessLng: "" };
            case "section":
                return { id: FCData.uid("f"), type: "section", label: "Section Title", description: "Add a short description here." };
            case "divider":
                return { id: FCData.uid("f"), type: "divider" };
            case "html":
                return { id: FCData.uid("f"), type: "html", html: "<p>Add custom HTML here.</p>" };
            case "columns":
                return { id: FCData.uid("f"), type: "columns", columns: 2 };
            case "gdpr":
                return { ...base, label: "I agree to the privacy policy and terms of service.", required: true };
            case "repeater":
                return {
                    ...base,
                    label:      "Add Items",
                    minRows:    1,
                    maxRows:    10,
                    addLabel:   "+ Add another",
                    removeLabel:"Remove",
                    subFields: [
                        { id: FCData.uid("rf"), type: "text",  label: "Name",  required: true },
                        { id: FCData.uid("rf"), type: "email", label: "Email", required: false }
                    ]
                };
            case "list":
                return {
                    ...base,
                    label:       "Items",
                    placeholder: "Enter an item",
                    minRows:     1,
                    maxRows:     20,
                    addLabel:    "+ Add row"
                };
            case "video":
                return {
                    ...base,
                    label:        "Record a video",
                    pipeAccountHash: "",
                    pipeEnvCode:     "",
                    maxSeconds:      120,
                    showCountdown:   true
                };
            case "schedule":
                return {
                    ...base,
                    label:        "Pick a date & time",
                    headline:     "Schedule a call with me",
                    organizerName: "",
                    organizerRole: "Organizer",
                    organizerAvatar: "",
                    days:         [1, 2, 3, 4, 5],        // Mon-Fri (0=Sun, 6=Sat)
                    timeWindows:  [{ start: "09:00", end: "17:00" }],   // multi-window: add more for split shifts
                    // Legacy mirror — kept so anything still reading these
                    // keys gets the first window's bounds for free.
                    startTime:    "09:00",
                    endTime:      "17:00",
                    slotMinutes:  30,
                    capacity:     1,                       // max bookings per slot
                    leadHours:    24,                       // min hours in advance
                    daysAhead:    30,                       // how many days out
                    timezone:     "auto",
                    skipDates:    [],                       // optional list of YYYY-MM-DD blackout dates
                    meetingProvider: "jitsi",               // "jitsi" | "custom" | "none"
                    meetingProviderLabel: "",               // override the displayed provider name
                    meetingUrl:      "",                    // used when provider = "custom"
                    meetingTitle:    "",                    // e.g. "30-min consultation"
                    sendReminder:    true,                  // schedule 30-min reminder email
                    reminderMinutes: 30
                };
            case "likert":
                return {
                    ...base,
                    label: "How satisfied are you?",
                    scale: ["Strongly Disagree","Disagree","Neutral","Agree","Strongly Agree"],
                    statements: ["The product met my expectations", "I would recommend it to others"]
                };
            case "nps":
                return {
                    ...base,
                    label:     "How likely are you to recommend us?",
                    leftLabel: "Not likely",
                    rightLabel:"Very likely"
                };
            case "poll":
                return {
                    ...base,
                    label:    "What's your favorite?",
                    options:  ["Option A", "Option B", "Option C"],
                    showResultsAfterSubmit: true
                };
            case "product":
                return { ...base, label: "Choose a Plan", products: [
                    { name: "Starter",     price: 29 },
                    { name: "Pro",         price: 79 },
                    { name: "Enterprise",  price: 199 }
                ]};
            case "wc-products":
                return {
                    ...base,
                    label: "Choose a Product",
                    wcProducts: [],
                    wcAllowQuantity: true,
                    wcMaxQuantity: 10
                };
            case "pricing":
                return { ...base, label: "Pick your plan", tiers: [
                    { name: "Basic",    price: 9,  features: ["1 form", "100 subs/mo"] },
                    { name: "Pro",      price: 29, features: ["10 forms", "2000 subs/mo"] },
                    { name: "Business", price: 99, features: ["Unlimited forms", "All integrations"] }
                ]};
            case "payment":
                return {
                    ...base,
                    label: "Payment Method",
                    // Which payment options to show as radio choices. Each
                    // method renders a custom panel below when selected.
                    methods: ["upi", "bank", "card", "cod"],
                    amount: "",
                    currency: "INR",
                    instructions: "",
                    upi: {
                        upiId:     "",
                        payeeName: ""
                    },
                    bank: {
                        accountHolder: "",
                        accountNumber: "",
                        ifsc:          "",
                        bankName:      "",
                        branch:        "",
                        swift:         ""
                    }
                };
            case "bank":
                return {
                    ...base,
                    label: "Bank Transfer",
                    accountHolder: "",
                    accountNumber: "",
                    ifsc:          "",
                    bankName:      "",
                    branch:        "",
                    swift:         "",
                    amount:        "",
                    currency:      "INR",
                    instructions:  "Please transfer the amount to the account below and enter your transaction reference in the field at the bottom."
                };
            case "upi":
                return {
                    ...base,
                    label: "UPI Payment",
                    upiId:     "",
                    payeeName: "",
                    amount:    "",
                    currency:  "INR",
                    instructions: "Scan the QR code with any UPI app (Google Pay / PhonePe / Paytm / BHIM), pay, and enter the reference ID below."
                };
            case "calculation":
                return {
                    ...base,
                    label:    "Total",
                    formula:  "",                // generated by the visual builder
                    calcRows: [],                // visual builder row state — { id, kind, op?, a/b?, operands?, cond?, expr? }
                    decimals: 2,
                    prefix:   "",
                    suffix:   "",
                    required: false
                };
            case "otp":
                return {
                    ...base,
                    label:        "Verification Code",
                    required:     true,
                    otpChannel:   "email",   // "email" | "twilio" | "msg91"
                    otpTarget:    "",        // id of the linked phone/email field (empty = ask user)
                    otpLength:    6,
                    sendLabel:    "Send Code",
                    resendLabel:  "Resend Code",
                    help:         "We'll send a verification code to confirm it's really you."
                };
            default:
                return base;
        }
    }

    function typeLabel(type) {
        const map = {
            text: "Single Line Text", textarea: "Paragraph", email: "Email", tel: "Phone",
            number: "Number", password: "Password", url: "URL", hidden: "Hidden Field",
            select: "Dropdown", multiselect: "Multi Select", radio: "Choose One",
            checkbox: "Check All", toggle: "Toggle", rating: "Rating", yesno: "Yes or No",
            file: "File Upload", image: "Image Upload", date: "Date", time: "Time",
            datetime: "Date & Time", range: "Range", color: "Color", signature: "Signature",
            otp: "OTP", captcha: "Verify you're human",
            name: "Full Name", address: "Street Address", city: "City", state: "State",
            country: "Country", zip: "Zip / Postal Code", company: "Company", gst: "GST Number",
            product: "Product", "wc-products": "WooCommerce Product", pricing: "Plan", coupon: "Coupon Code", calculation: "Total", payment: "Payment Method",
            card: "Credit Card", section: "Section", divider: "Divider", html: "HTML",
            columns: "Columns", repeater: "Group", gdpr: "Consent",
            likert: "Survey", nps: "NPS Score", poll: "Poll", schedule: "Booking", video: "Video Recording"
        };
        return map[type] || "Field";
    }

    /**
     * Render a field's INPUT only (no label wrap).
     * mode = "preview" (read-only-feel) or "live" (real interactivity).
     */
    /**
     * Resolve dynamic placeholders inside a hidden field's default value.
     * Supported tokens:
     *   {url:utm_source} → ?utm_source= from current URL (any param name works)
     *   {referrer}       → document.referrer
     *   {page_url}       → location.href
     *   {page_title}     → document.title
     *   {user_agent}     → navigator.userAgent
     *   {date}           → today's ISO date (YYYY-MM-DD)
     *   {time}           → current time (HH:MM:SS)
     *   {datetime}       → ISO datetime
     *   {form_title}     → the current form's title (FCFormConfig.form.title)
     *   {form_id}        → the current form's id
     *   {user_login}     → logged-in WP user login (empty for guests)
     *   {user_email}     → logged-in WP user email (empty for guests)
     *   {user_id}        → logged-in WP user id (0 for guests)
     * Unrecognized placeholders are left as-is so admins can use literal text.
     */
    function resolveHiddenValue(template) {
        if (!template || typeof template !== "string") return "";
        const params = new URLSearchParams(location.search);
        const cfg    = (window.FCFormConfig || {});
        const form   = cfg.form || {};
        const wp     = cfg.user || {};
        const now    = new Date();
        const pad    = n => String(n).padStart(2, "0");
        const timeStr     = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
        const datetimeStr = now.toISOString();
        return template
            .replace(/\{url:([^}]+)\}/g, (_, k) => params.get(k) || "")
            .replace(/\{referrer\}/g,    () => document.referrer || "")
            .replace(/\{page_url\}/g,    () => location.href)
            .replace(/\{page_title\}/g,  () => document.title || "")
            .replace(/\{user_agent\}/g,  () => navigator.userAgent || "")
            .replace(/\{date\}/g,        () => now.toISOString().slice(0, 10))
            .replace(/\{time\}/g,        () => timeStr)
            .replace(/\{datetime\}/g,    () => datetimeStr)
            .replace(/\{form_title\}/g,  () => form.title || "")
            .replace(/\{form_id\}/g,     () => String(form.id || ""))
            .replace(/\{user_login\}/g,  () => wp.login || "")
            .replace(/\{user_email\}/g,  () => wp.email || "")
            .replace(/\{user_id\}/g,     () => String(wp.id || 0));
    }

    /**
     * Friendly visitor timezone string ("Calcutta (GMT+05:30)") for the
     * schedule field's timezone dropdown — extracted from Intl APIs with a
     * safe fallback.
     */
    function visitorTimezoneLabel() {
        try {
            const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
            const city = tz.split("/").pop().replace(/_/g, " ");
            const off  = new Date().getTimezoneOffset();
            const sign = off <= 0 ? "+" : "-";
            const h    = String(Math.floor(Math.abs(off) / 60)).padStart(2, "0");
            const m    = String(Math.abs(off) % 60).padStart(2, "0");
            return `${city} (GMT${sign}${h}:${m})`;
        } catch (e) { return "Local time"; }
    }

    function renderInput(f, mode) {
        const name = "fld_" + f.id;
        const ph = FCApp.escapeHtml(f.placeholder || "");
        switch (f.type) {
            case "text": case "name": case "zip": case "company": case "gst":
                return `<input type="text" name="${name}" placeholder="${ph || FCApp.escapeHtml(f.label)}">`;

            // State and City are cascading selects driven by the Country field.
            // If no Country field exists in the same form they fall back to a
            // free-text input via the hydration step below.
            case "state":
                return `<select name="${name}" data-fcp-geo="state" disabled>
                    <option value="">${ph || "-- Select country first --"}</option>
                </select>`;
            case "city":
                return `<select name="${name}" data-fcp-geo="city" disabled>
                    <option value="">${ph || "-- Select state first --"}</option>
                </select>`;
            case "textarea": case "html":
                if (f.type === "html") return f.html || "";
                return `<textarea name="${name}" placeholder="${ph}" rows="4"></textarea>`;
            case "email":    return `<input type="email" name="${name}" placeholder="${ph || "you@example.com"}">`;
            case "tel":      return `<input type="tel" name="${name}" placeholder="${ph || "+1 555 0100"}">`;
            case "url":      return `<input type="url" name="${name}" placeholder="${ph || "https://example.com"}">`;
            case "number":   return `<input type="number" name="${name}" placeholder="${ph}">`;
            case "password": return `<input type="password" name="${name}" placeholder="${ph || "••••••••"}">`;
            case "hidden":
                // In live mode emit a true hidden input pre-filled with the
                // admin-configured default + auto-resolved URL params /
                // {wpUser} placeholders. In preview / builder mode show a
                // visible disabled stub so the admin knows it exists.
                if (mode === "live") {
                    return `<input type="hidden" name="${name}" value="${FCApp.escapeHtml(resolveHiddenValue(f.defaultValue || ""))}" data-fcp-hidden>`;
                }
                return `<input type="text" value="${FCApp.escapeHtml(f.defaultValue || "")}" placeholder="(hidden field — value: ${FCApp.escapeHtml(f.defaultValue || "(none)")})" disabled style="opacity:0.6;">`;
            case "date":     return `<input type="date" name="${name}">`;
            case "time":     return `<input type="time" name="${name}">`;
            case "datetime": return `<input type="datetime-local" name="${name}">`;
            case "color":    return `<input type="color" name="${name}" value="#6366f1" style="height:42px;padding:4px;">`;
            case "address":  return `<input type="text" name="${name}" placeholder="${ph || "Start typing an address…"}" data-fcp-address autocomplete="street-address">`;

            case "select":
                return `<select name="${name}">
                    <option value="">${ph || "-- Select --"}</option>
                    ${(f.options || []).map(o => `<option>${FCApp.escapeHtml(o)}</option>`).join("")}
                </select>`;

            case "country":
                return `<select name="${name}" data-fcp-geo="country">
                    <option value="">${ph || "-- Select Country --"}</option>
                    ${FCP_COUNTRIES.map(c => `<option>${FCApp.escapeHtml(c)}</option>`).join("")}
                </select>`;

            case "multiselect":
                // Custom dropdown — closed shows selected values, opens to
                // show a checkbox list. Uses native <details> so no extra
                // open/close JS is needed; the dynamic label is updated in
                // FCFields.hydrate().
                return `<details class="fc-multiselect" data-name="${name}">
                    <summary class="fc-multiselect-trigger">
                        <span class="fc-multiselect-text" data-placeholder="${ph || 'Select options…'}">${ph || 'Select options…'}</span>
                        <span class="fc-multiselect-arrow">▾</span>
                    </summary>
                    <div class="fc-multiselect-options">
                        ${(f.options || []).map(o =>
                            `<label class="fc-choice-item">
                                <input type="checkbox" name="${name}[]" value="${FCApp.escapeHtml(o)}">
                                <span class="fc-choice-label">${FCApp.escapeHtml(o)}</span>
                            </label>`).join("")}
                    </div>
                </details>`;

            case "radio":
            case "yesno":
                return `<div class="fc-choice-list">${(f.options || []).map(o =>
                    `<label class="fc-choice-item">
                        <input type="radio" name="${name}" value="${FCApp.escapeHtml(o)}">
                        <span class="fc-choice-label">${FCApp.escapeHtml(o)}</span>
                    </label>`).join("")}</div>`;

            case "checkbox":
                return `<div class="fc-choice-list">${(f.options || []).map(o =>
                    `<label class="fc-choice-item">
                        <input type="checkbox" name="${name}[]" value="${FCApp.escapeHtml(o)}">
                        <span class="fc-choice-label">${FCApp.escapeHtml(o)}</span>
                    </label>`).join("")}</div>`;

            case "toggle":
                // Visible switch + hidden text input so the engine reads a
                // clear "Yes" / "No" instead of "" / "on". The hidden input
                // is what carries the field name; the checkbox is just UI.
                return `<label class="switch" data-fcp-toggle>
                    <input type="checkbox" data-fcp-toggle-checkbox><span class="slider"></span>
                    <input type="hidden" name="${name}" value="No" data-fcp-toggle-value>
                </label>`;

            case "rating":
                // Hidden input mirrors the dataset.value so the engine + draft
                // restore + native form submission all see the picked rating.
                return `<div class="fc-rating" data-field="${f.id}" data-value="0">
                    ${Array.from({ length: f.max || 5 }).map((_, i) => `<span class="star" data-val="${i + 1}">★</span>`).join("")}
                    <input type="hidden" name="${name}" value="" data-fcp-rating-value>
                </div>`;

            case "range": {
                // Coerce explicitly so 0 doesn't get replaced by the fallbacks.
                const rMin  = Number.isFinite(parseFloat(f.min))  ? parseFloat(f.min)  : 0;
                const rMax  = Number.isFinite(parseFloat(f.max))  ? parseFloat(f.max)  : 100;
                const rStep = Number.isFinite(parseFloat(f.step)) && parseFloat(f.step) > 0 ? parseFloat(f.step) : 1;
                const rDef  = Number.isFinite(parseFloat(f.defaultValue)) ? parseFloat(f.defaultValue) : Math.round((rMin + rMax) / 2);
                const rPre  = FCApp.escapeHtml(f.rangePrefix || "");
                const rSuf  = FCApp.escapeHtml(f.rangeSuffix || "");
                return `<div data-fcp-range>
                    <div style="display:flex;align-items:center;gap:14px;">
                        <span class="text-muted text-sm" style="min-width:30px;text-align:right;">${rMin}</span>
                        <input type="range" name="${name}" min="${rMin}" max="${rMax}" step="${rStep}" value="${rDef}" style="flex:1;" data-fcp-range-input>
                        <span class="text-muted text-sm" style="min-width:30px;">${rMax}</span>
                    </div>
                    <div class="text-muted text-sm mt-2" style="text-align:center;">
                        <span class="fw-700" style="color:var(--brand-500);font-size:16px;">${rPre}<span data-fcp-range-value>${rDef}</span>${rSuf}</span>
                    </div>
                </div>`;
            }

            case "file":
            case "image": {
                // Modern file/image upload card with EXPLICIT colors so it
                // renders identically on every WP theme (light or dark).
                // Hosts often override --text / --bg variables, which made
                // the field text invisible — pinning hex values fixes it.
                const isImage = f.type === "image";
                const icon = isImage
                    ? `<svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <rect x="6" y="10" width="48" height="40" rx="5" stroke="#6366f1" stroke-width="3" fill="rgba(99,102,241,0.08)"/>
                        <circle cx="20" cy="24" r="4" fill="#6366f1"/>
                        <path d="M12 42l13-13 9 9 7-7 11 11" stroke="#6366f1" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
                        <circle cx="50" cy="48" r="10" fill="#6366f1"/>
                        <path d="M50 43v10M45 48h10" stroke="#fff" stroke-width="3" stroke-linecap="round"/>
                    </svg>`
                    : `<svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path d="M18 8h22l12 12v32a4 4 0 0 1-4 4H18a4 4 0 0 1-4-4V12a4 4 0 0 1 4-4z" stroke="#6366f1" stroke-width="3" fill="rgba(99,102,241,0.08)"/>
                        <path d="M40 8v12h12" stroke="#6366f1" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
                        <circle cx="50" cy="50" r="10" fill="#6366f1"/>
                        <path d="M50 45v10M45 50h10" stroke="#fff" stroke-width="3" stroke-linecap="round"/>
                    </svg>`;
                return `<div class="fcp-file-field" data-fcp-file ${isImage ? 'data-image="1"' : ""} style="color:#0f172a;">
                    <div class="fcp-file-shell" style="background:#f5f6ff;border-radius:14px;padding:20px;border:1px solid #e0e3ff;">
                        <div class="fcp-file-drop" data-fcp-file-drop style="border:2px dashed #a5b4fc;padding:38px 24px;border-radius:12px;text-align:center;cursor:pointer;transition:all .15s;background:#ffffff;">
                            <div style="margin-bottom:14px;display:flex;justify-content:center;">${icon}</div>
                            <div style="font-weight:700;color:#0f172a;margin-bottom:6px;font-size:16px;">Drag and Drop ${isImage ? "your image" : "your file"}</div>
                            <div style="font-size:13px;color:#64748b;margin-bottom:14px;">or click below to browse</div>
                            <button type="button" class="btn btn-primary" style="padding:11px 28px;font-weight:600;font-size:14px;background:#6366f1;color:#fff;border:none;border-radius:8px;cursor:pointer;box-shadow:0 2px 8px rgba(99,102,241,0.25);" data-fcp-file-pick>Choose File</button>
                            <div style="margin-top:14px;font-size:12px;color:#94a3b8;">${isImage ? "JPG, PNG, GIF, WebP" : "PDF, DOC, XLS, PPT, ZIP, TXT, JPG, PNG"} · max 10&nbsp;MB</div>
                            <input type="file" ${isImage ? 'accept="image/*"' : ""} style="display:none;" data-fcp-file-input>
                        </div>
                    </div>
                    <div class="fcp-file-status" data-fcp-file-status style="display:none;margin-top:10px;"></div>
                    <input type="hidden" name="${name}" data-fcp-file-url value="">
                </div>`;
            }

            // v2.67 — Map / Location picker (Leaflet + OpenStreetMap).
            // Renders an interactive map (~320px tall by default).
            // The hidden input carries a JSON payload with { address, lat, lng }
            // so submission storage gets all three. form-engine.js boots the
            // Leaflet runtime + wires search + click-to-pin + drag-to-move.
            case "map": {
                const h     = parseInt(f.mapHeight, 10) || 320;
                const lat   = parseFloat(f.mapCenterLat) || 28.6139;
                const lng   = parseFloat(f.mapCenterLng) || 77.2090;
                const zoom  = parseInt(f.mapZoom, 10) || 5;
                const allowSearch = f.mapSearch !== false;
                // v2.67.1 — Carry provider config as data-* attributes so
                // form-engine reads it without re-fetching field state.
                // v2.67.2 — Also carry business-location config (mode,
                // address, lat/lng, label) so the engine can place a
                // pre-set pin when the admin's filled it in.
                const provider  = f.mapProvider  || "osm";
                const apiKey    = f.mapApiKey    || "";
                const customUrl = f.mapCustomUrl || "";
                const mode      = f.mapMode || "pin_visitor";
                const bizAddr   = f.mapBusinessAddress || "";
                const bizLat    = f.mapBusinessLat || "";
                const bizLng    = f.mapBusinessLng || "";
                const bizLabel  = f.mapBusinessLabel || "";
                const showBiz   = (mode === "show_business" || mode === "both") && bizLat && bizLng;
                const visitorPicks = mode === "pin_visitor" || mode === "both";
                // When business mode is set + we have coords, center the
                // map on the business by default so the admin doesn't have
                // to also remember to update Initial latitude/longitude.
                const finalLat  = showBiz ? parseFloat(bizLat) : lat;
                const finalLng  = showBiz ? parseFloat(bizLng) : lng;
                const finalZoom = showBiz ? Math.max(zoom, 14)  : zoom;
                // Search box + click-to-pin only make sense when the visitor
                // is allowed to pick. In "show_business" mode they're off.
                const showSearch = allowSearch && visitorPicks;
                return `<div class="fcp-map-field" data-fcp-map="${FCApp.escapeHtml(f.id)}"
                            data-init-lat="${finalLat}" data-init-lng="${finalLng}" data-init-zoom="${finalZoom}"
                            data-allow-click="${(f.mapClickToPin !== false && visitorPicks) ? '1' : '0'}"
                            data-provider="${FCApp.escapeHtml(provider)}"
                            data-api-key="${FCApp.escapeHtml(apiKey)}"
                            data-custom-url="${FCApp.escapeHtml(customUrl)}"
                            data-mode="${FCApp.escapeHtml(mode)}"
                            data-biz-lat="${FCApp.escapeHtml(bizLat)}"
                            data-biz-lng="${FCApp.escapeHtml(bizLng)}"
                            data-biz-label="${FCApp.escapeHtml(bizLabel)}"
                            data-biz-address="${FCApp.escapeHtml(bizAddr)}">
                    ${showBiz ? `<div class="fcp-map-biz-card">
                        <div class="fcp-map-biz-icon">🏢</div>
                        <div class="fcp-map-biz-body">
                            <div class="fcp-map-biz-label">${FCApp.escapeHtml(bizLabel || "Our location")}</div>
                            ${bizAddr ? `<div class="fcp-map-biz-addr">${FCApp.escapeHtml(bizAddr)}</div>` : ""}
                        </div>
                        <a href="https://www.openstreetmap.org/?mlat=${bizLat}&mlon=${bizLng}#map=16/${bizLat}/${bizLng}" target="_blank" rel="noopener" class="fcp-map-biz-link">↗ Directions</a>
                    </div>` : ""}
                    ${showSearch ? `<div class="fcp-map-search">
                        <input type="text" class="form-control" placeholder="Search an address or place…" data-fcp-map-search autocomplete="off">
                        <button type="button" class="btn btn-outline btn-sm" data-fcp-map-locate title="Use my current location">📍</button>
                    </div>` : ""}
                    <div class="fcp-map-canvas" data-fcp-map-canvas style="height:${h}px;border-radius:10px;overflow:hidden;background:#e2e8f0;"></div>
                    ${visitorPicks ? `<div class="fcp-map-readout" data-fcp-map-readout style="margin-top:8px;font-size:12px;color:var(--text-muted);min-height:18px;">
                        Click on the map or search above to drop a pin.
                    </div>` : ""}
                    <input type="hidden" name="${name}" data-fcp-map-value value="">
                </div>`;
            }

            case "signature":
                return `<canvas class="signature-pad" data-field="${f.id}"></canvas>
                        <div class="flex gap-2 mt-2"><button type="button" class="btn btn-outline btn-sm" onclick="clearSignature(this)">Clear</button></div>`;

            case "otp": {
                const otpLen     = Math.max(4, Math.min(8, parseInt(f.otpLength, 10) || 6));
                const otpChannel = f.otpChannel || "email";
                const sendLabel  = FCApp.escapeHtml(f.sendLabel || "Send Code");
                const channelLbl = otpChannel === "twilio" ? "phone number"
                                 : otpChannel === "msg91"  ? "mobile number"
                                 : "email address";
                const targetCfg  = f.otpTarget || "";
                return `<div class="fcp-otp" data-fcp-otp data-channel="${otpChannel}" data-target-fid="${FCApp.escapeHtml(targetCfg)}" data-otp-length="${otpLen}">
                    ${targetCfg ? "" : `
                        <div class="form-group" style="margin-bottom:10px;">
                            <input type="${otpChannel === "email" ? "email" : "tel"}" class="form-control" data-fcp-otp-target
                                placeholder="Enter your ${channelLbl}"
                                autocomplete="${otpChannel === "email" ? "email" : "tel"}">
                        </div>`}
                    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                        <div style="display:flex;gap:6px;" data-fcp-otp-boxes>
                            ${Array.from({ length: otpLen }, () =>
                                `<input type="text" inputmode="numeric" maxlength="1" class="form-control" autocomplete="one-time-code"
                                    style="text-align:center;width:42px;font-size:18px;font-weight:700;padding:8px 0;">`
                            ).join("")}
                        </div>
                        <button type="button" class="btn btn-primary" data-fcp-otp-send>${sendLabel}</button>
                    </div>
                    <div class="form-help" data-fcp-otp-status style="margin-top:8px;min-height:18px;"></div>
                    <input type="hidden" name="${name}" value="" data-fcp-otp-value>
                </div>`;
            }

            case "captcha": {
                // In LIVE mode, render the real CAPTCHA widget for the
                // configured provider. reCAPTCHA v2 → visible checkbox,
                // v3 → invisible (token populated by form-engine before
                // submit). hCaptcha + Turnstile → visible widget, ship
                // tokens via fcp_recaptcha_token (shared field name).
                const rc = (window.FCFormConfig && FCFormConfig.recaptcha) || {};
                const provider = rc.provider || "recaptcha";
                if (mode === "live" && rc.enabled && rc.site_key) {
                    if (provider === "hcaptcha") {
                        return `<div class="fcp-hcaptcha">
                            <div class="h-captcha" data-sitekey="${FCApp.escapeHtml(rc.site_key)}" data-fcp-hcaptcha></div>
                            <input type="hidden" name="fcp_recaptcha_token" value="">
                        </div>`;
                    }
                    if (provider === "turnstile") {
                        return `<div class="fcp-turnstile">
                            <div class="cf-turnstile" data-sitekey="${FCApp.escapeHtml(rc.site_key)}" data-fcp-turnstile></div>
                            <input type="hidden" name="fcp_recaptcha_token" value="">
                        </div>`;
                    }
                    if (rc.version === "v2") {
                        return `<div class="fcp-captcha-v2">
                            <div class="g-recaptcha" data-sitekey="${FCApp.escapeHtml(rc.site_key)}" data-fcp-captcha></div>
                            <input type="hidden" name="fcp_recaptcha_token" value="">
                        </div>`;
                    }
                    // v3 — invisible. form-engine will call grecaptcha.execute() before submit.
                    return `<div class="fcp-captcha-v3" data-fcp-captcha-v3 data-sitekey="${FCApp.escapeHtml(rc.site_key)}" style="border:1px solid var(--border);background:var(--bg-soft);padding:10px 14px;border-radius:10px;display:flex;align-items:center;gap:10px;font-size:13px;color:var(--text-muted);">
                        <span style="width:24px;height:24px;display:grid;place-items:center;background:#4285f4;color:#fff;border-radius:6px;font-weight:700;">✓</span>
                        <span>Protected by reCAPTCHA v3 (invisible).</span>
                        <input type="hidden" name="fcp_recaptcha_token" value="">
                    </div>`;
                }
                // Live mode but no key — explain to admin without giving bots a free pass.
                if (mode === "live") {
                    return `<div style="border:1px solid #fbbf24;background:#fffbeb;color:#92400e;padding:10px 14px;border-radius:10px;font-size:13px;">
                        ⚠ reCAPTCHA not configured. Visit <strong>Integrations → Google reCAPTCHA</strong> and add your site key, then enable it under Form Settings.
                    </div>
                    <input type="hidden" name="fcp_recaptcha_token" value="">`;
                }
                // Preview mode (form builder canvas) — mock visual only.
                return `<div style="border:1px solid var(--border);background:var(--bg-soft);padding:14px;border-radius:10px;display:flex;align-items:center;gap:10px;max-width:320px;">
                    <input type="checkbox" disabled style="width:24px;height:24px;">
                    <span style="font-weight:600;">I'm not a robot</span>
                    <div style="margin-left:auto;font-size:11px;color:var(--text-soft);text-align:right;">reCAPTCHA<br>Privacy · Terms</div>
                </div>
                <div class="form-help" style="margin-top:6px;">Renders the real Google widget on the live form when reCAPTCHA is configured.</div>`;
            }

            case "product": {
                const prods = Array.isArray(f.products) ? f.products : [];
                if (!prods.length) {
                    return `<div style="border:1px dashed var(--border);padding:14px;border-radius:10px;color:var(--text-soft);line-height:1.55;">
                        <strong>No products configured.</strong>
                        ${mode === "live" ? "" : `<div class="form-help" style="margin-top:6px;">Open this field's settings → "Products" and add some.</div>`}
                    </div>`;
                }
                return `<div class="fc-choice-list" data-fcp-priced="product">
                    ${prods.map((p, i) => `
                        <label class="fc-choice-item" data-fcp-price="${p.price || 0}">
                            <input type="radio" name="${name}" value="${FCApp.escapeHtml(p.name)}" data-price="${p.price || 0}" ${i === 0 ? "checked" : ""}>
                            <span class="fc-choice-label">${FCApp.escapeHtml(p.name)}</span>
                            <span class="fw-700" style="margin-left:auto;">${p.price ? "$" + p.price : ""}</span>
                        </label>`).join("")}
                </div>`;
            }

            case "wc-products": {
                const products = Array.isArray(f.wcProducts) ? f.wcProducts : [];
                if (!products.length) {
                    return `<div style="border:1px dashed var(--border);padding:14px;border-radius:10px;color:var(--text-soft);line-height:1.55;">
                        <strong>No WooCommerce products selected.</strong>
                        ${mode === "live" ? "" : `<div class="form-help" style="margin-top:6px;">Open this field's settings → "Pick WooCommerce products" to add some.</div>`}
                    </div>`;
                }
                const currency = products[0].currency || "USD";
                const symbol   = ({ USD: "$", EUR: "€", GBP: "£", INR: "₹", AUD: "A$", CAD: "C$" })[currency] || (currency + " ");
                const allowQty = f.wcAllowQuantity !== false;
                const maxQty   = parseInt(f.wcMaxQuantity, 10) || 10;
                return `<div class="fcp-wc-field" data-fcp-priced="wc-products" data-fcp-currency="${FCApp.escapeHtml(currency)}">
                    <div class="fc-choice-list">
                        ${products.map((p, i) => {
                            const hasVars = Array.isArray(p.variations) && p.variations.length > 0;
                            const price   = hasVars ? p.variations[0].price : (p.price || 0);
                            const outOfStock = p.stock === "outofstock";
                            return `
                            <label class="fc-choice-item ${outOfStock ? "is-disabled" : ""}" data-fcp-price="${price}" style="${outOfStock ? "opacity:.5;cursor:not-allowed;" : ""}">
                                <input type="radio" name="${name}" value="${p.id}" data-price="${price}" data-has-variations="${hasVars ? 1 : 0}" data-product-id="${p.id}" ${i === 0 && !outOfStock ? "checked" : ""} ${outOfStock ? "disabled" : ""}>
                                ${p.image ? `<img src="${FCApp.escapeHtml(p.image)}" alt="" style="width:48px;height:48px;border-radius:6px;object-fit:cover;margin-right:8px;">` : ""}
                                <span class="fc-choice-label" style="display:flex;flex-direction:column;gap:2px;flex:1;">
                                    <span class="fw-700">${FCApp.escapeHtml(p.name)}</span>
                                    ${p.sku ? `<span class="text-muted text-sm">SKU: ${FCApp.escapeHtml(p.sku)}</span>` : ""}
                                    ${outOfStock ? `<span class="badge badge-danger" style="align-self:flex-start;margin-top:4px;">Out of stock</span>` : ""}
                                </span>
                                <span class="fw-700" style="margin-left:auto;">${symbol}${price}</span>
                            </label>`;
                        }).join("")}
                    </div>
                    ${products.some(p => Array.isArray(p.variations) && p.variations.length) ? `
                        <div class="fcp-wc-variations" data-fcp-wc-variations style="margin-top:10px;${mode === "live" ? "" : "display:none;"}">
                            <label class="form-label text-sm">Variation</label>
                            <select class="form-control" name="${name} Variation" data-fcp-wc-variation>
                                <option value="">Select…</option>
                            </select>
                        </div>` : ""}
                    ${allowQty ? `
                        <div style="margin-top:10px;display:flex;align-items:center;gap:10px;">
                            <label class="form-label text-sm" style="margin:0;">Quantity</label>
                            <input type="number" class="form-control" name="${name} Quantity" value="1" min="1" max="${maxQty}" data-fcp-wc-qty style="max-width:100px;text-align:center;">
                        </div>` : ""}
                </div>`;
            }


            case "pricing": {
                // Currency comes from f.currency (which auto-currency may
                // have already rewritten before render). Falls back to $.
                // ALL colors explicit (no var()) so the card is readable on
                // every host theme — dark sites used to wash these out.
                const sym = FCApp.currencySymbol(f.currency || "USD");
                return `<div class="grid grid-cols-3" style="gap:10px;color:#0f172a;" data-fcp-priced="pricing" data-fcp-currency="${FCApp.escapeHtml(f.currency || 'USD')}">
                    ${(f.tiers || []).map(t =>
                        `<label style="border:1px solid #e2e8f0;background:#ffffff;padding:18px 14px;border-radius:12px;cursor:pointer;text-align:center;display:block;transition:border-color .15s,box-shadow .15s;" data-fcp-price="${t.price || 0}">
                            <div style="font-weight:700;color:#0f172a;font-size:15px;margin-bottom:6px;">${FCApp.escapeHtml(t.name || "")}</div>
                            <div style="font-size:24px;font-weight:800;color:#0f172a;">${t.price ? FCApp.escapeHtml(sym) + t.price : ""}<span style="color:#64748b;font-size:13px;font-weight:500;">${t.price ? "/mo" : ""}</span></div>
                            <div style="color:#64748b;font-size:13px;margin-top:8px;line-height:1.5;">${(t.features || []).map(FCApp.escapeHtml).join("<br>")}</div>
                            <input type="radio" name="${name}" value="${FCApp.escapeHtml(t.name || "")}" data-price="${t.price || 0}" style="width:18px;height:18px;margin-top:12px;accent-color:#6366f1;">
                        </label>`).join("")}
                </div>`;
            }

            case "coupon":
                // In preview mode (form builder) the Apply button just toasts.
                // In live mode (form-engine) it calls FCBridge.validateCoupon
                // and updates the displayed total of Product/Pricing/Payment.
                if (mode === "live") {
                    const applyLabel = FCApp.escapeHtml(f.applyLabel || "Apply");
                    return `<div class="fcp-coupon" data-fcp-coupon data-field="${f.id}">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="${ph || 'Enter coupon code'}" name="${name}" style="text-transform:uppercase;">
                            <button type="button" class="btn btn-primary" data-fcp-coupon-apply>${applyLabel}</button>
                        </div>
                        <input type="hidden" name="fcp_applied_coupon" value="">
                        <div class="fcp-coupon-status" style="margin-top:8px;font-size:13px;"></div>
                    </div>`;
                }
                return `<div class="input-group">
                    <input type="text" class="form-control" placeholder="${ph || 'Enter coupon code'}" name="${name}">
                    <button type="button" class="btn btn-primary" onclick="FCApp.toast('Live coupon validation only works on the public form.','info')">Apply</button>
                </div>`;

            case "repeater": {
                // Repeater: a group of sub-fields the visitor can clone +
                // remove. The visible HTML contains a row TEMPLATE plus N
                // initial rows (one per minRows, default 1). Each row gets
                // a sequential index; form-engine reads rows on submit and
                // emits an array of objects under the field label.
                const minRows = Math.max(1, parseInt(f.minRows, 10) || 1);
                const maxRows = Math.max(minRows, parseInt(f.maxRows, 10) || 10);
                const subs    = Array.isArray(f.subFields) ? f.subFields : [];
                const renderSubRow = (rowIdx) => `
                    <div class="fcp-rep-row" data-fcp-rep-row data-row-idx="${rowIdx}" style="border:1px solid var(--border);border-radius:10px;padding:14px;background:var(--bg-elev);margin-bottom:10px;position:relative;">
                        <div style="position:absolute;top:10px;right:10px;display:flex;gap:6px;align-items:center;">
                            <span class="text-muted text-sm" data-fcp-rep-num>#${rowIdx + 1}</span>
                            <button type="button" class="btn btn-outline btn-sm" data-fcp-rep-remove style="padding:2px 8px;font-size:11px;">${FCApp.escapeHtml(f.removeLabel || "Remove")}</button>
                        </div>
                        <div class="fcp-rep-fields" style="display:grid;gap:10px;margin-right:80px;">
                            ${subs.map(sf => {
                                const subLabel = FCApp.escapeHtml(sf.label || "");
                                const subReq   = sf.required ? '<span style="color:var(--danger);">*</span>' : "";
                                const baseAttr = `data-sub-id="${sf.id}" data-sub-label="${subLabel}"`;
                                let input;
                                if (sf.type === "textarea") {
                                    input = `<textarea class="form-control" rows="2" ${baseAttr} placeholder="${FCApp.escapeHtml(sf.placeholder || "")}"></textarea>`;
                                } else if (sf.type === "select" && Array.isArray(sf.options)) {
                                    input = `<select class="form-control" ${baseAttr}>
                                        <option value="">${FCApp.escapeHtml(sf.placeholder || "Select…")}</option>
                                        ${sf.options.map(o => `<option value="${FCApp.escapeHtml(o)}">${FCApp.escapeHtml(o)}</option>`).join("")}
                                    </select>`;
                                } else if (sf.type === "checkbox") {
                                    input = `<label class="fc-choice-item" style="padding:6px 10px;">
                                        <input type="checkbox" ${baseAttr} value="1">
                                        <span class="fc-choice-label">${FCApp.escapeHtml(sf.placeholder || sf.label || "")}</span>
                                    </label>`;
                                } else {
                                    const t = ["text","email","tel","number","url","date"].includes(sf.type) ? sf.type : "text";
                                    input = `<input type="${t}" class="form-control" ${baseAttr} placeholder="${FCApp.escapeHtml(sf.placeholder || "")}">`;
                                }
                                return sf.type === "checkbox"
                                    ? input
                                    : `<label class="fc-sub-field"><span style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">${subLabel} ${subReq}</span>${input}</label>`;
                            }).join("")}
                        </div>
                    </div>`;
                const initial = [];
                for (let i = 0; i < minRows; i++) initial.push(renderSubRow(i));
                return `<div class="fcp-rep" data-fcp-repeater data-min="${minRows}" data-max="${maxRows}">
                    <div class="fcp-rep-rows" data-fcp-rep-rows>
                        ${initial.join("")}
                    </div>
                    <button type="button" class="btn btn-outline btn-sm" data-fcp-rep-add style="margin-top:4px;">${FCApp.escapeHtml(f.addLabel || "+ Add another")}</button>
                    <template data-fcp-rep-template>${renderSubRow(0)}</template>
                </div>`;
            }

            case "likert": {
                // Likert scale: a matrix of statements (rows) × scale (cols).
                // Each row records a value 1..N where N = scale.length.
                const scale = Array.isArray(f.scale) ? f.scale : [];
                const stmts = Array.isArray(f.statements) ? f.statements : [];
                if (!scale.length || !stmts.length) {
                    return `<div class="form-help">Likert needs at least one statement + one scale step. Edit the field settings.</div>`;
                }
                return `<div class="fcp-likert" data-fcp-likert>
                    <table style="width:100%;border-collapse:collapse;font-size:13px;">
                        <thead><tr>
                            <th style="text-align:left;padding:8px;color:var(--text-muted);"></th>
                            ${scale.map(s => `<th style="text-align:center;padding:8px;color:var(--text-muted);font-weight:600;">${FCApp.escapeHtml(s)}</th>`).join("")}
                        </tr></thead>
                        <tbody>
                            ${stmts.map((stmt, i) => `<tr>
                                <td style="padding:10px 8px;font-weight:600;">${FCApp.escapeHtml(stmt)}</td>
                                ${scale.map((s, j) => `<td style="text-align:center;padding:10px 8px;"><input type="radio" name="${name}__${i}" value="${j + 1}" data-likert-stmt="${FCApp.escapeHtml(stmt)}" data-likert-label="${FCApp.escapeHtml(s)}" style="width:18px;height:18px;cursor:pointer;"></td>`).join("")}
                            </tr>`).join("")}
                        </tbody>
                    </table>
                </div>`;
            }

            case "nps": {
                // NPS: 0-10 scale, server auto-categorizes 0-6 Detractor /
                // 7-8 Passive / 9-10 Promoter for analytics.
                return `<div class="fcp-nps" data-fcp-nps>
                    <div style="display:flex;gap:4px;flex-wrap:wrap;">
                        ${Array.from({ length: 11 }, (_, i) => i).map(n => `
                            <label style="flex:1;min-width:38px;text-align:center;cursor:pointer;">
                                <input type="radio" name="${name}" value="${n}" style="position:absolute;opacity:0;pointer-events:none;">
                                <span class="fcp-nps-btn" style="display:block;padding:10px 4px;border:1px solid var(--border);border-radius:8px;background:var(--bg-elev);font-weight:700;transition:.15s;">${n}</span>
                            </label>`).join("")}
                    </div>
                    <div style="display:flex;justify-content:space-between;margin-top:6px;font-size:12px;color:var(--text-muted);">
                        <span>${FCApp.escapeHtml(f.leftLabel || "Not likely")}</span>
                        <span>${FCApp.escapeHtml(f.rightLabel || "Very likely")}</span>
                    </div>
                </div>`;
            }

            case "poll": {
                const opts = Array.isArray(f.options) ? f.options : [];
                return `<div class="fcp-poll" data-fcp-poll data-field-id="${f.id}" data-show-results="${f.showResultsAfterSubmit ? "1" : "0"}">
                    <div class="fc-choice-list">
                        ${opts.map(o => `
                            <label class="fc-choice-item">
                                <input type="radio" name="${name}" value="${FCApp.escapeHtml(o)}">
                                <span class="fc-choice-label">${FCApp.escapeHtml(o)}</span>
                            </label>`).join("")}
                    </div>
                </div>`;
            }

            case "schedule": {
                // Calendly-style booking widget — organizer card on the left,
                // month calendar in the middle, time-slot pills on the right.
                // All real interactivity lives in hydrate() below.
                // Multi-window support: timeWindows is an array of {start,end}.
                // Falls back to a single window built from the legacy
                // startTime / endTime fields so old forms keep working.
                const timeWindows = Array.isArray(f.timeWindows) && f.timeWindows.length
                    ? f.timeWindows.filter(w => w && w.start && w.end)
                    : [{ start: f.startTime || "09:00", end: f.endTime || "17:00" }];
                const cfgJson  = FCApp.escapeHtml(JSON.stringify({
                    days:        Array.isArray(f.days) ? f.days : [1,2,3,4,5],
                    timeWindows: timeWindows,
                    // Kept for any consumer still reading the legacy keys
                    startTime:   timeWindows[0]?.start || "09:00",
                    endTime:     timeWindows[timeWindows.length - 1]?.end || "17:00",
                    slotMinutes: parseInt(f.slotMinutes, 10) || 30,
                    capacity:    parseInt(f.capacity,    10) || 1,
                    leadHours:   parseInt(f.leadHours,   10) || 24,
                    daysAhead:   parseInt(f.daysAhead,   10) || 30,
                    skipDates:   Array.isArray(f.skipDates) ? f.skipDates : []
                }));
                const headline = FCApp.escapeHtml(f.headline || "Schedule a call with me");
                const orgName  = FCApp.escapeHtml(f.organizerName || "");
                const orgRole  = FCApp.escapeHtml(f.organizerRole || "Organizer");
                const orgAv    = f.organizerAvatar || "";
                const initials = orgName ? orgName.trim().split(/\s+/).map(p => p[0]).join("").slice(0,2).toUpperCase() : "?";
                const dur      = (parseInt(f.slotMinutes, 10) || 30) + " minutes";
                const providerLabels = { jitsi: "Jitsi Meet", custom: "Online meeting", none: "In-person / phone" };
                const provider = FCApp.escapeHtml(f.meetingProviderLabel || providerLabels[f.meetingProvider || "jitsi"]);
                return `<div class="fcp-cal" data-fcp-schedule data-cfg="${cfgJson}">
                    <div class="fcp-cal-left">
                        ${orgName || headline ? `<div class="fcp-cal-title">${headline}</div>` : ""}
                        ${orgName ? `<div class="fcp-cal-org">
                            ${orgAv ? `<img src="${FCApp.escapeHtml(orgAv)}" alt="" class="fcp-cal-avatar">` : `<div class="fcp-cal-avatar fcp-cal-avatar-initials">${initials}</div>`}
                            <div><div class="fcp-cal-org-name">${orgName}</div><div class="fcp-cal-org-role">${orgRole}</div></div>
                        </div>` : ""}
                        <div class="fcp-cal-meta">
                            <span class="fcp-cal-meta-icon" style="display:inline-flex;width:16px;height:16px;">${FCApp.ICONS.calendar}</span><span>${dur}</span>
                        </div>
                        ${f.meetingProvider !== "none" ? `<div class="fcp-cal-meta">
                            <span class="fcp-cal-meta-icon" style="display:inline-flex;width:16px;height:16px;">${FCApp.ICONS.videoCam}</span><span>${provider}</span>
                        </div>` : ""}
                        <select class="form-control fcp-cal-tz" data-fcp-cal-tz>
                            <option value="auto">${FCApp.escapeHtml(visitorTimezoneLabel())}</option>
                        </select>
                    </div>
                    <div class="fcp-cal-divider"></div>
                    <div class="fcp-cal-center">
                        <div class="fcp-cal-month-head">
                            <div class="fcp-cal-month-label" data-fcp-cal-month></div>
                            <div class="fcp-cal-nav">
                                <button type="button" class="fcp-cal-nav-btn" data-fcp-cal-prev aria-label="Previous month">‹</button>
                                <button type="button" class="fcp-cal-nav-btn" data-fcp-cal-next aria-label="Next month">›</button>
                            </div>
                        </div>
                        <div class="fcp-cal-weekdays">
                            ${["SU","MO","TU","WE","TH","FR","SA"].map(d => `<div>${d}</div>`).join("")}
                        </div>
                        <div class="fcp-cal-grid" data-fcp-cal-grid></div>
                    </div>
                    <div class="fcp-cal-right" data-fcp-cal-right>
                        <div class="fcp-cal-right-date" data-fcp-cal-right-date>Pick a date</div>
                        <div class="fcp-cal-slots" data-fcp-cal-slots></div>
                        <div class="fcp-cal-status" data-fcp-cal-status></div>
                    </div>
                    <input type="hidden" name="${name}" value="" data-fcp-schedule-value>
                </div>`;
            }

            case "video": {
                // Pipe Video Recording (addpipe.com). Pipe loads a recorder
                // into a div; on stop it fires onVideoUploadSuccess and we
                // grab the playable URL into our hidden input.
                const acc = FCApp.escapeHtml(f.pipeAccountHash || "");
                const env = FCApp.escapeHtml(f.pipeEnvCode     || "");
                const max = parseInt(f.maxSeconds, 10) || 120;
                if (!acc) {
                    return `<div style="border:1px dashed var(--border);padding:14px;border-radius:10px;color:var(--text-soft);line-height:1.55;">
                        <strong>Pipe not configured.</strong>
                        ${mode === "live" ? "" : `<div class="form-help" style="margin-top:6px;">Open this field's settings → add your Pipe Account Hash + Environment Code. Sign up free at <a href="https://addpipe.com/" target="_blank">addpipe.com</a>.</div>`}
                    </div>`;
                }
                return `<div class="fcp-video" data-fcp-video data-pipe-account="${acc}" data-pipe-env="${env}" data-pipe-max="${max}">
                    <div id="pipe-${f.id}" style="background:#0f172a;border-radius:10px;overflow:hidden;min-height:240px;display:grid;place-items:center;color:#94a3b8;">
                        ${mode === "live" ? "Loading recorder…" : "Pipe recorder mounts here on the live form"}
                    </div>
                    <div class="form-help" data-fcp-video-status style="margin-top:6px;min-height:18px;"></div>
                    <input type="hidden" name="${name}" value="" data-fcp-video-url>
                </div>`;
            }

            case "list": {
                // Simpler than repeater: one text input per row, visitor adds /
                // removes rows. Stored as a flat array of strings keyed by the
                // field label. Useful for "list each topic", "your skills", etc.
                const min = Math.max(1, parseInt(f.minRows, 10) || 1);
                const max = Math.max(min, parseInt(f.maxRows, 10) || 20);
                const ph  = FCApp.escapeHtml(f.placeholder || "");
                const rowHtml = (i) => `
                    <div class="fcp-list-row" data-fcp-list-row style="display:flex;gap:8px;align-items:center;margin-bottom:6px;">
                        <span class="text-muted text-sm" style="width:28px;text-align:right;" data-fcp-list-num>${i + 1}.</span>
                        <input type="text" class="form-control" data-fcp-list-input placeholder="${ph}" style="flex:1;">
                        <button type="button" class="btn btn-outline btn-sm" data-fcp-list-remove style="padding:2px 10px;">✕</button>
                    </div>`;
                const initial = [];
                for (let i = 0; i < min; i++) initial.push(rowHtml(i));
                return `<div class="fcp-list" data-fcp-list data-min="${min}" data-max="${max}">
                    <div class="fcp-list-rows" data-fcp-list-rows>${initial.join("")}</div>
                    <button type="button" class="btn btn-outline btn-sm" data-fcp-list-add style="margin-top:4px;">${FCApp.escapeHtml(f.addLabel || "+ Add row")}</button>
                    <template data-fcp-list-template>${rowHtml(0)}</template>
                </div>`;
            }

            case "calculation": {
                // Two-faced render:
                //   • mode === "live"   → big result card the visitor sees
                //   • mode === "builder"→ canvas preview matching the new
                //     Calculation Builder aesthetic (green formula pill +
                //     live result, no more "0.00 — No formula set" placeholder)
                const decimals = Number.isFinite(parseInt(f.decimals, 10)) ? parseInt(f.decimals, 10) : 2;
                const prefix   = (f.prefix || "").trim();
                const suffix   = (f.suffix || "").trim();
                const formula  = f.formula || "";
                const zero     = (0).toFixed(decimals);
                const display  = prefix + " " + zero + (suffix ? " " + suffix : "");

                // -- LIVE visitor view: minimal result card --
                if (mode === "live") {
                    return `<div data-fcp-calc
                                  data-formula="${FCApp.escapeHtml(formula)}"
                                  data-decimals="${decimals}"
                                  data-prefix="${FCApp.escapeHtml(prefix)}"
                                  data-suffix="${FCApp.escapeHtml(suffix)}"
                                  style="background:#f5f6ff;border:1px solid #e0e3ff;border-radius:12px;padding:18px 20px;">
                        <div style="display:flex;align-items:baseline;gap:10px;flex-wrap:wrap;">
                            ${prefix ? `<span style="display:inline-flex;align-items:center;justify-content:center;background:#6366f1;color:#fff;padding:6px 14px;border-radius:8px;font-weight:700;font-size:16px;min-width:36px;" data-fcp-calc-prefix>${FCApp.escapeHtml(prefix)}</span>` : ""}
                            <span style="font-size:28px;font-weight:800;color:#6366f1;letter-spacing:-0.02em;line-height:1.1;" data-fcp-calc-value>${zero}</span>
                            ${suffix ? `<span style="display:inline-flex;align-items:center;justify-content:center;background:#6366f1;color:#fff;padding:6px 14px;border-radius:8px;font-weight:700;font-size:14px;" data-fcp-calc-suffix>${FCApp.escapeHtml(suffix)}</span>` : ""}
                        </div>
                        <input type="hidden" name="${name}" class="fcp-calc-display"
                               value="${FCApp.escapeHtml(display)}"
                               data-fcp-raw-value="0">
                    </div>`;
                }

                // -- BUILDER canvas view: matches Calculation Builder aesthetic --
                // Compute a pretty "Price × Quantity + Tax − Discount = Output" line
                // straight from the row model when available; fall back to the
                // brace-stripped formula string otherwise.
                let prettyLine = "";
                let outputName = "";
                if (Array.isArray(f.calcRows) && f.calcRows.length && "output" in f.calcRows[0]) {
                    // Resolve chained outputs into a single readable expression.
                    const opMap = { "*": "×", "/": "÷", "-": "−", "+": "+", "%": "%" };
                    const outputs = {};
                    let last = null;
                    f.calcRows.forEach((row, idx) => {
                        const resolve = (n) => {
                            if (!n) return "?";
                            const t = String(n).trim();
                            if (outputs[t] !== undefined) return outputs[t];
                            if (/^-?\d+(\.\d+)?$/.test(t)) return t;
                            return t;
                        };
                        const a = resolve(row.a);
                        const b = resolve(row.b);
                        const op = opMap[row.op] || "+";
                        const expr = a + " " + op + " " + b;
                        const out = (row.output || "").trim() || ("Result " + (idx + 1));
                        outputs[out] = "(" + expr + ")";
                        last = { expr, out };
                    });
                    if (last) {
                        prettyLine = last.expr;
                        outputName = last.out;
                    }
                } else if (formula) {
                    prettyLine = formula
                        .replace(/\*/g, "×")
                        .replace(/\//g, "÷")
                        .replace(/(?<![\w])-(?![\d])/g, "−")
                        .replace(/\{([^}]+)\}/g, "$1");
                    outputName = f.label || "Result";
                }

                const hasContent = !!prettyLine;
                return `<div data-fcp-calc
                              data-formula="${FCApp.escapeHtml(formula)}"
                              data-decimals="${decimals}"
                              data-prefix="${FCApp.escapeHtml(prefix)}"
                              data-suffix="${FCApp.escapeHtml(suffix)}"
                              style="background:#ffffff;border:1px solid #e2e8f0;border-radius:12px;padding:14px 16px;">
                    <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-bottom:${hasContent ? "10px" : "0"};">
                        <div style="display:flex;align-items:center;gap:8px;">
                            <span style="display:inline-grid;place-items:center;width:28px;height:28px;border-radius:8px;background:linear-gradient(135deg,#eef2ff,#faf5ff);color:#4338ca;font-size:14px;">🧮</span>
                            <span style="font-weight:700;font-size:13px;color:#0f172a;">Calculation</span>
                        </div>
                        <span style="font-size:11px;color:#64748b;background:#f1f5f9;padding:3px 8px;border-radius:999px;">Click to edit</span>
                    </div>
                    ${hasContent
                        ? `<div style="padding:10px 12px;background:#f0fdf4;border:1px solid #86efac;border-radius:8px;font-family:var(--mono);font-size:12.5px;font-weight:700;color:#166534;line-height:1.5;word-break:break-word;">
                              ${FCApp.escapeHtml(prettyLine)} <span style="color:#16a34a;">=</span> ${FCApp.escapeHtml(outputName)}
                          </div>
                          <div style="margin-top:8px;display:flex;align-items:center;justify-content:space-between;gap:8px;">
                              <span style="font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:0.04em;font-weight:700;">Live result</span>
                              <span style="font-family:var(--mono);font-size:14px;font-weight:800;color:#4338ca;" data-fcp-calc-value>${(prefix ? prefix + " " : "") + zero + (suffix ? " " + suffix : "")}</span>
                          </div>`
                        : `<div style="padding:14px;background:#f8fafc;border:1px dashed #cbd5e1;border-radius:8px;color:#64748b;font-size:12.5px;line-height:1.5;text-align:center;">
                              <strong style="color:#0f172a;">No calculation yet.</strong><br>
                              Click this field to open the builder and add your first row.
                          </div>`}
                    <input type="hidden" name="${name}" class="fcp-calc-display"
                           value="${FCApp.escapeHtml(display)}"
                           data-fcp-raw-value="0">
                </div>`;
            }

            case "payment": {
                // Badges removed — the live form shows only the clean method
                // label. Map kept for the .filter(m => METHODS[m]) check.
                const METHODS = {
                    upi:         { label: "UPI Payment"         },
                    bank:        { label: "Bank Transfer"       },
                    card:        { label: "Credit / Debit Card" },
                    cod:         { label: "Cash on Delivery"    },
                    razorpay:    { label: "Razorpay"            },
                    stripe:      { label: "Stripe Checkout"     },
                    cashfree:    { label: "Cashfree"            },
                    instamojo:   { label: "Instamojo"           },
                    paypal:      { label: "PayPal"              },
                    mollie:      { label: "Mollie"              },
                    paystack:    { label: "Paystack"            },
                    mercadopago: { label: "Mercado Pago"        }
                };
                const enabled = (f.methods && f.methods.length ? f.methods : ["upi","bank","card","cod"])
                    .filter(m => METHODS[m]);
                if (!enabled.length) {
                    return `<div class="text-muted text-sm" style="padding:14px;border:1px dashed var(--border);border-radius:8px;">No payment methods enabled — choose at least one in the field settings.</div>`;
                }
                return `<div class="fcp-payment-field" data-fcp-payment data-fcp-priced="payment" data-fcp-base="${FCApp.escapeHtml(f.amount || 0)}" data-fcp-currency="${FCApp.escapeHtml(f.currency || 'INR')}" data-fcp-source-id="${FCApp.escapeHtml(f.priceSource || '')}" data-fcp-multiplier="${FCApp.escapeHtml(f.priceMultiplier ?? 1)}">
                    <div class="fcp-pay-summary" ${f.amount ? "" : 'style="display:none;"'}><span>Amount due</span><strong data-fcp-pay-total>${FCApp.escapeHtml(f.currency || 'INR')} ${FCApp.escapeHtml(f.amount || '')}</strong></div>
                    ${f.instructions ? `<div class="fcp-pay-instructions" style="margin-bottom:12px;">${FCApp.escapeHtml(f.instructions)}</div>` : ""}
                    <div class="fc-choice-list">
                        ${enabled.map((m, i) => `
                            <label class="fc-choice-item">
                                <input type="radio" name="${name}" value="${m}" ${i === 0 ? 'checked' : ''}>
                                <span class="fc-choice-label">${METHODS[m].label}</span>
                            </label>`).join("")}
                    </div>
                    <div class="fcp-method-panels">
                        ${enabled.map((m, i) => `
                            <div class="fcp-method-panel" data-method="${m}" ${i === 0 ? '' : 'hidden'}>
                                ${renderPaymentMethodPanel(m, f, name)}
                            </div>`).join("")}
                    </div>
                </div>`;
            }

            case "card":
                // Deprecated — capturing raw card numbers requires PCI-DSS
                // compliance which the plugin doesn't provide. The field
                // is left in place so older forms still render, but it
                // shows a security notice instead of accepting card data.
                // Use the Payment Method field with a real gateway
                // (Stripe / Razorpay / Cashfree) for actual card payments.
                return `<div style="border:1px solid #fecaca;background:#fef2f2;color:#7f1d1d;padding:14px 16px;border-radius:10px;line-height:1.55;">
                    <div style="font-weight:700;margin-bottom:6px;">⚠ Card field deprecated</div>
                    <div style="font-size:13px;">
                        This field used to collect raw credit-card numbers, which violates PCI-DSS rules for any site that isn't a certified payment processor.
                        Delete it from the form and use the <strong>Payment Method</strong> field with <strong>Stripe</strong> / <strong>Razorpay</strong> / <strong>Cashfree</strong> instead — those tokenise the card inside the gateway, never touching your server.
                    </div>
                </div>`;

            case "bank": {
                const rows = [
                    f.accountHolder ? ["Account Holder", f.accountHolder] : null,
                    f.bankName      ? ["Bank Name",      f.bankName]      : null,
                    f.accountNumber ? ["Account Number", f.accountNumber, true] : null,
                    f.ifsc          ? ["IFSC Code",      f.ifsc, true]    : null,
                    f.swift         ? ["SWIFT / BIC",    f.swift, true]   : null,
                    f.branch        ? ["Branch",         f.branch]        : null,
                ].filter(Boolean);
                const empty = rows.length === 0;
                return `<div class="fcp-pay-card" data-fcp-priced="bank" data-fcp-base="${FCApp.escapeHtml(f.amount || 0)}" data-fcp-currency="${FCApp.escapeHtml(f.currency || '')}" data-fcp-source-id="${FCApp.escapeHtml(f.priceSource || '')}" data-fcp-multiplier="${FCApp.escapeHtml(f.priceMultiplier ?? 1)}">
                    <div class="fcp-pay-head">
                        <div class="fcp-pay-title">${FCApp.ICONS.credit}<span>Bank Transfer</span></div>
                        ${f.amount ? `<div class="fcp-pay-amount" data-fcp-pay-total>${FCApp.escapeHtml(f.currency || "")} ${FCApp.escapeHtml(f.amount)}</div>` : `<div class="fcp-pay-amount" data-fcp-pay-total style="display:none;"></div>`}
                    </div>
                    ${empty
                        ? `<div class="text-muted text-sm" style="padding:16px 0;">No bank details configured yet — set them in the field settings panel.</div>`
                        : (f.hidePaymentDetails
                            ? `<div class="text-muted text-sm" style="padding:14px 0;">Bank details have been sent to you separately. Enter your reference ID below to confirm the transfer.</div>`
                            : `<table class="fcp-pay-table">${rows.map(r => `
                                <tr>
                                    <td>${r[0]}</td>
                                    <td><strong>${FCApp.escapeHtml(r[1])}</strong>
                                        ${r[2] ? `<button type="button" class="fcp-copy" data-copy="${FCApp.escapeHtml(r[1])}" title="Copy">${FCApp.ICONS.copy}</button>` : ""}
                                    </td>
                                </tr>`).join("")}
                            </table>`)}
                    ${f.instructions ? `<div class="fcp-pay-instructions">${FCApp.escapeHtml(f.instructions)}</div>` : ""}
                    <div class="fcp-pay-confirm" data-fcp-payconfirm data-min-ref="6">
                        <label class="fc-field" style="margin:0;">
                            <span style="font-weight:600;font-size:13px;color:var(--text);">Transaction / Reference ID <span style="color:var(--danger);">*</span></span>
                            <input type="text" name="${name}_txn" placeholder="e.g. UTR / NEFT / IMPS reference" data-fcp-payref minlength="6" autocomplete="off" required>
                            <div class="fcp-payref-hint" style="font-size:12px;color:var(--text-muted, #64748b);margin-top:4px;">Enter the reference ID first to confirm payment.</div>
                        </label>
                        <div class="fcp-payconfirm-callout" data-fcp-confirm-callout>
                            <label class="fc-choice-item fcp-payconfirm-row" title="Enter the Transaction / Reference ID first">
                                <input type="checkbox" name="${name}_confirmed" value="1" data-fcp-payconfirm-cb disabled required>
                                <span class="fc-choice-label">
                                    <strong>I confirm I have made the payment</strong>
                                    <span class="fcp-payconfirm-required" style="background:#dc2626;color:#fff;padding:1px 7px;border-radius:999px;font-size:10px;font-weight:700;margin-left:6px;letter-spacing:0.05em;">REQUIRED</span>
                                </span>
                            </label>
                            <div class="fcp-payconfirm-hint" style="font-size:11.5px;color:#92400e;margin-top:6px;line-height:1.4;">
                                You must enter the reference ID above AND tick this confirmation to submit the form.
                            </div>
                        </div>
                    </div>
                </div>`;
            }

            case "upi": {
                // Build the standard UPI deep-link and a QR code for it.
                const params = [];
                if (f.upiId)     params.push("pa=" + encodeURIComponent(f.upiId));
                if (f.payeeName) params.push("pn=" + encodeURIComponent(f.payeeName));
                if (f.amount)    params.push("am=" + encodeURIComponent(f.amount));
                params.push("cu=" + encodeURIComponent(f.currency || "INR"));
                const upiUrl = "upi://pay?" + params.join("&");
                const qrSrc = f.upiId
                    ? "https://api.qrserver.com/v1/create-qr-code/?size=200x200&margin=4&data=" + encodeURIComponent(upiUrl)
                    : "";
                return `<div class="fcp-pay-card" data-fcp-priced="upi" data-fcp-base="${FCApp.escapeHtml(f.amount || 0)}" data-fcp-currency="${FCApp.escapeHtml(f.currency || 'INR')}" data-fcp-source-id="${FCApp.escapeHtml(f.priceSource || '')}" data-fcp-multiplier="${FCApp.escapeHtml(f.priceMultiplier ?? 1)}" data-fcp-upi-id="${FCApp.escapeHtml(f.upiId || '')}" data-fcp-payee="${FCApp.escapeHtml(f.payeeName || '')}">
                    <div class="fcp-pay-head">
                        <div class="fcp-pay-title">${FCApp.ICONS.credit}<span>UPI Payment</span></div>
                        ${f.amount ? `<div class="fcp-pay-amount" data-fcp-pay-total>${FCApp.escapeHtml(f.currency || "INR")} ${FCApp.escapeHtml(f.amount)}</div>` : `<div class="fcp-pay-amount" data-fcp-pay-total style="display:none;"></div>`}
                    </div>
                    ${f.upiId
                        ? `<div class="fcp-upi-row${f.hidePaymentDetails ? " fcp-upi-row-qr-only" : ""}">
                            <div class="fcp-upi-qr-wrap">
                                <img src="${qrSrc}" alt="UPI QR" class="fcp-upi-qr" loading="lazy" data-fcp-qr>
                                <a href="${FCApp.escapeHtml(upiUrl)}" class="fcp-upi-link" data-fcp-upi-link>Open in UPI app →</a>
                            </div>
                            ${f.hidePaymentDetails ? "" : `
                            <div class="fcp-upi-info">
                                <div class="text-muted text-sm" style="margin-bottom:4px;">UPI ID</div>
                                <div class="fcp-upi-id">
                                    <code>${FCApp.escapeHtml(f.upiId)}</code>
                                    <button type="button" class="fcp-copy" data-copy="${FCApp.escapeHtml(f.upiId)}" title="Copy">${FCApp.ICONS.copy}</button>
                                </div>
                                ${f.payeeName ? `<div class="text-muted text-sm mt-2">Payee: <strong>${FCApp.escapeHtml(f.payeeName)}</strong></div>` : ""}
                                <p class="text-sm" style="margin-top:8px;line-height:1.5;">Scan the QR with Google Pay, PhonePe, Paytm, BHIM or any UPI-compatible app — or tap "Open in UPI app" on mobile.</p>
                            </div>`}
                        </div>`
                        : `<div class="text-muted text-sm" style="padding:16px 0;">No UPI ID configured yet — set it in the field settings panel.</div>`}
                    ${f.instructions ? `<div class="fcp-pay-instructions">${FCApp.escapeHtml(f.instructions)}</div>` : ""}
                    <div class="fcp-pay-confirm" data-fcp-payconfirm data-min-ref="12">
                        <label class="fc-field" style="margin:0;">
                            <span style="font-weight:600;font-size:13px;color:var(--text);">UPI Reference / Transaction ID <span style="color:var(--danger);">*</span></span>
                            <input type="text" name="${name}_txn" placeholder="12-digit UPI reference number" inputmode="numeric" minlength="12" maxlength="12" pattern="\\d{12}" data-fcp-payref autocomplete="off" required>
                            <div class="fcp-payref-hint" style="font-size:12px;color:var(--text-muted, #64748b);margin-top:4px;">Enter the 12-digit reference shown by your UPI app to confirm payment.</div>
                        </label>
                        <!-- Yellow confirmation callout — replaces the easy-to-miss
                             faded checkbox row. Stays prominent in BOTH disabled
                             and enabled states so the visitor sees a clear
                             "still required" gate before they can submit. -->
                        <div class="fcp-payconfirm-callout" data-fcp-confirm-callout>
                            <label class="fc-choice-item fcp-payconfirm-row" title="Enter the 12-digit UPI Reference / Transaction ID first">
                                <input type="checkbox" name="${name}_confirmed" value="1" data-fcp-payconfirm-cb disabled required>
                                <span class="fc-choice-label">
                                    <strong>I have completed the UPI payment</strong>
                                    <span class="fcp-payconfirm-required" style="background:#dc2626;color:#fff;padding:1px 7px;border-radius:999px;font-size:10px;font-weight:700;margin-left:6px;letter-spacing:0.05em;">REQUIRED</span>
                                </span>
                            </label>
                            <div class="fcp-payconfirm-hint" style="font-size:11.5px;color:#92400e;margin-top:6px;line-height:1.4;">
                                You must enter the 12-digit reference above AND tick this confirmation to submit the form.
                            </div>
                        </div>
                    </div>
                </div>`;
            }

            case "section":
                return `<div style="border-top:1px solid var(--border-soft);padding-top:14px;margin-bottom:-4px;"><div class="fw-700" style="font-size:16px;">${FCApp.escapeHtml(f.label)}</div><div class="text-muted text-sm">${FCApp.escapeHtml(f.description || "")}</div></div>`;
            case "divider":
                return `<hr style="border:none;border-top:1px solid var(--border);margin:0;">`;
            case "columns":
                // Columns is a layout-only placeholder; it doesn't store any
                // submitted value. The live form just renders an empty grid
                // (the surrounding step already lays fields out in CSS grid).
                // In preview / builder mode we show the dashed-border outline
                // so the admin can see where the field is.
                if (mode === "live") return "";
                return `<div class="grid" style="grid-template-columns:repeat(${f.columns || 2},1fr);gap:10px;">
                    ${Array.from({ length: f.columns || 2 }).map((_, i) => `<div style="border:1px dashed var(--border);padding:16px;border-radius:8px;color:var(--text-soft);text-align:center;">Column ${i + 1}</div>`).join("")}
                </div>
                <div class="form-help" style="margin-top:6px;">Layout-only placeholder. Drop fields above to arrange them in this many columns visually.</div>`;
            case "gdpr":
                // The required="" attribute browser-enforces the checkbox, and
                // the form-engine validator also checks it explicitly so the
                // visitor can't bypass it even with JS validation disabled.
                return `<label style="display:flex;gap:8px;align-items:flex-start;cursor:pointer;">
                    <input type="checkbox" name="${name}" value="agreed" ${f.required ? 'required' : ''} data-fcp-gdpr>
                    <span>${FCApp.escapeHtml(f.label)} ${f.required ? '<span style="color:var(--danger);">*</span>' : ''}</span>
                </label>`;
            default:
                return `<input type="text" name="${name}" placeholder="${ph || "(unsupported field type)"}" disabled>`;
        }
    }

    function renderField(f, mode) {
        if (f.type === "section" || f.type === "divider" || f.type === "html") {
            return `<div class="fc-field" data-fid="${f.id}" data-type="${f.type}">${renderInput(f, mode)}</div>`;
        }
        // Admin-defined custom class + id, both sanitized into safe attrs.
        const safeCls  = (f.cssClass || "").replace(/[^\w\s-]/g, "").trim();
        const safeId   = (f.customId || "").replace(/[^\w-]/g, "").trim();
        const wrapCls  = "fc-field" + (safeCls ? " " + safeCls : "");
        const wrapId   = safeId ? ` id="${safeId}"` : "";

        if (f.type === "hidden") {
            // Wrap inside .fc-field so saveCurrentStepData picks it up. In
            // live mode the wrapper is display:none so the visitor never
            // sees it. In preview / builder mode we show a labelled stub so
            // the admin knows it's there + what value it'll submit.
            if (mode === "live") {
                return `<div class="${wrapCls}"${wrapId} data-fid="${f.id}" data-type="hidden" style="display:none;">${renderInput(f, mode)}</div>`;
            }
            return `<div class="${wrapCls}"${wrapId} data-fid="${f.id}" data-type="hidden">
                <label>${FCApp.escapeHtml(f.label)} <span class="text-muted text-sm" style="font-weight:400;">(hidden — submitted, not shown to visitor)</span></label>
                ${renderInput(f, mode)}
                ${f.help ? `<div class="form-help">${FCApp.escapeHtml(f.help)}</div>` : ""}
            </div>`;
        }
        return `<div class="${wrapCls}"${wrapId} data-fid="${f.id}" data-type="${f.type}">
            <label for="fld_${f.id}">${FCApp.escapeHtml(f.label)}${f.required ? ' <span style="color:var(--danger)">*</span>' : ""}</label>
            ${renderInput(f, mode)}
            ${f.help ? `<div class="form-help">${FCApp.escapeHtml(f.help)}</div>` : ""}
        </div>`;
    }

    // Initialize interactive bits (rating stars, signature pad)
    function hydrate(scope) {
        scope = scope || document;

        // Payment confirmation gate: every .fcp-pay-confirm wrapper has a
        // reference-id input AND a "I have made the payment" checkbox. The
        // checkbox stays disabled until the reference id is the right length
        // (12 chars for UPI, 6 for bank transfer). For UPI we also require
        // pure digits via the pattern attribute. Prevents visitors from
        // ticking "paid" without actually entering proof of payment.
        scope.querySelectorAll("[data-fcp-payconfirm]").forEach(wrap => {
            const ref     = wrap.querySelector("[data-fcp-payref]");
            const cb      = wrap.querySelector("[data-fcp-payconfirm-cb]");
            const row     = wrap.querySelector(".fcp-payconfirm-row");
            const hint    = wrap.querySelector(".fcp-payref-hint");
            const callout = wrap.querySelector("[data-fcp-confirm-callout]");
            if (!ref || !cb || !row) return;
            const minLen = parseInt(wrap.dataset.minRef || "6", 10);
            const wantDigits = !!ref.pattern; // pattern="\d{12}" → digits-only
            function refresh() {
                const v = (ref.value || "").trim();
                const refOk = v.length >= minLen && (!wantDigits || /^\d+$/.test(v));
                cb.disabled = !refOk;
                row.style.cursor = refOk ? "pointer" : "not-allowed";
                row.title        = refOk ? "" : (wantDigits
                    ? "Enter the " + minLen + "-digit reference number first"
                    : "Enter the Transaction / Reference ID first");
                if (!refOk) cb.checked = false;
                if (hint) hint.style.color = refOk ? "var(--success, #10b981)" : "var(--text-muted, #64748b)";
                // Three callout states make required-ness unmissable:
                //   waiting   — ref empty: yellow warning, "enter ref first"
                //   ready     — ref OK, cb unchecked: amber, "tick to submit"
                //   confirmed — cb checked: green, ready to submit
                if (callout) {
                    callout.classList.toggle("is-waiting",   !refOk);
                    callout.classList.toggle("is-ready",      refOk && !cb.checked);
                    callout.classList.toggle("is-confirmed",  refOk &&  cb.checked);
                }
            }
            ref.addEventListener("input",  refresh);
            ref.addEventListener("change", refresh);
            cb.addEventListener("change",  refresh);
            refresh();
        });

        // Stars
        scope.querySelectorAll(".fc-rating").forEach(rt => {
            const hidden = rt.querySelector("[data-fcp-rating-value]");
            rt.querySelectorAll(".star").forEach(s => {
                s.addEventListener("click", () => {
                    const v = parseInt(s.dataset.val, 10);
                    rt.querySelectorAll(".star").forEach((x, i) => x.classList.toggle("active", (i + 1) <= v));
                    rt.dataset.value = v;
                    if (hidden) {
                        hidden.value = String(v);
                        hidden.dispatchEvent(new Event("change", { bubbles: true }));
                    }
                });
            });
        });
        // Signature pad
        scope.querySelectorAll(".signature-pad").forEach(c => {
            const ctx = c.getContext("2d");
            const rect = () => c.getBoundingClientRect();
            // ensure correct internal size
            c.width = c.offsetWidth; c.height = c.offsetHeight;
            ctx.lineWidth = 2; ctx.strokeStyle = "#0f172a"; ctx.lineCap = "round";
            let drawing = false;
            const down = e => {
                const r = rect();
                drawing = true;
                ctx.beginPath();
                ctx.moveTo((e.touches ? e.touches[0].clientX : e.clientX) - r.left, (e.touches ? e.touches[0].clientY : e.clientY) - r.top);
                // Mark that the user has actually drawn something — form-engine
                // checks this flag before exporting the canvas as a data URL.
                c.dataset.fcpHasDrawing = "1";
                e.preventDefault();
            };
            const move = e => {
                if (!drawing) return;
                const r = rect();
                ctx.lineTo((e.touches ? e.touches[0].clientX : e.clientX) - r.left, (e.touches ? e.touches[0].clientY : e.clientY) - r.top);
                ctx.stroke();
                e.preventDefault();
            };
            const up = () => drawing = false;
            c.addEventListener("mousedown", down); c.addEventListener("mousemove", move);
            window.addEventListener("mouseup", up);
            c.addEventListener("touchstart", down); c.addEventListener("touchmove", move);
            c.addEventListener("touchend", up);
        });
        // -------- File / Image upload --------
        // Real upload flow: file picked → POST multipart to /upload-file →
        // server validates ext + size + stashes under wp-content/uploads/
        // formcraft-pro/, returns the URL, we save it on the hidden input so
        // form-engine sends it with the submission.
        scope.querySelectorAll("[data-fcp-file]").forEach(field => {
            const drop   = field.querySelector("[data-fcp-file-drop]");
            const input  = field.querySelector("[data-fcp-file-input]");
            const status = field.querySelector("[data-fcp-file-status]");
            const hidden = field.querySelector("[data-fcp-file-url]");
            // v2.68.2 — Also toggle the outer .fcp-file-shell so the empty
            // purple pill wrapper doesn't linger below the uploaded-file card.
            const shell  = field.querySelector(".fcp-file-shell");
            if (!drop || !input || !status || !hidden) return;

            function resetUI() {
                status.innerHTML = "";
                status.style.display = "none";
                drop.style.display = "";
                if (shell) shell.style.display = "";
                hidden.value = "";
                input.value = "";
            }
            function setStatusHtml(html) {
                status.innerHTML = html;
                status.style.display = "";
                drop.style.display = "none";
                if (shell) shell.style.display = "none";
            }
            function wireRemove() {
                const b = status.querySelector("[data-fcp-file-remove]");
                if (b) b.addEventListener("click", resetUI);
            }
            function wireRetry() {
                const b = status.querySelector("[data-fcp-file-retry]");
                if (b) b.addEventListener("click", resetUI);
            }

            drop.addEventListener("click", e => {
                // Any click inside the drop zone (including the "Choose File"
                // button and the icon SVG) opens the native file picker.
                if (e.target !== input) input.click();
            });
            drop.addEventListener("dragover", e => {
                e.preventDefault();
                drop.style.borderColor = "var(--brand-500)";
                drop.style.background  = "rgba(99,102,241,0.10)";
                drop.style.transform   = "scale(1.01)";
            });
            const dragOff = () => {
                drop.style.borderColor = "";
                drop.style.background  = "";
                drop.style.transform   = "";
            };
            drop.addEventListener("dragleave", dragOff);
            drop.addEventListener("drop", e => {
                e.preventDefault();
                dragOff();
                if (e.dataTransfer && e.dataTransfer.files.length) {
                    uploadFile(e.dataTransfer.files[0]);
                }
            });
            input.addEventListener("change", () => {
                if (input.files && input.files.length) uploadFile(input.files[0]);
            });

            function uploadFile(file) {
                const restBase  = (window.FCFormConfig && FCFormConfig.rest)
                              || (window.FCBridge && FCBridge.ctx && FCBridge.ctx.restBase)
                              || "";
                const restNonce = (window.FCFormConfig && FCFormConfig.nonce)
                              || (window.FCBridge && FCBridge.ctx && FCBridge.ctx.restNonce)
                              || "";
                if (!restBase) {
                    setStatusHtml(`<div class="text-sm" style="color:var(--danger);">File uploads only work when the form is published in WordPress.</div>`);
                    return;
                }
                setStatusHtml(`<div style="display:flex;align-items:center;gap:10px;padding:10px;border:1px solid var(--border);background:var(--bg-soft);border-radius:8px;">
                    <span class="spinner" style="width:16px;height:16px;border:2px solid var(--border);border-top-color:var(--brand-500);border-radius:50%;display:inline-block;animation:spin 0.6s linear infinite;"></span>
                    <div style="flex:1;">Uploading <strong>${FCApp.escapeHtml(file.name)}</strong>…</div>
                </div>`);

                const fd = new FormData();
                fd.append("file", file);
                fetch(restBase.replace(/\/$/, "") + "/upload-file", {
                    method: "POST",
                    credentials: "same-origin",
                    headers: { "X-WP-Nonce": restNonce },
                    body: fd
                }).then(r => r.json().then(j => ({ ok: r.ok, body: j })))
                  .then(({ ok, body }) => {
                    if (!ok || !body || body.code) {
                        const msg = (body && (body.message || body.code)) || "Upload failed.";
                        setStatusHtml(`<div style="display:flex;align-items:center;gap:10px;padding:10px;border:1px solid var(--danger);background:rgba(239,68,68,0.06);border-radius:8px;color:var(--danger);">
                            <span style="font-size:18px;">⚠</span>
                            <div style="flex:1;">${FCApp.escapeHtml(msg)}</div>
                            <button type="button" class="btn btn-outline btn-sm" data-fcp-file-retry>Try again</button>
                        </div>`);
                        wireRetry();
                        return;
                    }
                    hidden.value = body.url;
                    const sizeKB = (body.size / 1024).toFixed(1);
                    const isImg  = body.type && body.type.indexOf("image/") === 0;
                    const thumb  = isImg
                        ? `<img src="${FCApp.escapeHtml(body.url)}" alt="" style="width:42px;height:42px;border-radius:6px;object-fit:cover;border:1px solid var(--border);">`
                        : `<span style="font-size:24px;">📄</span>`;
                    setStatusHtml(`<div style="display:flex;align-items:center;gap:10px;padding:10px;border:1px solid var(--border);background:var(--bg-soft);border-radius:8px;">
                        ${thumb}
                        <div style="flex:1;min-width:0;">
                            <div class="fw-700" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${FCApp.escapeHtml(body.name)}</div>
                            <div class="text-muted text-sm">${sizeKB} KB · uploaded ✓</div>
                        </div>
                        <button type="button" class="btn btn-outline btn-sm" data-fcp-file-remove>Remove</button>
                    </div>`);
                    wireRemove();
                }).catch(err => {
                    setStatusHtml(`<div style="color:var(--danger);padding:10px;">Upload failed: ${FCApp.escapeHtml(err.message || "network error")} <button type="button" class="btn btn-outline btn-sm" data-fcp-file-retry>Try again</button></div>`);
                    wireRetry();
                });
            }
        });
        // Click-to-copy buttons inside payment cards (bank / UPI).
        scope.querySelectorAll(".fcp-copy[data-copy]").forEach(btn => {
            btn.addEventListener("click", e => {
                e.preventDefault();
                const txt = btn.dataset.copy || "";
                if (FCApp && FCApp.copyToClipboard) {
                    FCApp.copyToClipboard(txt, "Copied: " + txt);
                } else {
                    try { navigator.clipboard.writeText(txt); } catch (e) {}
                }
            });
        });

        // -------- Helper: update a Payment / UPI / Bank field's display --------
        // Used by BOTH the dynamic-pricing source-watcher AND the coupon Apply
        // handler. Writes dataset.fcpBase = amount so form-engine sends the
        // right number to the gateway, updates the visible total, and (for
        // UPI) rebuilds the QR + deep-link so the visitor scans the
        // post-discount amount.
        function setPaymentDisplayAmount(payField, amount) {
            if (!payField) return;
            const cur       = payField.dataset.fcpCurrency || "INR";
            const totalEl   = payField.querySelector("[data-fcp-pay-total]");
            const summaryEl = payField.querySelector(".fcp-pay-summary");
            payField.dataset.fcpBase = String(amount);
            if (totalEl) {
                if (amount > 0) {
                    totalEl.textContent = cur + " " + amount.toFixed(2);
                    totalEl.style.display = "";
                    if (summaryEl) summaryEl.style.display = "";
                } else {
                    totalEl.textContent = "";
                    totalEl.style.display = "none";
                    if (summaryEl) summaryEl.style.display = "none";
                }
            }
            // UPI-only: rebuild the QR code + upi://pay link with the new amount.
            const qrImg  = payField.querySelector("[data-fcp-qr]");
            const qrLink = payField.querySelector("[data-fcp-upi-link]");
            const upiId  = payField.dataset.fcpUpiId || "";
            const payee  = payField.dataset.fcpPayee || "";
            if (qrImg && upiId) {
                const params = [
                    "pa=" + encodeURIComponent(upiId),
                    payee ? "pn=" + encodeURIComponent(payee) : "",
                    amount > 0 ? "am=" + encodeURIComponent(amount.toFixed(2)) : "",
                    "cu=" + encodeURIComponent(cur)
                ].filter(Boolean);
                const url = "upi://pay?" + params.join("&");
                qrImg.src = "https://api.qrserver.com/v1/create-qr-code/?size=200x200&margin=4&data=" + encodeURIComponent(url);
                if (qrLink) qrLink.href = url;
            }
        }

        // -------- Dynamic payment pricing --------
        // For each Payment / UPI / Bank field that has data-fcp-source-id set,
        // watch the matching source field (Product or Pricing Table) and
        // recompute the displayed amount + UPI QR whenever the selection
        // changes. Multiplier lets admins convert currencies (e.g. USD → INR).
        scope.querySelectorAll("[data-fcp-source-id]").forEach(payField => {
            const sourceId  = payField.dataset.fcpSourceId;
            if (!sourceId) return;
            const sourceWrap = scope.querySelector(`.fc-field[data-fid="${sourceId}"]`);
            if (!sourceWrap) return;

            const multiplier = parseFloat(payField.dataset.fcpMultiplier || 1) || 1;

            function readSourcePrice() {
                // Calculation field source — read its raw computed value.
                const calc = sourceWrap.querySelector("[data-fcp-calc] input");
                if (calc) return parseFloat(calc.dataset.fcpRawValue || 0) || 0;
                // WooCommerce Products source — unit price × quantity.
                const wc = sourceWrap.querySelector('[data-fcp-priced="wc-products"]');
                if (wc) {
                    const checked = wc.querySelector("input[type='radio']:checked");
                    const unit = checked ? (parseFloat(checked.dataset.price || 0) || 0) : 0;
                    const qty  = parseInt((wc.querySelector("[data-fcp-wc-qty]") || {}).value || 1, 10) || 1;
                    return unit * qty;
                }
                // Product / Pricing radio source — read the checked option's data-price.
                const checked = sourceWrap.querySelector("input[type='radio']:checked");
                return checked ? (parseFloat(checked.dataset.price || 0) || 0) : 0;
            }

            function recompute() {
                const price  = readSourcePrice();
                const amount = +(price * multiplier).toFixed(2);
                setPaymentDisplayAmount(payField, amount);
            }

            // Listen to ANY input/change inside the source field. Covers
            // radio selection (product/pricing) and WC quantity changes.
            sourceWrap.querySelectorAll("input, select, textarea").forEach(el => {
                el.addEventListener("change", recompute);
            });
            // Initial sync — the source may already have a default selection.
            recompute();
        });

        // -------- Repeater field --------
        // Add row: clone the embedded <template> until we hit maxRows. Remove
        // row: drop the clicked row + reindex remaining numbers. minRows is
        // enforced by hiding the Remove button when only one row is left.
        scope.querySelectorAll("[data-fcp-repeater]").forEach(field => {
            const rowsWrap = field.querySelector("[data-fcp-rep-rows]");
            const addBtn   = field.querySelector("[data-fcp-rep-add]");
            const tmpl     = field.querySelector("[data-fcp-rep-template]");
            const min      = parseInt(field.dataset.min || "1", 10);
            const max      = parseInt(field.dataset.max || "10", 10);

            function reindex() {
                const rows = rowsWrap.querySelectorAll("[data-fcp-rep-row]");
                rows.forEach((r, i) => {
                    r.dataset.rowIdx = i;
                    const num = r.querySelector("[data-fcp-rep-num]");
                    if (num) num.textContent = "#" + (i + 1);
                    const removeBtn = r.querySelector("[data-fcp-rep-remove]");
                    if (removeBtn) removeBtn.style.display = (rows.length <= min) ? "none" : "";
                });
                if (addBtn) addBtn.style.display = (rows.length >= max) ? "none" : "";
            }

            function wireRow(row) {
                const rm = row.querySelector("[data-fcp-rep-remove]");
                if (rm) rm.addEventListener("click", () => {
                    const rows = rowsWrap.querySelectorAll("[data-fcp-rep-row]");
                    if (rows.length <= min) return;
                    row.remove();
                    reindex();
                });
            }
            rowsWrap.querySelectorAll("[data-fcp-rep-row]").forEach(wireRow);

            if (addBtn) addBtn.addEventListener("click", () => {
                const current = rowsWrap.querySelectorAll("[data-fcp-rep-row]").length;
                if (current >= max) return;
                const fresh = tmpl.content.firstElementChild.cloneNode(true);
                // Clear values in the cloned row (template carries defaults).
                fresh.querySelectorAll("input, textarea, select").forEach(inp => {
                    if (inp.type === "checkbox" || inp.type === "radio") inp.checked = false;
                    else inp.value = "";
                });
                rowsWrap.appendChild(fresh);
                wireRow(fresh);
                reindex();
            });

            reindex();
        });

        // -------- Address: Google Places autocomplete --------
        // Lit up when the Maps JS API is loaded (the shortcode enqueues it
        // only when the form actually has an address field AND a key is
        // configured). Silently degrades to a plain text input otherwise.
        scope.querySelectorAll("input[data-fcp-address]").forEach(input => {
            if (input.dataset.fcpAddressInited === "1") return;
            input.dataset.fcpAddressInited = "1";
            function init() {
                if (!window.google || !google.maps || !google.maps.places) return false;
                try {
                    const ac = new google.maps.places.Autocomplete(input, {
                        fields: ["address_components", "formatted_address", "geometry"],
                        types:  ["address"]
                    });
                    ac.addListener("place_changed", () => {
                        const p = ac.getPlace();
                        if (p && p.formatted_address) {
                            input.value = p.formatted_address;
                            // Dispatch change so downstream listeners (calc /
                            // logic / autosave) see the new value.
                            input.dispatchEvent(new Event("change", { bubbles: true }));
                        }
                    });
                    return true;
                } catch (e) { return false; }
            }
            if (!init()) {
                // Maps script may still be loading — poll briefly.
                let tries = 0;
                const iv = setInterval(() => {
                    if (init() || ++tries > 30) clearInterval(iv);
                }, 250);
            }
        });

        // -------- Toggle: mirror checkbox state into hidden Yes/No input --------
        scope.querySelectorAll("[data-fcp-toggle]").forEach(field => {
            const cb  = field.querySelector("[data-fcp-toggle-checkbox]");
            const val = field.querySelector("[data-fcp-toggle-value]");
            if (!cb || !val) return;
            const sync = () => { val.value = cb.checked ? "Yes" : "No"; };
            cb.addEventListener("change", sync);
            sync();
        });

        // -------- Range slider: live value display --------
        // Targets the dedicated <span data-fcp-range-value> so updating doesn't
        // clobber the surrounding prefix/suffix text. Also runs on initial
        // hydrate to sync the display with the input's actual value (covers
        // draft-resume + back-button navigation cases).
        scope.querySelectorAll("[data-fcp-range]").forEach(wrap => {
            const input = wrap.querySelector("[data-fcp-range-input]");
            const valEl = wrap.querySelector("[data-fcp-range-value]");
            if (!input || !valEl) return;
            const sync = () => { valEl.textContent = input.value; };
            input.addEventListener("input",  sync);
            input.addEventListener("change", sync);
            sync();
        });

        // -------- NPS: highlight the picked button --------
        scope.querySelectorAll("[data-fcp-nps]").forEach(field => {
            field.querySelectorAll("input[type='radio']").forEach(r => {
                r.addEventListener("change", () => {
                    field.querySelectorAll(".fcp-nps-btn").forEach(b => {
                        b.style.background = "var(--bg-elev)";
                        b.style.color      = "";
                        b.style.borderColor = "var(--border)";
                    });
                    const btn = r.parentElement.querySelector(".fcp-nps-btn");
                    if (!btn) return;
                    const v = parseInt(r.value, 10);
                    // 0-6 = Detractor (red), 7-8 = Passive (amber), 9-10 = Promoter (green)
                    const c = v <= 6 ? "#ef4444" : v <= 8 ? "#f59e0b" : "#10b981";
                    btn.style.background = c;
                    btn.style.color = "#fff";
                    btn.style.borderColor = c;
                });
            });
        });

        // -------- Pipe Video Recording (addpipe.com) --------
        // Loads the Pipe SDK on demand + embeds the recorder. When the
        // visitor stops + uploads, Pipe fires onVideoUploadSuccess with the
        // playable URL — we stash it in the hidden input so the form-engine
        // submits it like any other field value.
        scope.querySelectorAll("[data-fcp-video]").forEach(field => {
            const acc = field.dataset.pipeAccount;
            const env = field.dataset.pipeEnv;
            const max = parseInt(field.dataset.pipeMax, 10) || 120;
            const mountId = field.querySelector("[id^='pipe-']")?.id;
            const hidden  = field.querySelector("[data-fcp-video-url]");
            const status  = field.querySelector("[data-fcp-video-status]");
            if (!acc || !mountId) return;
            function loadPipeSdk() {
                if (window.PipeSDK) return Promise.resolve();
                return new Promise((resolve, reject) => {
                    const s = document.createElement("script");
                    s.src = "https://cdn.addpipe.com/2.0/pipe.js";
                    s.onload = resolve;
                    s.onerror = reject;
                    document.head.appendChild(s);
                    const css = document.createElement("link");
                    css.rel = "stylesheet";
                    css.href = "https://cdn.addpipe.com/2.0/pipe.css";
                    document.head.appendChild(css);
                });
            }
            loadPipeSdk().then(() => {
                if (!window.PipeSDK || !PipeSDK.insert) return;
                const opts = {
                    size:    { width: "100%", height: 280 },
                    qualityurl:  "avq/360p.xml",
                    accountHash: acc,
                    eid:         env || 1,
                    mrt:         max,
                    sis:         1,  // show interface settings
                    asv:         1   // auto-save video on stop
                };
                PipeSDK.insert(mountId, opts, function (pipeRecorder) {
                    pipeRecorder.onVideoUploadSuccess = function (recorderId, filename, filetype, videoId, audioOnly, location) {
                        // location = base URL; final file = location/filename.mp4
                        const url = (location || "").replace(/\/$/, "") + "/" + filename + ".mp4";
                        hidden.value = url;
                        hidden.dispatchEvent(new Event("change", { bubbles: true }));
                        if (status) status.innerHTML = `<span style="color:var(--success);">✓ Recording uploaded.</span>`;
                    };
                    pipeRecorder.onUploadDone = function () {
                        if (status && !hidden.value) status.textContent = "Upload finishing…";
                    };
                });
            }).catch(() => {
                if (status) status.textContent = "Couldn't load the recorder. Check your connection.";
            });
        });

        // -------- Schedule / Booking field (Calendly-style) --------
        // Custom month calendar (no native date input). Clicking a bookable
        // date fetches that date's slot availability from the server and
        // renders pill-shaped slot buttons on the right. Selecting a slot
        // stores the ISO datetime in the hidden input form-engine submits.
        scope.querySelectorAll("[data-fcp-schedule]").forEach(field => {
            let cfg;
            try { cfg = JSON.parse(field.dataset.cfg); }
            catch (e) { cfg = { days:[1,2,3,4,5], startTime:"09:00", endTime:"17:00", slotMinutes:30, capacity:1, leadHours:24, daysAhead:30, skipDates:[] }; }

            const monthEl  = field.querySelector("[data-fcp-cal-month]");
            const gridEl   = field.querySelector("[data-fcp-cal-grid]");
            const slotsEl  = field.querySelector("[data-fcp-cal-slots]");
            const dateLbl  = field.querySelector("[data-fcp-cal-right-date]");
            const status   = field.querySelector("[data-fcp-cal-status]");
            const hidden   = field.querySelector("[data-fcp-schedule-value]");
            const prevBtn  = field.querySelector("[data-fcp-cal-prev]");
            const nextBtn  = field.querySelector("[data-fcp-cal-next]");
            const formId   = (window.FCFormConfig && FCFormConfig.formId) || 0;
            if (!gridEl) return;

            // State: current viewed month + selected date
            const today    = new Date();
            today.setHours(0, 0, 0, 0);
            const maxDate  = new Date(today.getTime() + (parseInt(cfg.daysAhead, 10) || 30) * 86400000);
            let viewYear   = today.getFullYear();
            let viewMonth  = today.getMonth();
            let selectedDate = ""; // YYYY-MM-DD

            const MONTH_NAMES = ["January","February","March","April","May","June","July","August","September","October","November","December"];

            function isoOf(d) {
                return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
            }
            function isBookable(d) {
                if (d < today) return false;
                if (d > maxDate) return false;
                if (!(cfg.days || []).includes(d.getDay())) return false;
                if ((cfg.skipDates || []).includes(isoOf(d))) return false;
                return true;
            }
            function fmt12(hhmm) {
                const [h, m] = hhmm.split(":").map(n => parseInt(n, 10));
                const ampm = h >= 12 ? "pm" : "am";
                const h12  = ((h + 11) % 12) + 1;
                return h12 + ":" + String(m).padStart(2, "0") + " " + ampm;
            }
            function buildSlots() {
                // Multi-window: walk each {start,end} pair and concat slots.
                // Falls back to legacy cfg.startTime / cfg.endTime when the
                // form was saved before timeWindows existed.
                const windows = Array.isArray(cfg.timeWindows) && cfg.timeWindows.length
                    ? cfg.timeWindows
                    : [{ start: cfg.startTime || "09:00", end: cfg.endTime || "17:00" }];
                const step = Math.max(5, parseInt(cfg.slotMinutes, 10) || 30);
                const seen = new Set();   // dedupe in case windows overlap
                const out  = [];
                for (const w of windows) {
                    if (!w || !w.start || !w.end) continue;
                    const [sh, sm] = w.start.split(":").map(n => parseInt(n, 10) || 0);
                    const [eh, em] = w.end.split(":").map(n => parseInt(n, 10) || 0);
                    const startM = sh * 60 + sm;
                    const endM   = eh * 60 + em;
                    if (endM <= startM) continue;
                    for (let m = startM; m + step <= endM; m += step) {
                        const hh = Math.floor(m / 60);
                        const mm = m % 60;
                        const slot = String(hh).padStart(2, "0") + ":" + String(mm).padStart(2, "0");
                        if (!seen.has(slot)) { seen.add(slot); out.push(slot); }
                    }
                }
                // Slots come out in window-order; sort so a 09:00 from window 2 still appears before 14:00 from window 3
                return out.sort();
            }

            function renderMonth() {
                if (monthEl) monthEl.textContent = MONTH_NAMES[viewMonth] + " " + viewYear;
                // Disable nav buttons when we'd go before today's month or
                // past the last allowed month.
                if (prevBtn) {
                    const minM = today.getFullYear() * 12 + today.getMonth();
                    const cur  = viewYear * 12 + viewMonth;
                    prevBtn.disabled = cur <= minM;
                }
                if (nextBtn) {
                    const maxM = maxDate.getFullYear() * 12 + maxDate.getMonth();
                    const cur  = viewYear * 12 + viewMonth;
                    nextBtn.disabled = cur >= maxM;
                }
                const firstOfMonth = new Date(viewYear, viewMonth, 1);
                const lastOfMonth  = new Date(viewYear, viewMonth + 1, 0);
                const startDow     = firstOfMonth.getDay();
                const daysInMonth  = lastOfMonth.getDate();
                let html = "";
                // Leading blanks for days from prev month
                for (let i = 0; i < startDow; i++) html += `<div class="fcp-cal-day fcp-cal-day-empty"></div>`;
                // Each day in this month
                for (let day = 1; day <= daysInMonth; day++) {
                    const d   = new Date(viewYear, viewMonth, day);
                    const iso = isoOf(d);
                    const ok  = isBookable(d);
                    const sel = iso === selectedDate;
                    const cls = "fcp-cal-day"
                              + (ok  ? " fcp-cal-day-on"       : " fcp-cal-day-off")
                              + (sel ? " fcp-cal-day-selected" : "");
                    html += `<button type="button" class="${cls}" ${ok ? `data-cal-day="${iso}"` : "disabled"}>${day}</button>`;
                }
                gridEl.innerHTML = html;
                gridEl.querySelectorAll("[data-cal-day]").forEach(b => {
                    b.addEventListener("click", () => pickDate(b.dataset.calDay));
                });
            }

            function pickDate(iso) {
                selectedDate = iso;
                hidden.value = "";  // clear slot until they re-click
                hidden.dispatchEvent(new Event("change", { bubbles: true }));
                renderMonth();
                // Right-column label "Mon, Jun 15"
                const d = new Date(iso + "T00:00");
                dateLbl.textContent = d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
                loadSlotsFor(iso);
            }

            function loadSlotsFor(dateStr) {
                if (!slotsEl) return;
                slotsEl.innerHTML = `<div class="fcp-cal-status">Loading…</div>`;
                if (status) status.textContent = "";
                const restBase  = (window.FCFormConfig && FCFormConfig.rest)  || "";
                const restNonce = (window.FCFormConfig && FCFormConfig.nonce) || "";
                const fetcher = (restBase && formId)
                    ? fetch(restBase.replace(/\/$/, "") + "/forms/" + formId + "/slot-availability?date=" + encodeURIComponent(dateStr), {
                        credentials: "same-origin",
                        headers: { "X-WP-Nonce": restNonce }
                      }).then(r => r.json()).catch(() => ({ booked: {} }))
                    : Promise.resolve({ booked: {} });
                fetcher.then(res => {
                    const booked = (res && res.booked) || {};
                    const slots  = buildSlots();
                    const now    = Date.now();
                    const leadMs = Math.max(0, (parseInt(cfg.leadHours, 10) || 0) * 3600000);
                    const cap    = parseInt(cfg.capacity, 10) || 1;
                    const items  = slots.map(s => {
                        const iso     = dateStr + "T" + s;
                        const slotMs  = new Date(iso).getTime();
                        const full    = (booked[s] || 0) >= cap;
                        const tooSoon = slotMs - now < leadMs;
                        return { s, iso, full, tooSoon, label: fmt12(s) };
                    });
                    const available = items.filter(x => !x.full && !x.tooSoon);
                    if (available.length === 0) {
                        slotsEl.innerHTML = `<div class="fcp-cal-status">No available times this day. Try another.</div>`;
                        return;
                    }
                    slotsEl.innerHTML = available.map(x =>
                        `<button type="button" class="fcp-cal-slot" data-cal-slot="${x.iso}">${x.label}</button>`
                    ).join("");
                    slotsEl.querySelectorAll("[data-cal-slot]").forEach(b => {
                        b.addEventListener("click", () => {
                            slotsEl.querySelectorAll(".fcp-cal-slot").forEach(o => o.classList.remove("selected"));
                            b.classList.add("selected");
                            hidden.value = b.dataset.calSlot;
                            hidden.dispatchEvent(new Event("change", { bubbles: true }));
                            if (status) status.innerHTML = `<span style="color:var(--success,#10b981);">✓ Slot reserved — submit the form to confirm.</span>`;
                        });
                    });
                });
            }

            if (prevBtn) prevBtn.addEventListener("click", () => {
                viewMonth--;
                if (viewMonth < 0) { viewMonth = 11; viewYear--; }
                renderMonth();
            });
            if (nextBtn) nextBtn.addEventListener("click", () => {
                viewMonth++;
                if (viewMonth > 11) { viewMonth = 0; viewYear++; }
                renderMonth();
            });

            renderMonth();
        });

        // -------- List field --------
        // Lightweight dynamic-row list. Same Add/Remove pattern as repeater
        // but each row is a single text input. Values export as a flat array
        // under the field label.
        scope.querySelectorAll("[data-fcp-list]").forEach(field => {
            const rowsWrap = field.querySelector("[data-fcp-list-rows]");
            const addBtn   = field.querySelector("[data-fcp-list-add]");
            const tmpl     = field.querySelector("[data-fcp-list-template]");
            const min      = parseInt(field.dataset.min || "1", 10);
            const max      = parseInt(field.dataset.max || "20", 10);

            function reindex() {
                const rows = rowsWrap.querySelectorAll("[data-fcp-list-row]");
                rows.forEach((r, i) => {
                    const num = r.querySelector("[data-fcp-list-num]");
                    if (num) num.textContent = (i + 1) + ".";
                    const rm = r.querySelector("[data-fcp-list-remove]");
                    if (rm) rm.style.display = (rows.length <= min) ? "none" : "";
                });
                if (addBtn) addBtn.style.display = (rows.length >= max) ? "none" : "";
            }
            function wireRow(row) {
                const rm = row.querySelector("[data-fcp-list-remove]");
                if (rm) rm.addEventListener("click", () => {
                    const rows = rowsWrap.querySelectorAll("[data-fcp-list-row]");
                    if (rows.length <= min) return;
                    row.remove(); reindex();
                });
            }
            rowsWrap.querySelectorAll("[data-fcp-list-row]").forEach(wireRow);
            if (addBtn) addBtn.addEventListener("click", () => {
                const current = rowsWrap.querySelectorAll("[data-fcp-list-row]").length;
                if (current >= max) return;
                const fresh = tmpl.content.firstElementChild.cloneNode(true);
                fresh.querySelectorAll("input").forEach(i => i.value = "");
                rowsWrap.appendChild(fresh);
                wireRow(fresh); reindex();
            });
            reindex();
        });

        // -------- OTP field --------
        // Real send/verify flow. The Send button calls /otp/send with the
        // target (linked field value or the inline input) + channel; on
        // success we lock the target, start a 60s cooldown countdown, then
        // let the user type the code. The 6 boxes auto-advance + paste-spread.
        scope.querySelectorAll("[data-fcp-otp]").forEach(field => {
            const channel   = field.dataset.channel || "email";
            const targetFid = field.dataset.targetFid || "";
            const otpLen    = parseInt(field.dataset.otpLength || "6", 10);
            const sendBtn   = field.querySelector("[data-fcp-otp-send]");
            const status    = field.querySelector("[data-fcp-otp-status]");
            const hidden    = field.querySelector("[data-fcp-otp-value]");
            const boxes     = Array.from(field.querySelectorAll("[data-fcp-otp-boxes] input"));
            const inlineTgt = field.querySelector("[data-fcp-otp-target]");
            const formId    = (window.FCFormConfig && FCFormConfig.formId) || 0;

            function setStatus(msg, kind) {
                if (!status) return;
                status.textContent = msg || "";
                status.style.color = kind === "ok"   ? "var(--success, #10b981)"
                                  : kind === "err" ? "var(--danger,  #ef4444)"
                                                   : "var(--text-muted)";
            }

            function readTarget() {
                if (inlineTgt) return (inlineTgt.value || "").trim();
                if (!targetFid) return "";
                const root = field.closest("form") || field.closest(".fc-form-public") || scope;
                const wrap = root.querySelector(`.fc-field[data-fid="${targetFid}"]`);
                if (!wrap) return "";
                const input = wrap.querySelector("input, select, textarea");
                return input ? (input.value || "").trim() : "";
            }

            function readCode() {
                return boxes.map(b => (b.value || "").replace(/\D/g, "")).join("").slice(0, otpLen);
            }

            function refreshHidden() {
                const target = readTarget();
                const code   = readCode();
                hidden.value = JSON.stringify({ target, channel, code });
            }

            // Auto-advance + backspace + paste handling on the boxes.
            boxes.forEach((box, i) => {
                box.addEventListener("input", e => {
                    box.value = (box.value || "").replace(/\D/g, "").slice(-1);
                    if (box.value && i < boxes.length - 1) boxes[i + 1].focus();
                    refreshHidden();
                });
                box.addEventListener("keydown", e => {
                    if (e.key === "Backspace" && !box.value && i > 0) boxes[i - 1].focus();
                    if (e.key === "ArrowLeft"  && i > 0) boxes[i - 1].focus();
                    if (e.key === "ArrowRight" && i < boxes.length - 1) boxes[i + 1].focus();
                });
                box.addEventListener("paste", e => {
                    const text = (e.clipboardData || window.clipboardData).getData("text").replace(/\D/g, "");
                    if (!text) return;
                    e.preventDefault();
                    text.slice(0, boxes.length - i).split("").forEach((ch, j) => {
                        boxes[i + j].value = ch;
                    });
                    const lastFilled = Math.min(boxes.length - 1, i + text.length - 1);
                    boxes[lastFilled].focus();
                    refreshHidden();
                });
            });

            if (inlineTgt) inlineTgt.addEventListener("input", refreshHidden);

            let cooldownTimer = null;
            function startCooldown(seconds) {
                if (!sendBtn) return;
                sendBtn.disabled = true;
                const origLabel  = sendBtn.dataset.fcpOrigLabel || sendBtn.textContent;
                sendBtn.dataset.fcpOrigLabel = origLabel;
                let left = seconds;
                sendBtn.textContent = `Resend in ${left}s`;
                if (cooldownTimer) clearInterval(cooldownTimer);
                cooldownTimer = setInterval(() => {
                    left--;
                    if (left <= 0) {
                        clearInterval(cooldownTimer);
                        sendBtn.disabled = false;
                        sendBtn.textContent = origLabel.replace(/^Send/i, "Resend");
                    } else {
                        sendBtn.textContent = `Resend in ${left}s`;
                    }
                }, 1000);
            }

            // The send button hits /otp/send. We use FCFormConfig (public
            // shortcode mode) or FCBridge.ctx (admin preview) for the REST base.
            function callSend() {
                const target = readTarget();
                if (!target) {
                    setStatus(channel === "email" ? "Please enter your email first." : "Please enter your phone first.", "err");
                    return;
                }
                const restBase = (window.FCFormConfig && FCFormConfig.rest)
                              || (window.FCBridge && FCBridge.ctx && FCBridge.ctx.restBase)
                              || "";
                const restNonce = (window.FCFormConfig && FCFormConfig.nonce)
                              || (window.FCBridge && FCBridge.ctx && FCBridge.ctx.restNonce)
                              || "";
                if (!restBase) {
                    setStatus("OTP only works when the form is rendered inside WordPress.", "err");
                    return;
                }
                sendBtn.disabled = true;
                const oldLabel = sendBtn.textContent;
                sendBtn.textContent = "Sending…";
                setStatus("Sending code…", "info");
                fetch(restBase.replace(/\/$/, "") + "/otp/send", {
                    method: "POST",
                    credentials: "same-origin",
                    headers: { "Content-Type": "application/json", "X-WP-Nonce": restNonce },
                    body: JSON.stringify({ target, channel, form_id: formId })
                }).then(r => r.json().then(j => ({ ok: r.ok, body: j })))
                  .then(({ ok, body }) => {
                    if (!ok || !body || body.code) {
                        const msg = (body && (body.message || body.code)) || "Could not send code.";
                        setStatus(msg, "err");
                        sendBtn.disabled = false;
                        sendBtn.textContent = oldLabel;
                        return;
                    }
                    setStatus(`Code sent. It expires in ${Math.round((body.ttl || 300) / 60)} min.`, "ok");
                    startCooldown(body.cooldown || 60);
                    boxes[0] && boxes[0].focus();
                    refreshHidden();
                }).catch(err => {
                    setStatus(err.message || "Could not send code.", "err");
                    sendBtn.disabled = false;
                    sendBtn.textContent = oldLabel;
                });
            }

            if (sendBtn) sendBtn.addEventListener("click", callSend);

            // Initial hidden-value sync (empty values, but ensures the key exists).
            refreshHidden();
        });

        // -------- WooCommerce Products field --------
        // Wire: when the user picks a product radio, populate the variation
        // dropdown (if the product has variations) and emit a synthetic
        // change so dynamic pricing / coupon / calc fields recompute.
        scope.querySelectorAll('[data-fcp-priced="wc-products"]').forEach(field => {
            const fid = field.closest(".fc-field")?.dataset.fid;
            const fieldData = (window.FCFormConfig && FCFormConfig.form && FCFormConfig.form.steps)
                ? FCFormConfig.form.steps.flatMap(s => s.fields).find(x => x.id === fid)
                : null;
            const products = fieldData ? (fieldData.wcProducts || []) : [];
            const varWrap  = field.querySelector("[data-fcp-wc-variations]");
            const varSel   = field.querySelector("[data-fcp-wc-variation]");
            const radios   = field.querySelectorAll('input[type="radio"]');

            function populateVariations() {
                const checked = field.querySelector('input[type="radio"]:checked');
                if (!checked || !varWrap || !varSel) return;
                const pid = parseInt(checked.dataset.productId, 10);
                const product = products.find(p => parseInt(p.id, 10) === pid);
                if (!product || !Array.isArray(product.variations) || !product.variations.length) {
                    varWrap.style.display = "none";
                    varSel.innerHTML = '<option value="">Select…</option>';
                    return;
                }
                varWrap.style.display = "";
                varSel.innerHTML = product.variations.map((v, i) =>
                    `<option value="${v.id}" data-price="${v.price}" ${i === 0 ? "selected" : ""}>${FCApp.escapeHtml(v.name)} — ${product.currency || ""} ${v.price}</option>`
                ).join("");
                // Refresh the radio's data-price so the price source picks it up.
                checked.dataset.price = product.variations[0].price;
            }

            radios.forEach(r => r.addEventListener("change", () => {
                populateVariations();
                // Bubble a change on the field's wrapper so coupon/payment listeners react.
                field.dispatchEvent(new Event("change", { bubbles: true }));
            }));

            if (varSel) {
                varSel.addEventListener("change", () => {
                    const opt = varSel.options[varSel.selectedIndex];
                    if (!opt) return;
                    const checked = field.querySelector('input[type="radio"]:checked');
                    if (checked && opt.dataset.price) {
                        checked.dataset.price = opt.dataset.price;
                        // Re-dispatch on the radio so price-source listeners recompute.
                        checked.dispatchEvent(new Event("change", { bubbles: true }));
                    }
                });
            }

            const qtyInput = field.querySelector("[data-fcp-wc-qty]");
            if (qtyInput) {
                qtyInput.addEventListener("input", () => {
                    // Re-dispatch a change on the selected radio so downstream
                    // listeners (coupon, dynamic price source) recompute total.
                    const checked = field.querySelector('input[type="radio"]:checked');
                    if (checked) checked.dispatchEvent(new Event("change", { bubbles: true }));
                });
            }

            // Initial sync — populate variations for the default-selected product.
            populateVariations();
        });

        // Payment Method field — show only the panel of the selected radio.
        scope.querySelectorAll("[data-fcp-payment]").forEach(field => {
            const radios = field.querySelectorAll("input[type='radio']");
            const panels = field.querySelectorAll(".fcp-method-panel");
            radios.forEach(r => {
                r.addEventListener("change", () => {
                    panels.forEach(p => {
                        p.hidden = (p.dataset.method !== r.value);
                    });
                });
            });
        });

        // -------- Calculation field --------
        // Reads other fields' values by label, evaluates a sandboxed formula,
        // and writes both a formatted display value (visible) and the raw
        // numeric value (hidden) so downstream features can chain.
        //
        // SAFETY: never `eval()` raw input. After substituting numeric values
        // for {label} placeholders and rewriting allow-listed function calls
        // to a sandbox object, any leftover identifier rejects the formula.
        const FCP_CALC_FUNCS = {
            round: (n, dp) => { const p = Math.pow(10, dp != null ? dp : 0); return Math.round((+n) * p) / p; },
            floor: (n) => Math.floor(+n),
            ceil:  (n) => Math.ceil(+n),
            abs:   (n) => Math.abs(+n),
            min:   (...a) => Math.min(...a.map(Number)),
            max:   (...a) => Math.max(...a.map(Number)),
            pow:   (b, e) => Math.pow(+b, +e),
            sqrt:  (n) => Math.sqrt(+n),
            sum:   (...a) => a.reduce((s, x) => s + (+x || 0), 0),
            avg:   (...a) => a.length ? a.reduce((s, x) => s + (+x || 0), 0) / a.length : 0,
            // Comparison helpers return 1/0 so they compose inside cond().
            gt:    (a, b) => (+a) >  (+b) ? 1 : 0,
            lt:    (a, b) => (+a) <  (+b) ? 1 : 0,
            gte:   (a, b) => (+a) >= (+b) ? 1 : 0,
            lte:   (a, b) => (+a) <= (+b) ? 1 : 0,
            eq:    (a, b) => (+a) === (+b) ? 1 : 0,
            neq:   (a, b) => (+a) !== (+b) ? 1 : 0,
            cond:  (c, t, e) => (+c) ? (+t) : (+e)
        };
        const FCP_CALC_FN_NAMES = Object.keys(FCP_CALC_FUNCS);

        function fcpReadFieldValue(fieldDiv) {
            if (!fieldDiv) return 0;
            // Calc field source — its hidden input carries the raw value.
            const inner = fieldDiv.querySelector("[data-fcp-calc] input");
            if (inner) return parseFloat(inner.dataset.fcpRawValue || 0) || 0;
            // Coupon field — the visible <input> holds the CODE STRING
            // ("SAVE25"), which parseFloat returns NaN for. The actually
            // useful number is the applied discount, parked on the form
            // root by applyDiscount(). Match WPForms behavior where
            // {Coupon} resolves to the discount amount.
            if (fieldDiv.querySelector("[data-fcp-coupon]")) {
                const root = fieldDiv.closest("form") || fieldDiv.closest(".fc-form-public");
                if (root && root.dataset.fcpCouponDiscount) {
                    return parseFloat(root.dataset.fcpCouponDiscount) || 0;
                }
                return 0;  // No coupon applied yet → discount is 0
            }
            // Product / Pricing radios — read the selected radio's data-price.
            const priced = fieldDiv.querySelector('[data-fcp-priced="product"] input[type="radio"]:checked, [data-fcp-priced="pricing"] input[type="radio"]:checked');
            if (priced) return parseFloat(priced.dataset.price || priced.value || 0) || 0;
            // Rating field — value lives on the rating widget's data-value
            // attribute (not on any <input> since stars aren't inputs).
            const ratingEl = fieldDiv.querySelector(".fc-rating[data-value]");
            if (ratingEl) return parseFloat(ratingEl.dataset.value || 0) || 0;
            // Toggle field — exposes Yes/No on its mirror; treat Yes as 1, No as 0.
            const toggleVal = fieldDiv.querySelector("[data-fcp-toggle-value]");
            if (toggleVal) return toggleVal.value === "Yes" ? 1 : 0;
            // Generic radio / checkbox — read the picked option's value.
            const checked = fieldDiv.querySelector("input[type='radio']:checked, input[type='checkbox']:checked");
            if (checked) return parseFloat(checked.value || 0) || 0;
            // Range / number / regular input.
            const inp = fieldDiv.querySelector("input, select, textarea");
            return inp ? (parseFloat(inp.value) || 0) : 0;
        }

        function fcpFieldByLabel(root, label) {
            const target = (label || "").trim().toLowerCase();
            const divs = root.querySelectorAll(".fc-field");
            for (let i = 0; i < divs.length; i++) {
                const lab = divs[i].querySelector("label");
                if (!lab) continue;
                const text = lab.textContent.replace(/\*\s*$/, "").trim().toLowerCase();
                if (text === target) return divs[i];
            }
            return null;
        }

        scope.querySelectorAll("[data-fcp-calc]").forEach(calcEl => {
            const formula  = calcEl.dataset.formula  || "";
            const decimals = parseInt(calcEl.dataset.decimals || "2", 10);
            const prefix   = calcEl.dataset.prefix   || "";
            const suffix   = calcEl.dataset.suffix   || "";
            const display  = calcEl.querySelector("input");
            const root     = calcEl.closest("form") || calcEl.closest(".fc-form-public") || scope;
            if (!display || !formula) return;

            const matches = [];
            const re = /\{([^}]+)\}/g;
            let m;
            while ((m = re.exec(formula)) !== null) matches.push(m[1].trim());
            const uniqueLabels = Array.from(new Set(matches));

            function compute() {
                let expr = formula;
                expr = expr.replace(/\{([^}]+)\}/g, (full, label) => {
                    const div = fcpFieldByLabel(root, label.trim());
                    const v = div ? fcpReadFieldValue(div) : 0;
                    return "(" + v + ")";
                });
                let safe = true;
                const allowedRe = new RegExp("\\b(" + FCP_CALC_FN_NAMES.join("|") + ")\\s*\\(", "g");
                expr = expr.replace(allowedRe, (mm, name) => "FCM." + name + "(");
                if (/\b[a-zA-Z_]\w*\b(?!\.)/.test(expr.replace(/FCM\.\w+/g, ""))) safe = false;
                if (!safe) return null;
                try {
                    // eslint-disable-next-line no-new-func
                    const result = Function("FCM", '"use strict"; return (' + expr + ")")(FCP_CALC_FUNCS);
                    if (typeof result === "number" && isFinite(result)) return result;
                } catch (e) { /* swallow */ }
                return null;
            }

            const valueEl = calcEl.querySelector("[data-fcp-calc-value]");

            function fmtNumber(n, dp) {
                try {
                    return n.toLocaleString(undefined, { minimumFractionDigits: dp, maximumFractionDigits: dp });
                } catch (e) {
                    return n.toFixed(dp);
                }
            }

            function update() {
                const v   = compute();
                const num = (v === null || isNaN(v)) ? 0 : v;
                const pretty   = fmtNumber(num, decimals);
                const formatted = (prefix ? prefix + " " : "") + pretty + (suffix ? " " + suffix : "");
                if (valueEl) valueEl.textContent = pretty;
                if (display.value !== formatted || display.dataset.fcpRawValue !== String(num)) {
                    display.value = formatted;
                    display.dataset.fcpRawValue = String(num);
                    // Chain: notify downstream calc fields + dynamic pricing.
                    display.dispatchEvent(new Event("change", { bubbles: true }));
                }
            }

            uniqueLabels.forEach(label => {
                const div = fcpFieldByLabel(root, label);
                if (!div) return;
                div.querySelectorAll("input, select, textarea").forEach(inp => {
                    inp.addEventListener("input",  update);
                    inp.addEventListener("change", update);
                });
            });

            // Initial paint — covers default selections.
            update();
        });

        // -------- Coupon field (live mode) --------
        // The Apply button calls FCBridge.validateCoupon() with the currently
        // selected product / pricing tier amount, then rewrites the displayed
        // total on the related Product / Pricing / Payment field and stores
        // the applied code on the form root so form-engine submits it.
        scope.querySelectorAll("[data-fcp-coupon]").forEach(field => {
            const applyBtn  = field.querySelector("[data-fcp-coupon-apply]");
            const codeInput = field.querySelector("input[type='text']");
            const hidden    = field.querySelector("input[name='fcp_applied_coupon']");
            const status    = field.querySelector(".fcp-coupon-status");
            if (!applyBtn || !codeInput) return;

            const root = field.closest("form") || field.closest(".fc-form-public") || document;

            function findPriceFields() {
                // Returns { amountField, currentAmount, currency, isPayClass }
                const out = { amountField: null, currentAmount: 0, currency: "", isPayClass: false };

                // Helpers that read each candidate field's current amount.
                const readPay = (pay) => {
                    if (!pay) return null;
                    const amt = pay.dataset.fcpPreCouponBase
                        ? parseFloat(pay.dataset.fcpPreCouponBase)
                        : parseFloat(pay.dataset.fcpBase || 0);
                    return { amountField: pay, currentAmount: amt || 0, currency: pay.dataset.fcpCurrency || "INR", isPayClass: true };
                };
                const readPricingLike = (sel) => {
                    const el = root.querySelector(sel);
                    if (!el) return null;
                    const checked = el.querySelector("input[type='radio']:checked");
                    const amt = checked ? parseFloat(checked.dataset.price || 0) : 0;
                    return { amountField: el, currentAmount: amt || 0, currency: "", isPayClass: false };
                };
                const readWc = () => {
                    const wc = root.querySelector('[data-fcp-priced="wc-products"]');
                    if (!wc) return null;
                    const checked = wc.querySelector("input[type='radio']:checked");
                    const unit = checked ? (parseFloat(checked.dataset.price || 0) || 0) : 0;
                    const qty  = parseInt((wc.querySelector("[data-fcp-wc-qty]") || {}).value || 1, 10) || 1;
                    return { amountField: wc, currentAmount: unit * qty, currency: wc.dataset.fcpCurrency || "", isPayClass: false };
                };

                // Prefer payment-class field (visible total + UPI QR). But if
                // its amount is 0 — admin didn't link a Price Source and there
                // is no fixed amount — fall through to a sibling Pricing /
                // Product / WC field so the coupon can still find a base.
                const payClass = root.querySelector('[data-fcp-priced="payment"], [data-fcp-priced="upi"], [data-fcp-priced="bank"]');
                const payRead  = readPay(payClass);
                if (payRead && payRead.currentAmount > 0) return payRead;

                const product = readPricingLike('[data-fcp-priced="product"]');
                if (product && product.currentAmount > 0) return product;

                const wc = readWc();
                if (wc && wc.currentAmount > 0) return wc;

                const pricing = readPricingLike('[data-fcp-priced="pricing"]');
                if (pricing && pricing.currentAmount > 0) return pricing;

                // Nothing found with a non-zero amount — return whichever
                // field exists (even with amount 0) so applyDiscount has
                // somewhere to render, or the empty default.
                return payRead || product || wc || pricing || out;
            }

            function setStatus(html, kind) {
                status.innerHTML = html;
                status.style.color = kind === "ok" ? "var(--success, #10b981)" : (kind === "err" ? "var(--danger, #ef4444)" : "var(--text-muted)");
            }

            function clearAppliedDisplay() {
                // Remove any existing green discount line we appended.
                root.querySelectorAll(".fcp-coupon-line").forEach(n => n.remove());
                // Restore a payment-class field to its pre-coupon amount.
                // applyDiscount stashes the pre-coupon amount on fcpPreCouponBase
                // — that's the authoritative restore value regardless of whether
                // the field uses a fixed amount or a dynamic price source.
                // (fcpBase was overwritten with the discounted total during apply,
                // so reading it here would re-show the discount.)
                const payField = root.querySelector('[data-fcp-priced="payment"], [data-fcp-priced="upi"], [data-fcp-priced="bank"]');
                if (payField && payField.dataset.fcpPreCouponBase) {
                    setPaymentDisplayAmount(payField, parseFloat(payField.dataset.fcpPreCouponBase));
                    delete payField.dataset.fcpPreCouponBase;
                }
            }

            function applyDiscount(res) {
                clearAppliedDisplay();
                const fp = findPriceFields();
                if (!fp.amountField) return;
                const amountField = fp.amountField;
                const cur = fp.currency || (amountField.dataset.fcpCurrency || "");

                // Remember the pre-coupon amount so we can restore on clear AND
                // so the form-engine can send the correct base amount to the
                // server (the server re-applies the discount itself).
                if (fp.isPayClass) {
                    amountField.dataset.fcpPreCouponBase = String(fp.currentAmount);
                }

                const lineHTML = `<div class="fcp-coupon-line" style="margin-top:10px;padding:10px 12px;border-radius:8px;background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.25);display:flex;justify-content:space-between;font-size:13px;">
                    <span>Coupon <strong>${FCApp.escapeHtml(res.code)}</strong> applied — ${res.discount_type === "percent" ? res.discount_value + "% off" : "−" + res.discount.toFixed(2)}</span>
                    <span><strong>New total: ${cur} ${res.final_amount.toFixed(2)}</strong></span>
                </div>`;
                amountField.insertAdjacentHTML("afterend", lineHTML);

                // For payment-class fields, also update the visible total + UPI QR.
                if (fp.isPayClass) {
                    setPaymentDisplayAmount(amountField, res.final_amount);
                }

                hidden.value = res.code;
                // Also expose to form-engine via a global per-form attribute.
                root.dataset.fcpCouponCode    = res.code;
                root.dataset.fcpCouponDiscount = String(res.discount);
                root.dataset.fcpCouponFinal    = String(res.final_amount);
                // Calc fields that reference the coupon field (e.g.
                // {Coupon Code} in a formula) listen for input/change on
                // its inputs. Coupon discount changes via button click,
                // not via typing — dispatch a synthetic change so any
                // calc field that depends on the discount recomputes.
                codeInput.dispatchEvent(new Event("change", { bubbles: true }));
            }

            // Snapshot the original button label so we can flip between
            // "Apply" → "Remove" → "Apply" without losing the admin's
            // configured wording.
            const applyLabel  = applyBtn.textContent;
            const removeLabel = "Remove";

            function setAppliedUI(applied) {
                if (applied) {
                    applyBtn.textContent = removeLabel;
                    applyBtn.classList.remove("btn-primary");
                    applyBtn.classList.add("btn-outline");
                    applyBtn.dataset.fcpCouponState = "applied";
                    codeInput.readOnly = true;
                    codeInput.style.opacity = "0.7";
                } else {
                    applyBtn.textContent = applyLabel;
                    applyBtn.classList.add("btn-primary");
                    applyBtn.classList.remove("btn-outline");
                    delete applyBtn.dataset.fcpCouponState;
                    codeInput.readOnly = false;
                    codeInput.style.opacity = "";
                }
            }

            function removeCoupon() {
                hidden.value = "";
                delete root.dataset.fcpCouponCode;
                delete root.dataset.fcpCouponDiscount;
                delete root.dataset.fcpCouponFinal;
                clearAppliedDisplay();
                codeInput.value = "";
                setAppliedUI(false);
                setStatus("Coupon removed.", "info");
                // Re-fire so dependent calc fields drop the discount back to 0.
                codeInput.dispatchEvent(new Event("change", { bubbles: true }));
            }

            applyBtn.addEventListener("click", () => {
                // Toggle off if already applied
                if (applyBtn.dataset.fcpCouponState === "applied") {
                    removeCoupon();
                    return;
                }

                const code = (codeInput.value || "").trim().toUpperCase();
                if (!code) { setStatus("Please enter a coupon code.", "err"); return; }

                const { currentAmount } = findPriceFields();
                if (!currentAmount || currentAmount <= 0) {
                    setStatus("Pick a product or plan before applying a coupon.", "err");
                    return;
                }

                // Pick the right way to call the validate endpoint:
                //   1. FCBridge (admin iframe / wp-admin context)
                //   2. FCFormConfig (public shortcode-rendered form)
                //   3. error if neither is available (standalone HTML preview)
                const formId   = (window.FCFormConfig && FCFormConfig.formId) || 0;
                const hasBridge = !!(window.FCBridge && FCBridge.enabled && FCBridge.validateCoupon);
                const hasShortcode = !!(window.FCFormConfig && FCFormConfig.rest);
                if (!hasBridge && !hasShortcode) {
                    setStatus("Coupon validation only works on the live WordPress form.", "err");
                    return;
                }

                applyBtn.disabled = true;
                applyBtn.textContent = "Checking…";
                setStatus("Validating coupon…", "info");

                const callValidate = hasBridge
                    ? FCBridge.validateCoupon(code, currentAmount, formId)
                    : fetch(FCFormConfig.rest.replace(/\/$/, "") + "/coupons/validate", {
                        method: "POST",
                        credentials: "same-origin",
                        headers: { "Content-Type": "application/json", "X-WP-Nonce": FCFormConfig.nonce || "" },
                        body: JSON.stringify({ code: code, amount: currentAmount, form_id: formId })
                      }).then(r => r.json());

                callValidate
                    .then(res => {
                        if (!res || !res.ok) {
                            setStatus((res && res.message) || "Coupon not valid.", "err");
                            hidden.value = "";
                            delete root.dataset.fcpCouponCode;
                            clearAppliedDisplay();
                            setAppliedUI(false);
                            return;
                        }
                        applyDiscount(res);
                        setStatus(`Coupon applied — you save ${(res.discount || 0).toFixed(2)}.`, "ok");
                        setAppliedUI(true);
                    })
                    .catch(err => {
                        setStatus((err && err.message) || "Could not validate coupon.", "err");
                        hidden.value = "";
                        setAppliedUI(false);
                    })
                    .finally(() => {
                        applyBtn.disabled = false;
                        // Label is restored by setAppliedUI in both paths.
                    });
            });

            // If the user changes the selected product/plan after applying a
            // coupon, the previous discount is stale — clear it and force them
            // to click Apply again so the new amount is re-validated.
            root.querySelectorAll('[data-fcp-priced="product"] input, [data-fcp-priced="pricing"] input, [data-fcp-priced="wc-products"] input, [data-fcp-priced="wc-products"] select').forEach(inp => {
                inp.addEventListener("change", () => {
                    if (!hidden.value) return;
                    hidden.value = "";
                    delete root.dataset.fcpCouponCode;
                    delete root.dataset.fcpCouponDiscount;
                    delete root.dataset.fcpCouponFinal;
                    clearAppliedDisplay();
                    setAppliedUI(false);
                    setStatus("Selection changed — please re-apply the coupon.", "info");
                });
            });
        });

        // Multi-select dropdown — update the trigger label as the user picks
        // options. The native <details> handles open/close on its own.
        scope.querySelectorAll(".fc-multiselect").forEach(ms => {
            const text   = ms.querySelector(".fc-multiselect-text");
            if (!text) return;
            const placeholder = text.dataset.placeholder || "Select options…";
            const inputs = ms.querySelectorAll("input[type='checkbox']");
            const sync = () => {
                const selected = Array.from(inputs).filter(i => i.checked).map(i => i.value);
                text.textContent = selected.length ? selected.join(", ") : placeholder;
                text.classList.toggle("is-empty", selected.length === 0);
            };
            inputs.forEach(i => i.addEventListener("change", sync));
            sync();
        });
        // Close any open multi-select when the user clicks outside it.
        if (!scope._fcpMultiselectClickAttached) {
            document.addEventListener("click", e => {
                document.querySelectorAll(".fc-multiselect[open]").forEach(ms => {
                    if (!ms.contains(e.target)) ms.removeAttribute("open");
                });
            });
            scope._fcpMultiselectClickAttached = true;
        }

        // ---- Country / State / City cascade ---------------------
        scope.querySelectorAll('[data-fcp-geo="country"]').forEach(countrySel => {
            const root     = countrySel.closest("form") || countrySel.closest(".fc-form-public") || scope;
            const stateSel = root.querySelector('[data-fcp-geo="state"]');
            const citySel  = root.querySelector('[data-fcp-geo="city"]');

            function loading(sel, text)  { sel.disabled = true;  sel.innerHTML = `<option value="">${text}</option>`; }
            function resetState()        { if (stateSel) loading(stateSel, "-- Select country first --"); }
            function resetCity()         { if (citySel)  loading(citySel,  stateSel ? "-- Select state first --" : "-- Select country first --"); }
            function fillSelect(sel, items, placeholder) {
                sel.disabled = false;
                sel.innerHTML = `<option value="">${placeholder}</option>` +
                    items.map(i => `<option>${FCApp.escapeHtml(i)}</option>`).join("");
            }

            countrySel.addEventListener("change", () => {
                const country = countrySel.value;
                resetState();
                resetCity();
                if (!country) return;

                if (stateSel) {
                    loading(stateSel, "Loading states…");
                    fetchStates(country)
                        .then(states => {
                            if (states.length) {
                                fillSelect(stateSel, states, "-- Select State --");
                            } else {
                                // Country has no states in dataset — let user type freely.
                                replaceWithText(stateSel, "State / Region");
                            }
                        })
                        .catch(() => replaceWithText(stateSel, "State / Region (type manually)"));
                } else if (citySel) {
                    // No state field — load cities for country directly via the all-cities endpoint.
                    loading(citySel, "Loading cities…");
                    fetch(FCP_GEO_API + "/cities", {
                        method: "POST", headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ country })
                    })
                    .then(r => r.json())
                    .then(d => fillSelect(citySel, d && d.data || [], "-- Select City --"))
                    .catch(() => replaceWithText(citySel, "City (type manually)"));
                }
            });

            if (stateSel) {
                stateSel.addEventListener("change", () => {
                    if (!citySel) return;
                    const country = countrySel.value;
                    const state   = stateSel.value;
                    if (!state) { resetCity(); return; }
                    loading(citySel, "Loading cities…");
                    fetchCities(country, state)
                        .then(cities => {
                            if (cities.length) fillSelect(citySel, cities, "-- Select City --");
                            else replaceWithText(citySel, "City (type manually)");
                        })
                        .catch(() => replaceWithText(citySel, "City (type manually)"));
                });
            }
        });

        // If a form has a state or city field without a country, fall back
        // to a plain text input so the user can still type a value.
        scope.querySelectorAll('[data-fcp-geo="state"]').forEach(sel => {
            const root = sel.closest("form") || sel.closest(".fc-form-public") || scope;
            if (!root.querySelector('[data-fcp-geo="country"]')) replaceWithText(sel, "State / Region");
        });
        scope.querySelectorAll('[data-fcp-geo="city"]').forEach(sel => {
            const root = sel.closest("form") || sel.closest(".fc-form-public") || scope;
            const hasCountry = root.querySelector('[data-fcp-geo="country"]');
            const hasState   = root.querySelector('[data-fcp-geo="state"]');
            if (!hasCountry && !hasState) replaceWithText(sel, "City");
        });

        function replaceWithText(sel, placeholder) {
            const input = document.createElement("input");
            input.type = "text";
            input.name = sel.name;
            input.placeholder = placeholder;
            sel.replaceWith(input);
        }
    }
    global.clearSignature = function (btn) {
        const c = btn.closest(".fc-field").querySelector(".signature-pad");
        if (c) {
            c.getContext("2d").clearRect(0, 0, c.width, c.height);
            delete c.dataset.fcpHasDrawing;
        }
    };

    global.FCFields = {
        FIELD_GROUPS,
        defaultsForType,
        renderInput,
        renderField,
        hydrate,
        typeLabel
    };
})(window);
