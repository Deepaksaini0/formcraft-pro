<?php
/**
 * Fires when the user deletes the plugin via the Plugins screen.
 * Creates a LAST-CHANCE backup to wp-content/uploads/formcraft-pro-backups/,
 * then drops the custom tables and removes the options.
 *
 * The backup dir lives OUTSIDE the plugin folder, so it survives this
 * uninstall and lets the admin restore everything after reinstall.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

/* ---------------- Last-chance backup ---------------- */

// The plugin folder still exists at uninstall time — WP hasn't deleted
// the files yet when it invokes this script. So we can safely load the
// backup class and its dependencies (constants, DB helper).
$plugin_dir = plugin_dir_path( __FILE__ );
$main       = $plugin_dir . 'formcraft-pro.php';
$backup_ok  = false;

if ( file_exists( $main ) ) {
    // Pull only the constants (define FCP_TABLE_* etc.) — safe to include
    // because we're already inside a WP context and the file is guarded by
    // ABSPATH. All the add_action / new-instance code at the bottom is
    // wrapped by hooks, so re-including here doesn't double-register.
    // We just need the DEFINEs and require_once chain to load the backup class.
    if ( ! defined( 'FCP_VERSION' ) ) {
        // Read + eval only the constants block. Simpler: just require the
        // file — the include is idempotent because everything is class-based
        // + defined() guarded.
        require_once $main;
    }
    if ( class_exists( 'FCP_Backup' ) ) {
        $result = FCP_Backup::create( 'before-uninstall' );
        if ( ! is_wp_error( $result ) ) {
            $backup_ok = true;
        } else {
            error_log( '[FormCraft Pro] Uninstall backup failed: ' . $result->get_error_message() );
        }
    }
}

/* ---------------- Drop tables + options ---------------- */

global $wpdb;
$prefix = $wpdb->prefix;

$tables = [
    'fcp_forms',
    'fcp_submissions',
    'fcp_mail_log',
    'fcp_coupons',
    'fcp_webhooks',
    'fcp_form_revisions',
    'fcp_step_events',
    'fcp_users',
];
foreach ( $tables as $t ) {
    $wpdb->query( "DROP TABLE IF EXISTS {$prefix}{$t}" );
}

// Delete all fcp_* options in one sweep.
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE 'fcp\\_%'" );

// Clear our transients.
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_fcp\\_%' OR option_name LIKE '\\_transient\\_timeout\\_fcp\\_%'" );

// Unschedule any of our cron events.
foreach ( [ 'fcp_backup_daily', 'fcp_abandon_recovery' ] as $hook ) {
    $ts = wp_next_scheduled( $hook );
    while ( $ts ) {
        wp_unschedule_event( $ts, $hook );
        $ts = wp_next_scheduled( $hook );
    }
}
