<?php
/**
 * FormCraft Pro - India Integrations Suite (v2.70).
 *
 * Five features tuned for the Indian market, each individually toggleable
 * on any form via form.settings.india.* flags:
 *
 *   1. IFSC bank lookup — proxy Razorpay's free public IFSC endpoint;
 *      autofills bank name / branch / city / state from the code.
 *   2. GST invoice generator — on paid submissions, produce a printable
 *      HTML invoice with CGST/SGST or IGST auto-split by state.
 *   3. WhatsApp Business alerts — send templated messages to buyer and/or
 *      admin via Meta Cloud API OR MSG91's WhatsApp channel.
 *   4. SMS alerts — MSG91 / TextLocal / Fast2SMS adapters, all speak the
 *      same interface.
 *   5. VAHAN vehicle lookup — proxy any pluggable VAHAN adapter (Surepass /
 *      Karza / Signzy / custom) so the visitor can autofill vehicle
 *      details from just the registration number.
 *
 * All outbound API keys live in ONE option (fcp_india_settings) and never
 * touch the browser — every hit goes through this class's REST proxies.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_India {

    const OPTION_KEY = 'fcp_india_settings';

    public static function bootstrap() {
        // Notification hooks fire on new submissions
        add_action( 'fcp_submission_created', [ __CLASS__, 'on_submission' ], 20, 4 );
        // Payment-verified fires on manual verify + auto-webhook success
        add_action( 'fcp_payment_verified',   [ __CLASS__, 'on_payment_verified' ], 20, 2 );
    }

    /* ---------------------------------------------------------------
     * Settings
     * ------------------------------------------------------------ */
    public static function get_settings() {
        $d = [
            'gst_invoice' => [
                'seller_name'    => '',
                'seller_gstin'   => '',
                'seller_state'   => '',
                'seller_address' => '',
                'invoice_prefix' => 'INV-',
                'invoice_counter'=> 1,
                'cgst_rate'      => 9,
                'sgst_rate'      => 9,
                'igst_rate'      => 18,
                'currency'       => 'INR',
                'footer_note'    => 'Thank you for your business.',
            ],
            'whatsapp' => [
                'provider'          => 'meta',   // 'meta' | 'msg91'
                'meta_phone_id'     => '',
                'meta_access_token' => '',
                'meta_template_buyer' => '',
                'meta_template_admin' => '',
                'meta_language'     => 'en',
                'msg91_authkey'     => '',
                'msg91_integrated_number' => '',
                'msg91_namespace'   => '',
                'msg91_template_buyer' => '',
                'msg91_template_admin' => '',
                'admin_phone'       => '',       // international format, e.g. 919876543210
            ],
            'sms' => [
                'provider'      => 'msg91',       // 'msg91' | 'textlocal' | 'fast2sms'
                'msg91_authkey' => '',
                'msg91_sender'  => 'FCPRO',
                'msg91_template_id' => '',        // DLT template id
                'textlocal_apikey' => '',
                'textlocal_sender' => 'FCPRO',
                'fast2sms_apikey' => '',
                'fast2sms_sender' => 'FCPRO',
                'fast2sms_route'  => 'dlt',
                'admin_phone'   => '',
            ],
            'vehicle' => [
                'provider'    => 'surepass',      // 'surepass' | 'custom'
                'surepass_token' => '',
                'custom_endpoint' => '',
                'custom_headers'  => '',          // JSON string
            ],
        ];
        $s = get_option( self::OPTION_KEY, [] );
        if ( ! is_array( $s ) ) $s = [];
        return array_replace_recursive( $d, $s );
    }

    public static function save_settings( $in ) {
        $c = self::get_settings();
        foreach ( [ 'gst_invoice', 'whatsapp', 'sms', 'vehicle' ] as $k ) {
            if ( isset( $in[ $k ] ) && is_array( $in[ $k ] ) ) {
                foreach ( $in[ $k ] as $kk => $vv ) {
                    if ( is_array( $vv ) ) $c[ $k ][ $kk ] = $vv;
                    elseif ( is_bool( $vv ) ) $c[ $k ][ $kk ] = $vv;
                    else $c[ $k ][ $kk ] = is_numeric( $vv ) ? $vv : sanitize_text_field( (string) $vv );
                }
            }
        }
        update_option( self::OPTION_KEY, $c );
        return self::get_settings();
    }

    /* ---------------------------------------------------------------
     * 1. IFSC Lookup — proxies https://ifsc.razorpay.com/{code}
     * ------------------------------------------------------------ */
    public static function lookup_ifsc( $code ) {
        $code = strtoupper( preg_replace( '/[^A-Z0-9]/', '', (string) $code ) );
        if ( ! preg_match( '/^[A-Z]{4}0[A-Z0-9]{6}$/', $code ) ) {
            return new WP_Error( 'bad_ifsc', 'Invalid IFSC format. Expected 11 chars: 4 letters + 0 + 6 alphanumerics.' );
        }
        // Cache hits for 30 days — IFSC data is essentially static.
        $cache_key = 'fcp_ifsc_' . $code;
        $hit = get_transient( $cache_key );
        if ( is_array( $hit ) ) return $hit;

        $res = wp_remote_get( 'https://ifsc.razorpay.com/' . rawurlencode( $code ), [ 'timeout' => 10 ] );
        if ( is_wp_error( $res ) ) return $res;
        $code_res = wp_remote_retrieve_response_code( $res );
        if ( $code_res !== 200 ) {
            return new WP_Error( 'not_found', 'IFSC not found. Check the code and try again.' );
        }
        $body = json_decode( wp_remote_retrieve_body( $res ), true );
        if ( ! is_array( $body ) ) return new WP_Error( 'bad_response', 'Bank service returned an unreadable response.' );
        $out = [
            'ifsc'    => (string) ( $body['IFSC']    ?? $code ),
            'bank'    => (string) ( $body['BANK']    ?? '' ),
            'branch'  => (string) ( $body['BRANCH']  ?? '' ),
            'address' => (string) ( $body['ADDRESS'] ?? '' ),
            'city'    => (string) ( $body['CITY']    ?? '' ),
            'district'=> (string) ( $body['DISTRICT']?? '' ),
            'state'   => (string) ( $body['STATE']   ?? '' ),
            'micr'    => (string) ( $body['MICR']    ?? '' ),
            'upi'     => ! empty( $body['UPI'] ),
            'imps'    => ! empty( $body['IMPS'] ),
            'neft'    => ! empty( $body['NEFT'] ),
            'rtgs'    => ! empty( $body['RTGS'] ),
        ];
        set_transient( $cache_key, $out, 30 * DAY_IN_SECONDS );
        return $out;
    }

    /* ---------------------------------------------------------------
     * 2. GST Invoice — renders self-contained printable HTML
     * ------------------------------------------------------------ */
    public static function generate_gst_invoice( $sub_id ) {
        global $wpdb;
        $sub = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . FCP_DB::subs_table() . " WHERE id = %d", (int) $sub_id
        ), ARRAY_A );
        if ( ! $sub ) return new WP_Error( 'not_found', 'Submission not found.' );

        $form = FCP_DB::get_form( (int) $sub['form_id'] );
        $data = is_string( $sub['data'] ) ? json_decode( $sub['data'], true ) : ( $sub['data'] ?? [] );
        if ( ! is_array( $data ) ) $data = [];

        $s = self::get_settings();
        $gst = $s['gst_invoice'];

        // Sequential invoice number
        $counter = (int) $gst['invoice_counter'];
        $invoice_no = $gst['invoice_prefix'] . str_pad( (string) $counter, 6, '0', STR_PAD_LEFT );

        $amount = (float) $sub['payment_amount'];
        // v2.70.6 — When the paid gateway path never ran (manual UPI / Bank /
        // COD), payment_amount is empty. Walk the form's fields to find the
        // picked Product / Pricing option and pull the price from its
        // config, so the invoice still shows a real amount.
        $line_items = self::build_line_items( $form, $data );
        if ( $amount <= 0 ) {
            $amount = array_reduce( $line_items, function ( $carry, $li ) { return $carry + (float) $li['amount']; }, 0.0 );
            if ( $amount <= 0 ) $amount = self::guess_amount_from_data( $data );
        }

        // Detect intra vs inter state — compare seller_state to buyer's state (from data)
        $buyer_state = self::detect_buyer_state( $data );
        $intrastate  = $buyer_state && $gst['seller_state']
                       && strcasecmp( trim( $buyer_state ), trim( $gst['seller_state'] ) ) === 0;

        $tax_base = $amount / ( 1 + ( ( $intrastate
            ? ( (float) $gst['cgst_rate'] + (float) $gst['sgst_rate'] )
            : (float) $gst['igst_rate'] ) / 100 ) );

        $cgst = $intrastate ? round( $tax_base * (float) $gst['cgst_rate'] / 100, 2 ) : 0;
        $sgst = $intrastate ? round( $tax_base * (float) $gst['sgst_rate'] / 100, 2 ) : 0;
        $igst = $intrastate ? 0 : round( $tax_base * (float) $gst['igst_rate'] / 100, 2 );
        $tax_base = round( $tax_base, 2 );

        $html = self::render_invoice_html( [
            'invoice_no'   => $invoice_no,
            'invoice_date' => date_i18n( 'd M Y' ),
            'seller_name'  => $gst['seller_name'],
            'seller_gstin' => $gst['seller_gstin'],
            'seller_state' => $gst['seller_state'],
            'seller_address' => $gst['seller_address'],
            'buyer_name'   => (string) ( $sub['submitter_name'] ?? '' ),
            'buyer_email'  => (string) ( $sub['submitter_email'] ?? '' ),
            'buyer_phone'  => self::extract_phone( $data ),
            'buyer_gstin'  => self::extract_gstin( $data ),
            'buyer_state'  => $buyer_state,
            'buyer_addr'   => self::extract_address( $data ),
            'form_title'   => (string) ( $form['title'] ?? 'Order' ),
            'line_items'   => $line_items,
            'currency'     => $gst['currency'] ?: 'INR',
            'tax_base'     => $tax_base,
            'cgst'         => $cgst,
            'sgst'         => $sgst,
            'igst'         => $igst,
            'cgst_rate'    => (float) $gst['cgst_rate'],
            'sgst_rate'    => (float) $gst['sgst_rate'],
            'igst_rate'    => (float) $gst['igst_rate'],
            'total'        => round( $amount, 2 ),
            'intrastate'   => $intrastate,
            'footer_note'  => $gst['footer_note'],
        ] );

        // Bump the counter only if a real download follows (do it here for
        // simplicity — admin can reset in settings if invoices went unsent).
        $s['gst_invoice']['invoice_counter'] = $counter + 1;
        update_option( self::OPTION_KEY, $s );

        return [
            'invoice_no' => $invoice_no,
            'html'       => $html,
            'amount'     => $amount,
            'tax_base'   => $tax_base,
            'cgst'       => $cgst,
            'sgst'       => $sgst,
            'igst'       => $igst,
        ];
    }

    private static function guess_amount_from_data( $data ) {
        foreach ( (array) $data as $k => $v ) {
            $lk = strtolower( (string) $k );
            if ( ( strpos( $lk, 'amount' ) !== false || strpos( $lk, 'total' ) !== false || strpos( $lk, 'price' ) !== false )
                 && is_numeric( str_replace( [ ',', ' ' ], '', (string) $v ) ) ) {
                return (float) str_replace( [ ',', ' ' ], '', (string) $v );
            }
        }
        return 0;
    }
    private static function detect_buyer_state( $data ) {
        foreach ( (array) $data as $k => $v ) {
            $lk = strtolower( (string) $k );
            if ( strpos( $lk, 'state' ) !== false && is_string( $v ) && $v ) return $v;
        }
        return '';
    }
    private static function extract_phone( $data ) {
        foreach ( [ 'phone', 'Phone', 'Mobile', 'mobile' ] as $k ) if ( ! empty( $data[ $k ] ) ) return (string) $data[ $k ];
        foreach ( (array) $data as $k => $v ) {
            $lk = strtolower( (string) $k );
            if ( ( strpos( $lk, 'phone' ) !== false || strpos( $lk, 'mobile' ) !== false ) && is_scalar( $v ) && $v ) return (string) $v;
        }
        return '';
    }
    private static function extract_address( $data ) {
        foreach ( (array) $data as $k => $v ) {
            $lk = strtolower( (string) $k );
            if ( strpos( $lk, 'address' ) !== false && is_scalar( $v ) && $v ) return (string) $v;
        }
        return '';
    }
    private static function extract_gstin( $data ) {
        foreach ( (array) $data as $k => $v ) {
            if ( is_string( $v ) && preg_match( '/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[0-9]{1}[A-Z]{1}[0-9A-Z]{1}$/', trim( $v ) ) ) {
                return trim( $v );
            }
        }
        return '';
    }

    /**
     * v2.70.6 — Walk the form's field definitions and produce line items
     * for anything the buyer picked. Returns array of
     * [ 'description' => 'Choose a Plan · Enterprise', 'amount' => 199 ].
     */
    private static function build_line_items( $form, $data ) {
        $items = [];
        if ( ! is_array( $form ) || empty( $form['steps'] ) ) return $items;
        foreach ( (array) $form['steps'] as $step ) {
            foreach ( (array) ( $step['fields'] ?? [] ) as $f ) {
                if ( ! is_array( $f ) || empty( $f['label'] ) ) continue;
                $label  = $f['label'];
                $picked = isset( $data[ $label ] ) ? $data[ $label ] : null;
                if ( $picked === null || $picked === '' ) continue;
                $type = $f['type'] ?? '';

                if ( $type === 'product' && ! empty( $f['products'] ) && is_array( $f['products'] ) ) {
                    foreach ( $f['products'] as $p ) {
                        if ( ! is_array( $p ) ) continue;
                        if ( strcasecmp( (string) ( $p['name'] ?? '' ), (string) $picked ) === 0 ) {
                            $items[] = [
                                'description' => sprintf( '%s · %s', $label, $p['name'] ),
                                'amount'      => (float) ( $p['price'] ?? 0 ),
                            ];
                            break;
                        }
                    }
                } elseif ( $type === 'pricing' && ! empty( $f['tiers'] ) && is_array( $f['tiers'] ) ) {
                    foreach ( $f['tiers'] as $t ) {
                        if ( ! is_array( $t ) ) continue;
                        if ( strcasecmp( (string) ( $t['name'] ?? '' ), (string) $picked ) === 0 ) {
                            $items[] = [
                                'description' => sprintf( '%s · %s', $label, $t['name'] ),
                                'amount'      => (float) ( $t['price'] ?? 0 ),
                            ];
                            break;
                        }
                    }
                } elseif ( $type === 'calculation' ) {
                    $n = (float) preg_replace( '/[^0-9.\-]/', '', (string) $picked );
                    if ( $n > 0 ) $items[] = [ 'description' => $label, 'amount' => $n ];
                }
            }
        }
        return $items;
    }

    private static function render_invoice_html( $a ) {
        // v2.70.6 — Fixed critical bug: $money closure was not capturing
        // $esc, causing "There has been a critical error" when the amount
        // cell tried to run. Explicitly capture both closures.
        $esc = function ( $v ) { return esc_html( (string) $v ); };
        $money = function ( $n ) use ( $a, $esc ) { return $esc( $a['currency'] . ' ' . number_format( (float) $n, 2 ) ); };
        ob_start(); ?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Invoice <?php echo $esc( $a['invoice_no'] ); ?></title>
<style>
    body { font-family: -apple-system, Segoe UI, Roboto, sans-serif; color:#0f172a; max-width:820px; margin:24px auto; padding:0 24px; line-height:1.55; }
    .head { display:flex; justify-content:space-between; align-items:flex-start; border-bottom:3px solid #6366f1; padding-bottom:14px; margin-bottom:20px; }
    .head h1 { margin:0; color:#6366f1; font-size:28px; letter-spacing:.5px; }
    .head .no { text-align:right; font-size:13px; color:#475569; }
    .head .no strong { display:block; font-size:16px; color:#0f172a; }
    .parties { display:grid; grid-template-columns:1fr 1fr; gap:18px; margin-bottom:20px; }
    .party h3 { margin:0 0 6px; font-size:11px; color:#94a3b8; letter-spacing:.6px; text-transform:uppercase; }
    .party .name { font-weight:700; font-size:15px; }
    .party .kv { font-size:12.5px; color:#475569; margin-top:2px; }
    table { width:100%; border-collapse:collapse; margin-bottom:14px; }
    th, td { padding:9px 12px; text-align:left; font-size:13px; }
    thead th { background:#f1f5f9; color:#334155; font-size:11px; letter-spacing:.4px; text-transform:uppercase; }
    tbody td { border-bottom:1px solid #e2e8f0; }
    tfoot td { font-weight:600; }
    .totals { margin-left:auto; width:320px; margin-top:12px; }
    .totals td { padding:6px 8px; font-size:13px; }
    .totals tr.grand td { font-size:16px; color:#0f172a; border-top:2px solid #0f172a; padding-top:10px; }
    .foot { margin-top:34px; padding-top:16px; border-top:1px solid #e2e8f0; font-size:12px; color:#94a3b8; }
    .print-btn { position:fixed; top:16px; right:16px; padding:10px 18px; background:#6366f1; color:#fff; border:0; border-radius:6px; font-weight:600; cursor:pointer; }
    @media print { .print-btn { display:none; } body { margin:0; } }
</style></head><body>
<button class="print-btn" onclick="window.print()">Save as PDF</button>
<div class="head">
    <h1>TAX INVOICE</h1>
    <div class="no">
        <strong>#<?php echo $esc( $a['invoice_no'] ); ?></strong>
        <?php echo $esc( $a['invoice_date'] ); ?>
    </div>
</div>
<div class="parties">
    <div class="party">
        <h3>Seller</h3>
        <div class="name"><?php echo $esc( $a['seller_name'] ); ?></div>
        <div class="kv">GSTIN: <?php echo $esc( $a['seller_gstin'] ); ?></div>
        <div class="kv">State: <?php echo $esc( $a['seller_state'] ); ?></div>
        <div class="kv"><?php echo nl2br( $esc( $a['seller_address'] ) ); ?></div>
    </div>
    <div class="party">
        <h3>Bill To</h3>
        <div class="name"><?php echo $esc( $a['buyer_name'] ); ?></div>
        <?php if ( $a['buyer_gstin'] ): ?><div class="kv">GSTIN: <?php echo $esc( $a['buyer_gstin'] ); ?></div><?php endif; ?>
        <?php if ( $a['buyer_state'] ): ?><div class="kv">State: <?php echo $esc( $a['buyer_state'] ); ?></div><?php endif; ?>
        <?php if ( $a['buyer_addr']  ): ?><div class="kv"><?php echo nl2br( $esc( $a['buyer_addr'] ) ); ?></div><?php endif; ?>
        <?php if ( $a['buyer_email'] ): ?><div class="kv"><?php echo $esc( $a['buyer_email'] ); ?></div><?php endif; ?>
        <?php if ( $a['buyer_phone'] ): ?><div class="kv"><?php echo $esc( $a['buyer_phone'] ); ?></div><?php endif; ?>
    </div>
</div>
<table>
    <thead><tr><th>Description</th><th style="text-align:right;">Taxable Amount</th></tr></thead>
    <tbody>
    <?php
        // v2.70.6 — Render one row per detected line item (product/pricing/
        // calculation the buyer picked). Falls back to the whole form title
        // with the computed tax_base when no line items are detectable.
        if ( ! empty( $a['line_items'] ) ) :
            // Distribute the tax removal proportionally so line-item amounts
            // sum to the tax_base (rather than the gross total).
            $sum_gross = 0;
            foreach ( $a['line_items'] as $li ) { $sum_gross += (float) $li['amount']; }
            $factor = ( $sum_gross > 0 && $a['tax_base'] > 0 ) ? ( $a['tax_base'] / $sum_gross ) : 1;
            foreach ( $a['line_items'] as $li ) :
                $li_taxable = round( ( (float) $li['amount'] ) * $factor, 2 );
    ?>
        <tr>
            <td><?php echo $esc( $li['description'] ); ?></td>
            <td style="text-align:right;"><?php echo $money( $li_taxable ); ?></td>
        </tr>
    <?php
            endforeach;
        else :
    ?>
        <tr>
            <td><?php echo $esc( $a['form_title'] ); ?></td>
            <td style="text-align:right;"><?php echo $money( $a['tax_base'] ); ?></td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
<table class="totals">
    <?php if ( $a['intrastate'] ) : ?>
        <tr><td>CGST (<?php echo $esc( $a['cgst_rate'] ); ?>%)</td><td style="text-align:right;"><?php echo $money( $a['cgst'] ); ?></td></tr>
        <tr><td>SGST (<?php echo $esc( $a['sgst_rate'] ); ?>%)</td><td style="text-align:right;"><?php echo $money( $a['sgst'] ); ?></td></tr>
    <?php else : ?>
        <tr><td>IGST (<?php echo $esc( $a['igst_rate'] ); ?>%)</td><td style="text-align:right;"><?php echo $money( $a['igst'] ); ?></td></tr>
    <?php endif; ?>
    <tr class="grand"><td>Grand Total</td><td style="text-align:right;"><?php echo $money( $a['total'] ); ?></td></tr>
</table>
<div class="foot"><?php echo $esc( $a['footer_note'] ); ?></div>
</body></html>
<?php
        return ob_get_clean();
    }

    /* ---------------------------------------------------------------
     * 3. WhatsApp Business alerts
     * ------------------------------------------------------------ */
    public static function send_whatsapp( $to_phone, $type, $vars ) {
        $s = self::get_settings();
        $w = $s['whatsapp'];
        $to_phone = self::normalize_phone_intl( $to_phone );
        if ( ! $to_phone ) return new WP_Error( 'bad_phone', 'Invalid phone number.' );
        if ( $w['provider'] === 'msg91' ) {
            return self::wa_msg91( $w, $to_phone, $type, $vars );
        }
        return self::wa_meta( $w, $to_phone, $type, $vars );
    }

    private static function wa_meta( $w, $to, $type, $vars ) {
        if ( empty( $w['meta_phone_id'] ) || empty( $w['meta_access_token'] ) ) {
            return new WP_Error( 'not_configured', 'WhatsApp (Meta) is not configured.' );
        }
        $template = $type === 'admin' ? $w['meta_template_admin'] : $w['meta_template_buyer'];
        if ( ! $template ) return new WP_Error( 'no_template', 'Template name is empty for ' . $type );
        // Template message with parameters
        $body_params = array_map( function ( $v ) { return [ 'type' => 'text', 'text' => (string) $v ]; }, array_values( $vars ) );
        $payload = [
            'messaging_product' => 'whatsapp',
            'to'                => $to,
            'type'              => 'template',
            'template'          => [
                'name'     => $template,
                'language' => [ 'code' => $w['meta_language'] ?: 'en' ],
                'components' => [
                    [ 'type' => 'body', 'parameters' => $body_params ],
                ],
            ],
        ];
        $res = wp_remote_post( 'https://graph.facebook.com/v20.0/' . rawurlencode( $w['meta_phone_id'] ) . '/messages', [
            'headers' => [ 'Authorization' => 'Bearer ' . $w['meta_access_token'], 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( $payload ),
            'timeout' => 20,
        ] );
        if ( is_wp_error( $res ) ) return $res;
        $code = wp_remote_retrieve_response_code( $res );
        $body = json_decode( wp_remote_retrieve_body( $res ), true );
        if ( $code >= 200 && $code < 300 ) return [ 'ok' => true, 'response' => $body ];
        return new WP_Error( 'meta_wa_failed', ( $body['error']['message'] ?? 'Meta API failed' ), [ 'response' => $body ] );
    }

    private static function wa_msg91( $w, $to, $type, $vars ) {
        if ( empty( $w['msg91_authkey'] ) || empty( $w['msg91_integrated_number'] ) ) {
            return new WP_Error( 'not_configured', 'WhatsApp (MSG91) is not configured.' );
        }
        $template_name = $type === 'admin' ? $w['msg91_template_admin'] : $w['msg91_template_buyer'];
        if ( ! $template_name ) return new WP_Error( 'no_template', 'Template name is empty for ' . $type );
        $body_components = [];
        $i = 1;
        foreach ( $vars as $v ) { $body_components[ 'body_' . $i++ ] = (string) $v; }
        $payload = [
            'integrated_number' => $w['msg91_integrated_number'],
            'content_type'      => 'template',
            'payload'           => [
                'messaging_product' => 'whatsapp',
                'type'              => 'template',
                'template'          => [
                    'name'     => $template_name,
                    'language' => [ 'code' => 'en', 'policy' => 'deterministic' ],
                    'namespace'=> $w['msg91_namespace'],
                    'to_and_components' => [
                        [ 'to' => [ $to ], 'components' => [ 'body_1' => [ 'type' => 'text', 'value' => implode( ' | ', array_values( $vars ) ) ] ] ],
                    ],
                ],
            ],
        ];
        $res = wp_remote_post( 'https://api.msg91.com/api/v5/whatsapp/whatsapp-outbound-message/bulk/', [
            'headers' => [ 'authkey' => $w['msg91_authkey'], 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( $payload ),
            'timeout' => 20,
        ] );
        if ( is_wp_error( $res ) ) return $res;
        $code = wp_remote_retrieve_response_code( $res );
        $body = json_decode( wp_remote_retrieve_body( $res ), true );
        if ( $code >= 200 && $code < 300 ) return [ 'ok' => true, 'response' => $body ];
        return new WP_Error( 'msg91_wa_failed', 'MSG91 WhatsApp API failed', [ 'response' => $body ] );
    }

    /* ---------------------------------------------------------------
     * 4. SMS alerts — MSG91 / TextLocal / Fast2SMS
     * ------------------------------------------------------------ */
    public static function send_sms( $to_phone, $message ) {
        $s = self::get_settings();
        $sms = $s['sms'];
        $to = self::normalize_phone_intl( $to_phone );
        if ( ! $to ) return new WP_Error( 'bad_phone', 'Invalid phone number.' );
        switch ( $sms['provider'] ) {
            case 'textlocal': return self::sms_textlocal( $sms, $to, $message );
            case 'fast2sms':  return self::sms_fast2sms( $sms, $to, $message );
            case 'msg91':
            default:          return self::sms_msg91( $sms, $to, $message );
        }
    }

    private static function sms_msg91( $sms, $to, $message ) {
        if ( empty( $sms['msg91_authkey'] ) ) return new WP_Error( 'not_configured', 'MSG91 authkey is empty.' );
        $payload = [
            'sender'      => $sms['msg91_sender'] ?: 'FCPRO',
            'route'       => '4',
            'country'     => '91',
            'sms'         => [ [ 'message' => $message, 'to' => [ ltrim( $to, '+' ) ] ] ],
        ];
        $res = wp_remote_post( 'https://api.msg91.com/api/v2/sendsms', [
            'headers' => [ 'authkey' => $sms['msg91_authkey'], 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( $payload ),
            'timeout' => 15,
        ] );
        return self::interpret_sms_response( $res, 'MSG91' );
    }

    private static function sms_textlocal( $sms, $to, $message ) {
        if ( empty( $sms['textlocal_apikey'] ) ) return new WP_Error( 'not_configured', 'TextLocal API key is empty.' );
        $res = wp_remote_post( 'https://api.textlocal.in/send/', [
            'body' => [
                'apikey'  => $sms['textlocal_apikey'],
                'numbers' => ltrim( $to, '+' ),
                'sender'  => $sms['textlocal_sender'] ?: 'FCPRO',
                'message' => $message,
            ],
            'timeout' => 15,
        ] );
        return self::interpret_sms_response( $res, 'TextLocal' );
    }

    private static function sms_fast2sms( $sms, $to, $message ) {
        if ( empty( $sms['fast2sms_apikey'] ) ) return new WP_Error( 'not_configured', 'Fast2SMS API key is empty.' );
        $payload = [
            'route'        => $sms['fast2sms_route'] ?: 'dlt',
            'sender_id'    => $sms['fast2sms_sender'] ?: 'FCPRO',
            'message'      => $message,
            'language'     => 'english',
            'flash'        => 0,
            'numbers'      => preg_replace( '/^\+?91/', '', $to ),
        ];
        $res = wp_remote_post( 'https://www.fast2sms.com/dev/bulkV2', [
            'headers' => [ 'authorization' => $sms['fast2sms_apikey'], 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( $payload ),
            'timeout' => 15,
        ] );
        return self::interpret_sms_response( $res, 'Fast2SMS' );
    }

    private static function interpret_sms_response( $res, $label ) {
        if ( is_wp_error( $res ) ) return $res;
        $code = wp_remote_retrieve_response_code( $res );
        $body = wp_remote_retrieve_body( $res );
        if ( $code >= 200 && $code < 300 ) return [ 'ok' => true, 'raw' => $body ];
        return new WP_Error( 'sms_failed', $label . ' failed: ' . substr( $body, 0, 200 ), [ 'status' => $code ] );
    }

    /* ---------------------------------------------------------------
     * 5. VAHAN Vehicle Lookup
     * ------------------------------------------------------------ */
    public static function lookup_vehicle( $reg_number ) {
        $reg = strtoupper( preg_replace( '/[^A-Z0-9]/', '', (string) $reg_number ) );
        if ( strlen( $reg ) < 6 || strlen( $reg ) > 12 ) {
            return new WP_Error( 'bad_reg', 'Invalid vehicle registration number.' );
        }
        $s = self::get_settings();
        $v = $s['vehicle'];
        // Cache the same reg for 12 hours
        $ck = 'fcp_vahan_' . $reg;
        $hit = get_transient( $ck );
        if ( is_array( $hit ) ) return $hit;

        if ( $v['provider'] === 'custom' ) {
            $out = self::vahan_custom( $v, $reg );
        } else {
            $out = self::vahan_surepass( $v, $reg );
        }
        if ( is_array( $out ) ) set_transient( $ck, $out, 12 * HOUR_IN_SECONDS );
        return $out;
    }

    private static function vahan_surepass( $v, $reg ) {
        if ( empty( $v['surepass_token'] ) ) return new WP_Error( 'not_configured', 'Surepass token is empty.' );
        $res = wp_remote_post( 'https://kyc-api.surepass.io/api/v1/rc/rc-full', [
            'headers' => [ 'Authorization' => 'Bearer ' . $v['surepass_token'], 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( [ 'id_number' => $reg ] ),
            'timeout' => 20,
        ] );
        if ( is_wp_error( $res ) ) return $res;
        $body = json_decode( wp_remote_retrieve_body( $res ), true );
        if ( empty( $body['data'] ) ) return new WP_Error( 'not_found', 'Vehicle not found or provider error.' );
        $d = $body['data'];
        return self::normalize_vahan( [
            'registration'    => $d['rc_number'] ?? $reg,
            'owner_name'      => $d['owner_name'] ?? '',
            'father_name'     => $d['father_name'] ?? '',
            'vehicle_class'   => $d['vehicle_category'] ?? '',
            'maker'           => $d['maker_description'] ?? ( $d['maker_model'] ?? '' ),
            'model'           => $d['maker_model'] ?? '',
            'fuel'            => $d['fuel_type'] ?? '',
            'colour'          => $d['colour'] ?? '',
            'registered_at'   => $d['registration_date'] ?? '',
            'insurance_valid' => $d['insurance_upto'] ?? '',
            'puc_valid'       => $d['pucc_upto'] ?? '',
            'rc_status'       => $d['rc_status'] ?? '',
        ] );
    }

    private static function vahan_custom( $v, $reg ) {
        if ( empty( $v['custom_endpoint'] ) ) return new WP_Error( 'not_configured', 'Custom endpoint is empty.' );
        $endpoint = str_replace( '{REG}', rawurlencode( $reg ), $v['custom_endpoint'] );
        $headers  = [];
        if ( ! empty( $v['custom_headers'] ) ) {
            $decoded = json_decode( $v['custom_headers'], true );
            if ( is_array( $decoded ) ) $headers = $decoded;
        }
        $res = wp_remote_get( $endpoint, [ 'headers' => $headers, 'timeout' => 20 ] );
        if ( is_wp_error( $res ) ) return $res;
        $body = json_decode( wp_remote_retrieve_body( $res ), true );
        return self::normalize_vahan( is_array( $body ) ? $body : [] );
    }

    private static function normalize_vahan( $raw ) {
        $keys = [ 'registration','owner_name','father_name','vehicle_class','maker','model','fuel','colour',
                  'registered_at','insurance_valid','puc_valid','rc_status' ];
        $out = [];
        foreach ( $keys as $k ) $out[ $k ] = (string) ( $raw[ $k ] ?? '' );
        return $out;
    }

    /* ---------------------------------------------------------------
     * Notification hooks — fire on submission / payment
     * ------------------------------------------------------------ */
    public static function on_submission( $sub_id, $form, $data, $is_spam = false ) {
        if ( $is_spam ) return; // Never notify on spam
        $flags = $form['settings']['india'] ?? [];
        if ( empty( $flags['enabled'] ) ) return;
        $s = self::get_settings();
        $buyer_name  = self::extract_first( $data, [ 'Full Name', 'Name', 'name', 'full_name', 'fullName' ], 'there' );
        $buyer_phone = self::extract_phone( $data );

        // Admin WhatsApp
        if ( ! empty( $flags['whatsapp_admin'] ) && ! empty( $s['whatsapp']['admin_phone'] ) ) {
            self::send_whatsapp( $s['whatsapp']['admin_phone'], 'admin', [
                (string) $form['title'], $buyer_name, $buyer_phone, admin_url( 'admin.php?page=formcraft-pro-submissions' ),
            ] );
        }
        // Buyer WhatsApp
        if ( ! empty( $flags['whatsapp_buyer'] ) && $buyer_phone ) {
            self::send_whatsapp( $buyer_phone, 'buyer', [
                $buyer_name, (string) $form['title'],
            ] );
        }
        // Admin SMS
        if ( ! empty( $flags['sms_admin'] ) && ! empty( $s['sms']['admin_phone'] ) ) {
            $msg = self::render_admin_message( $form, $data, $buyer_name, $buyer_phone );
            self::send_sms( $s['sms']['admin_phone'], $msg );
        }
        // Buyer SMS
        if ( ! empty( $flags['sms_buyer'] ) && $buyer_phone ) {
            $msg = self::render_buyer_message( $form, $buyer_name );
            self::send_sms( $buyer_phone, $msg );
        }
    }

    public static function on_payment_verified( $sub_id, $form ) {
        // GST invoice fires only after payment is confirmed
        $flags = $form['settings']['india'] ?? [];
        if ( empty( $flags['enabled'] ) || empty( $flags['gst_invoice'] ) ) return;
        // Auto-generate + attach to buyer email
        $res = self::generate_gst_invoice( $sub_id );
        if ( is_wp_error( $res ) ) return;
        // Store the invoice number on the submission's notes
        global $wpdb;
        $wpdb->update( FCP_DB::subs_table(), [ 'notes' => 'Invoice: ' . $res['invoice_no'] ], [ 'id' => (int) $sub_id ] );
    }

    private static function render_admin_message( $form, $data, $name, $phone ) {
        return sprintf(
            'FormCraft: New entry on "%s" from %s%s.',
            $form['title'] ?? 'Form',
            $name,
            $phone ? ' (' . $phone . ')' : ''
        );
    }
    private static function render_buyer_message( $form, $name ) {
        return sprintf(
            'Hi %s, we received your submission on "%s". We\'ll be in touch shortly. — %s',
            $name, $form['title'] ?? 'Form', get_bloginfo( 'name' )
        );
    }
    private static function extract_first( $data, $keys, $default = '' ) {
        foreach ( $keys as $k ) if ( ! empty( $data[ $k ] ) && is_scalar( $data[ $k ] ) ) return (string) $data[ $k ];
        return $default;
    }

    private static function normalize_phone_intl( $p ) {
        $p = preg_replace( '/[^0-9]/', '', (string) $p );
        if ( ! $p ) return '';
        if ( strlen( $p ) === 10 ) return '91' . $p;      // Indian numbers default
        return $p;
    }
}
