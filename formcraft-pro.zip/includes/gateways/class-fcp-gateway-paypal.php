<?php
/**
 * PayPal payment gateway adapter (Orders API v2).
 *
 * Flow:
 *   1) create_order() - POST /v2/checkout/orders → returns paypal order id
 *   2) Front-end opens PayPal Smart Buttons / Standard Checkout with that id
 *   3) On approval, PayPal returns the order id back
 *   4) verify_payment() - capture + verify the order
 *
 * Required $cfg fields:
 *   client_id
 *   client_secret
 *   webhook_id        (optional, for webhook signature verification)
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FCP_Gateway_PayPal extends FCP_Gateway_Base {

    public function slug() { return 'paypal'; }

    private function base_url() {
        return $this->test_mode
            ? 'https://api-m.sandbox.paypal.com'
            : 'https://api-m.paypal.com';
    }
    private function access_token() {
        $cached = get_transient( 'fcp_paypal_token_' . ( $this->test_mode ? 'sb' : 'live' ) );
        if ( $cached ) return $cached;

        $res = $this->http( $this->base_url() . '/v1/oauth2/token', [
            'method'  => 'POST',
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode( $this->cfg['client_id'] . ':' . $this->cfg['client_secret'] ),
                'Content-Type'  => 'application/x-www-form-urlencoded',
            ],
            'body'    => 'grant_type=client_credentials',
        ] );
        if ( is_wp_error( $res ) ) return $res;
        $token = isset( $res['access_token'] ) ? $res['access_token'] : '';
        if ( $token ) {
            set_transient( 'fcp_paypal_token_' . ( $this->test_mode ? 'sb' : 'live' ), $token, max( 60, ( $res['expires_in'] ?? 3600 ) - 60 ) );
        }
        return $token;
    }

    public function create_order( $args ) {
        if ( empty( $this->cfg['client_id'] ) || empty( $this->cfg['client_secret'] ) ) {
            return new WP_Error( 'config', 'PayPal credentials are not set in Payment Gateway settings.' );
        }
        $amount   = (float) ( $args['amount'] ?? 0 );
        $currency = isset( $args['currency'] ) ? strtoupper( $args['currency'] ) : 'USD';
        if ( $amount <= 0 ) return new WP_Error( 'bad_amount', 'Payment amount must be greater than zero.' );

        $token = $this->access_token();
        if ( is_wp_error( $token ) ) return $token;

        $payload = [
            'intent' => 'CAPTURE',
            'purchase_units' => [[
                'amount' => [
                    'currency_code' => $currency,
                    'value'         => number_format( $amount, 2, '.', '' ),
                ],
                'description' => isset( $args['name'] ) ? substr( $args['name'], 0, 127 ) : 'Form payment',
            ]],
        ];

        $res = $this->http( $this->base_url() . '/v2/checkout/orders', [
            'method'  => 'POST',
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ],
            'body'    => wp_json_encode( $payload ),
        ] );
        if ( is_wp_error( $res ) ) return $res;

        return [
            'provider' => 'paypal',
            'order_id' => $res['id'],
            'amount'   => $amount,
            'currency' => $currency,
            'checkout' => [
                'order_id'  => $res['id'],
                'client_id' => $this->cfg['client_id'],
                'mode'      => $this->test_mode ? 'sandbox' : 'production',
                'currency'  => $currency,
            ],
        ];
    }

    public function verify_payment( $args ) {
        $order_id = isset( $args['paypal_order_id'] ) ? $args['paypal_order_id'] : ( $args['order_id'] ?? '' );
        if ( ! $order_id ) return new WP_Error( 'bad_request', 'Missing PayPal order id.' );

        $token = $this->access_token();
        if ( is_wp_error( $token ) ) return $token;

        // Capture the order (if Smart Buttons already captured, this returns 422 — fall back to GET).
        $cap = $this->http( $this->base_url() . '/v2/checkout/orders/' . urlencode( $order_id ) . '/capture', [
            'method'  => 'POST',
            'headers' => [ 'Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json' ],
            'body'    => '{}',
        ] );
        if ( is_wp_error( $cap ) ) {
            // Probably already captured by front-end — read the order instead.
            $cap = $this->http( $this->base_url() . '/v2/checkout/orders/' . urlencode( $order_id ), [
                'headers' => [ 'Authorization' => 'Bearer ' . $token ],
            ] );
            if ( is_wp_error( $cap ) ) return $cap;
        }

        if ( ( $cap['status'] ?? '' ) !== 'COMPLETED' ) {
            return new WP_Error( 'payment_not_complete', 'PayPal order status: ' . ( $cap['status'] ?? 'unknown' ) );
        }
        $unit    = $cap['purchase_units'][0] ?? [];
        $capture = $unit['payments']['captures'][0] ?? [];
        return [
            'verified'   => true,
            'payment_id' => $capture['id'] ?? $order_id,
            'order_id'   => $order_id,
            'amount'     => (float) ( $capture['amount']['value'] ?? 0 ),
            'currency'   => $capture['amount']['currency_code'] ?? 'USD',
            'method'     => 'paypal',
            'email'      => $cap['payer']['email_address'] ?? '',
            'contact'    => '',
        ];
    }

    /**
     * v2.72 — PayPal refund via v2 Payments API. $payment_id here is the
     * capture id (what we save as payment_id after verify_payment).
     */
    public function refund( $payment_id, $amount = null ) {
        $token = $this->get_access_token();
        if ( is_wp_error( $token ) ) return $token;
        $body = [];
        if ( $amount !== null && $amount > 0 ) {
            $body['amount'] = [
                'value'         => number_format( (float) $amount, 2, '.', '' ),
                'currency_code' => $this->cfg['currency'] ?? 'USD',
            ];
        }
        $base = ! empty( $this->cfg['sandbox'] ) || $this->test_mode
            ? 'https://api-m.sandbox.paypal.com'
            : 'https://api-m.paypal.com';
        $res  = $this->http( $base . '/v2/payments/captures/' . rawurlencode( $payment_id ) . '/refund', [
            'method'  => 'POST',
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ],
            'body'    => $body ? wp_json_encode( $body ) : '',
        ] );
        if ( is_wp_error( $res ) ) return $res;
        return [ 'refund_id' => $res['id'] ?? '', 'status' => $res['status'] ?? 'PENDING' ];
    }
}
