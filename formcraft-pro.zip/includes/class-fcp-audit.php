<?php
/**
 * FormCraft Pro — Audit log.
 *
 * One row per "thing a privileged user did that someone might need to
 * answer for". Forensic + compliance use cases:
 *   - Who deleted submission #4231 yesterday?
 *   - Did anyone change the GDPR retention to 0 days?
 *   - When was API token "Zapier" minted, and by whom?
 *
 * Always-on. Calls are write-only fire-and-forget — a failed log row
 * MUST NOT abort the originating action (a corrupt audit table can't
 * brick the plugin). Reads are paginated + filterable from the
 * audit-log admin page.
 *
 * Action vocabulary — small, stable, machine-friendly:
 *   form_created · form_updated · form_deleted · form_status_changed
 *   submission_deleted · submission_edited · submission_status_changed · submission_exported
 *   settings_changed
 *   token_created · token_revoked
 *   2fa_enabled · 2fa_disabled · 2fa_backup_used · 2fa_failed
 *   integration_connected · integration_disconnected
 *   user_data_erased
 *   pii_field_viewed (only logged when the field is access-controlled)
 *
 * Before/after snapshots are stored as JSON, capped at 4KB each so a
 * giant form schema doesn't bloat the table. Anything bigger is replaced
 * with `{"_truncated": true, "_size": N}`.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_Audit {

    const TABLE   = 'fcp_audit_log';
    const MAX_LEN = 4096;

    public static function table() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE;
    }

    public static function install_table() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $table   = self::table();
        $sql     = "CREATE TABLE $table (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED DEFAULT NULL,
            user_login VARCHAR(60) DEFAULT NULL,
            action VARCHAR(48) NOT NULL,
            target_type VARCHAR(32) DEFAULT NULL,
            target_id VARCHAR(64) DEFAULT NULL,
            before_data MEDIUMTEXT,
            after_data MEDIUMTEXT,
            ip VARCHAR(45) DEFAULT NULL,
            user_agent VARCHAR(255) DEFAULT NULL,
            created_at DATETIME NOT NULL,
            KEY action (action),
            KEY user_id (user_id),
            KEY target (target_type, target_id),
            KEY created_at (created_at)
        ) $charset;";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    /**
     * Single entry point. Pass null for before/after when not applicable.
     * Silently swallows DB errors — never aborts the caller.
     */
    public static function log( $action, $target_type = null, $target_id = null, $before = null, $after = null ) {
        try {
            global $wpdb;
            $u = wp_get_current_user();
            $wpdb->insert( self::table(), [
                'user_id'     => $u && $u->ID ? (int) $u->ID : null,
                'user_login'  => $u && $u->user_login ? $u->user_login : null,
                'action'      => substr( (string) $action, 0, 48 ),
                'target_type' => $target_type ? substr( (string) $target_type, 0, 32 ) : null,
                'target_id'   => $target_id   ? substr( (string) $target_id, 0, 64 ) : null,
                'before_data' => self::pack( $before ),
                'after_data'  => self::pack( $after ),
                'ip'          => isset( $_SERVER['REMOTE_ADDR'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ), 0, 45 ) : null,
                'user_agent'  => isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 0, 255 ) : null,
                'created_at'  => current_time( 'mysql' ),
            ] );
        } catch ( Throwable $e ) {
            // Audit must never break the action that called it.
        }
    }

    private static function pack( $val ) {
        if ( $val === null ) return null;
        $json = wp_json_encode( $val );
        if ( strlen( $json ) > self::MAX_LEN ) {
            return wp_json_encode( [ '_truncated' => true, '_size' => strlen( $json ) ] );
        }
        return $json;
    }

    /* -----------------------------------------------------------------
     * Reader — filtered, paginated. Returns [ rows, total ].
     * -----------------------------------------------------------------*/
    public static function query( $args = [] ) {
        global $wpdb;
        $args = wp_parse_args( $args, [
            'action'      => '',
            'user_id'     => 0,
            'target_type' => '',
            'since'       => '',
            'until'       => '',
            'page'        => 1,
            'per_page'    => 50,
        ] );
        $where = [];
        // v2.72.3 — Action filter uses LIKE so "form" matches "form_updated",
        // "form_deleted", "form_created" — instead of only exact strings.
        if ( $args['action'] )      $where[] = $wpdb->prepare( 'action LIKE %s', '%' . $wpdb->esc_like( $args['action'] ) . '%' );
        if ( $args['user_id'] )     $where[] = $wpdb->prepare( 'user_id = %d', $args['user_id'] );
        if ( $args['target_type'] ) $where[] = $wpdb->prepare( 'target_type = %s', $args['target_type'] );
        if ( $args['since'] )       $where[] = $wpdb->prepare( 'created_at >= %s', $args['since'] );
        if ( $args['until'] )       $where[] = $wpdb->prepare( 'created_at <= %s', $args['until'] );
        $where_sql = $where ? 'WHERE ' . implode( ' AND ', $where ) : '';
        $per       = max( 1, min( 200, (int) $args['per_page'] ) );
        $off       = max( 0, ( max( 1, (int) $args['page'] ) - 1 ) * $per );
        $table     = self::table();
        $rows      = $wpdb->get_results( "SELECT * FROM $table $where_sql ORDER BY id DESC LIMIT $per OFFSET $off", ARRAY_A );
        $total     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table $where_sql" );
        return [ 'rows' => $rows ?: [], 'total' => $total ];
    }

    public static function action_summary( $since_days = 30 ) {
        global $wpdb;
        $since = gmdate( 'Y-m-d H:i:s', time() - $since_days * 86400 );
        $rows  = $wpdb->get_results( $wpdb->prepare(
            "SELECT action, COUNT(*) AS n FROM " . self::table() . " WHERE created_at >= %s GROUP BY action ORDER BY n DESC",
            $since
        ), ARRAY_A );
        return $rows ?: [];
    }
}
