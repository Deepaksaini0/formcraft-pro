<?php
/**
 * FormCraft Pro - Integrations dispatcher.
 *
 * Centralises every outbound call to a third-party service triggered by a
 * form event (submission received, payment confirmed, spam detected). It
 * walks the wp_fcp_webhooks table for matching rows + calls each enabled
 * adapter (Mailchimp, HubSpot, Slack) once.
 *
 * Adapters are intentionally inline (not separate classes) because they
 * are short, well-isolated, and never share state. If any one grows past
 * ~60 lines, split it out then.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_Integrations {

    /**
     * Default args for outbound integration POSTs. `blocking => false`
     * tells WordPress to fire the request and return without waiting
     * for the response — the form submission completes in milliseconds
     * instead of waiting on every Mailchimp / HubSpot / Slack / Airtable
     * API in serial. We sacrifice failure-logging on the rare case where
     * an integration's API is down, but the speed win is worth it (the
     * webhooks table still stores last_status/last_error for blocking
     * webhooks the admin set up explicitly).
     */
    private static function async_args( $extra = [] ) {
        return array_replace_recursive( [
            'timeout'   => 4,      // hard cap when blocking
            'blocking'  => false,  // fire-and-forget
            'sslverify' => true,
        ], $extra );
    }

    /**
     * Fire all integrations matching the given event for this form.
     *
     * @param string $event       One of: 'submission' | 'payment' | 'spam'
     * @param array  $form        Hydrated form row.
     * @param array  $clean_data  Sanitised submission data.
     * @param int    $sid         Submission id.
     * @param array  $context     Optional: payment + coupon info.
     */
    public static function fire( $event, $form, $clean_data, $sid, $context = [] ) {
        $payload = self::build_payload( $event, $form, $clean_data, $sid, $context );

        // 1. Custom webhooks (also covers Zapier / Make / Slack-as-webhook).
        $form_id = isset( $form['id'] ) ? (int) $form['id'] : 0;
        $hooks   = FCP_DB::get_webhooks( [ 'event' => $event, 'status' => 'active', 'form_id' => $form_id ] );
        foreach ( $hooks as $hook ) {
            self::dispatch_webhook( $hook, $payload );
        }

        // 2. Native adapters (Mailchimp / HubSpot / Slack incoming-webhook).
        if ( $event === 'submission' ) {
            $settings = get_option( 'fcp_settings', [] );
            $ints     = isset( $settings['integrations'] ) && is_array( $settings['integrations'] ) ? $settings['integrations'] : [];

            if ( ! empty( $ints['mailchimp']['enabled'] ) && ! empty( $ints['mailchimp']['api_key'] ) ) {
                self::push_mailchimp( $ints['mailchimp'], $payload );
            }
            if ( ! empty( $ints['hubspot']['enabled'] ) && ! empty( $ints['hubspot']['api_token'] ) ) {
                self::push_hubspot( $ints['hubspot'], $payload );
            }
            if ( ! empty( $ints['slack']['enabled'] ) && ! empty( $ints['slack']['webhook_url'] ) ) {
                self::push_slack( $ints['slack'], $payload );
            }
            if ( ! empty( $ints['activecampaign']['enabled'] ) && ! empty( $ints['activecampaign']['api_key'] ) ) {
                self::push_activecampaign( $ints['activecampaign'], $payload );
            }
            if ( ! empty( $ints['convertkit']['enabled'] ) && ! empty( $ints['convertkit']['api_key'] ) ) {
                self::push_convertkit( $ints['convertkit'], $payload );
            }
            if ( ! empty( $ints['salesforce']['enabled'] ) && ! empty( $ints['salesforce']['refresh_token'] ) ) {
                self::push_salesforce( $ints['salesforce'], $payload );
            }
            if ( ! empty( $ints['zoho_crm']['enabled'] ) && ! empty( $ints['zoho_crm']['refresh_token'] ) ) {
                self::push_zoho_crm( $ints['zoho_crm'], $payload );
            }
            if ( ! empty( $ints['dropbox']['enabled'] ) && ! empty( $ints['dropbox']['access_token'] ) ) {
                self::push_dropbox( $ints['dropbox'], $payload, $form, $clean_data );
            }
            if ( ! empty( $ints['google_drive']['enabled'] ) && ! empty( $ints['google_drive']['refresh_token'] ) ) {
                self::push_google_drive( $ints['google_drive'], $payload, $form, $clean_data );
            }
            // v2.70.14 — Google Sheets append. Uses service-account auth
            // (no user OAuth callback). Admin shares the target sheet with
            // the service account's client_email and pastes the JSON key.
            if ( ! empty( $ints['google_sheets']['enabled'] )
                 && ! empty( $ints['google_sheets']['client_email'] )
                 && ! empty( $ints['google_sheets']['private_key'] )
                 && ! empty( $ints['google_sheets']['spreadsheet_id'] ) ) {
                self::push_google_sheets( $ints['google_sheets'], $form, $payload );
            }
            // v2.70.15 — Discord webhook. Zero config besides pasting the
            // webhook URL from Discord → Server Settings → Integrations.
            if ( ! empty( $ints['discord']['enabled'] ) && ! empty( $ints['discord']['webhook_url'] ) ) {
                self::push_discord( $ints['discord'], $form, $payload );
            }
            // v2.70.15 — Telegram bot. Requires a bot token from @BotFather
            // and the chat_id (get it from https://api.telegram.org/bot<TOKEN>/getUpdates
            // after messaging your bot once, or use @userinfobot).
            if ( ! empty( $ints['telegram']['enabled'] ) && ! empty( $ints['telegram']['bot_token'] ) && ! empty( $ints['telegram']['chat_id'] ) ) {
                self::push_telegram( $ints['telegram'], $form, $payload );
            }
            // v2.72 — Microsoft Teams webhook (same pattern as Discord)
            if ( ! empty( $ints['msteams']['enabled'] ) && ! empty( $ints['msteams']['webhook_url'] ) ) {
                self::push_msteams( $ints['msteams'], $form, $payload );
            }
            // v2.72 — Box cloud storage (uploads submission JSON + file URLs)
            if ( ! empty( $ints['box']['enabled'] ) && ! empty( $ints['box']['access_token'] ) ) {
                self::push_box( $ints['box'], $payload, $form, $clean_data );
            }
            if ( ! empty( $ints['brevo']['enabled'] ) && ! empty( $ints['brevo']['api_key'] ) ) {
                self::push_brevo( $ints['brevo'], $payload );
            }
            if ( ! empty( $ints['aweber']['enabled'] ) && ! empty( $ints['aweber']['access_token'] ) ) {
                self::push_aweber( $ints['aweber'], $payload );
            }
            if ( ! empty( $ints['campaign_monitor']['enabled'] ) && ! empty( $ints['campaign_monitor']['api_key'] ) ) {
                self::push_campaign_monitor( $ints['campaign_monitor'], $payload );
            }
            if ( ! empty( $ints['breeze']['enabled'] ) && ! empty( $ints['breeze']['webhook_url'] ) ) {
                self::push_breeze( $ints['breeze'], $payload );
            }
            if ( ! empty( $ints['agile_crm']['enabled'] ) && ! empty( $ints['agile_crm']['api_key'] ) ) {
                self::push_agile_crm( $ints['agile_crm'], $payload );
            }
            if ( ! empty( $ints['mailgun']['enabled'] ) && ! empty( $ints['mailgun']['api_key'] ) ) {
                self::send_transactional_email( 'mailgun', $ints['mailgun'], $payload );
            }
            if ( ! empty( $ints['postmark']['enabled'] ) && ! empty( $ints['postmark']['server_token'] ) ) {
                self::send_transactional_email( 'postmark', $ints['postmark'], $payload );
            }
            if ( ! empty( $ints['sendgrid']['enabled'] ) && ! empty( $ints['sendgrid']['api_key'] ) ) {
                self::send_transactional_email( 'sendgrid', $ints['sendgrid'], $payload );
            }
            // Airtable — global gate is the personal access token; per-form
            // base/table/field-mapping lives on the form itself (under
            // settings.afterSubmit.airtable) so different forms can write
            // to different Airtable tables.
            if ( ! empty( $ints['airtable']['enabled'] ) && ! empty( $ints['airtable']['pat'] ) ) {
                self::push_airtable( $ints['airtable'], $form, $payload );
            }

            // v2.56 — Generic dispatcher for all new integrations. Each
            // entry: [setting_key, required_field, push_method]. Keeps
            // the dispatch list one-line-per-platform instead of a wall
            // of identical if blocks.
            $dispatch_map = [
                // CRMs
                [ 'pipedrive',      'api_token',   'push_pipedrive'     ],
                [ 'close_crm',      'api_key',     'push_close_crm'     ],
                [ 'copper',         'api_key',     'push_copper'        ],
                [ 'freshsales',     'api_key',     'push_freshsales'    ],
                // Marketing
                [ 'drip',           'api_token',   'push_drip'          ],
                [ 'klaviyo',        'api_key',     'push_klaviyo'       ],
                // Project mgmt
                [ 'trello',         'api_key',     'push_trello'        ],
                [ 'asana',          'pat',         'push_asana'         ],
                [ 'clickup',        'api_token',   'push_clickup'       ],
                [ 'linear',         'api_key',     'push_linear'        ],
                [ 'notion',         'api_token',   'push_notion'        ],
                [ 'monday',         'api_token',   'push_monday'        ],
                // Automation (these are essentially webhooks with extras)
                [ 'make',           'webhook_url', 'push_make'          ],
                [ 'n8n',            'webhook_url', 'push_n8n'           ],
                [ 'pabbly',         'webhook_url', 'push_pabbly'        ],
                // Comms — Teams native (Graph) vs webhook is already done.
                [ 'ms_teams',       'webhook_url', 'push_ms_teams'      ],
                // Calendar
                [ 'calendly',       'api_token',   'push_calendly'      ],
                [ 'savvycal',       'api_key',     'push_savvycal'      ],
                [ 'cal_com',        'api_key',     'push_cal_com'       ],
                // E-signature (envelope creation — needs OAuth, ships as stub
                // that POSTs document URL + signer to provider's REST API).
                [ 'docusign',       'access_token','push_docusign'      ],
                [ 'hellosign',      'api_key',     'push_hellosign'     ],
                // Storage (file routing — POSTs uploaded file URLs)
                [ 'onedrive',       'access_token','push_onedrive'      ],
                // AI
                [ 'openai',         'api_key',     'push_openai'        ],
                [ 'anthropic',      'api_key',     'push_anthropic'     ],
                // Payments — these record receipt/order metadata rather
                // than do checkout. Real checkout uses FCP_Payment.
                [ 'square',         'access_token','push_square'        ],
                [ 'mollie',         'api_key',     'push_mollie'        ],
                [ 'gocardless',     'access_token','push_gocardless'    ],
            ];
            foreach ( $dispatch_map as $row ) {
                list( $key, $required, $method ) = $row;
                if ( ! empty( $ints[ $key ]['enabled'] )
                     && ! empty( $ints[ $key ][ $required ] )
                     && method_exists( __CLASS__, $method ) ) {
                    try {
                        self::$method( $ints[ $key ], $payload, $form, $clean_data );
                    } catch ( \Throwable $e ) {
                        error_log( "[FormCraft Integrations] {$key} failed: " . $e->getMessage() );
                    }
                }
            }

            // Ad platforms + social posting + messaging — all routed
            // through one registry-driven dispatcher so per-platform code
            // stays out of this file. See class-fcp-ad-platforms.php.
            if ( class_exists( 'FCP_Ad_Platforms' ) ) {
                FCP_Ad_Platforms::fire( $form, $clean_data, $sid );
            }
        }
    }

    /* ===================================================================
     * v2.56 — New integration adapters.
     * Each method follows the same shape: take ($cfg, $payload, $form?,
     * $clean_data?), extract the relevant fields, POST to the platform's
     * REST API with the admin-configured API key. Async-safe (8s timeout,
     * sslverify on). When the platform requires OAuth, the method assumes
     * the admin has already obtained an access token via setup steps.
     * =================================================================== */

    /* ---- CRMs ---- */

    /** Pipedrive — creates a Person (the lead). */
    public static function push_pipedrive( $cfg, $payload ) {
        $tok = trim( $cfg['api_token'] ?? '' );
        $sub = trim( $cfg['company_domain'] ?? 'api' );
        if ( ! $tok ) return;
        $d = $payload['submission']['data'] ?? [];
        $email = self::pick_email( $d );
        $name  = self::pick_name( $d ) ?: $email;
        if ( ! $email && ! $name ) return;
        $url  = 'https://' . $sub . '.pipedrive.com/api/v1/persons?api_token=' . rawurlencode( $tok );
        $body = [
            'name'  => $name,
            'email' => array_filter( [ $email ] ),
            'phone' => array_filter( [ self::pick_phone( $d ) ] ),
            'visible_to' => 3,
        ];
        wp_remote_post( $url, [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [ 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( $body ),
        ] );
    }

    /** Close.com — creates a Lead. */
    public static function push_close_crm( $cfg, $payload ) {
        $key = trim( $cfg['api_key'] ?? '' );
        if ( ! $key ) return;
        $d = $payload['submission']['data'] ?? [];
        $email = self::pick_email( $d );
        if ( ! $email ) return;
        wp_remote_post( 'https://api.close.com/api/v1/lead/', [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode( $key . ':' ),
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( [
                'name' => self::pick_name( $d ) ?: $email,
                'contacts' => [[
                    'name'   => self::pick_name( $d ),
                    'emails' => [[ 'email' => $email, 'type' => 'office' ]],
                    'phones' => array_filter([[ 'phone' => self::pick_phone( $d ), 'type' => 'office' ]], fn($p) => ! empty( $p['phone'] ) ),
                ]],
            ] ),
        ] );
    }

    /** Copper CRM — creates a Person. */
    public static function push_copper( $cfg, $payload ) {
        $key   = trim( $cfg['api_key']        ?? '' );
        $email = trim( $cfg['account_email']  ?? '' );
        if ( ! $key || ! $email ) return;
        $d = $payload['submission']['data'] ?? [];
        $sender = self::pick_email( $d );
        if ( ! $sender ) return;
        wp_remote_post( 'https://api.copper.com/developer_api/v1/people', [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [
                'X-PW-AccessToken'  => $key,
                'X-PW-Application'  => 'developer_api',
                'X-PW-UserEmail'    => $email,
                'Content-Type'      => 'application/json',
            ],
            'body' => wp_json_encode( [
                'name'   => self::pick_name( $d ) ?: $sender,
                'emails' => [[ 'email' => $sender, 'category' => 'work' ]],
                'phone_numbers' => array_filter([[ 'number' => self::pick_phone( $d ), 'category' => 'work' ]], fn($p) => ! empty( $p['number'] ) ),
            ] ),
        ] );
    }

    /** Freshsales — creates a Contact. */
    public static function push_freshsales( $cfg, $payload ) {
        $key = trim( $cfg['api_key']  ?? '' );
        $sub = trim( $cfg['bundle']   ?? '' );  // e.g. "acme" → acme.myfreshworks.com
        if ( ! $key || ! $sub ) return;
        $d = $payload['submission']['data'] ?? [];
        $email = self::pick_email( $d );
        if ( ! $email ) return;
        $name = self::pick_name( $d );
        wp_remote_post( 'https://' . $sub . '.myfreshworks.com/crm/sales/api/contacts', [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [
                'Authorization' => 'Token token=' . $key,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( [ 'contact' => [
                'first_name' => self::first_name( $name ),
                'last_name'  => self::last_name( $name ),
                'email'      => $email,
                'mobile_number' => self::pick_phone( $d ),
            ] ] ),
        ] );
    }

    /* ---- Marketing ---- */

    /** Drip — adds/updates a subscriber. */
    public static function push_drip( $cfg, $payload ) {
        $tok = trim( $cfg['api_token'] ?? '' );
        $aid = trim( $cfg['account_id'] ?? '' );
        if ( ! $tok || ! $aid ) return;
        $d = $payload['submission']['data'] ?? [];
        $email = self::pick_email( $d );
        if ( ! $email ) return;
        wp_remote_post( 'https://api.getdrip.com/v2/' . rawurlencode( $aid ) . '/subscribers', [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode( $tok . ':' ),
                'Content-Type'  => 'application/vnd.api+json',
            ],
            'body' => wp_json_encode( [ 'subscribers' => [[
                'email'      => $email,
                'first_name' => self::first_name( self::pick_name( $d ) ),
                'last_name'  => self::last_name(  self::pick_name( $d ) ),
            ]] ] ),
        ] );
    }

    /** Klaviyo — adds a profile, optionally to a list. */
    public static function push_klaviyo( $cfg, $payload ) {
        $key = trim( $cfg['api_key'] ?? '' );           // private API key (pk_...)
        $list = trim( $cfg['list_id'] ?? '' );
        if ( ! $key ) return;
        $d = $payload['submission']['data'] ?? [];
        $email = self::pick_email( $d );
        if ( ! $email ) return;
        $name = self::pick_name( $d );
        $body = [ 'data' => [
            'type' => 'profile',
            'attributes' => [
                'email'      => $email,
                'first_name' => self::first_name( $name ),
                'last_name'  => self::last_name( $name ),
                'phone_number' => self::pick_phone( $d ),
            ],
        ] ];
        wp_remote_post( 'https://a.klaviyo.com/api/profiles/', [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [
                'Authorization' => 'Klaviyo-API-Key ' . $key,
                'revision'      => '2024-02-15',
                'Content-Type'  => 'application/json',
                'accept'        => 'application/json',
            ],
            'body' => wp_json_encode( $body ),
        ] );
    }

    /* ---- Project management ---- */

    /** Trello — creates a card. */
    public static function push_trello( $cfg, $payload ) {
        $key = trim( $cfg['api_key'] ?? '' );
        $tok = trim( $cfg['token'] ?? '' );
        $list= trim( $cfg['list_id'] ?? '' );
        if ( ! $key || ! $tok || ! $list ) return;
        wp_remote_post( 'https://api.trello.com/1/cards', [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [ 'Content-Type' => 'application/x-www-form-urlencoded' ],
            'body' => http_build_query([
                'key'   => $key,
                'token' => $tok,
                'idList'=> $list,
                'name'  => self::card_title( $payload ),
                'desc'  => self::card_body( $payload ),
            ]),
        ] );
    }

    /** Asana — creates a task. */
    public static function push_asana( $cfg, $payload ) {
        $pat     = trim( $cfg['pat'] ?? '' );           // personal access token
        $project = trim( $cfg['project_id'] ?? '' );
        if ( ! $pat || ! $project ) return;
        wp_remote_post( 'https://app.asana.com/api/1.0/tasks', [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [
                'Authorization' => 'Bearer ' . $pat,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( [ 'data' => [
                'name'     => self::card_title( $payload ),
                'notes'    => self::card_body( $payload ),
                'projects' => [ $project ],
            ] ] ),
        ] );
    }

    /** ClickUp — creates a task. */
    public static function push_clickup( $cfg, $payload ) {
        $tok  = trim( $cfg['api_token'] ?? '' );
        $list = trim( $cfg['list_id'] ?? '' );
        if ( ! $tok || ! $list ) return;
        wp_remote_post( 'https://api.clickup.com/api/v2/list/' . rawurlencode( $list ) . '/task', [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [
                'Authorization' => $tok,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( [
                'name'        => self::card_title( $payload ),
                'description' => self::card_body( $payload ),
            ] ),
        ] );
    }

    /** Linear — creates an issue via GraphQL. */
    public static function push_linear( $cfg, $payload ) {
        $key  = trim( $cfg['api_key'] ?? '' );
        $team = trim( $cfg['team_id'] ?? '' );
        if ( ! $key || ! $team ) return;
        $query = 'mutation IssueCreate($input: IssueCreateInput!) { issueCreate(input: $input) { issue { id identifier } } }';
        wp_remote_post( 'https://api.linear.app/graphql', [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [
                'Authorization' => $key,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( [
                'query' => $query,
                'variables' => [ 'input' => [
                    'teamId'      => $team,
                    'title'       => self::card_title( $payload ),
                    'description' => self::card_body( $payload ),
                ] ],
            ] ),
        ] );
    }

    /** Notion — creates a page in a database. */
    public static function push_notion( $cfg, $payload ) {
        $tok = trim( $cfg['api_token'] ?? '' );
        $db  = trim( $cfg['database_id'] ?? '' );
        if ( ! $tok || ! $db ) return;
        $title_prop = $cfg['title_property'] ?? 'Name';
        wp_remote_post( 'https://api.notion.com/v1/pages', [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [
                'Authorization'  => 'Bearer ' . $tok,
                'Notion-Version' => '2022-06-28',
                'Content-Type'   => 'application/json',
            ],
            'body' => wp_json_encode( [
                'parent' => [ 'database_id' => $db ],
                'properties' => [
                    $title_prop => [
                        'title' => [[ 'text' => [ 'content' => self::card_title( $payload ) ] ]],
                    ],
                ],
                'children' => [[
                    'object' => 'block',
                    'type'   => 'paragraph',
                    'paragraph' => [ 'rich_text' => [[ 'type' => 'text', 'text' => [ 'content' => self::card_body( $payload ) ] ]] ],
                ]],
            ] ),
        ] );
    }

    /** Monday.com — creates an item via GraphQL. */
    public static function push_monday( $cfg, $payload ) {
        $tok   = trim( $cfg['api_token'] ?? '' );
        $board = trim( $cfg['board_id'] ?? '' );
        if ( ! $tok || ! $board ) return;
        $query = 'mutation ($board: ID!, $name: String!) { create_item (board_id: $board, item_name: $name) { id } }';
        wp_remote_post( 'https://api.monday.com/v2', [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [
                'Authorization' => $tok,
                'Content-Type'  => 'application/json',
                'API-Version'   => '2024-01',
            ],
            'body' => wp_json_encode( [
                'query' => $query,
                'variables' => [
                    'board' => $board,
                    'name'  => self::card_title( $payload ),
                ],
            ] ),
        ] );
    }

    /* ---- Automation platforms (variants of webhooks) ---- */

    public static function push_make( $cfg, $payload ) {
        wp_remote_post( $cfg['webhook_url'], [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [ 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( $payload ),
        ] );
    }
    public static function push_n8n( $cfg, $payload )    { self::push_make( $cfg, $payload ); }
    public static function push_pabbly( $cfg, $payload ) { self::push_make( $cfg, $payload ); }

    /* ---- Microsoft Teams native via Graph (not webhook) ---- */
    /**
     * Posts a Teams channel message via Microsoft Graph. Requires admin
     * pre-configured channel_id + access token (OAuth flow on first connect).
     * Falls back to the existing incoming-webhook adapter if no token.
     */
    public static function push_ms_teams( $cfg, $payload ) {
        $tok     = trim( $cfg['access_token'] ?? '' );
        $team    = trim( $cfg['team_id'] ?? '' );
        $channel = trim( $cfg['channel_id'] ?? '' );
        if ( ! $tok || ! $team || ! $channel ) {
            // Fall back to incoming-webhook URL if configured that way.
            if ( ! empty( $cfg['webhook_url'] ) ) {
                wp_remote_post( $cfg['webhook_url'], [
                    'timeout' => 8, 'sslverify' => true,
                    'headers' => [ 'Content-Type' => 'application/json' ],
                    'body' => wp_json_encode( [
                        '@type'    => 'MessageCard',
                        '@context' => 'http://schema.org/extensions',
                        'summary'  => self::card_title( $payload ),
                        'text'     => self::card_body( $payload ),
                    ] ),
                ] );
            }
            return;
        }
        wp_remote_post(
            "https://graph.microsoft.com/v1.0/teams/{$team}/channels/{$channel}/messages",
            [
                'timeout' => 8, 'sslverify' => true,
                'headers' => [
                    'Authorization' => 'Bearer ' . $tok,
                    'Content-Type'  => 'application/json',
                ],
                'body' => wp_json_encode( [
                    'body' => [
                        'contentType' => 'html',
                        'content'     => '<strong>' . esc_html( self::card_title( $payload ) ) . '</strong><br>' . nl2br( esc_html( self::card_body( $payload ) ) ),
                    ],
                ] ),
            ]
        );
    }

    /* ---- Calendar ---- */

    /** Calendly — registers an invitee using one-off scheduling links. */
    public static function push_calendly( $cfg, $payload ) {
        $tok = trim( $cfg['api_token'] ?? '' );
        $uri = trim( $cfg['event_type_uri'] ?? '' );
        if ( ! $tok || ! $uri ) return;
        $d = $payload['submission']['data'] ?? [];
        $email = self::pick_email( $d );
        if ( ! $email ) return;
        wp_remote_post( 'https://api.calendly.com/scheduling_links', [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [
                'Authorization' => 'Bearer ' . $tok,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( [
                'max_event_count' => 1,
                'owner'           => $uri,
                'owner_type'      => 'EventType',
            ] ),
        ] );
    }

    /** SavvyCal — sends a meeting invitation. */
    public static function push_savvycal( $cfg, $payload ) {
        $key  = trim( $cfg['api_key'] ?? '' );
        $link = trim( $cfg['link_id'] ?? '' );
        if ( ! $key || ! $link ) return;
        $d = $payload['submission']['data'] ?? [];
        $email = self::pick_email( $d );
        if ( ! $email ) return;
        wp_remote_post( 'https://api.savvycal.com/v1/links/' . rawurlencode( $link ) . '/invites', [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [
                'Authorization' => 'Bearer ' . $key,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( [
                'email' => $email,
                'name'  => self::pick_name( $d ),
            ] ),
        ] );
    }

    /** Cal.com — books a meeting via REST. */
    public static function push_cal_com( $cfg, $payload ) {
        $key  = trim( $cfg['api_key'] ?? '' );
        $type = trim( $cfg['event_type_id'] ?? '' );
        if ( ! $key || ! $type ) return;
        $d = $payload['submission']['data'] ?? [];
        $email = self::pick_email( $d );
        if ( ! $email ) return;
        // The actual booking endpoint requires a slot — we POST as a
        // "pending" booking with the next available slot left blank for
        // the host to confirm. Real production setups should use a
        // Schedule field to capture the slot.
        wp_remote_post( 'https://api.cal.com/v1/bookings?apiKey=' . rawurlencode( $key ), [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [ 'Content-Type' => 'application/json' ],
            'body' => wp_json_encode( [
                'eventTypeId' => (int) $type,
                'email'       => $email,
                'name'        => self::pick_name( $d ) ?: $email,
                'metadata'    => [],
            ] ),
        ] );
    }

    /* ---- E-signature ---- */

    /** DocuSign — creates an envelope. */
    public static function push_docusign( $cfg, $payload ) {
        $tok      = trim( $cfg['access_token'] ?? '' );
        $account  = trim( $cfg['account_id'] ?? '' );
        $template = trim( $cfg['template_id'] ?? '' );
        $base     = trim( $cfg['base_url'] ?? 'https://demo.docusign.net' );
        if ( ! $tok || ! $account || ! $template ) return;
        $d = $payload['submission']['data'] ?? [];
        $email = self::pick_email( $d );
        $name  = self::pick_name( $d );
        if ( ! $email ) return;
        wp_remote_post( "{$base}/restapi/v2.1/accounts/{$account}/envelopes", [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [
                'Authorization' => 'Bearer ' . $tok,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( [
                'templateId' => $template,
                'status'     => 'sent',
                'templateRoles' => [[
                    'email'    => $email,
                    'name'     => $name ?: $email,
                    'roleName' => 'Signer 1',
                ]],
            ] ),
        ] );
    }

    /** HelloSign / Dropbox Sign — creates a signature request from a template. */
    public static function push_hellosign( $cfg, $payload ) {
        $key      = trim( $cfg['api_key']      ?? '' );
        $template = trim( $cfg['template_id']  ?? '' );
        if ( ! $key || ! $template ) return;
        $d = $payload['submission']['data'] ?? [];
        $email = self::pick_email( $d );
        $name  = self::pick_name( $d );
        if ( ! $email ) return;
        wp_remote_post( 'https://api.hellosign.com/v3/signature_request/send_with_template', [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode( $key . ':' ),
                'Content-Type'  => 'application/x-www-form-urlencoded',
            ],
            'body' => http_build_query( [
                'template_id'   => $template,
                'subject'       => self::card_title( $payload ),
                'signers[0][role_name]' => 'Signer',
                'signers[0][name]'      => $name ?: $email,
                'signers[0][email_address]' => $email,
            ] ),
        ] );
    }

    /* ---- Storage ---- */

    /** OneDrive — uploads attached files. Existing dropbox/drive adapters
     * use a similar pattern. Skips when no uploads present.
     */
    public static function push_onedrive( $cfg, $payload, $form, $clean_data ) {
        $tok = trim( $cfg['access_token'] ?? '' );
        $folder = trim( $cfg['folder_path'] ?? '/FormCraft' );
        if ( ! $tok ) return;
        // Detect file URLs in the submission data.
        $uploads = [];
        foreach ( (array) $clean_data as $k => $v ) {
            if ( is_string( $v ) && preg_match( '#^https?://#', $v ) && preg_match( '#\.(pdf|jpg|jpeg|png|gif|doc|docx|xls|xlsx|csv|txt)$#i', $v ) ) {
                $uploads[ $k ] = $v;
            }
        }
        if ( ! $uploads ) return;
        foreach ( $uploads as $field => $url ) {
            $file = wp_remote_get( $url, [ 'timeout' => 8 ] );
            if ( is_wp_error( $file ) ) continue;
            $bytes = wp_remote_retrieve_body( $file );
            $name  = basename( parse_url( $url, PHP_URL_PATH ) );
            $path  = rtrim( $folder, '/' ) . '/' . ( $payload['submission']['id'] ?? 'sub' ) . '_' . $name;
            wp_remote_request(
                'https://graph.microsoft.com/v1.0/me/drive/root:' . rawurlencode( $path ) . ':/content',
                [
                    'method'  => 'PUT',
                    'timeout' => 15, 'sslverify' => true,
                    'headers' => [
                        'Authorization' => 'Bearer ' . $tok,
                        'Content-Type'  => 'application/octet-stream',
                    ],
                    'body' => $bytes,
                ]
            );
        }
    }

    /* ---- AI (OpenAI + Anthropic) ---- */

    /**
     * Sends the submission's text content to OpenAI for processing
     * (summarize, classify, sentiment — admin's choice via "operation").
     * The response is stored back in the submission's data._meta.ai.
     */
    public static function push_openai( $cfg, $payload, $form, $clean_data ) {
        $key = trim( $cfg['api_key'] ?? '' );
        $op  = $cfg['operation']    ?? 'summarize';      // summarize | classify | sentiment
        $model = $cfg['model']      ?? 'gpt-4o-mini';
        if ( ! $key ) return;
        $text = self::extract_text_payload( $clean_data );
        if ( ! $text ) return;
        $prompt = self::ai_prompt_for( $op, $text );
        $resp = wp_remote_post( 'https://api.openai.com/v1/chat/completions', [
            'timeout' => 15, 'sslverify' => true,
            'headers' => [
                'Authorization' => 'Bearer ' . $key,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( [
                'model'    => $model,
                'messages' => [
                    [ 'role' => 'system', 'content' => 'You are a concise assistant analysing form submissions.' ],
                    [ 'role' => 'user',   'content' => $prompt ],
                ],
                'temperature' => 0.3,
                'max_tokens'  => 250,
            ] ),
        ] );
        self::store_ai_result( $resp, $payload, $op, 'openai' );
    }
    /** Anthropic — same shape, different API. */
    public static function push_anthropic( $cfg, $payload, $form, $clean_data ) {
        $key = trim( $cfg['api_key'] ?? '' );
        $op  = $cfg['operation']    ?? 'summarize';
        $model = $cfg['model']      ?? 'claude-3-5-haiku-latest';
        if ( ! $key ) return;
        $text = self::extract_text_payload( $clean_data );
        if ( ! $text ) return;
        $prompt = self::ai_prompt_for( $op, $text );
        $resp = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
            'timeout' => 15, 'sslverify' => true,
            'headers' => [
                'x-api-key'         => $key,
                'anthropic-version' => '2023-06-01',
                'Content-Type'      => 'application/json',
            ],
            'body' => wp_json_encode( [
                'model'     => $model,
                'max_tokens'=> 250,
                'messages'  => [
                    [ 'role' => 'user', 'content' => $prompt ],
                ],
            ] ),
        ] );
        self::store_ai_result( $resp, $payload, $op, 'anthropic' );
    }

    /* ---- Payments (lightweight order recording — full checkout uses FCP_Payment) ---- */

    public static function push_square( $cfg, $payload ) {
        $tok = trim( $cfg['access_token'] ?? '' );
        $loc = trim( $cfg['location_id']  ?? '' );
        if ( ! $tok || ! $loc ) return;
        $amount = (int) round( ( $payload['submission']['amount'] ?? 0 ) * 100 );
        if ( ! $amount ) return;
        wp_remote_post( 'https://connect.squareup.com/v2/orders', [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [
                'Authorization' => 'Bearer ' . $tok,
                'Content-Type'  => 'application/json',
                'Square-Version'=> '2024-02-22',
            ],
            'body' => wp_json_encode( [
                'idempotency_key' => 'fcp_' . ( $payload['submission']['id'] ?? wp_generate_password( 8, false ) ),
                'order' => [
                    'location_id' => $loc,
                    'line_items'  => [[ 'name' => $payload['form']['title'] ?? 'Form submission', 'quantity' => '1', 'base_price_money' => [ 'amount' => $amount, 'currency' => 'USD' ] ]],
                ],
            ] ),
        ] );
    }

    public static function push_mollie( $cfg, $payload ) {
        $key = trim( $cfg['api_key'] ?? '' );
        if ( ! $key ) return;
        $amount = (float) ( $payload['submission']['amount'] ?? 0 );
        if ( $amount <= 0 ) return;
        wp_remote_post( 'https://api.mollie.com/v2/payments', [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [
                'Authorization' => 'Bearer ' . $key,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( [
                'amount'      => [ 'currency' => $cfg['currency'] ?? 'EUR', 'value' => number_format( $amount, 2, '.', '' ) ],
                'description' => $payload['form']['title'] ?? 'Form submission',
                'redirectUrl' => home_url(),
            ] ),
        ] );
    }

    public static function push_gocardless( $cfg, $payload ) {
        $tok = trim( $cfg['access_token'] ?? '' );
        if ( ! $tok ) return;
        $d = $payload['submission']['data'] ?? [];
        $email = self::pick_email( $d );
        if ( ! $email ) return;
        wp_remote_post( 'https://api.gocardless.com/customers', [
            'timeout' => 8, 'sslverify' => true,
            'headers' => [
                'Authorization'    => 'Bearer ' . $tok,
                'Content-Type'     => 'application/json',
                'GoCardless-Version' => '2015-07-06',
            ],
            'body' => wp_json_encode( [ 'customers' => [
                'email'       => $email,
                'given_name'  => self::first_name( self::pick_name( $d ) ),
                'family_name' => self::last_name(  self::pick_name( $d ) ),
            ] ] ),
        ] );
    }

    /* ---- Shared helpers for the new dispatchers ----
       pick_phone() + last_name() + pick_email() + pick_name() + first_name()
       already exist as private static below — we reuse them. */

    /** Headline for project-mgmt cards / tasks. */
    public static function card_title( $payload ) {
        $title = $payload['form']['title'] ?? 'Form submission';
        $d     = $payload['submission']['data'] ?? [];
        $name  = self::pick_name( $d );
        return $title . ( $name ? ' — ' . $name : '' );
    }
    /** Markdown-ish dump of every field, for card descriptions. */
    public static function card_body( $payload ) {
        $lines = [];
        foreach ( (array) ( $payload['submission']['data'] ?? [] ) as $k => $v ) {
            if ( strpos( (string) $k, '_' ) === 0 ) continue;
            if ( is_array( $v ) ) $v = implode( ', ', $v );
            $lines[] = '**' . $k . ':** ' . (string) $v;
        }
        $lines[] = '';
        $lines[] = 'Submitted: ' . ( $payload['submission']['date'] ?? current_time( 'mysql' ) );
        return implode( "\n", $lines );
    }
    /** Concatenate text-shaped fields for AI processing. */
    public static function extract_text_payload( $clean_data ) {
        $parts = [];
        foreach ( (array) $clean_data as $k => $v ) {
            if ( strpos( (string) $k, '_' ) === 0 ) continue;
            if ( ! is_string( $v ) || strlen( $v ) < 5 ) continue;
            $parts[] = $k . ': ' . $v;
        }
        return substr( implode( "\n", $parts ), 0, 3000 );
    }
    /** Builds prompts for the three operations. */
    public static function ai_prompt_for( $op, $text ) {
        if ( $op === 'classify' ) {
            return "Classify this form submission into exactly one of: LEAD, SUPPORT, COMPLAINT, SPAM, OTHER. Reply with just the label.\n\n" . $text;
        }
        if ( $op === 'sentiment' ) {
            return "Rate the sentiment of this form submission. Reply with one word: POSITIVE, NEUTRAL, or NEGATIVE.\n\n" . $text;
        }
        // Default — summarize
        return "In 2 sentences, summarize what this person wants. Be specific and actionable.\n\n" . $text;
    }
    /** Parses the LLM response + writes back into the submission's _meta.ai. */
    public static function store_ai_result( $resp, $payload, $op, $provider ) {
        if ( is_wp_error( $resp ) ) return;
        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        $text = '';
        if ( isset( $body['choices'][0]['message']['content'] ) )           $text = (string) $body['choices'][0]['message']['content'];
        elseif ( isset( $body['content'][0]['text'] ) )                     $text = (string) $body['content'][0]['text'];
        if ( ! $text ) return;
        $sid = (int) ( $payload['submission']['id'] ?? 0 );
        if ( ! $sid ) return;
        $row = FCP_DB::get_submission( $sid );
        $data = is_string( $row['data'] ?? '' ) ? json_decode( $row['data'], true ) : [];
        if ( ! is_array( $data ) ) $data = [];
        if ( ! isset( $data['_meta'] ) || ! is_array( $data['_meta'] ) ) $data['_meta'] = [];
        $data['_meta']['ai'] = array_merge(
            is_array( $data['_meta']['ai'] ?? null ) ? $data['_meta']['ai'] : [],
            [ $op => [ 'provider' => $provider, 'text' => trim( $text ), 'at' => current_time( 'mysql' ) ] ]
        );
        FCP_DB::update_submission( $sid, [ 'data' => wp_json_encode( $data ) ] );
    }

    /* ----------------- Brevo (Sendinblue) ----------------- */
    public static function push_brevo( $cfg, $payload ) {
        $key  = trim( $cfg['api_key'] ?? '' );
        $list = trim( $cfg['list_id'] ?? '' );
        if ( ! $key ) return;
        $d = $payload['submission']['data'] ?? [];
        $email = self::pick_email( $d );
        if ( ! $email ) return;
        $name  = self::pick_name( $d );
        $body = [
            'email'      => $email,
            'updateEnabled' => true,
            'attributes' => [
                'FIRSTNAME' => self::first_name( $name ),
                'LASTNAME'  => self::last_name( $name ),
                'SMS'       => self::pick_phone( $d ),
            ],
        ];
        if ( $list ) $body['listIds'] = [ (int) $list ];
        $resp = wp_remote_post( 'https://api.brevo.com/v3/contacts', [
            'timeout' => 15,
            'headers' => [ 'api-key' => $key, 'Content-Type' => 'application/json', 'Accept' => 'application/json' ],
            'body'    => wp_json_encode( $body ),
        ] );
        if ( is_wp_error( $resp ) ) error_log( '[FormCraft Pro] Brevo: ' . $resp->get_error_message() );
    }

    /* ----------------- AWeber ----------------- */
    /**
     * AWeber uses OAuth2. The admin completes the OAuth dance once on AWeber's
     * developer console and pastes the access_token + account_id + list_id
     * here. The access token doesn't expire if the OAuth scope is "subscribers".
     */
    public static function push_aweber( $cfg, $payload ) {
        $token   = trim( $cfg['access_token'] ?? '' );
        $account = trim( $cfg['account_id']   ?? '' );
        $list    = trim( $cfg['list_id']      ?? '' );
        if ( ! $token || ! $account || ! $list ) return;
        $d = $payload['submission']['data'] ?? [];
        $email = self::pick_email( $d );
        if ( ! $email ) return;
        $name = self::pick_name( $d );
        $url = 'https://api.aweber.com/1.0/accounts/' . rawurlencode( $account )
             . '/lists/' . rawurlencode( $list ) . '/subscribers';
        wp_remote_post( $url, [
            'timeout' => 15,
            'headers' => [ 'Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( [ 'email' => $email, 'name' => $name ] ),
        ] );
    }

    /* ----------------- Campaign Monitor ----------------- */
    public static function push_campaign_monitor( $cfg, $payload ) {
        $key  = trim( $cfg['api_key'] ?? '' );
        $list = trim( $cfg['list_id'] ?? '' );
        if ( ! $key || ! $list ) return;
        $d = $payload['submission']['data'] ?? [];
        $email = self::pick_email( $d );
        if ( ! $email ) return;
        $body = [ 'EmailAddress' => $email, 'Name' => self::pick_name( $d ), 'ConsentToTrack' => 'Yes' ];
        wp_remote_post( 'https://api.createsend.com/api/v3.3/subscribers/' . rawurlencode( $list ) . '.json', [
            'timeout' => 15,
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode( $key . ':x' ),
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( $body ),
        ] );
    }

    /* ----------------- Breeze (generic webhook) ----------------- */
    /**
     * Breeze isn't a single widely-known API — different products use this
     * name. We treat it as a configurable webhook POST so the admin can
     * paste any Breeze/Breezy endpoint. Optional Bearer token header.
     */
    public static function push_breeze( $cfg, $payload ) {
        $url   = $cfg['webhook_url'] ?? '';
        $token = $cfg['api_key']     ?? '';
        if ( ! $url ) return;
        $headers = [ 'Content-Type' => 'application/json' ];
        if ( $token ) $headers['Authorization'] = 'Bearer ' . $token;
        wp_remote_post( $url, [
            'timeout' => 15,
            'headers' => $headers,
            'body'    => wp_json_encode( $payload ),
        ] );
    }

    /* ----------------- Agile CRM ----------------- */
    public static function push_agile_crm( $cfg, $payload ) {
        $domain = trim( $cfg['domain']   ?? '' );  // e.g. yoursite.agilecrm.com (no protocol)
        $email  = trim( $cfg['email']    ?? '' );  // admin email
        $key    = trim( $cfg['api_key']  ?? '' );
        if ( ! $domain || ! $email || ! $key ) return;
        $d  = $payload['submission']['data'] ?? [];
        $contact_email = self::pick_email( $d );
        if ( ! $contact_email ) return;
        $name = self::pick_name( $d );
        $body = [
            'properties' => array_values( array_filter( [
                [ 'name' => 'first_name', 'value' => self::first_name( $name ) ],
                [ 'name' => 'last_name',  'value' => self::last_name( $name ) ],
                [ 'name' => 'email',      'value' => $contact_email, 'subtype' => 'work' ],
                self::pick_phone( $d ) ? [ 'name' => 'phone', 'value' => self::pick_phone( $d ), 'subtype' => 'work' ] : null,
            ] ) ),
            'lead_source' => 'FormCraft Pro',
        ];
        $url = 'https://' . preg_replace( '#^https?://#', '', $domain ) . '/dev/api/contacts';
        wp_remote_post( $url, [
            'timeout' => 15,
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode( $email . ':' . $key ),
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
            ],
            'body' => wp_json_encode( $body ),
        ] );
    }

    /* ----------------- Transactional email providers ----------------- */
    /**
     * Send a single transactional email via Mailgun / Postmark / SendGrid
     * on form submit. Useful when an admin wants per-form custom emails
     * (e.g. immediate calendar invite, role-specific notification) routed
     * through a deliverability-focused provider instead of wp_mail.
     */
    public static function send_transactional_email( $provider, $cfg, $payload ) {
        $d         = $payload['submission']['data'] ?? [];
        $to        = self::resolve_tx_recipient( $cfg, $d );
        $from_em   = $cfg['from_email']   ?? '';
        $from_nm   = $cfg['from_name']    ?? get_bloginfo( 'name' );
        $subject   = self::resolve_tx_template( $cfg['subject'] ?? 'New submission', $d, $payload );
        $body_html = self::resolve_tx_template( $cfg['body']    ?? '', $d, $payload );
        if ( ! $body_html ) $body_html = self::auto_email_body( $payload );
        if ( ! $to || ! $from_em ) return;

        switch ( $provider ) {
            case 'mailgun':
                $domain = $cfg['domain'] ?? '';
                $region = ( $cfg['region'] ?? 'us' ) === 'eu' ? 'api.eu.mailgun.net' : 'api.mailgun.net';
                if ( ! $domain ) return;
                wp_remote_post( 'https://' . $region . '/v3/' . rawurlencode( $domain ) . '/messages', [
                    'timeout' => 15,
                    'headers' => [ 'Authorization' => 'Basic ' . base64_encode( 'api:' . $cfg['api_key'] ) ],
                    'body'    => [
                        'from'    => sprintf( '%s <%s>', $from_nm, $from_em ),
                        'to'      => $to,
                        'subject' => $subject,
                        'html'    => $body_html,
                    ],
                ] );
                break;
            case 'postmark':
                wp_remote_post( 'https://api.postmarkapp.com/email', [
                    'timeout' => 15,
                    'headers' => [
                        'X-Postmark-Server-Token' => $cfg['server_token'],
                        'Content-Type'            => 'application/json',
                        'Accept'                  => 'application/json',
                    ],
                    'body' => wp_json_encode( [
                        'From'     => sprintf( '%s <%s>', $from_nm, $from_em ),
                        'To'       => $to,
                        'Subject'  => $subject,
                        'HtmlBody' => $body_html,
                        'MessageStream' => $cfg['message_stream'] ?? 'outbound',
                    ] ),
                ] );
                break;
            case 'sendgrid':
                wp_remote_post( 'https://api.sendgrid.com/v3/mail/send', [
                    'timeout' => 15,
                    'headers' => [
                        'Authorization' => 'Bearer ' . $cfg['api_key'],
                        'Content-Type'  => 'application/json',
                    ],
                    'body' => wp_json_encode( [
                        'personalizations' => [ [ 'to' => [ [ 'email' => $to ] ], 'subject' => $subject ] ],
                        'from'             => [ 'email' => $from_em, 'name' => $from_nm ],
                        'content'          => [ [ 'type' => 'text/html', 'value' => $body_html ] ],
                    ] ),
                ] );
                break;
        }
    }
    private static function resolve_tx_recipient( $cfg, $data ) {
        $to = $cfg['to_email'] ?? '';
        if ( $to === '{submitter}' ) return self::pick_email( $data );
        if ( $to === '{admin}'     ) return get_option( 'admin_email' );
        return $to;
    }
    private static function resolve_tx_template( $tpl, $data, $payload ) {
        if ( ! $tpl ) return '';
        $tpl = str_replace( '{form_title}', $payload['submission']['form_title'] ?? '', $tpl );
        $tpl = str_replace( '{submission_id}', (string) ( $payload['submission']['id'] ?? '' ), $tpl );
        foreach ( $data as $k => $v ) {
            $val = is_array( $v ) ? implode( ', ', $v ) : (string) $v;
            $tpl = str_replace( '{' . $k . '}', $val, $tpl );
        }
        return $tpl;
    }
    private static function auto_email_body( $payload ) {
        $rows = '';
        foreach ( ( $payload['submission']['data'] ?? [] ) as $k => $v ) {
            $val = is_array( $v ) ? implode( ', ', $v ) : (string) $v;
            $rows .= '<tr><th align="left" style="background:#f8fafc;padding:8px;border-bottom:1px solid #e5e7eb;">' . esc_html( $k ) . '</th>';
            $rows .= '<td style="padding:8px;border-bottom:1px solid #e5e7eb;">' . esc_html( $val ) . '</td></tr>';
        }
        return '<h2>New submission</h2><table cellpadding="0" cellspacing="0" style="border-collapse:collapse;border:1px solid #e5e7eb;font-family:Inter,Arial,sans-serif;">' . $rows . '</table>';
    }

    /* ----------------- ActiveCampaign ----------------- */
    public static function push_activecampaign( $cfg, $payload ) {
        $api_url = rtrim( $cfg['api_url'] ?? '', '/' );  // e.g. https://youraccount.api-us1.com
        $api_key = $cfg['api_key'] ?? '';
        $list_id = $cfg['list_id'] ?? '';
        if ( ! $api_url || ! $api_key ) return;
        $d = $payload['submission']['data'] ?? [];
        $email = self::pick_email( $d );
        if ( ! $email ) return;
        $name  = self::pick_name( $d );
        $phone = self::pick_phone( $d );

        // 1. Upsert contact
        $body = [ 'contact' => [
            'email'     => $email,
            'firstName' => self::first_name( $name ),
            'lastName'  => self::last_name( $name ),
            'phone'     => $phone,
        ]];
        $res = wp_remote_post( $api_url . '/api/3/contact/sync', [
            'timeout' => 15,
            'headers' => [ 'Api-Token' => $api_key, 'Content-Type' => 'application/json', 'Accept' => 'application/json' ],
            'body'    => wp_json_encode( $body ),
        ] );
        if ( is_wp_error( $res ) ) {
            error_log( '[FormCraft Pro] ActiveCampaign: ' . $res->get_error_message() );
            return;
        }
        $j = json_decode( wp_remote_retrieve_body( $res ), true );
        $contact_id = $j['contact']['id'] ?? null;

        // 2. Add to list (if configured)
        if ( $contact_id && $list_id ) {
            wp_remote_post( $api_url . '/api/3/contactLists', [
                'timeout' => 15,
                'headers' => [ 'Api-Token' => $api_key, 'Content-Type' => 'application/json' ],
                'body'    => wp_json_encode( [ 'contactList' => [
                    'list'    => (int) $list_id,
                    'contact' => (int) $contact_id,
                    'status'  => 1, // 1 = active subscriber
                ] ] ),
            ] );
        }
    }

    /* ----------------- ConvertKit (Kit) ----------------- */
    public static function push_convertkit( $cfg, $payload ) {
        $api_key = $cfg['api_key'] ?? '';
        $form_id = $cfg['form_id'] ?? '';
        if ( ! $api_key ) return;
        $d = $payload['submission']['data'] ?? [];
        $email = self::pick_email( $d );
        if ( ! $email ) return;
        $name = self::pick_name( $d );

        // Subscribe to a form (preferred) — falls back to a tag-only call.
        if ( $form_id ) {
            wp_remote_post( 'https://api.convertkit.com/v3/forms/' . rawurlencode( $form_id ) . '/subscribe', [
                'timeout' => 15,
                'headers' => [ 'Content-Type' => 'application/json' ],
                'body'    => wp_json_encode( [
                    'api_key'    => $api_key,
                    'email'      => $email,
                    'first_name' => self::first_name( $name ),
                ] ),
            ] );
        } else {
            wp_remote_post( 'https://api.convertkit.com/v3/subscribers', [
                'timeout' => 15,
                'headers' => [ 'Content-Type' => 'application/json' ],
                'body'    => wp_json_encode( [
                    'api_key'    => $api_key,
                    'email'      => $email,
                    'first_name' => self::first_name( $name ),
                ] ),
            ] );
        }
    }

    /* ----------------- Salesforce ----------------- */
    /**
     * Salesforce auth uses an OAuth refresh-token flow — the admin sets up a
     * Connected App once + pastes the refresh token here. We exchange it for
     * a short-lived access token on each fire (cached in a transient).
     */
    public static function push_salesforce( $cfg, $payload ) {
        $cid    = $cfg['client_id']     ?? '';
        $secret = $cfg['client_secret'] ?? '';
        $rt     = $cfg['refresh_token'] ?? '';
        $inst   = rtrim( $cfg['instance_url'] ?? '', '/' );
        if ( ! $cid || ! $secret || ! $rt ) return;

        $access_key = 'fcp_sf_token_' . md5( $cid . $rt );
        $access = get_transient( $access_key );
        if ( ! $access || empty( $access['access_token'] ) ) {
            $tok = wp_remote_post( 'https://login.salesforce.com/services/oauth2/token', [
                'timeout' => 20,
                'body'    => [
                    'grant_type'    => 'refresh_token',
                    'client_id'     => $cid,
                    'client_secret' => $secret,
                    'refresh_token' => $rt,
                ],
            ] );
            if ( is_wp_error( $tok ) ) { error_log( '[FormCraft Pro] Salesforce token: ' . $tok->get_error_message() ); return; }
            $access = json_decode( wp_remote_retrieve_body( $tok ), true );
            if ( empty( $access['access_token'] ) ) { error_log( '[FormCraft Pro] Salesforce token: no access_token' ); return; }
            // Salesforce access tokens live ~2 hours — cache 90 min to be safe.
            set_transient( $access_key, $access, 90 * MINUTE_IN_SECONDS );
            if ( ! empty( $access['instance_url'] ) ) $inst = $access['instance_url'];
        }
        $inst = $inst ?: ( $access['instance_url'] ?? '' );
        if ( ! $inst ) return;
        $d = $payload['submission']['data'] ?? [];
        $email = self::pick_email( $d );
        $name  = self::pick_name( $d );
        wp_remote_post( $inst . '/services/data/v59.0/sobjects/Lead/', [
            'timeout' => 20,
            'headers' => [ 'Authorization' => 'Bearer ' . $access['access_token'], 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( [
                'FirstName' => self::first_name( $name ),
                'LastName'  => self::last_name( $name )  ?: 'Unknown',
                'Email'     => $email,
                'Phone'     => self::pick_phone( $d ),
                'Company'   => $d['Company'] ?? $d['company'] ?? ( $payload['site']['name'] ?? 'Web Lead' ),
                'LeadSource'=> 'FormCraft Pro',
            ] ),
        ] );
    }

    /* ----------------- Zoho CRM ----------------- */
    public static function push_zoho_crm( $cfg, $payload ) {
        $cid    = $cfg['client_id']     ?? '';
        $secret = $cfg['client_secret'] ?? '';
        $rt     = $cfg['refresh_token'] ?? '';
        $region = $cfg['region']        ?? 'com';
        $module = $cfg['module']        ?? 'Leads';
        if ( ! $cid || ! $secret || ! $rt ) return;

        $accounts = 'https://accounts.zoho.' . $region;
        $api_base = 'https://www.zohoapis.' . $region;

        $access_key = 'fcp_zoho_token_' . md5( $cid . $rt );
        $token = get_transient( $access_key );
        if ( ! $token ) {
            $tok = wp_remote_post( $accounts . '/oauth/v2/token', [
                'timeout' => 20,
                'body'    => [
                    'refresh_token' => $rt,
                    'client_id'     => $cid,
                    'client_secret' => $secret,
                    'grant_type'    => 'refresh_token',
                ],
            ] );
            if ( is_wp_error( $tok ) ) { error_log( '[FormCraft Pro] Zoho token: ' . $tok->get_error_message() ); return; }
            $j = json_decode( wp_remote_retrieve_body( $tok ), true );
            if ( empty( $j['access_token'] ) ) { error_log( '[FormCraft Pro] Zoho: ' . wp_remote_retrieve_body( $tok ) ); return; }
            $token = $j['access_token'];
            set_transient( $access_key, $token, 50 * MINUTE_IN_SECONDS );
        }
        $d = $payload['submission']['data'] ?? [];
        $name = self::pick_name( $d );
        $row = [
            'Last_Name'  => self::last_name( $name ) ?: ( self::first_name( $name ) ?: 'Unknown' ),
            'First_Name' => self::first_name( $name ),
            'Email'      => self::pick_email( $d ),
            'Phone'      => self::pick_phone( $d ),
            'Company'    => $d['Company'] ?? $d['company'] ?? ( $payload['site']['name'] ?? 'Web Lead' ),
            'Lead_Source'=> 'FormCraft Pro',
        ];
        wp_remote_post( $api_base . '/crm/v3/' . rawurlencode( $module ), [
            'timeout' => 20,
            'headers' => [
                'Authorization' => 'Zoho-oauthtoken ' . $token,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( [ 'data' => [ $row ] ] ),
        ] );
    }

    /* ----------------- Dropbox ----------------- */
    /**
     * Upload every File/Image field's content to the configured Dropbox
     * folder. A JSON snapshot of the submission is also written so the
     * folder is a complete archive of the entry.
     */
    public static function push_dropbox( $cfg, $payload, $form, $clean_data ) {
        $token  = $cfg['access_token'] ?? '';
        $folder = rtrim( $cfg['folder_path'] ?? '/FormCraft', '/' ) ?: '/FormCraft';
        if ( ! $token ) return;
        $sub_id = $payload['submission']['id'] ?? 0;
        $base   = $folder . '/sub-' . (int) $sub_id;

        $upload_files = self::extract_uploaded_files( $form, $clean_data );
        foreach ( $upload_files as $url ) {
            self::dropbox_upload_url( $token, $url, $base . '/' . basename( parse_url( $url, PHP_URL_PATH ) ?: 'file' ) );
        }
        // Always save submission JSON snapshot
        self::dropbox_upload_data( $token, wp_json_encode( $payload, JSON_PRETTY_PRINT ), $base . '/submission.json' );
    }
    private static function dropbox_upload_url( $token, $url, $dest ) {
        $tmp = download_url( $url, 30 );
        if ( is_wp_error( $tmp ) ) return;
        $bytes = file_get_contents( $tmp );
        @unlink( $tmp );
        if ( $bytes !== false ) self::dropbox_upload_data( $token, $bytes, $dest );
    }
    private static function dropbox_upload_data( $token, $bytes, $dest ) {
        wp_remote_post( 'https://content.dropboxapi.com/2/files/upload', [
            'timeout' => 30,
            'headers' => [
                'Authorization'   => 'Bearer ' . $token,
                'Dropbox-API-Arg' => wp_json_encode( [
                    'path' => $dest, 'mode' => 'add', 'autorename' => true, 'mute' => true,
                ] ),
                'Content-Type' => 'application/octet-stream',
            ],
            'body' => $bytes,
        ] );
    }

    /* ----------------- Google Drive ----------------- */
    public static function push_google_drive( $cfg, $payload, $form, $clean_data ) {
        $cid    = $cfg['client_id']     ?? '';
        $secret = $cfg['client_secret'] ?? '';
        $rt     = $cfg['refresh_token'] ?? '';
        $folder = $cfg['folder_id']     ?? '';
        if ( ! $cid || ! $secret || ! $rt ) return;

        $access_key = 'fcp_gdrive_' . md5( $cid . $rt );
        $token = get_transient( $access_key );
        if ( ! $token ) {
            $tok = wp_remote_post( 'https://oauth2.googleapis.com/token', [
                'timeout' => 20,
                'body'    => [
                    'client_id'     => $cid,
                    'client_secret' => $secret,
                    'refresh_token' => $rt,
                    'grant_type'    => 'refresh_token',
                ],
            ] );
            if ( is_wp_error( $tok ) ) { error_log( '[FormCraft Pro] GDrive token: ' . $tok->get_error_message() ); return; }
            $j = json_decode( wp_remote_retrieve_body( $tok ), true );
            if ( empty( $j['access_token'] ) ) return;
            $token = $j['access_token'];
            set_transient( $access_key, $token, 50 * MINUTE_IN_SECONDS );
        }
        $sub_id = (int) ( $payload['submission']['id'] ?? 0 );

        $upload_files = self::extract_uploaded_files( $form, $clean_data );
        foreach ( $upload_files as $url ) {
            self::gdrive_upload_url( $token, $url, $folder, 'sub-' . $sub_id . '-' . basename( parse_url( $url, PHP_URL_PATH ) ?: 'file' ) );
        }
        // Submission JSON snapshot
        self::gdrive_upload_data( $token, wp_json_encode( $payload, JSON_PRETTY_PRINT ), $folder, 'submission-' . $sub_id . '.json', 'application/json' );
    }
    private static function gdrive_upload_url( $token, $url, $folder_id, $name ) {
        $tmp = download_url( $url, 30 );
        if ( is_wp_error( $tmp ) ) return;
        $bytes = file_get_contents( $tmp );
        $mime  = mime_content_type( $tmp ) ?: 'application/octet-stream';
        @unlink( $tmp );
        if ( $bytes !== false ) self::gdrive_upload_data( $token, $bytes, $folder_id, $name, $mime );
    }
    private static function gdrive_upload_data( $token, $bytes, $folder_id, $name, $mime ) {
        $meta = [ 'name' => $name ];
        if ( $folder_id ) $meta['parents'] = [ $folder_id ];
        $boundary = '----FCPGDRIVE_' . wp_generate_password( 12, false );
        $body  = "--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n" . wp_json_encode( $meta ) . "\r\n";
        $body .= "--$boundary\r\nContent-Type: $mime\r\n\r\n" . $bytes . "\r\n--$boundary--";
        wp_remote_post( 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', [
            'timeout' => 30,
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => "multipart/related; boundary=$boundary",
            ],
            'body' => $body,
        ] );
    }

    /* ----------------- Helpers ----------------- */
    private static function extract_uploaded_files( $form, $data ) {
        $files = [];
        foreach ( $form['steps'] ?? [] as $step ) {
            foreach ( $step['fields'] ?? [] as $f ) {
                if ( ! in_array( $f['type'] ?? '', [ 'file', 'image' ], true ) ) continue;
                $v = $data[ $f['label'] ?? '' ] ?? '';
                if ( is_string( $v ) && preg_match( '#^https?://#', $v ) ) $files[] = $v;
            }
        }
        return $files;
    }
    private static function pick_email( $d ) {
        foreach ( [ 'Email','email','Email Address','Your Email','Work Email' ] as $k ) {
            if ( ! empty( $d[ $k ] ) && is_email( $d[ $k ] ) ) return $d[ $k ];
        }
        foreach ( $d as $v ) if ( is_string( $v ) && is_email( $v ) ) return $v;
        return '';
    }
    private static function pick_name( $d ) {
        foreach ( [ 'Full Name','Name','Your Name','name','full_name' ] as $k ) {
            if ( ! empty( $d[ $k ] ) ) return (string) $d[ $k ];
        }
        return '';
    }
    private static function pick_phone( $d ) {
        foreach ( [ 'Phone','phone','Mobile','Tel' ] as $k ) {
            if ( ! empty( $d[ $k ] ) ) return (string) $d[ $k ];
        }
        return '';
    }
    private static function first_name( $name ) {
        $p = preg_split( '/\s+/', trim( $name ), 2 );
        return $p[0] ?? '';
    }
    private static function last_name( $name ) {
        $p = preg_split( '/\s+/', trim( $name ), 2 );
        return $p[1] ?? '';
    }

    public static function build_payload( $event, $form, $data, $sid, $context = [] ) {
        $payload = [
            'event'        => $event,
            'submission'   => [
                'id'         => (int) $sid,
                'form_id'    => isset( $form['id'] )    ? (int) $form['id']    : 0,
                'form_title' => isset( $form['title'] ) ? $form['title']       : '',
                'submitted_at' => current_time( 'c' ),
                'data'         => is_array( $data ) ? $data : [],
            ],
            'site' => [
                'name' => get_bloginfo( 'name' ),
                'url'  => home_url(),
            ],
        ];
        if ( ! empty( $context ) ) {
            $payload['context'] = $context;
        }
        return $payload;
    }

    /**
     * Dispatch a single webhook. Adds an HMAC signature header so receivers
     * can verify the payload was sent by this site. Result is logged on the
     * webhook row (last_status / last_error / fire_count).
     */
    public static function dispatch_webhook( $hook, $payload ) {
        $body    = wp_json_encode( $payload );
        $headers = [
            'Content-Type'        => 'application/json',
            'User-Agent'          => 'FormCraftPro/' . FCP_VERSION . ' (+' . home_url() . ')',
            'X-FormCraft-Event'   => isset( $payload['event'] ) ? $payload['event'] : 'submission',
            'X-FormCraft-Webhook' => (string) $hook['id'],
        ];
        if ( ! empty( $hook['secret'] ) ) {
            $headers['X-FormCraft-Signature'] = 'sha256=' . hash_hmac( 'sha256', $body, $hook['secret'] );
        }

        // Merge admin-defined headers (one "Key: Value" per line).
        if ( ! empty( $hook['headers'] ) ) {
            foreach ( preg_split( '/\r?\n/', $hook['headers'] ) as $line ) {
                $line = trim( $line );
                if ( $line === '' || strpos( $line, ':' ) === false ) continue;
                list( $k, $v ) = array_map( 'trim', explode( ':', $line, 2 ) );
                if ( $k !== '' ) $headers[ $k ] = $v;
            }
        }

        // Slack expects a `text` field, not our full payload — adapt if the
        // target was created as 'slack' so a webhook row pointing to a Slack
        // incoming-webhook URL formats the message readably.
        if ( ( $hook['target'] ?? '' ) === 'slack' ) {
            $body = wp_json_encode( self::format_slack_message( $payload ) );
            $headers['Content-Type'] = 'application/json';
            unset( $headers['X-FormCraft-Signature'] ); // Slack ignores extra headers
        }

        // Webhooks STAY blocking (with a tight 4s timeout) because we need
        // to log the actual response status into fcp_webhooks.last_status
        // for the admin's webhook list page. If you have 5 webhooks and
        // each takes 1s, that's 5s added to the submit — admin should keep
        // the webhook list short or use Zapier as a fanout.
        $resp = wp_remote_post( $hook['url'], [
            'method'      => 'POST',
            'timeout'     => 4,
            'redirection' => 3,
            'blocking'    => true,
            'headers'     => $headers,
            'body'        => $body,
            'data_format' => 'body',
        ] );

        if ( is_wp_error( $resp ) ) {
            FCP_DB::record_webhook_fire( $hook['id'], 0, $resp->get_error_message() );
            // Enqueue for retry — the WP-cron tick will replay with
            // exponential backoff (5min → 30min → 6h, then give up).
            if ( class_exists( 'FCP_Retry_Queue' ) ) {
                FCP_Retry_Queue::enqueue(
                    'webhook:' . (int) $hook['id'], 'POST', $hook['url'],
                    [ 'headers' => $headers, 'body' => $body ],
                    $resp->get_error_message()
                );
            }
            return false;
        }
        $status = (int) wp_remote_retrieve_response_code( $resp );
        $err    = ( $status >= 200 && $status < 300 ) ? '' : substr( (string) wp_remote_retrieve_body( $resp ), 0, 1000 );
        FCP_DB::record_webhook_fire( $hook['id'], $status, $err );
        // Retry queue: only 5xx + 429 (server-side / rate-limit issues) are
        // worth retrying. 4xx means the payload itself is wrong — replaying
        // won't help.
        if ( ! ( $status >= 200 && $status < 300 ) && class_exists( 'FCP_Retry_Queue' ) ) {
            if ( $status === 429 || ( $status >= 500 && $status < 600 ) ) {
                FCP_Retry_Queue::enqueue(
                    'webhook:' . (int) $hook['id'], 'POST', $hook['url'],
                    [ 'headers' => $headers, 'body' => $body ],
                    'HTTP ' . $status
                );
            }
        }
        return $status >= 200 && $status < 300;
    }

    public static function format_slack_message( $payload ) {
        $s = $payload['submission'];
        $lines = [];
        foreach ( $s['data'] as $k => $v ) {
            if ( is_array( $v ) ) $v = implode( ', ', $v );
            $lines[] = '*' . $k . ':* ' . $v;
        }
        return [
            'text' => ':inbox_tray: New submission on *' . $s['form_title'] . '*',
            'attachments' => [[
                'color'  => '#6366f1',
                'text'   => implode( "\n", $lines ),
                'footer' => $payload['site']['name'],
                'ts'     => time(),
            ]],
        ];
    }

    /* -----------------------------------------------------------------
     * Native adapters
     * -----------------------------------------------------------------*/

    /**
     * Push to a Slack incoming-webhook URL set under Integrations settings.
     * (Slack-as-webhook from the Webhooks tab is covered by dispatch_webhook.)
     */
    public static function push_slack( $cfg, $payload ) {
        $resp = wp_remote_post( $cfg['webhook_url'], self::async_args( [
            'headers' => [ 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( self::format_slack_message( $payload ) ),
        ] ) );
        return ! is_wp_error( $resp );
    }

    /**
     * Subscribe the submitter to a Mailchimp audience (Lists API v3).
     * Datacenter is derived from the API key (e.g. "abc123-us10" → us10).
     */
    public static function push_mailchimp( $cfg, $payload ) {
        $email = self::detect_email( $payload['submission']['data'] );
        if ( ! $email || empty( $cfg['audience_id'] ) ) return false;

        $key = $cfg['api_key'];
        $dc  = ! empty( $cfg['datacenter'] ) ? $cfg['datacenter'] : ( strpos( $key, '-' ) !== false ? substr( $key, strpos( $key, '-' ) + 1 ) : '' );
        if ( ! $dc ) return false;

        $name_parts = preg_split( '/\s+/', (string) self::detect_name( $payload['submission']['data'] ), 2 );
        $url = "https://{$dc}.api.mailchimp.com/3.0/lists/" . rawurlencode( $cfg['audience_id'] ) . '/members/' . md5( strtolower( $email ) );
        $resp = wp_remote_request( $url, self::async_args( [
            'method'  => 'PUT',
            'headers' => [
                'Authorization' => 'apikey ' . $key,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( [
                'email_address' => $email,
                'status_if_new' => 'subscribed',
                'merge_fields'  => [
                    'FNAME' => $name_parts[0] ?? '',
                    'LNAME' => $name_parts[1] ?? '',
                ],
            ] ),
        ] ) );
        return ! is_wp_error( $resp );
    }

    /**
     * Push the submitter as a HubSpot Contact (CRM v3, private app token).
     * Uses the upsert-by-email endpoint so it works for both create + update.
     */
    public static function push_hubspot( $cfg, $payload ) {
        $email = self::detect_email( $payload['submission']['data'] );
        if ( ! $email ) return false;

        $name_parts = preg_split( '/\s+/', (string) self::detect_name( $payload['submission']['data'] ), 2 );
        $props = [
            'email'     => $email,
            'firstname' => $name_parts[0] ?? '',
            'lastname'  => $name_parts[1] ?? '',
        ];
        $phone = self::detect_phone( $payload['submission']['data'] );
        if ( $phone ) $props['phone'] = $phone;

        $url  = 'https://api.hubapi.com/crm/v3/objects/contacts/' . rawurlencode( $email ) . '?idProperty=email';
        // First call is blocking (short timeout) so we can detect 404 →
        // need-to-create flow. Subsequent create POST is fire-and-forget.
        $resp = wp_remote_request( $url, [
            'method'  => 'PATCH',
            'timeout' => 4,
            'headers' => [
                'Authorization' => 'Bearer ' . $cfg['api_token'],
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( [ 'properties' => $props ] ),
        ] );
        if ( is_wp_error( $resp ) ) return false;
        $code = (int) wp_remote_retrieve_response_code( $resp );
        if ( $code === 404 ) {
            // Doesn't exist yet — create.
            $resp = wp_remote_post( 'https://api.hubapi.com/crm/v3/objects/contacts', [
                'timeout' => 10,
                'headers' => [
                    'Authorization' => 'Bearer ' . $cfg['api_token'],
                    'Content-Type'  => 'application/json',
                ],
                'body' => wp_json_encode( [ 'properties' => $props ] ),
            ] );
            $code = is_wp_error( $resp ) ? 0 : (int) wp_remote_retrieve_response_code( $resp );
        }
        return $code >= 200 && $code < 300;
    }

    /* ---- field detection helpers (loose match by common labels) ---- */
    public static function detect_email( $data ) {
        foreach ( $data as $k => $v ) {
            if ( is_array( $v ) ) continue;
            $v = (string) $v;
            if ( filter_var( $v, FILTER_VALIDATE_EMAIL ) ) return $v;
            if ( stripos( $k, 'email' ) !== false && $v ) return $v;
        }
        return '';
    }
    public static function detect_name( $data ) {
        foreach ( [ 'Full Name', 'Name', 'Your Name', 'First Name' ] as $key ) {
            if ( ! empty( $data[ $key ] ) ) return (string) $data[ $key ];
        }
        foreach ( $data as $k => $v ) {
            if ( is_array( $v ) ) continue;
            if ( stripos( $k, 'name' ) !== false && $v ) return (string) $v;
        }
        return '';
    }
    public static function detect_phone( $data ) {
        foreach ( $data as $k => $v ) {
            if ( is_array( $v ) ) continue;
            if ( stripos( $k, 'phone' ) !== false || stripos( $k, 'mobile' ) !== false ) return (string) $v;
        }
        return '';
    }

    /* =============================================================
     *                          AIRTABLE
     * ============================================================= */

    /**
     * Push the submission into an Airtable base + table. The PAT is
     * stored in global settings (so the same token works for every
     * form), but the destination base/table + field-mapping is stored
     * on the form itself under settings.afterSubmit.airtable. Lets
     * different forms feed different Airtable tables on the same site.
     *
     * Per-form config shape:
     *   {
     *     base:   'appXXXXXXXXXXXXXX',
     *     table:  'tblYYYYYYYYYYYYYY' or 'TableName',
     *     action: 'create' | 'upsert',
     *     unique_field: 'Email',     // only used when action=upsert
     *     mapping: { 'Email': 'Form Field Label', ... }  // Airtable col → form label
     *   }
     */
    public static function push_airtable( $cfg, $form, $payload ) {
        $pat  = trim( (string) ( $cfg['pat'] ?? '' ) );
        if ( ! $pat ) return false;

        $per  = $form['settings']['afterSubmit']['airtable'] ?? [];
        if ( empty( $per['enabled'] ) || empty( $per['base'] ) || empty( $per['table'] ) ) return false;

        $base    = trim( (string) $per['base'] );
        $table   = trim( (string) $per['table'] );
        $mapping = is_array( $per['mapping'] ?? null ) ? $per['mapping'] : [];
        if ( ! $mapping ) return false;

        $data = $payload['submission']['data'] ?? [];
        // Build the Airtable fields object: for each mapped Airtable column,
        // look up the corresponding form field value.
        $fields = [];
        foreach ( $mapping as $airtable_col => $form_label ) {
            if ( ! $form_label ) continue;
            $val = $data[ $form_label ] ?? null;
            if ( $val === null || $val === '' ) continue;
            $fields[ $airtable_col ] = self::airtable_format_value( $val );
        }
        if ( ! $fields ) return false;

        $url = 'https://api.airtable.com/v0/' . rawurlencode( $base ) . '/' . rawurlencode( $table );

        // Upsert by a unique field (e.g. Email): use PATCH with performUpsert
        $action       = ( $per['action'] ?? 'create' ) === 'upsert' ? 'upsert' : 'create';
        $unique_field = trim( (string) ( $per['unique_field'] ?? '' ) );

        $body = [ 'records' => [ [ 'fields' => $fields ] ] ];

        if ( $action === 'upsert' && $unique_field ) {
            $body['performUpsert'] = [ 'fieldsToMergeOn' => [ $unique_field ] ];
            $body['typecast']      = true;
            $method = 'PATCH';
        } else {
            $body['typecast'] = true;
            $method = 'POST';
        }

        $resp = wp_remote_request( $url, self::async_args( [
            'method'  => $method,
            'headers' => [
                'Authorization' => 'Bearer ' . $pat,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( $body ),
        ] ) );
        // With blocking=false, success is "request dispatched" not "API
        // accepted". Form submit returns instantly.
        return ! is_wp_error( $resp );
    }

    /**
     * Coerce form field values into Airtable-friendly types.
     *
     * Airtable's "typecast" option does most of the work for us — strings
     * get auto-converted to numbers / dates / single-selects when the
     * column type allows. We just need to handle the special cases:
     *   - Arrays (repeater rows, multi-checkbox) → join with ", "
     *   - Image-data URLs (signature pad) → skip (Airtable rejects data URIs)
     *   - Full URLs that look like file uploads → wrap as attachment
     */
    private static function airtable_format_value( $v ) {
        // Attachment: file/image upload URL hosted on our site
        if ( is_string( $v ) && preg_match( '#^https?://[^\s]+\.(jpg|jpeg|png|gif|webp|pdf|doc|docx|xlsx|csv|zip)(\?[^\s]*)?$#i', $v ) ) {
            return [ [ 'url' => $v ] ];
        }
        // Signature (data URL) — Airtable can't ingest data: URIs, skip
        if ( is_string( $v ) && strpos( $v, 'data:image/' ) === 0 ) {
            return '[signature captured — see submission detail]';
        }
        // Array (multi-checkbox, repeater rows): flatten
        if ( is_array( $v ) ) {
            // Repeater (array of objects): JSON-encode each row
            if ( isset( $v[0] ) && is_array( $v[0] ) ) {
                $rows = array_map( function ( $r ) {
                    return is_array( $r ) ? implode( ' · ', array_filter( $r, 'is_scalar' ) ) : (string) $r;
                }, $v );
                return implode( "\n", $rows );
            }
            return implode( ', ', array_map( 'strval', $v ) );
        }
        return (string) $v;
    }

    /* ---------- Airtable schema discovery (used by the admin UI) ---------- */

    public static function airtable_test( $pat ) {
        $pat = trim( (string) $pat );
        if ( ! preg_match( '/^pat[A-Za-z0-9]/', $pat ) ) {
            return new WP_Error( 'airtable_bad_format',
                "That doesn't look like a Personal Access Token. PATs start with \"pat\" followed by letters/numbers. Create one at airtable.com/create/tokens." );
        }
        $resp = wp_remote_get( 'https://api.airtable.com/v0/meta/bases', [
            'timeout' => 10,
            'headers' => [ 'Authorization' => 'Bearer ' . $pat ],
        ] );
        if ( is_wp_error( $resp ) ) return new WP_Error( 'airtable_unreachable', $resp->get_error_message() );
        $code = (int) wp_remote_retrieve_response_code( $resp );
        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        $err_type = $body['error']['type'] ?? '';

        if ( $code === 200 ) {
            // PAT is valid AND has schema.bases:read scope. But it might
            // return zero bases — which is technically OK for the token but
            // means we can't show anything in the base dropdown later.
            // Airtable's API doesn't distinguish "PAT has no Access list"
            // from "account has zero bases", so the error mentions both.
            $bases = isset( $body['bases'] ) && is_array( $body['bases'] ) ? $body['bases'] : [];
            if ( empty( $bases ) ) {
                return new WP_Error( 'airtable_no_bases',
                    "Token works, but no bases are visible. Two possible reasons: (1) your Airtable account doesn't have any bases yet — go to airtable.com and click \"+ Create a base\" first; (2) your PAT's \"Access\" list is empty — edit the token at airtable.com/create/tokens and add at least one base. Once you have a base, click Test connection again." );
            }
            return true;
        }

        if ( $code === 401 || $err_type === 'AUTHENTICATION_REQUIRED' || $err_type === 'INVALID_TOKEN' ) {
            return new WP_Error( 'airtable_unauthorized',
                "Airtable rejected the token. Either the PAT was revoked, mistyped, or copied incorrectly. Create a fresh one at airtable.com/create/tokens." );
        }
        if ( $code === 403 || $err_type === 'INVALID_PERMISSIONS_OR_MODEL_NOT_FOUND' || $err_type === 'INVALID_PERMISSIONS' ) {
            return new WP_Error( 'airtable_missing_scope',
                "Token is missing the required SCOPES or ACCESS. Edit your PAT at airtable.com/create/tokens and confirm: (1) Scopes — add \"data.records:read\", \"data.records:write\", and \"schema.bases:read\". (2) Access — click \"Add a base\" and pick at least one base (or pick \"All current and future bases\"). Save the token and test again." );
        }

        $msg = $body['error']['message'] ?? ( is_string( $body['error'] ?? null ) ? $body['error'] : 'Airtable returned HTTP ' . $code );
        return new WP_Error( 'airtable_error', (string) $msg );
    }

    public static function airtable_list_bases( $pat ) {
        if ( is_wp_error( $t = self::airtable_test( $pat ) ) ) return $t;
        $resp = wp_remote_get( 'https://api.airtable.com/v0/meta/bases', [
            'timeout' => 10,
            'headers' => [ 'Authorization' => 'Bearer ' . $pat ],
        ] );
        $b = json_decode( wp_remote_retrieve_body( $resp ), true );
        return is_array( $b['bases'] ?? null ) ? $b['bases'] : [];
    }

    public static function airtable_list_tables( $pat, $base_id ) {
        if ( is_wp_error( $t = self::airtable_test( $pat ) ) ) return $t;
        $resp = wp_remote_get( 'https://api.airtable.com/v0/meta/bases/' . rawurlencode( $base_id ) . '/tables', [
            'timeout' => 10,
            'headers' => [ 'Authorization' => 'Bearer ' . $pat ],
        ] );
        $code = (int) wp_remote_retrieve_response_code( $resp );
        if ( $code !== 200 ) return new WP_Error( 'airtable_table_fetch', 'Failed to list tables (HTTP ' . $code . ')' );
        $b = json_decode( wp_remote_retrieve_body( $resp ), true );
        $tables = $b['tables'] ?? [];
        // Return only the bits the UI needs: id, name, and the per-field
        // {id, name, type} so the field-mapping picker can show types.
        $out = [];
        foreach ( (array) $tables as $t ) {
            $fields = [];
            foreach ( (array) ( $t['fields'] ?? [] ) as $f ) {
                $fields[] = [
                    'id'   => $f['id']   ?? '',
                    'name' => $f['name'] ?? '',
                    'type' => $f['type'] ?? '',
                ];
            }
            $out[] = [
                'id'     => $t['id']     ?? '',
                'name'   => $t['name']   ?? '',
                'fields' => $fields,
            ];
        }
        return $out;
    }

    /* ================================================================
     * Discord webhook (v2.70.15)
     * Just POST to the webhook URL — Discord accepts a JSON payload with
     * "content" (plain text) or "embeds" (rich cards). We send an embed
     * because it looks better + shows the form name as a title.
     * ================================================================ */
    public static function push_discord( $cfg, $form, $payload ) {
        $data = isset( $payload['data'] ) && is_array( $payload['data'] ) ? $payload['data'] : [];
        // Build compact field list (max 25 fields — Discord's cap)
        $fields = [];
        $i = 0;
        foreach ( $data as $k => $v ) {
            if ( is_string( $k ) && strpos( $k, '_' ) === 0 ) continue; // skip _meta etc.
            if ( is_array( $v ) )  $v = implode( ', ', array_map( 'strval', $v ) );
            $val = (string) $v;
            if ( $val === '' ) continue;
            if ( strlen( $val ) > 1024 ) $val = substr( $val, 0, 1021 ) . '…';
            $fields[] = [ 'name' => substr( (string) $k, 0, 256 ), 'value' => $val, 'inline' => strlen( $val ) < 32 ];
            if ( ++$i >= 25 ) break;
        }
        $embed = [
            'title'       => 'New submission: ' . ( $form['title'] ?? 'Form' ),
            'description' => 'From ' . ( $payload['name'] ?? 'Anonymous' ) . ( $payload['email'] ? ' (' . $payload['email'] . ')' : '' ),
            'color'       => 0x6366F1, // FormCraft indigo
            'fields'      => $fields,
            'footer'      => [ 'text' => get_bloginfo( 'name' ) ],
            'timestamp'   => date( 'c' ),
        ];
        $body = [
            'username'   => 'FormCraft Pro',
            'embeds'     => [ $embed ],
        ];
        $res = wp_remote_post( $cfg['webhook_url'], [
            'headers' => [ 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( $body ),
            'timeout' => 15,
        ] );
        if ( is_wp_error( $res ) ) {
            error_log( '[FormCraft Pro] Discord push failed: ' . $res->get_error_message() );
            return $res;
        }
        return true;
    }

    /* ================================================================
     * Telegram bot notification (v2.70.15)
     * Uses the Bot API sendMessage endpoint. Formats the submission as
     * Markdown so field labels are bold, values are code-blocked for
     * copy-paste. Cap length at Telegram's 4096 char limit.
     * ================================================================ */
    public static function push_telegram( $cfg, $form, $payload ) {
        $data = isset( $payload['data'] ) && is_array( $payload['data'] ) ? $payload['data'] : [];
        $lines = [];
        $lines[] = '*🔔 New submission on _' . self::tg_escape( $form['title'] ?? 'Form' ) . '_*';
        $lines[] = '';
        if ( ! empty( $payload['name'] ) )  $lines[] = '*From:* ' . self::tg_escape( $payload['name'] );
        if ( ! empty( $payload['email'] ) ) $lines[] = '*Email:* ' . self::tg_escape( $payload['email'] );
        $lines[] = '';
        foreach ( $data as $k => $v ) {
            if ( is_string( $k ) && strpos( $k, '_' ) === 0 ) continue;
            if ( is_array( $v ) ) $v = implode( ', ', array_map( 'strval', $v ) );
            $val = (string) $v;
            if ( $val === '' ) continue;
            if ( strlen( $val ) > 200 ) $val = substr( $val, 0, 197 ) . '…';
            $lines[] = '*' . self::tg_escape( (string) $k ) . ':* ' . self::tg_escape( $val );
        }
        $text = implode( "\n", $lines );
        if ( strlen( $text ) > 4090 ) $text = substr( $text, 0, 4085 ) . "\n…";

        $chat_ids = array_filter( array_map( 'trim', explode( ',', (string) $cfg['chat_id'] ) ) );
        $ok_count = 0;
        foreach ( $chat_ids as $chat_id ) {
            $res = wp_remote_post( 'https://api.telegram.org/bot' . rawurlencode( $cfg['bot_token'] ) . '/sendMessage', [
                'body'    => [ 'chat_id' => $chat_id, 'text' => $text, 'parse_mode' => 'Markdown', 'disable_web_page_preview' => true ],
                'timeout' => 15,
            ] );
            if ( is_wp_error( $res ) ) {
                error_log( '[FormCraft Pro] Telegram push failed to chat ' . $chat_id . ': ' . $res->get_error_message() );
                continue;
            }
            $body = json_decode( wp_remote_retrieve_body( $res ), true );
            if ( ! empty( $body['ok'] ) ) $ok_count++;
            else error_log( '[FormCraft Pro] Telegram API returned: ' . ( $body['description'] ?? 'unknown' ) );
        }
        return $ok_count > 0;
    }

    /** Escape Markdown special chars for Telegram. */
    private static function tg_escape( $s ) {
        return str_replace( [ '_', '*', '`', '[' ], [ '\_', '\*', '\`', '\[' ], (string) $s );
    }

    /* ================================================================
     * Microsoft Teams webhook (v2.72)
     * Uses the MessageCard format (still supported alongside Adaptive
     * Cards for incoming-webhook connectors).
     * ================================================================ */
    public static function push_msteams( $cfg, $form, $payload ) {
        $data = isset( $payload['data'] ) && is_array( $payload['data'] ) ? $payload['data'] : [];
        $facts = [];
        $i = 0;
        foreach ( $data as $k => $v ) {
            if ( is_string( $k ) && strpos( $k, '_' ) === 0 ) continue;
            if ( is_array( $v ) ) $v = implode( ', ', array_map( 'strval', $v ) );
            $val = (string) $v;
            if ( $val === '' ) continue;
            if ( strlen( $val ) > 400 ) $val = substr( $val, 0, 397 ) . '…';
            $facts[] = [ 'name' => (string) $k, 'value' => $val ];
            if ( ++$i >= 20 ) break;
        }
        $card = [
            '@type'      => 'MessageCard',
            '@context'   => 'https://schema.org/extensions',
            'themeColor' => '6366F1',
            'summary'    => 'New submission on ' . ( $form['title'] ?? 'form' ),
            'title'      => '🔔 ' . ( $form['title'] ?? 'Form' ) . ' — new submission',
            'sections'   => [ [
                'activityTitle'    => (string) ( $payload['name'] ?? 'Anonymous' ),
                'activitySubtitle' => (string) ( $payload['email'] ?? '' ),
                'facts'            => $facts,
            ] ],
        ];
        $res = wp_remote_post( $cfg['webhook_url'], [
            'headers' => [ 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( $card ),
            'timeout' => 15,
        ] );
        if ( is_wp_error( $res ) ) {
            error_log( '[FormCraft Pro] Teams push failed: ' . $res->get_error_message() );
            return $res;
        }
        return true;
    }

    /* ================================================================
     * Box.com cloud storage (v2.72)
     * Uploads submission JSON to a Box folder. Uses a plain access token
     * (Box "developer token" or user OAuth token) — no OAuth refresh
     * dance in this release; use the token from the Box developer console.
     * ================================================================ */
    public static function push_box( $cfg, $payload, $form, $clean_data ) {
        $folder_id = trim( (string) ( $cfg['folder_id'] ?? '0' ) ); // 0 = root
        $token     = (string) $cfg['access_token'];
        $sub_id    = (int) ( $payload['submission_id'] ?? 0 );
        $filename  = 'submission-' . $sub_id . '.json';

        // Box uploads use their upload subdomain + multipart form POST
        $boundary  = '----FCPBoxBoundary' . wp_generate_password( 12, false );
        $json      = wp_json_encode( $payload, JSON_PRETTY_PRINT );
        $attrs     = wp_json_encode( [ 'name' => $filename, 'parent' => [ 'id' => $folder_id ] ] );

        $body  = "--$boundary\r\n";
        $body .= "Content-Disposition: form-data; name=\"attributes\"\r\n\r\n" . $attrs . "\r\n";
        $body .= "--$boundary\r\n";
        $body .= "Content-Disposition: form-data; name=\"file\"; filename=\"$filename\"\r\n";
        $body .= "Content-Type: application/json\r\n\r\n" . $json . "\r\n";
        $body .= "--$boundary--\r\n";

        $res = wp_remote_post( 'https://upload.box.com/api/2.0/files/content', [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'multipart/form-data; boundary=' . $boundary,
            ],
            'body'    => $body,
            'timeout' => 30,
        ] );
        if ( is_wp_error( $res ) ) {
            error_log( '[FormCraft Pro] Box push failed: ' . $res->get_error_message() );
            return $res;
        }
        return true;
    }

    /* ================================================================
     * Google Sheets integration (v2.70.14)
     *
     * Uses SERVICE ACCOUNT auth — no user OAuth callback needed. Admin:
     *   1. Creates a service account in Google Cloud Console
     *   2. Enables Sheets API on that project
     *   3. Downloads the JSON key
     *   4. Pastes client_email + private_key + spreadsheet_id here
     *   5. SHARES the target sheet with the service account's email
     *      (as Editor) — one click in Google Sheets → Share.
     *
     * On every submission we:
     *   - Sign a JWT with the service account's private key (RS256)
     *   - Exchange it for a short-lived access token
     *   - Append a row to the specified sheet/tab
     *
     * First-ever append writes a header row (form field labels) if the
     * sheet is empty. Subsequent appends align values to that header order.
     * ================================================================ */
    public static function push_google_sheets( $cfg, $form, $payload ) {
        $data = isset( $payload['data'] ) && is_array( $payload['data'] ) ? $payload['data'] : [];
        // Strip internal meta ("_meta", "_ai") from the outbound row
        foreach ( array_keys( $data ) as $k ) {
            if ( is_string( $k ) && strpos( $k, '_' ) === 0 ) unset( $data[ $k ] );
        }

        $spreadsheet_id = trim( (string) ( $cfg['spreadsheet_id'] ?? '' ) );
        $sheet_name     = trim( (string) ( $cfg['sheet_name'] ?? 'Sheet1' ) ) ?: 'Sheet1';

        $token = self::gsheets_access_token( $cfg );
        if ( is_wp_error( $token ) ) {
            error_log( '[FormCraft Pro] Google Sheets auth failed: ' . $token->get_error_message() );
            return $token;
        }

        // Ensure header row exists — read A1:Z1 first, only write header
        // if the sheet is empty. Prevents duplicate headers on every submit.
        $range   = rawurlencode( $sheet_name . '!A1:Z1' );
        $get_url = 'https://sheets.googleapis.com/v4/spreadsheets/' . rawurlencode( $spreadsheet_id ) . '/values/' . $range;
        $head_res = wp_remote_get( $get_url, [
            'headers' => [ 'Authorization' => 'Bearer ' . $token ],
            'timeout' => 15,
        ] );
        $existing_header = [];
        if ( ! is_wp_error( $head_res ) ) {
            $body = json_decode( wp_remote_retrieve_body( $head_res ), true );
            if ( isset( $body['values'][0] ) && is_array( $body['values'][0] ) ) {
                $existing_header = array_map( 'strval', $body['values'][0] );
            }
        }

        // Build the row. If the sheet already has a header, align values
        // to that header order (fill missing with ""). Otherwise, use the
        // form's own field labels + a few standard meta columns.
        $meta_cols = [
            'Submitted At' => current_time( 'mysql' ),
            'Name'         => (string) ( $payload['name']  ?? '' ),
            'Email'        => (string) ( $payload['email'] ?? '' ),
            'Form'         => (string) ( $form['title']    ?? '' ),
        ];
        $combined = array_merge( $meta_cols, $data );

        $write_header = false;
        if ( ! $existing_header ) {
            $existing_header = array_keys( $combined );
            $write_header    = true;
        }

        $row = [];
        foreach ( $existing_header as $col ) {
            $v = $combined[ $col ] ?? '';
            if ( is_array( $v ) ) $v = wp_json_encode( $v );
            $row[] = (string) $v;
        }

        $values_to_append = $write_header ? [ $existing_header, $row ] : [ $row ];

        // Append (VALUE_INPUT_OPTION=RAW so Sheets doesn't try to parse
        // numbers/dates — we already sanitized).
        $append_range = rawurlencode( $sheet_name . '!A1' );
        $append_url   = 'https://sheets.googleapis.com/v4/spreadsheets/' . rawurlencode( $spreadsheet_id )
                      . '/values/' . $append_range
                      . ':append?valueInputOption=RAW&insertDataOption=INSERT_ROWS';
        $res = wp_remote_post( $append_url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ],
            'body'    => wp_json_encode( [ 'values' => $values_to_append ] ),
            'timeout' => 15,
        ] );
        if ( is_wp_error( $res ) ) {
            error_log( '[FormCraft Pro] Google Sheets append failed: ' . $res->get_error_message() );
            return $res;
        }
        $code = wp_remote_retrieve_response_code( $res );
        if ( $code < 200 || $code >= 300 ) {
            $body = wp_remote_retrieve_body( $res );
            error_log( '[FormCraft Pro] Google Sheets HTTP ' . $code . ': ' . substr( $body, 0, 500 ) );
            return new WP_Error( 'sheets_http_' . $code, 'Google Sheets API returned HTTP ' . $code );
        }
        return true;
    }

    /**
     * Get a short-lived (1h) access token for Google Sheets using a
     * service account JWT. Token is cached in a transient so we don't
     * re-mint it on every submission.
     */
    private static function gsheets_access_token( $cfg ) {
        $client_email = trim( (string) ( $cfg['client_email'] ?? '' ) );
        $private_key  = (string) ( $cfg['private_key'] ?? '' );
        // Normalize private key — pasting it into a JSON textarea often
        // leaves it as a single line with literal "\n" chars. Convert
        // those back to real newlines so openssl_sign can parse it.
        $private_key  = str_replace( "\\n", "\n", $private_key );
        if ( ! $client_email || ! $private_key ) {
            return new WP_Error( 'no_creds', 'Missing client_email or private_key for Google Sheets.' );
        }

        $cache_key = 'fcp_gsheets_' . md5( $client_email );
        $cached = get_transient( $cache_key );
        if ( is_string( $cached ) && $cached ) return $cached;

        // Build JWT
        $now = time();
        $jwt_header = [ 'alg' => 'RS256', 'typ' => 'JWT' ];
        $jwt_claims = [
            'iss'   => $client_email,
            'scope' => 'https://www.googleapis.com/auth/spreadsheets',
            'aud'   => 'https://oauth2.googleapis.com/token',
            'iat'   => $now,
            'exp'   => $now + 3600,
        ];
        $b64 = function ( $s ) { return rtrim( strtr( base64_encode( $s ), '+/', '-_' ), '=' ); };
        $head_seg = $b64( wp_json_encode( $jwt_header ) );
        $body_seg = $b64( wp_json_encode( $jwt_claims ) );
        $signing_input = $head_seg . '.' . $body_seg;

        $signature = '';
        $key = openssl_pkey_get_private( $private_key );
        if ( ! $key ) {
            $err = function_exists( 'openssl_error_string' ) ? openssl_error_string() : 'unknown';
            return new WP_Error( 'bad_key', 'Could not parse the private key. Make sure you pasted the FULL "private_key" value from the JSON, including "-----BEGIN PRIVATE KEY-----" and "-----END PRIVATE KEY-----". OpenSSL says: ' . $err );
        }
        $ok = openssl_sign( $signing_input, $signature, $key, 'SHA256' );
        if ( ! $ok ) return new WP_Error( 'sign_failed', 'Could not sign JWT.' );
        $jwt = $signing_input . '.' . $b64( $signature );

        // Exchange for access token
        $res = wp_remote_post( 'https://oauth2.googleapis.com/token', [
            'body'    => [
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion'  => $jwt,
            ],
            'timeout' => 20,
        ] );
        if ( is_wp_error( $res ) ) return $res;
        $body = json_decode( wp_remote_retrieve_body( $res ), true );
        if ( empty( $body['access_token'] ) ) {
            $msg = ( $body['error_description'] ?? ( $body['error'] ?? 'no token in response' ) );
            return new WP_Error( 'token_failed', 'Google auth failed: ' . $msg );
        }
        $ttl = max( 60, (int) ( $body['expires_in'] ?? 3600 ) - 60 );
        set_transient( $cache_key, $body['access_token'], $ttl );
        return $body['access_token'];
    }

    /**
     * Test-connection endpoint used by the config modal's "Test" button.
     * Attempts to auth + read the header row so admins get instant
     * feedback on whether their setup works before saving.
     */
    public static function test_google_sheets( $cfg ) {
        $token = self::gsheets_access_token( $cfg );
        if ( is_wp_error( $token ) ) return $token;
        $spreadsheet_id = trim( (string) ( $cfg['spreadsheet_id'] ?? '' ) );
        $sheet_name     = trim( (string) ( $cfg['sheet_name'] ?? 'Sheet1' ) ) ?: 'Sheet1';
        if ( ! $spreadsheet_id ) return new WP_Error( 'no_sheet', 'Enter a spreadsheet ID first.' );
        $range = rawurlencode( $sheet_name . '!A1:A1' );
        $url = 'https://sheets.googleapis.com/v4/spreadsheets/' . rawurlencode( $spreadsheet_id ) . '/values/' . $range;
        $res = wp_remote_get( $url, [ 'headers' => [ 'Authorization' => 'Bearer ' . $token ], 'timeout' => 15 ] );
        if ( is_wp_error( $res ) ) return $res;
        $code = wp_remote_retrieve_response_code( $res );
        $body = json_decode( wp_remote_retrieve_body( $res ), true );
        if ( $code === 403 ) {
            return new WP_Error( 'not_shared', 'Auth works, but this service account cannot access the sheet. Open the target Google Sheet, click Share, and add ' . ( $cfg['client_email'] ?? 'your service account email' ) . ' as Editor.' );
        }
        if ( $code === 404 ) return new WP_Error( 'not_found', 'Spreadsheet not found. Double-check the spreadsheet ID.' );
        if ( $code < 200 || $code >= 300 ) return new WP_Error( 'http_' . $code, 'Sheets API returned HTTP ' . $code . ': ' . ( $body['error']['message'] ?? '' ) );
        return [ 'ok' => true, 'sheet_id' => $spreadsheet_id, 'sheet_name' => $sheet_name ];
    }
}
