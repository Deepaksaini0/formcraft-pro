<?php
/**
 * Pure-PHP unit tests for FCP_Ad_Platforms.
 *
 * These tests exercise the helpers that build/format outbound payloads
 * (PII hashing, name splitting, registry shape) without making any HTTP
 * requests or touching the database. Fast — should run in milliseconds.
 */

declare( strict_types=1 );

use PHPUnit\Framework\TestCase;

final class AdPlatformsTest extends TestCase {

    /**
     * The registry is the public contract of the dispatcher. Each entry
     * must declare a name, group, and field list — the admin UI mirrors
     * these and would break if the shape drifted.
     */
    public function test_registry_shape() : void {
        $reg = FCP_Ad_Platforms::registry();
        $this->assertNotEmpty( $reg, 'Registry must not be empty.' );

        foreach ( $reg as $key => $meta ) {
            $this->assertIsString( $key );
            $this->assertArrayHasKey( 'name',   $meta, "$key missing name" );
            $this->assertArrayHasKey( 'group',  $meta, "$key missing group" );
            $this->assertContains( $meta['group'], [ 'ads', 'social', 'messaging' ], "$key group invalid" );
            $this->assertArrayHasKey( 'fields', $meta, "$key missing fields" );
            $this->assertIsArray( $meta['fields'] );
        }
    }

    /**
     * PII hashing: every ad-platform server-side adapter passes user data
     * through the same private h() helper. We can't reach it directly, but
     * we can verify the shape via the public collect_pixel_snippets() path
     * (it doesn't hash, so no test there) and the registry round-trip.
     *
     * Direct hashing test via reflection — proves it's lowercase + trimmed
     * + SHA-256, which is the contract every platform (Meta, TikTok, etc.)
     * requires.
     */
    public function test_sha256_hash_helper() : void {
        $rc = new ReflectionClass( FCP_Ad_Platforms::class );
        $m  = $rc->getMethod( 'h' );
        $m->setAccessible( true );

        $this->assertSame( '', $m->invoke( null, '' ) );
        $expected = hash( 'sha256', 'jane@example.com' );
        $this->assertSame( $expected, $m->invoke( null, '  JANE@EXAMPLE.COM ' ),
            'Email must be lowercased + trimmed before hashing.' );
        // Phone numbers: only digits + plus survive the pick_phone strip, but
        // the h() helper itself doesn't strip — it just normalizes case.
        $this->assertSame( hash( 'sha256', '+919876543210' ), $m->invoke( null, '+919876543210' ) );
    }

    /**
     * The name splitter must always return [first, last] — even on edge
     * cases like single names or empty strings — because the Meta CAPI
     * payload uses both fn and ln keys.
     */
    public function test_name_splitter() : void {
        $rc = new ReflectionClass( FCP_Ad_Platforms::class );
        $m  = $rc->getMethod( 'split_name' );
        $m->setAccessible( true );

        $this->assertSame( [ 'Deepak', 'Saini' ], $m->invoke( null, 'Deepak Saini' ) );
        $this->assertSame( [ 'Cher', '' ],         $m->invoke( null, 'Cher' ) );
        $this->assertSame( [ '', '' ],             $m->invoke( null, '' ) );
        $this->assertSame( [ 'Maria', 'Garcia Lopez' ], $m->invoke( null, 'Maria Garcia Lopez' ) );
    }

    /**
     * The pixel-snippet emitter must produce HTML that includes the
     * configured pixel ID and listens for the fcp:submitted event.
     */
    public function test_meta_pixel_snippet_includes_pixel_id() : void {
        $rc = new ReflectionClass( FCP_Ad_Platforms::class );
        $m  = $rc->getMethod( 'pixel_snippet' );
        $m->setAccessible( true );

        $snippet = $m->invoke( null, 'meta', [ 'pixel_id' => '1234567890123456' ] );
        $this->assertStringContainsString( '1234567890123456',        $snippet );
        $this->assertStringContainsString( "fbq('track','Lead')",     $snippet );
        $this->assertStringContainsString( "fcp:submitted",           $snippet );
    }

    public function test_empty_pixel_id_emits_nothing() : void {
        $rc = new ReflectionClass( FCP_Ad_Platforms::class );
        $m  = $rc->getMethod( 'pixel_snippet' );
        $m->setAccessible( true );
        $this->assertSame( '', $m->invoke( null, 'meta', [] ) );
    }
}
