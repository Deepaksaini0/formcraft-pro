<?php
/**
 * Unit tests for FCP_Migrator's pure helpers — field-type mapping,
 * label humanizer, count helpers. The DB-touching adapters are exercised
 * by the integration suite separately.
 */

declare( strict_types=1 );

use PHPUnit\Framework\TestCase;

final class MigratorTest extends TestCase {

    public function test_sources_registry_shape() : void {
        $sources = FCP_Migrator::sources();
        $this->assertNotEmpty( $sources );
        foreach ( $sources as $key => $meta ) {
            $this->assertArrayHasKey( 'name',            $meta );
            $this->assertArrayHasKey( 'has_submissions', $meta );
            $this->assertIsBool( $meta['has_submissions'] );
        }
    }

    public function test_humanize_label() : void {
        $rc = new ReflectionClass( FCP_Migrator::class );
        $m  = $rc->getMethod( 'humanize_label' );
        $m->setAccessible( true );

        $this->assertSame( 'First Name',  $m->invoke( null, 'first-name' ) );
        $this->assertSame( 'First Name',  $m->invoke( null, 'first_name' ) );
        $this->assertSame( 'Email',       $m->invoke( null, 'email' ) );
        $this->assertSame( 'Field',       $m->invoke( null, '' ) );
    }

    public function test_blank_form_has_required_keys() : void {
        $rc = new ReflectionClass( FCP_Migrator::class );
        $m  = $rc->getMethod( 'blank_form' );
        $m->setAccessible( true );

        $form = $m->invoke( null, 'Test Form' );
        $this->assertSame( 'Test Form',  $form['title'] );
        $this->assertSame( 'draft',      $form['status'] );
        $this->assertNotEmpty( $form['steps'] );
        $this->assertArrayHasKey( 'settings', $form );
        $this->assertArrayHasKey( 'notifications', $form['settings'] );
    }

    public function test_count_form_fields_walks_all_steps() : void {
        $rc = new ReflectionClass( FCP_Migrator::class );
        $m  = $rc->getMethod( 'count_form_fields' );
        $m->setAccessible( true );

        $form = [
            'steps' => [
                [ 'fields' => [ [ 'id' => 1 ], [ 'id' => 2 ] ] ],
                [ 'fields' => [ [ 'id' => 3 ] ] ],
                [],
            ],
        ];
        $this->assertSame( 3, $m->invoke( null, $form ) );
    }

    public function test_strip_cf7_tags() : void {
        $rc = new ReflectionClass( FCP_Migrator::class );
        $m  = $rc->getMethod( 'strip_cf7_tags' );
        $m->setAccessible( true );

        $this->assertSame( ' you',         $m->invoke( null, '[email] you' ) );
        $this->assertSame( 'no tags here', $m->invoke( null, 'no tags here' ) );
    }
}
