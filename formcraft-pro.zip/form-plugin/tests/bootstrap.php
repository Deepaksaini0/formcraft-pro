<?php
/**
 * PHPUnit bootstrap.
 *
 * Two test paths:
 *   1. Unit tests (tests/unit/) — pure PHP, no WP, no DB. Faster, run on
 *      every commit via `composer test:unit`. Cover pure helpers like
 *      FCP_Ad_Platforms hashing, FCP_Migrator field-type mapping, etc.
 *   2. Integration tests (tests/integration/) — bootstrap WordPress
 *      (requires WP_TESTS_DIR env var pointing at the WP test suite)
 *      and exercise the REST endpoints + DB writes end-to-end.
 *
 * We don't ship vendor/ in the plugin zip — contributors run
 * `composer install` locally to enable the test runner.
 */

declare( strict_types=1 );

// Composer autoloader (PHPUnit + polyfills).
$autoload = dirname( __DIR__ ) . '/vendor/autoload.php';
if ( file_exists( $autoload ) ) {
    require_once $autoload;
}

// ----- Unit-test mode (no WordPress) -----
// Stub the small subset of WordPress globals our pure-PHP helpers touch.
// If WP_TESTS_DIR is set we fall through to the WordPress bootstrap below
// instead, which loads the real APIs.
if ( ! getenv( 'WP_TESTS_DIR' ) ) {

    if ( ! function_exists( 'sanitize_text_field' ) ) {
        function sanitize_text_field( $s ) { return is_string( $s ) ? trim( strip_tags( $s ) ) : ''; }
    }
    if ( ! function_exists( 'sanitize_email' ) ) {
        function sanitize_email( $s ) { return is_string( $s ) ? filter_var( $s, FILTER_SANITIZE_EMAIL ) : ''; }
    }
    if ( ! function_exists( 'is_email' ) ) {
        function is_email( $s ) { return is_string( $s ) && filter_var( $s, FILTER_VALIDATE_EMAIL ) !== false ? $s : false; }
    }
    if ( ! function_exists( 'wp_unslash' ) )       { function wp_unslash( $v )       { return is_string( $v ) ? stripslashes( $v ) : $v; } }
    if ( ! function_exists( 'esc_url_raw' ) )      { function esc_url_raw( $u )      { return filter_var( $u, FILTER_SANITIZE_URL ); } }
    if ( ! function_exists( 'esc_js' ) )           { function esc_js( $s )           { return str_replace( [ "'", '"', "\n" ], [ "\\'", '\\"', '\\n' ], (string) $s ); } }
    if ( ! function_exists( 'wp_json_encode' ) )   { function wp_json_encode( $d )   { return json_encode( $d ); } }
    if ( ! function_exists( 'get_option' ) )       { function get_option( $k, $d = null ) { return $d; } }
    if ( ! function_exists( 'get_bloginfo' ) )     { function get_bloginfo( $k = '' ) { return 'Test Site'; } }
    if ( ! function_exists( 'home_url' ) )         { function home_url( $p = '' )     { return 'https://test.local' . $p; } }
    if ( ! function_exists( 'wp_remote_post' ) )   { function wp_remote_post()        { /* no-op in unit tests */ } }

    // Constants used inside the includes/ files.
    if ( ! defined( 'ABSPATH' ) )       define( 'ABSPATH', __DIR__ . '/' );
    if ( ! defined( 'FCP_VERSION' ) )   define( 'FCP_VERSION', 'test' );
    if ( ! defined( 'FCP_PATH' ) )      define( 'FCP_PATH', dirname( __DIR__ ) . '/' );
    if ( ! defined( 'FCP_URL' ) )       define( 'FCP_URL',  'https://test.local/wp-content/plugins/formcraft-pro/' );

    // Load only the classes our unit tests cover (skip the full bootstrap).
    require_once dirname( __DIR__ ) . '/includes/class-fcp-ad-platforms.php';
    require_once dirname( __DIR__ ) . '/includes/class-fcp-migrator.php';
    return;
}

// ----- Integration-test mode (real WordPress) -----
$tests_dir = getenv( 'WP_TESTS_DIR' );
require_once $tests_dir . '/includes/functions.php';

tests_add_filter( 'muplugins_loaded', static function () {
    require dirname( __DIR__ ) . '/formcraft-pro.php';
} );

require $tests_dir . '/includes/bootstrap.php';
