=== FormCraft Pro ===
Contributors: formcraft
Tags: forms, form builder, multi-step form, contact form, drag and drop, recaptcha, conditional logic, payment forms, gravity forms alternative
Requires at least: 5.5
Tested up to: 6.5
Requires PHP: 7.2
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Modern drag-and-drop multi-step form builder with conditional logic, reCAPTCHA, analytics, submission management and integrations.

== Description ==

FormCraft Pro is a modern, lightweight, and powerful alternative to Gravity Forms. Build beautiful multi-step forms with a true drag-and-drop builder, then track and manage submissions from a premium SaaS-style dashboard.

= Features =

* **Drag-and-Drop Form Builder** — 50+ field types including Name, Email, Phone, File Upload, Date Picker, Signature, Rating, Payment fields and more
* **Multi-Step Forms** — Progress bars, step validation, auto-save, and animated transitions
* **Conditional Logic** — Show or hide fields based on other field values
* **Google reCAPTCHA** — v2 Checkbox, v2 Invisible, and v3 (Score) support
* **Email Notifications** — Admin notifications and user confirmations with merge tags
* **SMTP Integration** — Use Gmail, SendGrid, Mailgun, Amazon SES, Outlook, or any SMTP provider
* **Submission Management** — Filter, search, export (CSV, JSON, PDF), spam handling, bulk actions
* **Analytics** — Views, conversions, devices, countries, drop-off tracking with beautiful charts
* **Integrations** — Webhooks, Zapier, Slack, Mailchimp, HubSpot, Google Sheets, Stripe, Razorpay, PayPal
* **Templates Library** — 8 starter templates + AI form generator
* **REST API** — Full programmatic control
* **Frontend Shortcode** — `[formcraft id="1"]` to embed anywhere
* **Custom Styling** — Brand colors, fonts, button styles, custom CSS
* **Security** — CSRF protection, honeypot, rate limiting, file validation, GDPR consent
* **Dark Mode** — Beautiful dark and light themes
* **Mobile Responsive** — Works perfectly on every device
* **Multi-language & RTL** — Translation-ready

= Why FormCraft Pro? =

Built from scratch as a modern alternative to legacy form plugins. Lightweight, fast, secure, and beautiful out of the box.

== Installation ==

1. Upload the `form-plugin` (or `formcraft-pro`) folder to the `/wp-content/plugins/` directory, **or** install the plugin through the WordPress Plugins screen by uploading the `.zip` file.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. A new menu item **FormCraft Pro** appears in your admin sidebar — click it to get started.
4. Use the shortcode `[formcraft id="X"]` on any page or post to display a form.

== Frequently Asked Questions ==

= Where do I find the form ID? =

Go to **FormCraft Pro → Forms** and the ID is shown in the table for each form.

= Can I migrate from Contact Form 7 or WPForms? =

Yes — use the **Import** button on the Forms list to import a JSON export.

= Is reCAPTCHA required? =

No, but recommended. You can also use the built-in honeypot and rate limiting without reCAPTCHA keys.

= Where are submissions stored? =

In a custom database table (`wp_fcp_submissions`) with proper indexes for fast filtering.

== Screenshots ==

1. Modern admin dashboard with charts and recent activity
2. Drag-and-drop form builder with multi-step support
3. Submissions list with filters and bulk actions
4. Analytics with conversion funnel and device breakdown
5. reCAPTCHA settings with v2/v3 support
6. Beautiful form rendering on the frontend

== Changelog ==

= 2.0.0 =
* Initial release: complete builder, dashboard, analytics, integrations, REST API.

== Upgrade Notice ==

= 2.0.0 =
Initial release of FormCraft Pro.
