<?php
/**
 * Fires when the user deletes the plugin via the Plugins screen.
 * Drops the custom tables and removes the options.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;
$prefix = $wpdb->prefix;

$wpdb->query( "DROP TABLE IF EXISTS {$prefix}fcp_forms" );
$wpdb->query( "DROP TABLE IF EXISTS {$prefix}fcp_submissions" );

delete_option( 'fcp_settings' );
delete_option( 'fcp_version' );

// Clear transients
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_fcp\\_%' OR option_name LIKE '\\_transient\\_timeout\\_fcp\\_%'" );
