<?php
/**
 * FormCraft Pro — SaaS / Monetization layer.
 *
 * Bundles five related concerns into one class because they all read
 * from the same `fcp_settings.saas` options blob and answer the same
 * question: "what brand is this plugin running as, what's the customer
 * allowed to do, and how much have they used?"
 *
 *   1. White-label settings
 *        Admin overrides plugin display name, logo URL, support email,
 *        and the "Powered by FormCraft Pro" footer. Stored under
 *        fcp_settings.saas.brand.
 *
 *   2. License key system
 *        validate_license($key) POSTs to the configured license server
 *        (the admin can point this at their own gumroad / paddle / lemon
 *        squeezy / freemius webhook). On success we cache the
 *        valid-until date + plan tier for 12 hours. Premium features
 *        check has_valid_license() before unlocking.
 *
 *   3. Usage-based add-ons
 *        increment_usage($metric) bumps a counter scoped to the current
 *        month. Metrics are pluggable — the plugin tracks submissions,
 *        ai_calls, ocr_calls, and storage_mb out of the box. When a
 *        soft-limit is hit we surface a warning banner; hard-limits
 *        block the action.
 *
 *   4. Hosted SaaS
 *        register_rest() exposes /saas/embed which returns a signed
 *        embed token that lets a remote site render a form WITHOUT
 *        WordPress credentials. Used by the standalone hosted form
 *        page (/formcraft-pro/{slug}/) so it can run on a custom
 *        subdomain without exposing the admin area.
 *
 *   5. Multi-site / network admin
 *        On multisite installs we hook network_admin_menu to expose
 *        aggregate dashboards (totals across every site). License is
 *        network-activated by default — pay once for the whole network.
 *
 * One options blob, one class, one menu entry. Keeps the codebase from
 * growing five sub-classes that all need the same `get_option` boot.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_SaaS {

    const OPTION_KEY        = 'fcp_settings';
    const SAAS_NAMESPACE    = 'saas';
    const LICENSE_CACHE_TTL = 12 * HOUR_IN_SECONDS;
    const DEFAULT_FOOTER    = 'Powered by FormCraft Pro';

    /* Pluggable usage metrics. Add a new key here + an admin display
       label + a default soft/hard limit and the rest of the system
       picks it up automatically. */
    const METRICS = [
        'submissions'  => [ 'label' => 'Submissions',  'soft' => 800,   'hard' => 1000 ],
        'ai_calls'     => [ 'label' => 'AI calls',     'soft' => 400,   'hard' => 500 ],
        'ocr_calls'    => [ 'label' => 'OCR calls',    'soft' => 80,    'hard' => 100 ],
        'storage_mb'   => [ 'label' => 'File storage', 'soft' => 800,   'hard' => 1024 ],
    ];

    /* -------------------------------------------------------------------
     * Bootstrap — hooks fired from formcraft-pro.php on plugins_loaded.
     * ----------------------------------------------------------------- */
    public static function bootstrap() {
        add_action( 'rest_api_init', [ __CLASS__, 'register_rest' ] );
        // Multisite hooks fire under network_admin only.
        if ( is_multisite() ) {
            add_action( 'network_admin_menu',  [ __CLASS__, 'register_network_menu' ] );
        }
        // Auto-increment submission usage whenever a submission lands.
        add_action( 'fcp_submission_created', [ __CLASS__, 'on_submission' ], 10, 4 );
        // Inject the white-label footer attribution into form-engine output.
        add_filter( 'fcp_public_footer_html', [ __CLASS__, 'footer_html' ], 10, 2 );
    }

    /* -------------------------------------------------------------------
     * Settings accessors — single source of truth for the saas blob.
     * ----------------------------------------------------------------- */
    public static function get_settings() {
        $all = get_option( self::OPTION_KEY, [] );
        return isset( $all[ self::SAAS_NAMESPACE ] ) && is_array( $all[ self::SAAS_NAMESPACE ] )
            ? $all[ self::SAAS_NAMESPACE ]
            : [];
    }
    public static function update_settings( $patch ) {
        $all  = get_option( self::OPTION_KEY, [] );
        $saas = isset( $all[ self::SAAS_NAMESPACE ] ) && is_array( $all[ self::SAAS_NAMESPACE ] ) ? $all[ self::SAAS_NAMESPACE ] : [];
        $saas = array_replace_recursive( $saas, (array) $patch );
        $all[ self::SAAS_NAMESPACE ] = $saas;
        update_option( self::OPTION_KEY, $all, false );
        return $saas;
    }

    /* ===================================================================
     * 1. White-label settings + runtime application
     * =================================================================== */
    public static function brand() {
        $s = self::get_settings();
        $b = isset( $s['brand'] ) && is_array( $s['brand'] ) ? $s['brand'] : [];
        return [
            'enabled'       => ! empty( $b['enabled'] ),
            'name'          => isset( $b['name'] ) && $b['name']                ? (string) $b['name']          : 'FormCraft Pro',
            'logo_url'      => isset( $b['logo_url'] ) && $b['logo_url']        ? (string) $b['logo_url']      : '',
            'support_email' => isset( $b['support_email'] ) && $b['support_email'] ? (string) $b['support_email'] : '',
            'support_url'   => isset( $b['support_url'] ) && $b['support_url']  ? (string) $b['support_url']   : '',
            'footer_html'   => isset( $b['footer_html'] )                       ? (string) $b['footer_html']   : self::DEFAULT_FOOTER,
            'hide_footer'   => ! empty( $b['hide_footer'] ),
            'hide_links'    => ! empty( $b['hide_links'] ),  // strip docs/upgrade links from sidebar
        ];
    }

    public static function footer_html( $default, $form ) {
        $b = self::brand();
        if ( ! $b['enabled'] ) return $default;
        if ( $b['hide_footer'] ) return '';
        return wp_kses_post( $b['footer_html'] );
    }

    /* ===================================================================
     * 2. License key system
     * =================================================================== */
    public static function get_license() {
        $s = self::get_settings();
        return isset( $s['license'] ) && is_array( $s['license'] ) ? $s['license'] : [
            'key'         => '',
            'status'      => 'inactive',  // inactive | valid | expired | invalid
            'plan'        => '',          // "free" | "starter" | "pro" | "agency" | "lifetime"
            'valid_until' => '',
            'activated_at'=> '',
            'last_check'  => '',
            'site_count'  => 0,
        ];
    }
    public static function has_valid_license() {
        $l = self::get_license();
        if ( $l['status'] !== 'valid' ) return false;
        if ( ! $l['valid_until'] )      return true; // lifetime
        return strtotime( $l['valid_until'] ) > time();
    }
    public static function license_tier() {
        return self::get_license()['plan'] ?? '';
    }

    /**
     * Validate a license key against the admin-configured license server.
     * The server URL is stored in fcp_settings.saas.license_server (admin
     * controls it so they can point at their own gumroad/paddle/lemon
     * squeezy webhook). Expected response shape:
     *   { ok: true, plan: "pro", valid_until: "2027-06-15", site_limit: 5 }
     */
    public static function validate_license( $key ) {
        $key = trim( (string) $key );
        if ( ! $key ) return new WP_Error( 'bad_input', 'License key required', [ 'status' => 400 ] );

        $s      = self::get_settings();
        $server = isset( $s['license_server'] ) ? esc_url_raw( (string) $s['license_server'] ) : '';
        if ( ! $server ) {
            // Offline / self-managed mode — accept any key with the right
            // shape and store it as a lifetime "self-hosted" license.
            // Useful for agencies running the plugin internally.
            if ( ! preg_match( '/^[A-Z0-9-]{12,}$/i', $key ) ) {
                return new WP_Error( 'bad_key', 'License key format looks wrong — expected at least 12 alphanumeric/dash characters.', [ 'status' => 400 ] );
            }
            $license = [
                'key'          => $key,
                'status'       => 'valid',
                'plan'         => 'self-hosted',
                'valid_until'  => '',
                'activated_at' => current_time( 'mysql' ),
                'last_check'   => current_time( 'mysql' ),
                'site_count'   => 1,
            ];
            self::update_settings( [ 'license' => $license ] );
            return $license;
        }

        $resp = wp_remote_post( $server, [
            'timeout' => 15,
            'headers' => [ 'content-type' => 'application/json' ],
            'body'    => wp_json_encode( [
                'action'    => 'activate',
                'license'   => $key,
                'site_url'  => home_url(),
                'site_name' => get_bloginfo( 'name' ),
            ] ),
        ] );
        if ( is_wp_error( $resp ) ) return $resp;
        $code = wp_remote_retrieve_response_code( $resp );
        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        if ( $code < 200 || $code >= 300 || empty( $body['ok'] ) ) {
            return new WP_Error( 'license_rejected', $body['message'] ?? 'License server rejected the key', [ 'status' => 400 ] );
        }
        $license = [
            'key'          => $key,
            'status'       => 'valid',
            'plan'         => sanitize_text_field( $body['plan']        ?? 'pro' ),
            'valid_until'  => sanitize_text_field( $body['valid_until'] ?? '' ),
            'activated_at' => current_time( 'mysql' ),
            'last_check'   => current_time( 'mysql' ),
            'site_count'   => (int) ( $body['site_count'] ?? 1 ),
        ];
        self::update_settings( [ 'license' => $license ] );
        return $license;
    }

    public static function deactivate_license() {
        self::update_settings( [ 'license' => [
            'key' => '', 'status' => 'inactive', 'plan' => '',
            'valid_until' => '', 'activated_at' => '', 'last_check' => current_time( 'mysql' ),
            'site_count' => 0,
        ] ] );
    }

    /* ===================================================================
     * 3. Usage-based add-ons
     * =================================================================== */

    /** Period key — "2026-06" — so a metric increment is always bucketed by month. */
    private static function period() { return gmdate( 'Y-m' ); }

    public static function get_usage( $period = null ) {
        $period = $period ?: self::period();
        $s      = self::get_settings();
        $usage  = isset( $s['usage'] ) && is_array( $s['usage'] ) ? $s['usage'] : [];
        return isset( $usage[ $period ] ) && is_array( $usage[ $period ] ) ? $usage[ $period ] : [];
    }

    public static function increment_usage( $metric, $amount = 1 ) {
        if ( ! isset( self::METRICS[ $metric ] ) ) return;
        $period = self::period();
        $s      = self::get_settings();
        $usage  = isset( $s['usage'] ) && is_array( $s['usage'] ) ? $s['usage'] : [];
        if ( ! isset( $usage[ $period ] ) ) $usage[ $period ] = [];
        $usage[ $period ][ $metric ] = ( $usage[ $period ][ $metric ] ?? 0 ) + (int) $amount;
        // Trim history older than 12 months so the option doesn't grow forever.
        $cutoff = strtotime( '-12 months' );
        foreach ( array_keys( $usage ) as $p ) {
            $ts = strtotime( $p . '-01' );
            if ( $ts && $ts < $cutoff ) unset( $usage[ $p ] );
        }
        self::update_settings( [ 'usage' => $usage ] );
    }

    /** Returns: [ value, soft, hard, percent_of_hard, status: "ok|warn|over" ]. */
    public static function metric_state( $metric, $period = null ) {
        $value = (int) ( self::get_usage( $period )[ $metric ] ?? 0 );
        $def   = self::METRICS[ $metric ] ?? [ 'soft' => null, 'hard' => null ];
        $soft  = $def['soft']; $hard = $def['hard'];
        $pct   = $hard ? min( 100, round( ( $value / $hard ) * 100 ) ) : 0;
        $status = 'ok';
        if ( $soft && $value >= $soft ) $status = 'warn';
        if ( $hard && $value >= $hard ) $status = 'over';
        return [ 'value' => $value, 'soft' => $soft, 'hard' => $hard, 'percent' => $pct, 'status' => $status ];
    }

    public static function would_block( $metric ) {
        // Hard-blocks only apply when the license is NOT lifetime/agency
        // and the metric has gone over. Self-hosted / unlimited plans
        // bypass the block.
        $l = self::get_license();
        $plan = $l['plan'] ?? '';
        if ( in_array( $plan, [ 'agency', 'lifetime', 'self-hosted', 'unlimited' ], true ) ) return false;
        return self::metric_state( $metric )['status'] === 'over';
    }

    public static function on_submission( $sid, $form, $clean, $is_spam ) {
        if ( $is_spam ) return; // don't count spam against quota
        self::increment_usage( 'submissions', 1 );
    }

    /* ===================================================================
     * 4. Hosted-SaaS embed token
     * Used by remote pages that want to render this form via JS without
     * exposing wp-admin credentials. The hosted-form page reads ?t=token
     * + validates against this signed payload before mounting.
     * =================================================================== */
    public static function sign_embed( $form_id, $expires_in = 3600 ) {
        $form_id = (int) $form_id;
        if ( ! $form_id ) return null;
        $exp     = time() + (int) $expires_in;
        $payload = $form_id . '.' . $exp;
        $sig     = hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) );
        return $payload . '.' . substr( $sig, 0, 32 );
    }

    public static function verify_embed( $token ) {
        $parts = explode( '.', (string) $token );
        if ( count( $parts ) !== 3 ) return null;
        [ $form_id, $exp, $sig ] = $parts;
        if ( (int) $exp < time() ) return null;
        $expected = substr( hash_hmac( 'sha256', $form_id . '.' . $exp, wp_salt( 'auth' ) ), 0, 32 );
        if ( ! hash_equals( $expected, $sig ) ) return null;
        return [ 'form_id' => (int) $form_id, 'expires' => (int) $exp ];
    }

    /* ===================================================================
     * 5. Multisite / network admin
     * =================================================================== */
    public static function register_network_menu() {
        add_menu_page(
            'FormCraft Network',
            'FormCraft Network',
            'manage_network',
            'fcp-network',
            [ __CLASS__, 'render_network_page' ],
            'dashicons-feedback',
            66
        );
    }

    public static function render_network_page() {
        if ( ! current_user_can( 'manage_network' ) ) return;
        $sites = get_sites( [ 'number' => 0 ] );
        $rows  = [];
        $totals = [ 'forms' => 0, 'submissions' => 0 ];
        foreach ( $sites as $site ) {
            switch_to_blog( (int) $site->blog_id );
            global $wpdb;
            $forms = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . FCP_DB::forms_table() );
            $subs  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . FCP_DB::subs_table() );
            $rows[] = [
                'blog_id'   => (int) $site->blog_id,
                'domain'    => $site->domain . $site->path,
                'forms'     => $forms,
                'subs'      => $subs,
                'admin_url' => network_admin_url( 'admin.php?page=fcp-network-jump&site=' . $site->blog_id ),
                'site_url'  => trailingslashit( $site->siteurl ?? home_url() ) . 'wp-admin/admin.php?page=formcraft-pro',
            ];
            $totals['forms']       += $forms;
            $totals['submissions'] += $subs;
            restore_current_blog();
        }
        $l = self::get_license();
        ?>
        <div class="wrap">
            <h1>FormCraft Network</h1>
            <p>Aggregate stats across every site on this multisite network. License is shared network-wide.</p>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin:14px 0;">
                <div style="padding:14px;background:#fff;border:1px solid #e5e7eb;border-radius:8px;">
                    <div style="font-size:11px;color:#64748b;text-transform:uppercase;font-weight:700;">Sites</div>
                    <div style="font-size:24px;font-weight:800;"><?php echo count( $rows ); ?></div>
                </div>
                <div style="padding:14px;background:#fff;border:1px solid #e5e7eb;border-radius:8px;">
                    <div style="font-size:11px;color:#64748b;text-transform:uppercase;font-weight:700;">Total forms</div>
                    <div style="font-size:24px;font-weight:800;"><?php echo number_format( $totals['forms'] ); ?></div>
                </div>
                <div style="padding:14px;background:#fff;border:1px solid #e5e7eb;border-radius:8px;">
                    <div style="font-size:11px;color:#64748b;text-transform:uppercase;font-weight:700;">Total submissions</div>
                    <div style="font-size:24px;font-weight:800;"><?php echo number_format( $totals['submissions'] ); ?></div>
                </div>
                <div style="padding:14px;background:#fff;border:1px solid #e5e7eb;border-radius:8px;">
                    <div style="font-size:11px;color:#64748b;text-transform:uppercase;font-weight:700;">License</div>
                    <div style="font-size:14px;font-weight:700;"><?php echo esc_html( $l['plan'] ?: 'inactive' ); ?></div>
                </div>
            </div>
            <table class="wp-list-table widefat striped">
                <thead><tr><th>Site</th><th>Forms</th><th>Submissions</th><th>Open</th></tr></thead>
                <tbody>
                    <?php foreach ( $rows as $r ) : ?>
                        <tr>
                            <td><strong><?php echo esc_html( $r['domain'] ); ?></strong></td>
                            <td><?php echo number_format( $r['forms'] ); ?></td>
                            <td><?php echo number_format( $r['subs'] ); ?></td>
                            <td><a href="<?php echo esc_url( $r['site_url'] ); ?>">FormCraft →</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /* ===================================================================
     * REST endpoints — drive the admin saas.html page.
     * =================================================================== */
    public static function register_rest() {
        $ns  = 'fcp/v1';
        // v2.64.2 — Use a named static method as the permission callback,
        // not a closure. Some hosts' WP loaders fail to serialize closures
        // when the REST route map is cached, which silently drops the
        // route registration. Named callbacks are bulletproof.
        $cap = [ __CLASS__, 'can_manage' ];

        // v2.64.2 — Register each HTTP method as its OWN route call. The
        // array-of-arrays multi-method shorthand is technically valid per
        // the WP docs but seems to fail-silent on certain shared-host WP
        // builds — the route just never appears in the REST index. One
        // call per verb is the bulletproof equivalent.
        register_rest_route( $ns, '/saas/brand', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'rest_brand_get' ],
            'permission_callback' => $cap,
        ] );
        register_rest_route( $ns, '/saas/brand', [
            'methods'             => 'POST',
            'callback'            => [ __CLASS__, 'rest_brand_save' ],
            'permission_callback' => $cap,
        ], true ); // 4th-arg "override" lets the second call coexist with the first

        register_rest_route( $ns, '/saas/license', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'rest_license_get' ],
            'permission_callback' => $cap,
        ] );
        register_rest_route( $ns, '/saas/license', [
            'methods'             => 'POST',
            'callback'            => [ __CLASS__, 'rest_license_save' ],
            'permission_callback' => $cap,
        ], true );

        register_rest_route( $ns, '/saas/license/activate', [
            'methods'             => 'POST',
            'callback'            => [ __CLASS__, 'rest_license_activate' ],
            'permission_callback' => $cap,
        ] );
        register_rest_route( $ns, '/saas/license/deactivate', [
            'methods'             => 'POST',
            'callback'            => [ __CLASS__, 'rest_license_deactivate' ],
            'permission_callback' => $cap,
        ] );
        register_rest_route( $ns, '/saas/usage', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'rest_usage' ],
            'permission_callback' => $cap,
        ] );
        register_rest_route( $ns, '/saas/embed-token', [
            'methods'             => 'POST',
            'callback'            => [ __CLASS__, 'rest_embed_token' ],
            'permission_callback' => $cap,
        ] );
    }

    /** Public permission callback — referenced by name in register_rest(). */
    public static function can_manage() {
        return current_user_can( 'manage_options' );
    }

    /**
     * v2.64.1 — Safe body parser. WP_REST_Request::get_json_params() can
     * return null (no body) or a non-array value (malformed JSON). Without
     * this guard, downstream `$body['name']` would fatal in PHP 8 with
     * "Cannot access offset on null". One helper across every handler.
     */
    private static function body( $r ) {
        $b = $r->get_json_params();
        return is_array( $b ) ? $b : [];
    }

    public static function rest_brand_get()     { return rest_ensure_response( self::brand() ); }
    public static function rest_brand_save( $r ){
        $body = self::body( $r );
        $clean = [
            'enabled'       => ! empty( $body['enabled'] ),
            'name'          => sanitize_text_field( (string) ( $body['name']          ?? '' ) ),
            'logo_url'      => esc_url_raw( (string) ( $body['logo_url']               ?? '' ) ),
            'support_email' => sanitize_email( (string) ( $body['support_email']      ?? '' ) ),
            'support_url'   => esc_url_raw( (string) ( $body['support_url']            ?? '' ) ),
            'footer_html'   => wp_kses_post( (string) ( $body['footer_html']          ?? '' ) ),
            'hide_footer'   => ! empty( $body['hide_footer'] ),
            'hide_links'    => ! empty( $body['hide_links'] ),
        ];
        self::update_settings( [ 'brand' => $clean ] );
        return rest_ensure_response( self::brand() );
    }
    public static function rest_license_get()   { $l = self::get_license(); unset( $l['key'] ); return rest_ensure_response( $l ); }
    public static function rest_license_save( $r ){
        $body = self::body( $r );
        if ( isset( $body['license_server'] ) ) {
            self::update_settings( [ 'license_server' => esc_url_raw( (string) $body['license_server'] ) ] );
        }
        return rest_ensure_response( [ 'ok' => true, 'license_server' => self::get_settings()['license_server'] ?? '' ] );
    }
    public static function rest_license_activate( $r ) {
        $body = self::body( $r );
        $key  = (string) ( $body['key'] ?? '' );
        $out  = self::validate_license( $key );
        if ( is_wp_error( $out ) ) return $out;
        if ( class_exists( 'FCP_Audit' ) ) FCP_Audit::log( 'license_activated', 'license', null, null, [ 'plan' => $out['plan'] ] );
        unset( $out['key'] );
        return rest_ensure_response( $out );
    }
    public static function rest_license_deactivate() {
        self::deactivate_license();
        if ( class_exists( 'FCP_Audit' ) ) FCP_Audit::log( 'license_deactivated', 'license', null, null, null );
        return rest_ensure_response( [ 'ok' => true ] );
    }
    public static function rest_usage() {
        $period = gmdate( 'Y-m' );
        $out = [];
        foreach ( array_keys( self::METRICS ) as $m ) {
            $out[ $m ] = self::metric_state( $m, $period );
        }
        // Recent 6 months for the trend chart.
        $history = [];
        for ( $i = 5; $i >= 0; $i-- ) {
            $p = gmdate( 'Y-m', strtotime( "-{$i} months" ) );
            $history[ $p ] = self::get_usage( $p );
        }
        return rest_ensure_response( [
            'period'   => $period,
            'metrics'  => $out,
            'history'  => $history,
            'limits'   => self::METRICS,
            'license'  => self::get_license()['plan'] ?? 'inactive',
        ] );
    }
    public static function rest_embed_token( $r ) {
        $body    = self::body( $r );
        $form_id = (int) ( $body['form_id'] ?? 0 );
        $ttl     = (int) ( $body['ttl']     ?? 3600 );
        $token   = self::sign_embed( $form_id, $ttl );
        if ( ! $token ) return new WP_Error( 'bad_form', 'form_id required', [ 'status' => 400 ] );
        return rest_ensure_response( [
            'token'     => $token,
            'embed_url' => add_query_arg( [ 't' => $token ], trailingslashit( home_url() ) . 'formcraft-pro/embed/' ),
        ] );
    }
}
