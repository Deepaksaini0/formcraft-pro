<?php
/**
 * FormCraft Pro — Privacy / GDPR / CCPA.
 *
 * Plugs into WordPress core's Personal Data Exporter / Eraser framework
 * (Tools → Export Personal Data / Erase Personal Data). When the admin
 * runs an export or erase request for a given email, our hooks contribute:
 *   - Every form submission whose submitter_email matches
 *   - Every abandoned partial submission whose submitter_email matches
 *   - The Form User row (membership system) for that email
 *   - The user-journey blob attached to each submission
 *
 * Works alongside any other privacy-compliant plugin — WordPress dedupes
 * and bundles all responses into a single .zip the admin can deliver to
 * the data subject.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_Privacy {

    public function __construct() {
        add_filter( 'wp_privacy_personal_data_exporters', [ $this, 'register_exporters' ] );
        add_filter( 'wp_privacy_personal_data_erasers',   [ $this, 'register_erasers' ] );
        add_filter( 'wp_privacy_anonymize_data',          [ $this, 'anonymize_data_passthrough' ], 10, 3 );
    }

    /**
     * Register three exporters: completed submissions, abandoned
     * submissions, and Form Users. Each one is paginated through by core.
     */
    public function register_exporters( $exporters ) {
        $exporters['formcraft-pro-submissions'] = [
            'exporter_friendly_name' => __( 'FormCraft Pro — Form Submissions', 'formcraft-pro' ),
            'callback'               => [ $this, 'export_submissions' ],
        ];
        $exporters['formcraft-pro-abandoned'] = [
            'exporter_friendly_name' => __( 'FormCraft Pro — Abandoned Submissions', 'formcraft-pro' ),
            'callback'               => [ $this, 'export_abandoned' ],
        ];
        $exporters['formcraft-pro-form-users'] = [
            'exporter_friendly_name' => __( 'FormCraft Pro — Form User Account', 'formcraft-pro' ),
            'callback'               => [ $this, 'export_form_user' ],
        ];
        return $exporters;
    }

    public function register_erasers( $erasers ) {
        $erasers['formcraft-pro-submissions'] = [
            'eraser_friendly_name' => __( 'FormCraft Pro — Form Submissions', 'formcraft-pro' ),
            'callback'             => [ $this, 'erase_submissions' ],
        ];
        $erasers['formcraft-pro-abandoned'] = [
            'eraser_friendly_name' => __( 'FormCraft Pro — Abandoned Submissions', 'formcraft-pro' ),
            'callback'             => [ $this, 'erase_abandoned' ],
        ];
        $erasers['formcraft-pro-form-users'] = [
            'eraser_friendly_name' => __( 'FormCraft Pro — Form User Account', 'formcraft-pro' ),
            'callback'             => [ $this, 'erase_form_user' ],
        ];
        return $erasers;
    }

    /* -----------------------------------------------------------
     * EXPORTERS
     *
     * Return shape WP expects:
     *   { data: [ {group_id, group_label, item_id, data: [{name, value},...]} ], done: bool }
     * -------------------------------------------------------- */

    public function export_submissions( $email_address, $page = 1 ) {
        global $wpdb;
        $page     = max( 1, (int) $page );
        $per_page = 25;
        $offset   = ( $page - 1 ) * $per_page;
        $table    = FCP_DB::subs_table();
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM $table WHERE submitter_email = %s AND is_abandoned = 0 ORDER BY id ASC LIMIT %d OFFSET %d",
            $email_address, $per_page, $offset
        ), ARRAY_A );

        $data = [];
        foreach ( (array) $rows as $r ) {
            $items = [
                [ 'name' => __( 'Submission ID', 'formcraft-pro' ),    'value' => (int) $r['id'] ],
                [ 'name' => __( 'Form ID', 'formcraft-pro' ),          'value' => (int) $r['form_id'] ],
                [ 'name' => __( 'Submitter Name', 'formcraft-pro' ),   'value' => $r['submitter_name'] ],
                [ 'name' => __( 'Submitter Email', 'formcraft-pro' ),  'value' => $r['submitter_email'] ],
                [ 'name' => __( 'IP Address', 'formcraft-pro' ),       'value' => $r['ip_address'] ],
                [ 'name' => __( 'User Agent', 'formcraft-pro' ),       'value' => $r['user_agent'] ],
                [ 'name' => __( 'Country', 'formcraft-pro' ),          'value' => $r['country'] ],
                [ 'name' => __( 'Device', 'formcraft-pro' ),           'value' => $r['device'] ],
                [ 'name' => __( 'Browser', 'formcraft-pro' ),          'value' => $r['browser'] ],
                [ 'name' => __( 'Submitted At', 'formcraft-pro' ),     'value' => $r['created_at'] ],
            ];
            // Expand each form field key/value
            $form_data = json_decode( (string) $r['data'], true );
            if ( is_array( $form_data ) ) {
                foreach ( $form_data as $k => $v ) {
                    if ( is_array( $v ) || is_object( $v ) ) $v = wp_json_encode( $v );
                    $items[] = [
                        'name'  => sprintf( __( 'Field: %s', 'formcraft-pro' ), (string) $k ),
                        'value' => (string) $v,
                    ];
                }
            }
            // Payment info if present
            if ( ! empty( $r['payment_id'] ) ) {
                $items[] = [ 'name' => __( 'Payment Status', 'formcraft-pro' ),    'value' => $r['payment_status'] ];
                $items[] = [ 'name' => __( 'Payment Provider', 'formcraft-pro' ),  'value' => $r['payment_provider'] ];
                $items[] = [ 'name' => __( 'Payment Amount', 'formcraft-pro' ),    'value' => $r['payment_amount'] . ' ' . $r['payment_currency'] ];
            }
            // User journey if captured
            if ( ! empty( $r['journey'] ) ) {
                $items[] = [
                    'name'  => __( 'User Journey (pages visited before submitting)', 'formcraft-pro' ),
                    'value' => $r['journey'],
                ];
            }
            $data[] = [
                'group_id'    => 'formcraft-pro-submissions',
                'group_label' => __( 'FormCraft Pro — Form Submissions', 'formcraft-pro' ),
                'item_id'     => 'fcp-submission-' . $r['id'],
                'data'        => $items,
            ];
        }

        $done = count( $rows ) < $per_page;
        return [ 'data' => $data, 'done' => $done ];
    }

    public function export_abandoned( $email_address, $page = 1 ) {
        global $wpdb;
        $page     = max( 1, (int) $page );
        $per_page = 25;
        $offset   = ( $page - 1 ) * $per_page;
        $table    = FCP_DB::subs_table();
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM $table WHERE submitter_email = %s AND is_abandoned = 1 ORDER BY id ASC LIMIT %d OFFSET %d",
            $email_address, $per_page, $offset
        ), ARRAY_A );

        $data = [];
        foreach ( (array) $rows as $r ) {
            $items = [
                [ 'name' => __( 'Form ID', 'formcraft-pro' ),         'value' => (int) $r['form_id'] ],
                [ 'name' => __( 'Last Touched', 'formcraft-pro' ),    'value' => $r['last_touched_at'] ],
                [ 'name' => __( 'IP Address', 'formcraft-pro' ),      'value' => $r['ip_address'] ],
                [ 'name' => __( 'Captured Fields', 'formcraft-pro' ), 'value' => $r['data'] ],
            ];
            $data[] = [
                'group_id'    => 'formcraft-pro-abandoned',
                'group_label' => __( 'FormCraft Pro — Abandoned Submissions', 'formcraft-pro' ),
                'item_id'     => 'fcp-abandoned-' . $r['id'],
                'data'        => $items,
            ];
        }

        $done = count( $rows ) < $per_page;
        return [ 'data' => $data, 'done' => $done ];
    }

    public function export_form_user( $email_address, $page = 1 ) {
        if ( ! class_exists( 'FCP_Users' ) ) return [ 'data' => [], 'done' => true ];
        $user = FCP_Users::find_by_email( $email_address );
        if ( ! $user ) return [ 'data' => [], 'done' => true ];

        $items = [
            [ 'name' => __( 'Form User ID', 'formcraft-pro' ),     'value' => (int) $user['id'] ],
            [ 'name' => __( 'Display Name', 'formcraft-pro' ),     'value' => $user['display_name'] ],
            [ 'name' => __( 'Email', 'formcraft-pro' ),            'value' => $user['email'] ],
            [ 'name' => __( 'Phone', 'formcraft-pro' ),            'value' => $user['phone'] ],
            [ 'name' => __( 'Status', 'formcraft-pro' ),           'value' => $user['status'] ],
            [ 'name' => __( 'Registered Form ID', 'formcraft-pro' ),'value' => (int) $user['registered_form_id'] ],
            [ 'name' => __( 'Login Count', 'formcraft-pro' ),      'value' => (int) $user['login_count'] ],
            [ 'name' => __( 'Last Login', 'formcraft-pro' ),       'value' => $user['last_login_at'] ],
            [ 'name' => __( 'Last Login IP', 'formcraft-pro' ),    'value' => $user['last_login_ip'] ],
            [ 'name' => __( 'Created At', 'formcraft-pro' ),       'value' => $user['created_at'] ],
        ];
        // Additional meta captured from the registration form
        if ( ! empty( $user['meta'] ) ) {
            $meta = json_decode( (string) $user['meta'], true );
            if ( is_array( $meta ) ) {
                foreach ( $meta as $k => $v ) {
                    if ( is_array( $v ) || is_object( $v ) ) $v = wp_json_encode( $v );
                    $items[] = [
                        'name'  => sprintf( __( 'Meta: %s', 'formcraft-pro' ), (string) $k ),
                        'value' => (string) $v,
                    ];
                }
            }
        }

        return [
            'data' => [ [
                'group_id'    => 'formcraft-pro-form-users',
                'group_label' => __( 'FormCraft Pro — Form User Account', 'formcraft-pro' ),
                'item_id'     => 'fcp-form-user-' . $user['id'],
                'data'        => $items,
            ] ],
            'done' => true,
        ];
    }

    /* -----------------------------------------------------------
     * ERASERS
     *
     * Return shape WP expects:
     *   { items_removed, items_retained, messages, done }
     * -------------------------------------------------------- */

    public function erase_submissions( $email_address, $page = 1 ) {
        global $wpdb;
        $per_page = 50;
        $offset   = ( max( 1, (int) $page ) - 1 ) * $per_page;
        $table    = FCP_DB::subs_table();
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id FROM $table WHERE submitter_email = %s AND is_abandoned = 0 ORDER BY id ASC LIMIT %d OFFSET %d",
            $email_address, $per_page, $offset
        ), ARRAY_A );
        $removed = 0;
        foreach ( (array) $rows as $r ) {
            // Anonymize rather than hard-delete by default — preserves stats
            // (total submissions count) while stripping all PII. Admins who
            // want hard-delete can use the Form Users delete action instead.
            $wpdb->update( $table, [
                'submitter_name'  => '',
                'submitter_email' => '',
                'ip_address'      => '0.0.0.0',
                'user_agent'      => '',
                'data'            => wp_json_encode( [ '_anonymized' => true ] ),
                'journey'         => null,
            ], [ 'id' => (int) $r['id'] ] );
            $removed++;
        }
        return [
            'items_removed'  => $removed,
            'items_retained' => false,
            'messages'       => [],
            'done'           => count( $rows ) < $per_page,
        ];
    }

    public function erase_abandoned( $email_address, $page = 1 ) {
        global $wpdb;
        $per_page = 50;
        $offset   = ( max( 1, (int) $page ) - 1 ) * $per_page;
        $table    = FCP_DB::subs_table();
        // Hard-delete abandoned rows — they have no business value once
        // the visitor invokes their right to erasure.
        $rows = $wpdb->get_col( $wpdb->prepare(
            "SELECT id FROM $table WHERE submitter_email = %s AND is_abandoned = 1 ORDER BY id ASC LIMIT %d OFFSET %d",
            $email_address, $per_page, $offset
        ) );
        $removed = 0;
        foreach ( (array) $rows as $id ) {
            $wpdb->delete( $table, [ 'id' => (int) $id ] );
            $removed++;
        }
        return [
            'items_removed'  => $removed,
            'items_retained' => false,
            'messages'       => [],
            'done'           => count( $rows ) < $per_page,
        ];
    }

    public function erase_form_user( $email_address, $page = 1 ) {
        if ( ! class_exists( 'FCP_Users' ) ) {
            return [ 'items_removed' => 0, 'items_retained' => false, 'messages' => [], 'done' => true ];
        }
        $user = FCP_Users::find_by_email( $email_address );
        if ( ! $user ) {
            return [ 'items_removed' => 0, 'items_retained' => false, 'messages' => [], 'done' => true ];
        }
        FCP_Users::delete_user( (int) $user['id'] );
        return [
            'items_removed'  => 1,
            'items_retained' => false,
            'messages'       => [],
            'done'           => true,
        ];
    }

    /** No-op filter — exists so other privacy-suite plugins can hook in. */
    public function anonymize_data_passthrough( $anonymous, $type, $data ) {
        return $anonymous;
    }
}
