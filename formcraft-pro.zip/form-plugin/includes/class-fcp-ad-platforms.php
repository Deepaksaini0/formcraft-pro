<?php
/**
 * FormCraft Pro - Ad Platforms, Social Posting, Messaging dispatcher.
 *
 * Three phases bundled in one registry-driven class:
 *
 *   PHASE 1 — Ad Conversions APIs (server-side):
 *     Meta (Facebook+Instagram), Google Ads, TikTok, LinkedIn, Pinterest
 *   PHASE 2 — Ad Conversions APIs (server-side):
 *     Snapchat, Twitter/X, Reddit, Microsoft Ads (Bing), Quora
 *   PHASE 3 — Social posting + messaging:
 *     Facebook Page, Instagram Business, LinkedIn Page,
 *     Telegram, WhatsApp Business, Microsoft Teams, Discord
 *
 * Plus client-side pixel injection for every ad platform that supports one
 * (output by collect_pixel_snippets() — the shortcode emits them once per
 * form render and fires the standard `Lead`/`SubmitForm`/`generate_lead`
 * event when the success message appears).
 *
 * Each ad-conversion adapter is intentionally short (single push_* method),
 * hashes PII (email/phone) before sending, and uses fire-and-forget HTTP
 * so the visitor's submit response isn't blocked on slow third-party APIs.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_Ad_Platforms {

    /* =====================================================================
     * Registry — single source of truth for what the plugin supports.
     * Adding a new platform = add a row here + one push_* method below.
     * ================================================================== */

    public static function registry() {
        return [
            // ---------- PHASE 1 ----------
            'meta' => [
                'name'   => 'Meta (Facebook + Instagram)',
                'group'  => 'ads',
                'phase'  => 1,
                'pixel'  => true,
                'capi'   => true,
                'fields' => [
                    'pixel_id'     => [ 'label' => 'Pixel ID', 'placeholder' => '1234567890123456' ],
                    'access_token' => [ 'label' => 'Conversions API Access Token', 'type' => 'password', 'placeholder' => 'EAAxxxxxxxxxxxx' ],
                    'test_code'    => [ 'label' => 'Test Event Code', 'placeholder' => 'TEST12345 (optional)' ],
                ],
            ],
            'google_ads' => [
                'name'   => 'Google Ads',
                'group'  => 'ads',
                'phase'  => 1,
                'pixel'  => true,
                'capi'   => true,
                'fields' => [
                    'conversion_id'    => [ 'label' => 'Conversion ID', 'placeholder' => 'AW-123456789' ],
                    'conversion_label' => [ 'label' => 'Conversion Label', 'placeholder' => 'abcDEFgHiJ' ],
                    'developer_token'  => [ 'label' => 'Developer Token (offline upload)', 'type' => 'password' ],
                    'customer_id'      => [ 'label' => 'Customer ID', 'placeholder' => '123-456-7890' ],
                ],
            ],
            'tiktok' => [
                'name'   => 'TikTok Ads',
                'group'  => 'ads',
                'phase'  => 1,
                'pixel'  => true,
                'capi'   => true,
                'fields' => [
                    'pixel_id'     => [ 'label' => 'Pixel ID', 'placeholder' => 'C12345ABCDE6789FGHIJ' ],
                    'access_token' => [ 'label' => 'Events API Access Token', 'type' => 'password' ],
                ],
            ],
            'linkedin_ads' => [
                'name'   => 'LinkedIn Ads',
                'group'  => 'ads',
                'phase'  => 1,
                'pixel'  => true,
                'capi'   => true,
                'fields' => [
                    'partner_id'    => [ 'label' => 'Partner / Insight Tag ID', 'placeholder' => '1234567' ],
                    'access_token'  => [ 'label' => 'Conversions API Access Token', 'type' => 'password' ],
                    'conversion_id' => [ 'label' => 'Conversion Rule ID', 'placeholder' => 'urn:lla:llaPartnerConversion:1234567' ],
                ],
            ],
            'pinterest_ads' => [
                'name'   => 'Pinterest Ads',
                'group'  => 'ads',
                'phase'  => 1,
                'pixel'  => true,
                'capi'   => true,
                'fields' => [
                    'pixel_id'      => [ 'label' => 'Tag ID', 'placeholder' => '2613000000000' ],
                    'ad_account_id' => [ 'label' => 'Ad Account ID' ],
                    'access_token'  => [ 'label' => 'Conversions API Access Token', 'type' => 'password' ],
                ],
            ],
            // ---------- PHASE 2 ----------
            'snapchat' => [
                'name'   => 'Snapchat Ads',
                'group'  => 'ads',
                'phase'  => 2,
                'pixel'  => true,
                'capi'   => true,
                'fields' => [
                    'pixel_id'     => [ 'label' => 'Pixel ID' ],
                    'access_token' => [ 'label' => 'Long-Lived Access Token', 'type' => 'password' ],
                ],
            ],
            'twitter_ads' => [
                'name'   => 'Twitter / X Ads',
                'group'  => 'ads',
                'phase'  => 2,
                'pixel'  => true,
                'capi'   => false,
                'fields' => [
                    'pixel_id' => [ 'label' => 'Pixel / Tag ID', 'placeholder' => 'o1abc' ],
                    'event_id' => [ 'label' => 'Conversion Event ID', 'placeholder' => 'tw-o1abc-xyz' ],
                ],
            ],
            'reddit' => [
                'name'   => 'Reddit Ads',
                'group'  => 'ads',
                'phase'  => 2,
                'pixel'  => true,
                'capi'   => true,
                'fields' => [
                    'pixel_id'     => [ 'label' => 'Pixel ID', 'placeholder' => 'a2_xxxxxxxxxxxxxx' ],
                    'access_token' => [ 'label' => 'Conversions Access Token', 'type' => 'password' ],
                ],
            ],
            'bing_ads' => [
                'name'   => 'Microsoft Ads (Bing)',
                'group'  => 'ads',
                'phase'  => 2,
                'pixel'  => true,
                'capi'   => false,
                'fields' => [
                    'uet_tag_id' => [ 'label' => 'UET Tag ID', 'placeholder' => '12345678' ],
                ],
            ],
            'quora_ads' => [
                'name'   => 'Quora Ads',
                'group'  => 'ads',
                'phase'  => 2,
                'pixel'  => true,
                'capi'   => false,
                'fields' => [
                    'pixel_id' => [ 'label' => 'Pixel ID' ],
                ],
            ],

            // ---------- PHASE 3a — social posting ----------
            'fb_page' => [
                'name'   => 'Facebook Page',
                'group'  => 'social',
                'phase'  => 3,
                'fields' => [
                    'page_id'      => [ 'label' => 'Page ID' ],
                    'access_token' => [ 'label' => 'Page Access Token', 'type' => 'password' ],
                    'template'     => [ 'label' => 'Post template (placeholders: {name}, {email}, {form_title})', 'type' => 'textarea', 'placeholder' => 'New submission from {name}: {email}' ],
                ],
            ],
            'ig_business' => [
                'name'   => 'Instagram Business',
                'group'  => 'social',
                'phase'  => 3,
                'fields' => [
                    'ig_user_id'   => [ 'label' => 'Instagram Business User ID' ],
                    'access_token' => [ 'label' => 'Access Token', 'type' => 'password' ],
                    'image_url'    => [ 'label' => 'Image URL (required by IG API)', 'placeholder' => 'https://example.com/post.jpg' ],
                    'template'     => [ 'label' => 'Caption template', 'type' => 'textarea', 'placeholder' => 'New lead: {name} via {form_title}' ],
                ],
            ],
            'li_page' => [
                'name'   => 'LinkedIn Page',
                'group'  => 'social',
                'phase'  => 3,
                'fields' => [
                    'org_urn'      => [ 'label' => 'Organization URN', 'placeholder' => 'urn:li:organization:1234567' ],
                    'access_token' => [ 'label' => 'Access Token', 'type' => 'password' ],
                    'template'     => [ 'label' => 'Post template', 'type' => 'textarea', 'placeholder' => 'New submission from {name}' ],
                ],
            ],

            // ---------- PHASE 3b — messaging ----------
            'telegram' => [
                'name'   => 'Telegram',
                'group'  => 'messaging',
                'phase'  => 3,
                'fields' => [
                    'bot_token' => [ 'label' => 'Bot Token (from @BotFather)', 'type' => 'password', 'placeholder' => '123456789:ABC-DEF…' ],
                    'chat_id'   => [ 'label' => 'Chat ID', 'placeholder' => '-1001234567890 or @your_channel' ],
                ],
            ],
            'whatsapp' => [
                'name'   => 'WhatsApp Business',
                'group'  => 'messaging',
                'phase'  => 3,
                'fields' => [
                    'phone_number_id' => [ 'label' => 'Phone Number ID' ],
                    'access_token'    => [ 'label' => 'Access Token', 'type' => 'password' ],
                    'recipient'       => [ 'label' => 'Recipient phone (E.164)', 'placeholder' => '+919876543210' ],
                    'template'        => [ 'label' => 'WhatsApp template name', 'placeholder' => 'lead_notification' ],
                ],
            ],
            'teams' => [
                'name'   => 'Microsoft Teams',
                'group'  => 'messaging',
                'phase'  => 3,
                'fields' => [
                    'webhook_url' => [ 'label' => 'Incoming Webhook URL', 'type' => 'password', 'placeholder' => 'https://outlook.office.com/webhook/…' ],
                ],
            ],
            'discord' => [
                'name'   => 'Discord',
                'group'  => 'messaging',
                'phase'  => 3,
                'fields' => [
                    'webhook_url' => [ 'label' => 'Webhook URL', 'type' => 'password', 'placeholder' => 'https://discord.com/api/webhooks/…' ],
                ],
            ],
        ];
    }

    /* =====================================================================
     * Helpers — PII hashing, name/email extraction, cookies
     * ================================================================== */

    /** SHA-256 lowercase-trimmed hash. Required by every server-side ads API. */
    private static function h( $v ) {
        $v = strtolower( trim( (string) $v ) );
        return $v === '' ? '' : hash( 'sha256', $v );
    }

    private static function pick_email( $data ) {
        foreach ( $data as $v ) {
            if ( is_string( $v ) && is_email( trim( $v ) ) ) return trim( $v );
        }
        return '';
    }

    private static function pick_name( $data ) {
        foreach ( $data as $k => $v ) {
            if ( ! is_string( $v ) || $v === '' ) continue;
            $lk = strtolower( (string) $k );
            if ( strpos( $lk, 'name' ) !== false ) return trim( $v );
        }
        return '';
    }

    private static function pick_phone( $data ) {
        foreach ( $data as $k => $v ) {
            if ( ! is_string( $v ) || $v === '' ) continue;
            $lk = strtolower( (string) $k );
            if ( strpos( $lk, 'phone' ) !== false || strpos( $lk, 'mobile' ) !== false || strpos( $lk, 'tel' ) !== false ) {
                return preg_replace( '/[^\d+]/', '', $v );
            }
        }
        return '';
    }

    /** Visitor's IP for server-side conversion APIs (better attribution). */
    private static function ip() {
        if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) )      return $_SERVER['HTTP_CF_CONNECTING_IP'];
        if ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) )       return trim( explode( ',', $_SERVER['HTTP_X_FORWARDED_FOR'] )[0] );
        return $_SERVER['REMOTE_ADDR'] ?? '';
    }

    private static function ua() {
        return $_SERVER['HTTP_USER_AGENT'] ?? '';
    }

    /** First-name / last-name split — best-effort. */
    private static function split_name( $full ) {
        $parts = preg_split( '/\s+/', trim( (string) $full ), 2 );
        return [ $parts[0] ?? '', $parts[1] ?? '' ];
    }

    /** Cookie value or empty (used for fbp / fbc / _ttp etc). */
    private static function ck( $key ) {
        return isset( $_COOKIE[ $key ] ) ? sanitize_text_field( wp_unslash( $_COOKIE[ $key ] ) ) : '';
    }

    private static function async( $extra = [] ) {
        return array_replace_recursive( [
            'timeout'   => 4,
            'blocking'  => false,
            'sslverify' => true,
            'headers'   => [ 'Content-Type' => 'application/json' ],
        ], $extra );
    }

    private static function template( $tpl, $form, $data ) {
        $name  = self::pick_name( $data );
        $email = self::pick_email( $data );
        return str_replace(
            [ '{name}', '{email}', '{form_title}', '{site_name}' ],
            [ $name, $email, $form['title'] ?? '', get_bloginfo( 'name' ) ],
            (string) $tpl
        );
    }

    /* =====================================================================
     * Dispatcher — called from FCP_Integrations::fire()
     * ================================================================== */

    public static function fire( $form, $clean_data, $sid ) {
        $settings = get_option( 'fcp_settings', [] );
        $cfgs     = isset( $settings['ad_platforms'] ) && is_array( $settings['ad_platforms'] )
            ? $settings['ad_platforms'] : [];
        foreach ( self::registry() as $key => $meta ) {
            $cfg = $cfgs[ $key ] ?? [];
            if ( empty( $cfg['enabled'] ) ) continue;
            $method = 'push_' . $key;
            if ( method_exists( __CLASS__, $method ) ) {
                try {
                    call_user_func( [ __CLASS__, $method ], $cfg, $form, $clean_data, $sid );
                } catch ( \Throwable $e ) {
                    error_log( '[FormCraft Pro] ad-platforms ' . $key . ' failed: ' . $e->getMessage() );
                }
            }
        }
    }

    /* =====================================================================
     * PHASE 1 — Conversions APIs
     * ================================================================== */

    /** Meta Conversions API — Facebook + Instagram conversion events. */
    public static function push_meta( $cfg, $form, $data, $sid ) {
        $pixel  = trim( $cfg['pixel_id']     ?? '' );
        $token  = trim( $cfg['access_token'] ?? '' );
        if ( ! $pixel || ! $token ) return;

        $email = self::pick_email( $data );
        $phone = self::pick_phone( $data );
        $name  = self::pick_name( $data );
        list( $fn, $ln ) = self::split_name( $name );

        $user = array_filter( [
            'em'        => $email ? [ self::h( $email ) ] : null,
            'ph'        => $phone ? [ self::h( $phone ) ] : null,
            'fn'        => $fn    ? [ self::h( $fn ) ]    : null,
            'ln'        => $ln    ? [ self::h( $ln ) ]    : null,
            'client_ip_address'  => self::ip(),
            'client_user_agent'  => self::ua(),
            'fbp'                => self::ck( '_fbp' ),
            'fbc'                => self::ck( '_fbc' ),
        ] );

        $body = [
            'data' => [ [
                'event_name'    => 'Lead',
                'event_time'    => time(),
                'event_id'      => 'fcp_' . $sid,
                'action_source' => 'website',
                'event_source_url' => $_SERVER['HTTP_REFERER'] ?? home_url(),
                'user_data'     => $user,
                'custom_data'   => [ 'currency' => 'USD', 'value' => 0 ],
            ] ],
        ];
        if ( ! empty( $cfg['test_code'] ) ) $body['test_event_code'] = $cfg['test_code'];

        $url = 'https://graph.facebook.com/v18.0/' . rawurlencode( $pixel ) . '/events?access_token=' . rawurlencode( $token );
        wp_remote_post( $url, self::async( [ 'body' => wp_json_encode( $body ) ] ) );
    }

    /**
     * Google Ads — Offline Conversions upload via Google Ads API.
     * Requires a refresh token + developer token. As a fallback (and the
     * common case for SMB admins), we also send a simple "click conversion"
     * via the public conversion endpoint when a GCLID cookie is present.
     */
    public static function push_google_ads( $cfg, $form, $data, $sid ) {
        $conv_id    = trim( $cfg['conversion_id']    ?? '' );
        $conv_label = trim( $cfg['conversion_label'] ?? '' );
        if ( ! $conv_id || ! $conv_label ) return;

        $gclid = self::ck( '_gcl_aw' ) ?: self::ck( 'gclid' );
        if ( ! $gclid ) return;   // No click → nothing to attribute server-side

        // Public conversion-tracking endpoint (server-side beacon, no auth).
        // Mirrors what the on-page gtag('event', 'conversion') would fire.
        $url = 'https://www.googleadservices.com/pagead/conversion/' . rawurlencode( str_replace( 'AW-', '', $conv_id ) ) . '/';
        $body = http_build_query( [
            'label'  => $conv_label,
            'guid'   => $gclid,
            'value'  => 0,
            'is_vtc' => 0,
        ] );
        wp_remote_post( $url, self::async( [
            'headers' => [ 'Content-Type' => 'application/x-www-form-urlencoded' ],
            'body'    => $body,
        ] ) );
    }

    /** TikTok Events API */
    public static function push_tiktok( $cfg, $form, $data, $sid ) {
        $pixel = trim( $cfg['pixel_id']     ?? '' );
        $token = trim( $cfg['access_token'] ?? '' );
        if ( ! $pixel || ! $token ) return;

        $email = self::pick_email( $data );
        $phone = self::pick_phone( $data );

        $body = [
            'event_source'    => 'web',
            'event_source_id' => $pixel,
            'data' => [ [
                'event'      => 'SubmitForm',
                'event_time' => time(),
                'event_id'   => 'fcp_' . $sid,
                'user'       => array_filter( [
                    'email'      => $email ? self::h( $email ) : null,
                    'phone'      => $phone ? self::h( $phone ) : null,
                    'ip'         => self::ip(),
                    'user_agent' => self::ua(),
                    'ttp'        => self::ck( '_ttp' ),
                ] ),
                'page'       => [ 'url' => $_SERVER['HTTP_REFERER'] ?? home_url() ],
                'properties' => [ 'currency' => 'USD', 'value' => 0 ],
            ] ],
        ];

        wp_remote_post( 'https://business-api.tiktok.com/open_api/v1.3/event/track/', self::async( [
            'headers' => [ 'Access-Token' => $token, 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( $body ),
        ] ) );
    }

    /** LinkedIn Conversions API */
    public static function push_linkedin_ads( $cfg, $form, $data, $sid ) {
        $token   = trim( $cfg['access_token']  ?? '' );
        $conv_id = trim( $cfg['conversion_id'] ?? '' );
        if ( ! $token || ! $conv_id ) return;

        $email = self::pick_email( $data );
        if ( ! $email ) return;   // LI needs email as the primary user match

        $body = [
            'conversion'      => $conv_id,
            'conversionHappenedAt' => round( microtime( true ) * 1000 ),
            'user'            => [
                'userIds' => [ [
                    'idType'  => 'SHA256_EMAIL',
                    'idValue' => self::h( $email ),
                ] ],
            ],
        ];

        wp_remote_post( 'https://api.linkedin.com/rest/conversionEvents', self::async( [
            'headers' => [
                'Authorization'             => 'Bearer ' . $token,
                'LinkedIn-Version'          => '202401',
                'X-Restli-Protocol-Version' => '2.0.0',
                'Content-Type'              => 'application/json',
            ],
            'body' => wp_json_encode( $body ),
        ] ) );
    }

    /** Pinterest Conversions API */
    public static function push_pinterest_ads( $cfg, $form, $data, $sid ) {
        $pixel = trim( $cfg['pixel_id']      ?? '' );
        $acct  = trim( $cfg['ad_account_id'] ?? '' );
        $token = trim( $cfg['access_token']  ?? '' );
        if ( ! $pixel || ! $acct || ! $token ) return;

        $email = self::pick_email( $data );
        $body = [
            'data' => [ [
                'event_name'    => 'lead',
                'action_source' => 'web',
                'event_time'    => time(),
                'event_id'      => 'fcp_' . $sid,
                'event_source_url' => $_SERVER['HTTP_REFERER'] ?? home_url(),
                'user_data'     => array_filter( [
                    'em'                => $email ? [ self::h( $email ) ] : null,
                    'client_ip_address' => self::ip(),
                    'client_user_agent' => self::ua(),
                ] ),
            ] ],
        ];

        $url = 'https://api.pinterest.com/v5/ad_accounts/' . rawurlencode( $acct ) . '/events';
        wp_remote_post( $url, self::async( [
            'headers' => [ 'Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( $body ),
        ] ) );
    }

    /* =====================================================================
     * PHASE 2 — Conversions APIs
     * ================================================================== */

    /** Snapchat Conversions API */
    public static function push_snapchat( $cfg, $form, $data, $sid ) {
        $pixel = trim( $cfg['pixel_id']     ?? '' );
        $token = trim( $cfg['access_token'] ?? '' );
        if ( ! $pixel || ! $token ) return;
        $email = self::pick_email( $data );
        $body = [
            'data' => [ [
                'event_name'    => 'SIGN_UP',
                'event_time'    => time(),
                'event_id'      => 'fcp_' . $sid,
                'action_source' => 'web',
                'event_source_url' => $_SERVER['HTTP_REFERER'] ?? home_url(),
                'user_data' => array_filter( [
                    'em'         => $email ? [ self::h( $email ) ] : null,
                    'client_ip'  => self::ip(),
                    'user_agent' => self::ua(),
                ] ),
            ] ],
        ];
        $url = 'https://tr.snapchat.com/v3/' . rawurlencode( $pixel ) . '/events?access_token=' . rawurlencode( $token );
        wp_remote_post( $url, self::async( [ 'body' => wp_json_encode( $body ) ] ) );
    }

    /** Twitter / X — pixel-only (no public CAPI for SMB). No-op server-side. */
    public static function push_twitter_ads( $cfg, $form, $data, $sid ) { /* pixel-only */ }

    /** Reddit Conversions API */
    public static function push_reddit( $cfg, $form, $data, $sid ) {
        $pixel = trim( $cfg['pixel_id']     ?? '' );
        $token = trim( $cfg['access_token'] ?? '' );
        if ( ! $pixel || ! $token ) return;
        $email = self::pick_email( $data );
        $body = [
            'events' => [ [
                'event_at'   => gmdate( 'c' ),
                'event_type' => [ 'tracking_type' => 'SignUp' ],
                'event_metadata' => [
                    'conversion_id' => 'fcp_' . $sid,
                ],
                'user' => array_filter( [
                    'email'      => $email ? self::h( $email ) : null,
                    'ip_address' => self::ip(),
                    'user_agent' => self::ua(),
                ] ),
            ] ],
        ];
        $url = 'https://ads-api.reddit.com/api/v2.0/conversions/events/' . rawurlencode( $pixel );
        wp_remote_post( $url, self::async( [
            'headers' => [ 'Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( $body ),
        ] ) );
    }

    /** Microsoft Ads / Bing — UET is pixel-only client-side. */
    public static function push_bing_ads( $cfg, $form, $data, $sid ) { /* pixel-only */ }

    /** Quora — pixel-only. */
    public static function push_quora_ads( $cfg, $form, $data, $sid ) { /* pixel-only */ }

    /* =====================================================================
     * PHASE 3a — Social posting
     * ================================================================== */

    public static function push_fb_page( $cfg, $form, $data, $sid ) {
        $page  = trim( $cfg['page_id']      ?? '' );
        $token = trim( $cfg['access_token'] ?? '' );
        if ( ! $page || ! $token ) return;
        $msg = self::template( $cfg['template'] ?? 'New submission from {name}', $form, $data );
        if ( ! trim( $msg ) ) return;
        $url = 'https://graph.facebook.com/v18.0/' . rawurlencode( $page ) . '/feed';
        wp_remote_post( $url, self::async( [
            'body'    => wp_json_encode( [ 'message' => $msg, 'access_token' => $token ] ),
        ] ) );
    }

    public static function push_ig_business( $cfg, $form, $data, $sid ) {
        $user  = trim( $cfg['ig_user_id']   ?? '' );
        $token = trim( $cfg['access_token'] ?? '' );
        $img   = trim( $cfg['image_url']    ?? '' );
        if ( ! $user || ! $token || ! $img ) return;
        $caption = self::template( $cfg['template'] ?? 'New lead via {form_title}', $form, $data );
        // Two-step IG publish: 1) create container, 2) publish.
        // We do step 1 fire-and-forget (admin can fix on first failure).
        $create_url = 'https://graph.facebook.com/v18.0/' . rawurlencode( $user ) . '/media';
        wp_remote_post( $create_url, self::async( [
            'body' => wp_json_encode( [ 'image_url' => $img, 'caption' => $caption, 'access_token' => $token ] ),
        ] ) );
    }

    public static function push_li_page( $cfg, $form, $data, $sid ) {
        $org   = trim( $cfg['org_urn']      ?? '' );
        $token = trim( $cfg['access_token'] ?? '' );
        if ( ! $org || ! $token ) return;
        $msg = self::template( $cfg['template'] ?? 'New submission from {name}', $form, $data );
        $body = [
            'author'         => $org,
            'lifecycleState' => 'PUBLISHED',
            'specificContent'=> [
                'com.linkedin.ugc.ShareContent' => [
                    'shareCommentary'    => [ 'text' => $msg ],
                    'shareMediaCategory' => 'NONE',
                ],
            ],
            'visibility'     => [ 'com.linkedin.ugc.MemberNetworkVisibility' => 'PUBLIC' ],
        ];
        wp_remote_post( 'https://api.linkedin.com/v2/ugcPosts', self::async( [
            'headers' => [ 'Authorization' => 'Bearer ' . $token, 'X-Restli-Protocol-Version' => '2.0.0', 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( $body ),
        ] ) );
    }

    /* =====================================================================
     * PHASE 3b — Messaging
     * ================================================================== */

    public static function push_telegram( $cfg, $form, $data, $sid ) {
        $bot  = trim( $cfg['bot_token'] ?? '' );
        $chat = trim( $cfg['chat_id']   ?? '' );
        if ( ! $bot || ! $chat ) return;
        $lines = [ '*New submission*: ' . ( $form['title'] ?? '' ), '' ];
        foreach ( $data as $k => $v ) {
            if ( is_array( $v ) ) $v = wp_json_encode( $v );
            $lines[] = '*' . str_replace( '*', '', (string) $k ) . '*: ' . substr( (string) $v, 0, 400 );
        }
        wp_remote_post( 'https://api.telegram.org/bot' . rawurlencode( $bot ) . '/sendMessage', self::async( [
            'body' => wp_json_encode( [ 'chat_id' => $chat, 'text' => implode( "\n", $lines ), 'parse_mode' => 'Markdown' ] ),
        ] ) );
    }

    public static function push_whatsapp( $cfg, $form, $data, $sid ) {
        $phone_id = trim( $cfg['phone_number_id'] ?? '' );
        $token    = trim( $cfg['access_token']    ?? '' );
        $to       = trim( $cfg['recipient']       ?? '' );
        $tpl      = trim( $cfg['template']        ?? '' );
        if ( ! $phone_id || ! $token || ! $to || ! $tpl ) return;
        $body = [
            'messaging_product' => 'whatsapp',
            'to'                => $to,
            'type'              => 'template',
            'template'          => [
                'name'     => $tpl,
                'language' => [ 'code' => 'en_US' ],
                'components' => [ [
                    'type'       => 'body',
                    'parameters' => [
                        [ 'type' => 'text', 'text' => self::pick_name( $data )  ?: '—' ],
                        [ 'type' => 'text', 'text' => self::pick_email( $data ) ?: '—' ],
                    ],
                ] ],
            ],
        ];
        wp_remote_post( 'https://graph.facebook.com/v18.0/' . rawurlencode( $phone_id ) . '/messages', self::async( [
            'headers' => [ 'Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( $body ),
        ] ) );
    }

    public static function push_teams( $cfg, $form, $data, $sid ) {
        $url = esc_url_raw( $cfg['webhook_url'] ?? '' );
        if ( ! $url ) return;
        $facts = [];
        foreach ( $data as $k => $v ) {
            if ( is_array( $v ) ) $v = wp_json_encode( $v );
            $facts[] = [ 'name' => (string) $k, 'value' => substr( (string) $v, 0, 200 ) ];
        }
        $card = [
            '@type'      => 'MessageCard',
            '@context'   => 'http://schema.org/extensions',
            'summary'    => 'New form submission',
            'themeColor' => '6366F1',
            'title'      => 'New submission · ' . ( $form['title'] ?? '' ),
            'sections'   => [ [ 'facts' => $facts ] ],
        ];
        wp_remote_post( $url, self::async( [ 'body' => wp_json_encode( $card ) ] ) );
    }

    public static function push_discord( $cfg, $form, $data, $sid ) {
        $url = esc_url_raw( $cfg['webhook_url'] ?? '' );
        if ( ! $url ) return;
        $fields = [];
        foreach ( $data as $k => $v ) {
            if ( is_array( $v ) ) $v = wp_json_encode( $v );
            $fields[] = [ 'name' => substr( (string) $k, 0, 256 ), 'value' => substr( (string) $v, 0, 1024 ) ?: '—', 'inline' => false ];
            if ( count( $fields ) >= 25 ) break;  // Discord limit
        }
        $body = [
            'username' => 'FormCraft Pro',
            'embeds'   => [ [
                'title'       => 'New submission · ' . ( $form['title'] ?? '' ),
                'color'       => 6577887,
                'fields'      => $fields,
                'timestamp'   => gmdate( 'c' ),
            ] ],
        ];
        wp_remote_post( $url, self::async( [ 'body' => wp_json_encode( $body ) ] ) );
    }

    /* =====================================================================
     * Pixel snippets — client-side scripts that fire on submit success.
     * Emitted once per page by FCP_Shortcode. The companion JS in
     * form-engine.js dispatches a synthetic `fcp:submitted` event after a
     * successful submission, and each pixel listens for it.
     * ================================================================== */

    public static function collect_pixel_snippets() {
        $settings = get_option( 'fcp_settings', [] );
        $cfgs     = isset( $settings['ad_platforms'] ) && is_array( $settings['ad_platforms'] )
            ? $settings['ad_platforms'] : [];
        $out = '';
        foreach ( self::registry() as $key => $meta ) {
            if ( empty( $meta['pixel'] ) ) continue;
            $cfg = $cfgs[ $key ] ?? [];
            if ( empty( $cfg['enabled'] ) ) continue;
            $snippet = self::pixel_snippet( $key, $cfg );
            if ( $snippet ) $out .= $snippet;
        }
        return $out;
    }

    private static function pixel_snippet( $key, $cfg ) {
        switch ( $key ) {

            case 'meta':
                $pid = esc_js( $cfg['pixel_id'] ?? '' );
                if ( ! $pid ) return '';
                return "<!-- FormCraft Pro · Meta Pixel -->
<script>!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','{$pid}');fbq('track','PageView');document.addEventListener('fcp:submitted',function(){fbq('track','Lead');});</script>
";

            case 'google_ads':
                $cid   = esc_js( $cfg['conversion_id']    ?? '' );
                $label = esc_js( $cfg['conversion_label'] ?? '' );
                if ( ! $cid ) return '';
                return "<!-- FormCraft Pro · Google Ads -->
<script async src='https://www.googletagmanager.com/gtag/js?id={$cid}'></script>
<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','{$cid}');document.addEventListener('fcp:submitted',function(){gtag('event','conversion',{'send_to':'{$cid}/{$label}'});});</script>
";

            case 'tiktok':
                $pid = esc_js( $cfg['pixel_id'] ?? '' );
                if ( ! $pid ) return '';
                return "<!-- FormCraft Pro · TikTok Pixel -->
<script>!function(w,d,t){w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=['page','track','identify','instances','debug','on','off','once','ready','alias','group','enableCookie','disableCookie'],ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e},ttq.load=function(e,n){var i='https://analytics.tiktok.com/i18n/pixel/events.js';ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=i,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};var o=document.createElement('script');o.type='text/javascript',o.async=!0,o.src=i+'?sdkid='+e+'&lib='+t;var a=document.getElementsByTagName('script')[0];a.parentNode.insertBefore(o,a)};ttq.load('{$pid}');ttq.page();document.addEventListener('fcp:submitted',function(){ttq.track('SubmitForm');});}(window,document,'ttq');</script>
";

            case 'linkedin_ads':
                $pid = esc_js( $cfg['partner_id'] ?? '' );
                if ( ! $pid ) return '';
                return "<!-- FormCraft Pro · LinkedIn Insight Tag -->
<script>_linkedin_partner_id='{$pid}';window._linkedin_data_partner_ids=window._linkedin_data_partner_ids||[];window._linkedin_data_partner_ids.push(_linkedin_partner_id);</script>
<script>(function(l){if(!l){window.lintrk=function(a,b){window.lintrk.q.push([a,b])};window.lintrk.q=[]}var s=document.getElementsByTagName('script')[0];var b=document.createElement('script');b.type='text/javascript';b.async=true;b.src='https://snap.licdn.com/li.lms-analytics/insight.min.js';s.parentNode.insertBefore(b,s);})(window.lintrk);document.addEventListener('fcp:submitted',function(){if(window.lintrk)window.lintrk('track');});</script>
";

            case 'pinterest_ads':
                $pid = esc_js( $cfg['pixel_id'] ?? '' );
                if ( ! $pid ) return '';
                return "<!-- FormCraft Pro · Pinterest Tag -->
<script>!function(e){if(!window.pintrk){window.pintrk=function(){window.pintrk.queue.push(Array.prototype.slice.call(arguments))};var n=window.pintrk;n.queue=[];n.version='3.0';var t=document.createElement('script');t.async=!0;t.src=e;var r=document.getElementsByTagName('script')[0];r.parentNode.insertBefore(t,r)}}('https://s.pinimg.com/ct/core.js');pintrk('load','{$pid}');pintrk('page');document.addEventListener('fcp:submitted',function(){pintrk('track','Lead');});</script>
";

            case 'snapchat':
                $pid = esc_js( $cfg['pixel_id'] ?? '' );
                if ( ! $pid ) return '';
                return "<!-- FormCraft Pro · Snap Pixel -->
<script>(function(e,t,n){if(e.snaptr)return;var a=e.snaptr=function(){a.handleRequest?a.handleRequest.apply(a,arguments):a.queue.push(arguments)};a.queue=[];var s='script';r=t.createElement(s);r.async=!0;r.src=n;var u=t.getElementsByTagName(s)[0];u.parentNode.insertBefore(r,u);})(window,document,'https://sc-static.net/scevent.min.js');snaptr('init','{$pid}');snaptr('track','PAGE_VIEW');document.addEventListener('fcp:submitted',function(){snaptr('track','SIGN_UP');});</script>
";

            case 'twitter_ads':
                $pid = esc_js( $cfg['pixel_id'] ?? '' );
                $eid = esc_js( $cfg['event_id'] ?? '' );
                if ( ! $pid ) return '';
                return "<!-- FormCraft Pro · Twitter Pixel -->
<script>!function(e,t,n,s,u,a){e.twq||(s=e.twq=function(){s.exe?s.exe.apply(s,arguments):s.queue.push(arguments)},s.version='1.1',s.queue=[],u=t.createElement(n),u.async=!0,u.src='https://static.ads-twitter.com/uwt.js',a=t.getElementsByTagName(n)[0],a.parentNode.insertBefore(u,a))}(window,document,'script');twq('config','{$pid}');document.addEventListener('fcp:submitted',function(){twq('event','{$eid}',{});});</script>
";

            case 'reddit':
                $pid = esc_js( $cfg['pixel_id'] ?? '' );
                if ( ! $pid ) return '';
                return "<!-- FormCraft Pro · Reddit Pixel -->
<script>!function(w,d){if(!w.rdt){var p=w.rdt=function(){p.sendEvent?p.sendEvent.apply(p,arguments):p.callQueue.push(arguments)};p.callQueue=[];var t=d.createElement('script');t.src='https://www.redditstatic.com/ads/pixel.js';t.async=!0;var s=d.getElementsByTagName('script')[0];s.parentNode.insertBefore(t,s)}}(window,document);rdt('init','{$pid}');rdt('track','PageVisit');document.addEventListener('fcp:submitted',function(){rdt('track','Lead');});</script>
";

            case 'bing_ads':
                $uet = esc_js( $cfg['uet_tag_id'] ?? '' );
                if ( ! $uet ) return '';
                return "<!-- FormCraft Pro · Microsoft UET -->
<script>(function(w,d,t,r,u){var f,n,i;w[u]=w[u]||[],f=function(){var o={ti:'{$uet}'};o.q=w[u],w[u]=new UET(o),w[u].push('pageLoad')},n=d.createElement(t),n.src=r,n.async=1,n.onload=n.onreadystatechange=function(){var s=this.readyState;s&&s!=='loaded'&&s!=='complete'||(f(),n.onload=n.onreadystatechange=null)},i=d.getElementsByTagName(t)[0],i.parentNode.insertBefore(n,i)})(window,document,'script','//bat.bing.com/bat.js','uetq');document.addEventListener('fcp:submitted',function(){window.uetq=window.uetq||[];window.uetq.push('event','submit_lead_form',{});});</script>
";

            case 'quora_ads':
                $pid = esc_js( $cfg['pixel_id'] ?? '' );
                if ( ! $pid ) return '';
                return "<!-- FormCraft Pro · Quora Pixel -->
<script>!function(q,e,v,n,t,s){if(q.qp)return;n=q.qp=function(){n.qp?n.qp.apply(n,arguments):n.queue.push(arguments)};n.queue=[];t=document.createElement(e);t.async=!0;t.src=v;s=document.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,'script','https://a.quora.com/qevents.js');qp('init','{$pid}');qp('track','ViewContent');document.addEventListener('fcp:submitted',function(){qp('track','GenerateLead');});</script>
";
        }
        return '';
    }
}
