<?php
/**
 * FormCraft Pro - 1-Click Form Migration.
 *
 * Detect & import forms from competing WP form plugins:
 *   - Contact Form 7
 *   - WPForms (Lite / Pro)
 *   - Fluent Forms
 *   - Gravity Forms
 *   - Ninja Forms
 *   - Formidable Forms
 *   - Everest Forms
 *
 * Each source plugin has its own adapter — a `detect_*` to confirm it's
 * installed, `list_*_forms` to enumerate available forms, `import_*_form`
 * to convert one into a FormCraft form, and (where the source plugin
 * stores submissions in WP) `import_*_subs` to migrate those too.
 *
 * Every migration writes a row into the migration log (fcp_migrations)
 * so admins can see what they imported, view warnings, and roll back.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_Migrator {

    /* =====================================================================
     * Source registry — single source of truth for which plugins we support
     * ================================================================== */

    public static function sources() {
        return [
            'cf7'         => [ 'name' => 'Contact Form 7',  'slug' => 'cf7',         'has_submissions' => false ],
            'wpforms'     => [ 'name' => 'WPForms',         'slug' => 'wpforms',     'has_submissions' => true  ],
            'fluentform'  => [ 'name' => 'Fluent Forms',    'slug' => 'fluentform',  'has_submissions' => true  ],
            'gravity'     => [ 'name' => 'Gravity Forms',   'slug' => 'gravity',     'has_submissions' => true  ],
            'ninja'       => [ 'name' => 'Ninja Forms',     'slug' => 'ninja',       'has_submissions' => true  ],
            'formidable'  => [ 'name' => 'Formidable Forms','slug' => 'formidable',  'has_submissions' => true  ],
            'everest'     => [ 'name' => 'Everest Forms',   'slug' => 'everest',     'has_submissions' => true  ],
            'forminator'  => [ 'name' => 'Forminator',      'slug' => 'forminator',  'has_submissions' => true  ],
            'caldera'     => [ 'name' => 'Caldera Forms',   'slug' => 'caldera',     'has_submissions' => true  ],
        ];
    }

    /**
     * Per-source feature-support matrix — which translation paths each
     * adapter handles. Used to render the compatibility-score chip and
     * the "what carries over" tooltip on each source card. Keep the keys
     * stable; the UI reads them by name. A value of:
     *    true   → translated fully
     *    'partial' → translated with caveats (warning emitted)
     *    false  → not supported, falls through to defaults
     */
    public static function feature_matrix() {
        return [
            //              fields  logic   calc  notif  confirm  upload  spam   css   ajax
            'cf7'        => [ true,  false, false, true,  true,    'partial', false, false, true ],
            'wpforms'    => [ true,  true,  'partial', true, true, 'partial', 'partial', false, true ],
            'fluentform' => [ true,  true,  'partial', true, true, 'partial', 'partial', 'partial', true ],
            'gravity'    => [ true,  true,  'partial', true, true, 'partial', false, 'partial', true ],
            'ninja'      => [ true,  'partial', false, 'partial', true, 'partial', false, false, true ],
            'formidable' => [ true,  'partial', false, true, true, 'partial', false, false, true ],
            'everest'    => [ true,  'partial', false, true, true, 'partial', false, false, true ],
            'forminator' => [ true,  'partial', false, true, true, 'partial', false, false, true ],
            'caldera'    => [ true,  'partial', false, true, true, 'partial', false, false, true ],
        ];
    }

    /**
     * Score the feature_matrix() row into a (supported/total) tuple plus
     * a percent. partial is counted as 0.5. UI renders this as
     * "8.5/9 · 94%" with the % colour-graded.
     */
    public static function compatibility_score( $source ) {
        $row = self::feature_matrix()[ $source ] ?? null;
        if ( ! $row ) return [ 'supported' => 0, 'total' => 9, 'pct' => 0 ];
        $sup = 0;
        foreach ( $row as $v ) {
            if ( $v === true ) $sup += 1;
            elseif ( $v === 'partial' ) $sup += 0.5;
        }
        $total = count( $row );
        return [
            'supported' => $sup,
            'total'     => $total,
            'pct'       => $total ? round( ( $sup / $total ) * 100 ) : 0,
        ];
    }

    /* =====================================================================
     * Detection — which source plugins are active, and how many forms each
     * ================================================================== */

    public static function detect_plugins() {
        $out = [];
        foreach ( self::sources() as $key => $meta ) {
            $found = self::detect_one( $key );
            $count = $found ? (int) self::count_forms( $key ) : 0;
            $out[ $key ] = array_merge( $meta, [
                'active'         => (bool) $found,
                'count'          => $count,
                'version'        => $found['version']  ?? null,
                'note'           => $found['note']     ?? null,
            ] );
        }
        return $out;
    }

    private static function detect_one( $key ) {
        switch ( $key ) {
            case 'cf7':
                if ( defined( 'WPCF7_VERSION' ) || class_exists( 'WPCF7' ) || class_exists( 'WPCF7_ContactForm' ) ) {
                    return [ 'version' => defined( 'WPCF7_VERSION' ) ? WPCF7_VERSION : null ];
                }
                return null;
            case 'wpforms':
                if ( defined( 'WPFORMS_VERSION' ) || function_exists( 'wpforms' ) || class_exists( '\\WPForms\\WPForms' ) ) {
                    return [ 'version' => defined( 'WPFORMS_VERSION' ) ? WPFORMS_VERSION : null ];
                }
                return null;
            case 'fluentform':
                if ( defined( 'FLUENTFORM_VERSION' ) || defined( 'FLUENTFORM' ) || class_exists( 'FluentForm\\App\\Modules\\Form\\Form' ) ) {
                    return [ 'version' => defined( 'FLUENTFORM_VERSION' ) ? FLUENTFORM_VERSION : null ];
                }
                // Fluent Forms also creates a dedicated table — fallback check
                global $wpdb;
                $t = $wpdb->prefix . 'fluentform_forms';
                if ( $wpdb->get_var( "SHOW TABLES LIKE '$t'" ) ) return [];
                return null;
            case 'gravity':
                if ( class_exists( 'GFForms' ) || class_exists( 'GFAPI' ) || defined( 'GF_MIN_WP_VERSION' ) ) {
                    return [ 'version' => defined( 'GF_VERSION' ) ? GF_VERSION : null ];
                }
                return null;
            case 'ninja':
                if ( class_exists( 'Ninja_Forms' ) || defined( 'NF_PLUGIN_VERSION' ) ) {
                    return [ 'version' => defined( 'NF_PLUGIN_VERSION' ) ? NF_PLUGIN_VERSION : null ];
                }
                return null;
            case 'formidable':
                if ( class_exists( 'FrmForm' ) || class_exists( 'FrmAppController' ) || defined( 'FrmAppHelper::plugin_version' ) ) {
                    return [];
                }
                return null;
            case 'everest':
                if ( function_exists( 'EVF' ) || class_exists( 'EverestForms' ) || defined( 'EVF_VERSION' ) ) {
                    return [ 'version' => defined( 'EVF_VERSION' ) ? EVF_VERSION : null ];
                }
                return null;
            case 'forminator':
                // Forminator stores forms in a custom CPT + meta. Class
                // names vary across major versions, so we probe both.
                if ( class_exists( 'Forminator' ) || class_exists( 'Forminator_API' ) || defined( 'FORMINATOR_VERSION' ) ) {
                    return [ 'version' => defined( 'FORMINATOR_VERSION' ) ? FORMINATOR_VERSION : null ];
                }
                return null;
            case 'caldera':
                // Caldera was discontinued but plenty of sites still have it.
                // We detect by checking for either the class or the form-
                // storage option pattern Caldera used to write into wp_options.
                if ( class_exists( 'Caldera_Forms' ) || class_exists( 'Caldera_Forms_Forms' ) ) {
                    return [ 'version' => defined( 'CFCORE_VER' ) ? CFCORE_VER : null, 'note' => 'Caldera Forms is discontinued — migrate while you still can.' ];
                }
                // Fallback: option-based storage check
                if ( get_option( '_caldera_forms', false ) !== false ) {
                    return [ 'note' => 'Caldera Forms is discontinued — migrate while you still can.' ];
                }
                return null;
        }
        return null;
    }

    private static function count_forms( $key ) {
        global $wpdb;
        switch ( $key ) {
            case 'cf7':
                return $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'wpcf7_contact_form' AND post_status = 'publish'" );
            case 'wpforms':
                return $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'wpforms' AND post_status = 'publish'" );
            case 'fluentform':
                $t = $wpdb->prefix . 'fluentform_forms';
                if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$t'" ) ) return 0;
                return $wpdb->get_var( "SELECT COUNT(*) FROM $t" );
            case 'gravity':
                $t = $wpdb->prefix . 'gf_form';
                if ( $wpdb->get_var( "SHOW TABLES LIKE '$t'" ) ) {
                    return $wpdb->get_var( "SELECT COUNT(*) FROM $t WHERE is_trash = 0" );
                }
                // Older GF schema
                $t2 = $wpdb->prefix . 'rg_form';
                if ( $wpdb->get_var( "SHOW TABLES LIKE '$t2'" ) ) {
                    return $wpdb->get_var( "SELECT COUNT(*) FROM $t2 WHERE is_trash = 0" );
                }
                return 0;
            case 'ninja':
                $t = $wpdb->prefix . 'nf3_forms';
                if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$t'" ) ) return 0;
                return $wpdb->get_var( "SELECT COUNT(*) FROM $t" );
            case 'formidable':
                $t = $wpdb->prefix . 'frm_forms';
                if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$t'" ) ) return 0;
                return $wpdb->get_var( "SELECT COUNT(*) FROM $t WHERE is_template = 0 AND status != 'trash'" );
            case 'everest':
                return $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'everest_form' AND post_status = 'publish'" );
            case 'forminator':
                // Forminator uses 'forminator_forms' CPT for forms.
                return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'forminator_forms' AND post_status IN ('publish','draft')" );
            case 'caldera':
                // Caldera stores forms in a JSON-encoded wp_options row.
                $raw = get_option( '_caldera_forms', [] );
                return is_array( $raw ) ? count( $raw ) : 0;
        }
        return 0;
    }

    /* =====================================================================
     * Form listing — per-source enumeration with light metadata
     * ================================================================== */

    public static function list_forms( $source ) {
        global $wpdb;
        switch ( $source ) {
            case 'cf7':
                $rows = $wpdb->get_results( "SELECT ID, post_title FROM {$wpdb->posts} WHERE post_type = 'wpcf7_contact_form' AND post_status = 'publish' ORDER BY post_title ASC", ARRAY_A );
                $out = [];
                foreach ( $rows as $r ) {
                    $form_template = get_post_meta( $r['ID'], '_form', true );
                    $field_count = preg_match_all( '/\[([a-z0-9_*-]+)\s/i', (string) $form_template );
                    $out[] = [ 'id' => (int) $r['ID'], 'title' => $r['post_title'], 'fields' => (int) $field_count, 'submissions' => 0 ];
                }
                return $out;

            case 'wpforms':
                $rows = $wpdb->get_results( "SELECT ID, post_title, post_content FROM {$wpdb->posts} WHERE post_type = 'wpforms' AND post_status = 'publish' ORDER BY post_title ASC", ARRAY_A );
                $out = [];
                foreach ( $rows as $r ) {
                    $def = json_decode( $r['post_content'], true );
                    $fc  = is_array( $def ) && isset( $def['fields'] ) ? count( $def['fields'] ) : 0;
                    $sc  = self::count_submissions( 'wpforms', (int) $r['ID'] );
                    $out[] = [ 'id' => (int) $r['ID'], 'title' => $r['post_title'], 'fields' => $fc, 'submissions' => $sc ];
                }
                return $out;

            case 'fluentform':
                $t  = $wpdb->prefix . 'fluentform_forms';
                $rows = $wpdb->get_results( "SELECT id, title, form_fields FROM $t ORDER BY title ASC", ARRAY_A );
                $out = [];
                foreach ( $rows as $r ) {
                    $def = json_decode( $r['form_fields'], true );
                    $fc  = 0;
                    if ( is_array( $def ) && isset( $def['fields'] ) ) $fc = count( $def['fields'] );
                    $sc  = self::count_submissions( 'fluentform', (int) $r['id'] );
                    $out[] = [ 'id' => (int) $r['id'], 'title' => $r['title'], 'fields' => $fc, 'submissions' => $sc ];
                }
                return $out;

            case 'gravity':
                $t  = $wpdb->prefix . 'gf_form';
                $tm = $wpdb->prefix . 'gf_form_meta';
                if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$t'" ) ) {
                    $t  = $wpdb->prefix . 'rg_form';
                    $tm = $wpdb->prefix . 'rg_form_meta';
                }
                $rows = $wpdb->get_results( "SELECT id, title FROM $t WHERE is_trash = 0 ORDER BY title ASC", ARRAY_A );
                $out = [];
                foreach ( $rows as $r ) {
                    $meta = $wpdb->get_var( $wpdb->prepare( "SELECT display_meta FROM $tm WHERE form_id = %d", $r['id'] ) );
                    $def  = json_decode( $meta, true );
                    $fc   = is_array( $def ) && isset( $def['fields'] ) ? count( $def['fields'] ) : 0;
                    $sc   = self::count_submissions( 'gravity', (int) $r['id'] );
                    $out[] = [ 'id' => (int) $r['id'], 'title' => $r['title'], 'fields' => $fc, 'submissions' => $sc ];
                }
                return $out;

            case 'ninja':
                $t  = $wpdb->prefix . 'nf3_forms';
                $tf = $wpdb->prefix . 'nf3_fields';
                $rows = $wpdb->get_results( "SELECT id, title FROM $t ORDER BY title ASC", ARRAY_A );
                $out = [];
                foreach ( $rows as $r ) {
                    $fc = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $tf WHERE parent_id = %d", $r['id'] ) );
                    $sc = self::count_submissions( 'ninja', (int) $r['id'] );
                    $out[] = [ 'id' => (int) $r['id'], 'title' => $r['title'], 'fields' => $fc, 'submissions' => $sc ];
                }
                return $out;

            case 'formidable':
                $t  = $wpdb->prefix . 'frm_forms';
                $tf = $wpdb->prefix . 'frm_fields';
                $rows = $wpdb->get_results( "SELECT id, name FROM $t WHERE is_template = 0 AND status != 'trash' ORDER BY name ASC", ARRAY_A );
                $out = [];
                foreach ( $rows as $r ) {
                    $fc = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $tf WHERE form_id = %d", $r['id'] ) );
                    $sc = self::count_submissions( 'formidable', (int) $r['id'] );
                    $out[] = [ 'id' => (int) $r['id'], 'title' => $r['name'], 'fields' => $fc, 'submissions' => $sc ];
                }
                return $out;

            case 'everest':
                $rows = $wpdb->get_results( "SELECT ID, post_title FROM {$wpdb->posts} WHERE post_type = 'everest_form' AND post_status = 'publish' ORDER BY post_title ASC", ARRAY_A );
                $out = [];
                foreach ( $rows as $r ) {
                    $struct = get_post_meta( $r['ID'], 'evf_form_template', true );
                    $struct = is_string( $struct ) ? maybe_unserialize( $struct ) : $struct;
                    $fc = 0;
                    if ( is_array( $struct ) && isset( $struct['form_fields'] ) ) $fc = count( $struct['form_fields'] );
                    $sc = self::count_submissions( 'everest', (int) $r['ID'] );
                    $out[] = [ 'id' => (int) $r['ID'], 'title' => $r['post_title'], 'fields' => $fc, 'submissions' => $sc ];
                }
                return $out;

            case 'forminator':
                $rows = $wpdb->get_results(
                    "SELECT ID, post_title FROM {$wpdb->posts}
                     WHERE post_type = 'forminator_forms' AND post_status IN ('publish','draft')
                     ORDER BY post_title ASC",
                    ARRAY_A
                );
                $out = [];
                foreach ( $rows as $r ) {
                    $settings = get_post_meta( $r['ID'], 'forminator_form_meta', true );
                    $settings = is_string( $settings ) ? maybe_unserialize( $settings ) : $settings;
                    $fc = 0;
                    if ( is_array( $settings ) ) {
                        if ( isset( $settings['fields'] ) && is_array( $settings['fields'] ) ) {
                            // Forminator wraps fields in groups (wrappers)
                            foreach ( $settings['fields'] as $wrapper ) {
                                $fc += isset( $wrapper['fields'] ) && is_array( $wrapper['fields'] )
                                    ? count( $wrapper['fields'] )
                                    : 1;
                            }
                        }
                    }
                    $sc = self::count_submissions( 'forminator', (int) $r['ID'] );
                    $out[] = [ 'id' => (int) $r['ID'], 'title' => $r['post_title'], 'fields' => $fc, 'submissions' => $sc ];
                }
                return $out;

            case 'caldera':
                // Caldera stores forms as a single wp_options row containing
                // a hash-keyed array of form IDs → definitions.
                $forms = get_option( '_caldera_forms', [] );
                if ( ! is_array( $forms ) ) return [];
                $out = [];
                foreach ( $forms as $form_id => $form_def ) {
                    // Each row in _caldera_forms may itself be a stub pointing
                    // to a separate _caldera_forms_<id> option for full def.
                    $full = get_option( $form_id, $form_def );
                    if ( ! is_array( $full ) ) continue;
                    $fc = isset( $full['fields'] ) && is_array( $full['fields'] ) ? count( $full['fields'] ) : 0;
                    $sc = self::count_submissions( 'caldera', $form_id );
                    $out[] = [
                        'id'          => $form_id,                              // Caldera uses string ids ("CF59abc...")
                        'title'       => $full['name'] ?? $form_def['name'] ?? $form_id,
                        'fields'      => $fc,
                        'submissions' => $sc,
                    ];
                }
                return $out;
        }
        return [];
    }

    private static function count_submissions( $source, $form_id ) {
        global $wpdb;
        switch ( $source ) {
            case 'wpforms':
                $t = $wpdb->prefix . 'wpforms_entries';
                if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$t'" ) ) return 0;
                return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE form_id = %d", $form_id ) );
            case 'fluentform':
                $t = $wpdb->prefix . 'fluentform_submissions';
                if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$t'" ) ) return 0;
                return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE form_id = %d", $form_id ) );
            case 'gravity':
                $t = $wpdb->prefix . 'gf_entry';
                if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$t'" ) ) {
                    $t = $wpdb->prefix . 'rg_lead';
                    if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$t'" ) ) return 0;
                }
                return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE form_id = %d AND status = 'active'", $form_id ) );
            case 'ninja':
                $t = $wpdb->prefix . 'posts';
                return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE post_type = 'nf_sub' AND post_parent = %d", $form_id ) );
            case 'formidable':
                $t = $wpdb->prefix . 'frm_items';
                if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$t'" ) ) return 0;
                return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE form_id = %d", $form_id ) );
            case 'everest':
                $t = $wpdb->prefix . 'evf_entries';
                if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$t'" ) ) return 0;
                return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE form_id = %d", $form_id ) );
            case 'forminator':
                $t = $wpdb->prefix . 'frmt_form_entry';
                if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$t'" ) ) return 0;
                return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE form_id = %d AND is_spam = 0", $form_id ) );
            case 'caldera':
                // Caldera stores entries in its own table (string form id key).
                $t = $wpdb->prefix . 'cf_form_entries';
                if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$t'" ) ) return 0;
                return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE form_id = %s", $form_id ) );
        }
        return 0;
    }

    /* =====================================================================
     * Import — convert a source form into a FormCraft form + insert it
     * ================================================================== */

    /**
     * @param string $source     'cf7' | 'wpforms' | etc.
     * @param int    $external_id  ID in the source plugin's storage
     * @param array  $opts        ['include_submissions' => bool, 'suffix' => string]
     * @return array              ['new_form_id' => int, 'migration_id' => int, 'warnings' => [], 'submissions_count' => int]
     */
    public static function import( $source, $external_id, $opts = [] ) {
        if ( ! isset( self::sources()[ $source ] ) ) {
            return new WP_Error( 'bad_source', "Unknown source: $source" );
        }
        $include_subs = ! empty( $opts['include_submissions'] );
        $dry_run      = ! empty( $opts['dry_run'] );      // ← simulate only
        $suffix       = isset( $opts['suffix'] ) ? (string) $opts['suffix'] : '';

        // Build the FormCraft form payload
        $result = call_user_func( [ __CLASS__, "import_{$source}_form" ], (int) $external_id );
        if ( is_wp_error( $result ) ) return $result;

        $form     = $result['form'];
        $warnings = $result['warnings'];
        if ( $suffix ) $form['title'] .= ' ' . $suffix;

        // ---- Dry-run short-circuit ----
        // Return what would be imported without writing anything. The UI
        // uses this to render a diff preview ("Step 1 would have 5 fields:
        // Name, Email, Phone, …") before the admin commits.
        if ( $dry_run ) {
            return [
                'dry_run'           => true,
                'preview_form'      => $form,
                'fields_count'      => self::count_form_fields( $form ),
                'subs_count'        => $include_subs ? self::count_submissions( $source, $external_id ) : 0,
                'warnings'          => $warnings,
                'compatibility_pct' => self::compatibility_score( $source )['pct'],
            ];
        }

        // Insert as a new FormCraft form
        $new_id = FCP_DB::insert_form( $form );
        if ( ! $new_id ) return new WP_Error( 'insert_failed', 'Could not insert imported form into the database.' );
        // First revision snapshot so the rollback target is in the history list too
        FCP_DB::insert_revision( $new_id, $form, sprintf( 'Imported from %s (form #%d)', self::sources()[ $source ]['name'], (int) $external_id ) );

        // Optional submissions migration
        $subs_count = 0;
        if ( $include_subs && self::sources()[ $source ]['has_submissions'] ) {
            $method = "import_{$source}_subs";
            if ( method_exists( __CLASS__, $method ) ) {
                $subs_count = (int) call_user_func( [ __CLASS__, $method ], (int) $external_id, (int) $new_id, $form );
            }
        }

        $mid = self::log_migration( [
            'source'          => $source,
            'source_form_id'  => (int) $external_id,
            'new_form_id'     => (int) $new_id,
            'form_title'      => $form['title'],
            'fields_count'    => self::count_form_fields( $form ),
            'subs_count'      => $subs_count,
            'warnings'        => $warnings,
        ] );

        return [
            'new_form_id'       => (int) $new_id,
            'migration_id'      => (int) $mid,
            'warnings'          => $warnings,
            'submissions_count' => $subs_count,
            'fields_count'      => self::count_form_fields( $form ),
        ];
    }

    /* =====================================================================
     * Source adapter: Contact Form 7
     *
     * CF7 stores its form as a shortcode-style template string in
     * `_form` postmeta. We parse [tag* name "label" attrs] tags out
     * of it. No native entries store — Flamingo addon stores them,
     * but we leave that out of scope for v1.
     * ================================================================== */

    private static function import_cf7_form( $external_id ) {
        $post = get_post( $external_id );
        if ( ! $post || $post->post_type !== 'wpcf7_contact_form' ) {
            return new WP_Error( 'cf7_missing', "Contact Form 7 form #$external_id not found." );
        }
        $template = (string) get_post_meta( $external_id, '_form', true );
        $warnings = [];
        $fields   = [];

        // Loose tag parser: matches [tag attr ...] OR [tag* attr ...]
        // Captures: 1=tag, 2=name, rest=attrs/label
        preg_match_all( '/\[([a-z0-9_-]+)(\*?)\s+([a-z0-9_-]+)([^\]]*)\]/i', $template, $matches, PREG_SET_ORDER );

        $known = [
            'text'         => 'text',
            'email'        => 'email',
            'url'          => 'url',
            'tel'          => 'tel',
            'number'       => 'number',
            'date'         => 'date',
            'textarea'     => 'textarea',
            'select'       => 'select',
            'checkbox'     => 'checkbox',
            'radio'        => 'radio',
            'file'         => 'file',
            'acceptance'   => 'checkbox',
            'hidden'       => 'hidden',
            'submit'       => null,        // handled via form button label
            'quiz'         => 'text',
            'captchac'     => null,        // skipped, FormCraft has its own reCAPTCHA
            'captchar'     => null,
        ];

        foreach ( $matches as $m ) {
            $tag      = strtolower( $m[1] );
            $required = $m[2] === '*';
            $name     = $m[3];
            $attr     = $m[4];

            if ( $tag === 'submit' ) {
                continue;
            }
            if ( ! array_key_exists( $tag, $known ) ) {
                $warnings[] = "Unknown CF7 tag [$tag] — mapped to text.";
                $target = 'text';
            } else {
                $target = $known[ $tag ];
                if ( $target === null ) continue;
            }

            $label = self::humanize_label( $name );
            $placeholder = '';
            if ( preg_match( '/placeholder\s+"?([^"\]]+)"?/', $attr, $pm ) ) $placeholder = trim( $pm[1] );

            $field = self::new_field( $target, $label );
            $field['required']    = $required;
            $field['placeholder'] = $placeholder;

            // For select / radio / checkbox, parse "Option 1" "Option 2" ...
            if ( in_array( $target, [ 'select', 'radio', 'checkbox' ], true ) ) {
                preg_match_all( '/"([^"]+)"/', $attr, $om );
                if ( ! empty( $om[1] ) ) $field['options'] = $om[1];
                else $field['options'] = [ 'Option 1', 'Option 2' ];
            }

            $fields[] = $field;
        }

        if ( empty( $fields ) ) $warnings[] = 'No fields detected in the CF7 form template — please review the imported form.';

        $form = self::blank_form( $post->post_title ?: 'Imported CF7 Form' );
        $form['steps'][0]['fields'] = $fields;

        // Pull the recipient + subject from CF7's _mail meta
        $mail = get_post_meta( $external_id, '_mail', true );
        if ( is_array( $mail ) ) {
            if ( ! empty( $mail['recipient'] ) ) {
                $form['settings']['notifications']['admin']['to']      = self::strip_cf7_tags( $mail['recipient'] );
                $form['settings']['notifications']['admin']['subject'] = self::strip_cf7_tags( $mail['subject'] ?? 'New submission' );
            }
        }

        return [ 'form' => $form, 'warnings' => $warnings ];
    }

    private static function strip_cf7_tags( $s ) {
        return preg_replace( '/\[[^\]]+\]/', '', (string) $s );
    }

    /* =====================================================================
     * Source adapter: WPForms
     * ================================================================== */

    private static function import_wpforms_form( $external_id ) {
        $post = get_post( $external_id );
        if ( ! $post || $post->post_type !== 'wpforms' ) {
            return new WP_Error( 'wpf_missing', "WPForms form #$external_id not found." );
        }
        $def = json_decode( $post->post_content, true );
        if ( ! is_array( $def ) ) return new WP_Error( 'wpf_parse', 'Could not parse WPForms form JSON.' );

        $warnings = [];
        // WPForms field 'type' -> FormCraft type
        $map = [
            'text'           => 'text',
            'textarea'       => 'textarea',
            'email'          => 'email',
            'url'            => 'url',
            'number'         => 'number',
            'phone'          => 'tel',
            'number-slider'  => 'range',
            'select'         => 'select',
            'radio'          => 'radio',
            'checkbox'       => 'checkbox',
            'gdpr-checkbox'  => 'checkbox',
            'date-time'      => 'date',
            'file-upload'    => 'file',
            'rating'         => 'rating',
            'hidden'         => 'hidden',
            'name'           => 'text',
            'address'        => 'text',
            'password'       => 'password',
            'rich-text'      => 'textarea',
            'html'           => 'html',
            'divider'        => 'html',
            'pagebreak'      => '__step__',
        ];

        $steps_acc = [];
        $current   = [];
        $fields    = is_array( $def['fields'] ?? null ) ? $def['fields'] : [];
        // source_field_id → new FormCraft field id, populated below so we
        // can translate conditional-logic rules in a second pass.
        $id_map  = [];
        $raw_log = [];   // [ src_id → raw conditional source ] for later translation
        // WPForms field order can be by 'id' — but the array iteration order is correct in modern versions
        foreach ( $fields as $fld ) {
            $st = (string) ( $fld['type'] ?? 'text' );
            if ( ! isset( $map[ $st ] ) ) {
                $warnings[] = "Unknown WPForms field type '$st' — mapped to text.";
                $target = 'text';
            } else {
                $target = $map[ $st ];
            }
            if ( $target === '__step__' ) {
                if ( $current ) $steps_acc[] = $current;
                $current = [];
                continue;
            }

            $label = (string) ( $fld['label'] ?? self::humanize_label( $st ) );
            $field = self::new_field( $target, $label );
            $field['required']    = ! empty( $fld['required'] );
            $field['placeholder'] = (string) ( $fld['placeholder'] ?? '' );
            $field['help']        = (string) ( $fld['description'] ?? '' );
            $field['defaultValue']= (string) ( $fld['default_value'] ?? '' );

            // Options: WPForms uses choices[] with ['label' => ...] entries
            if ( in_array( $target, [ 'select', 'radio', 'checkbox' ], true ) ) {
                $choices = is_array( $fld['choices'] ?? null ) ? $fld['choices'] : [];
                $opts    = [];
                foreach ( $choices as $c ) {
                    if ( is_array( $c ) && isset( $c['label'] ) ) $opts[] = (string) $c['label'];
                    elseif ( is_string( $c ) ) $opts[] = $c;
                }
                if ( $opts ) $field['options'] = $opts;
            }
            if ( $target === 'range' ) {
                $field['min']  = isset( $fld['min'] )  ? (float) $fld['min']  : 0;
                $field['max']  = isset( $fld['max'] )  ? (float) $fld['max']  : 100;
                $field['step'] = isset( $fld['step'] ) ? (float) $fld['step'] : 1;
            }
            if ( $target === 'rating' ) {
                $field['max'] = isset( $fld['scale'] ) ? (int) $fld['scale'] : 5;
            }
            // Track id mapping for the conditional-logic translator below.
            $src_id = (string) ( $fld['id'] ?? '' );
            if ( $src_id ) $id_map[ $src_id ] = $field['id'];
            if ( ! empty( $fld['conditionals'] ) ) $raw_log[ $src_id ] = $fld['conditionals'];
            self::translate_field_meta( $field, $fld );
            self::translate_file_settings( $field, $fld );
            $current[] = $field;
        }
        if ( $current ) $steps_acc[] = $current;

        $form = self::blank_form( $post->post_title ?: 'Imported WPForm' );
        // Multi-page WPForm -> multi-step FormCraft form
        if ( count( $steps_acc ) > 1 ) {
            $form['steps'] = [];
            foreach ( $steps_acc as $i => $step_fields ) {
                $form['steps'][] = self::new_step( 'Step ' . ( $i + 1 ), $step_fields );
            }
        } elseif ( count( $steps_acc ) === 1 ) {
            $form['steps'][0]['fields'] = $steps_acc[0];
        }

        // ---- Conditional-logic translation (best-effort) ----
        // Walk every imported field; if WPForms had conditional rules on it,
        // translate them into FormCraft's f.logic shape using the id_map.
        $applied = 0;
        foreach ( $form['steps'] as &$step ) {
            foreach ( $step['fields'] as &$f_ref ) {
                // Find the source id from the new id (reverse-lookup)
                $src_id = array_search( $f_ref['id'], $id_map, true );
                if ( $src_id === false || empty( $raw_log[ $src_id ] ) ) continue;
                list( $groups, $act ) = self::translate_conditional_rules( $raw_log[ $src_id ], $id_map, 'wpforms' );
                if ( $groups ) {
                    $f_ref['logicGroups'] = $groups;
                    $f_ref['logic']       = array_merge( [], ...$groups );  // flat mirror for legacy readers
                    $f_ref['logicAction'] = $act;
                    $applied++;
                }
            }
            unset( $f_ref );
        }
        unset( $step );
        if ( $applied ) $warnings[] = "Translated conditional logic on $applied field(s). Review for accuracy.";

        // Pull notification recipient if present
        $settings = $def['settings'] ?? [];
        if ( is_array( $settings ) && ! empty( $settings['notifications'] ) ) {
            $first = is_array( $settings['notifications'] ) ? reset( $settings['notifications'] ) : null;
            if ( is_array( $first ) && ! empty( $first['email'] ) ) {
                $form['settings']['notifications']['admin']['to'] = self::strip_wpf_tags( $first['email'] );
                if ( ! empty( $first['subject'] ) ) {
                    $form['settings']['notifications']['admin']['subject'] = self::strip_wpf_tags( $first['subject'] );
                }
            }
        }

        return [ 'form' => $form, 'warnings' => $warnings ];
    }

    private static function strip_wpf_tags( $s ) {
        return preg_replace( '/\{[^}]+\}/', '', (string) $s );
    }

    /**
     * Translate a source plugin's conditional-logic shape into FormCraft's
     * rule-group model. Returns:
     *   [ logicGroups, logicAction ]
     * where logicGroups = [[rule,rule],[rule]] — inner array AND, outer OR.
     * Caller supplies $id_map: source field ID → new FormCraft field ID.
     */
    private static function translate_conditional_rules( $raw, $id_map, $source ) {
        $groups    = [];
        $action    = 'show';

        // ---- Operator dictionaries ----
        $wpf_ops = [
            '=='      => 'equals',
            '='       => 'equals',
            'is'      => 'equals',
            '!='      => 'not_equals',
            'isnot'   => 'not_equals',
            'contains'=> 'contains',
            '!contains'=> 'not_contains',
            '>'       => 'greater_than',
            '<'       => 'less_than',
            'empty'   => 'is_empty',
            '!empty'  => 'is_not_empty',
        ];
        $gf_ops = [
            'is'           => 'equals',
            'isnot'        => 'not_equals',
            'is not'       => 'not_equals',
            '>'            => 'greater_than',
            '<'            => 'less_than',
            'contains'     => 'contains',
            'starts_with'  => 'contains',
            'ends_with'    => 'contains',
        ];
        $ff_ops = [
            '='            => 'equals',
            '=='           => 'equals',
            '!='           => 'not_equals',
            '>'            => 'greater_than',
            '<'            => 'less_than',
            'contains'     => 'contains',
            'doNotContains'=> 'not_contains',
        ];

        $rule_from = function( $src_fid, $op_raw, $val, $ops ) use ( $id_map ) {
            if ( ! isset( $id_map[ $src_fid ] ) ) return null;
            return [
                'field' => $id_map[ $src_fid ],
                'op'    => $ops[ $op_raw ] ?? 'equals',
                'value' => (string) $val,
            ];
        };

        if ( $source === 'wpforms' ) {
            // WPForms: outer = OR, inner = AND — exact match for our model.
            if ( ! is_array( $raw ) ) return [ $groups, $action ];
            foreach ( $raw as $and_group ) {
                if ( ! is_array( $and_group ) ) continue;
                $g = [];
                foreach ( $and_group as $rule ) {
                    if ( ! is_array( $rule ) ) continue;
                    $r = $rule_from(
                        (string) ( $rule['field'] ?? '' ),
                        strtolower( (string) ( $rule['operator'] ?? $rule['comparison'] ?? '==' ) ),
                        $rule['value'] ?? '',
                        $wpf_ops
                    );
                    if ( $r ) $g[] = $r;
                }
                if ( $g ) $groups[] = $g;
            }
        } elseif ( $source === 'fluent' ) {
            if ( ! is_array( $raw ) || empty( $raw['status'] ) ) return [ $groups, $action ];
            $is_any = ( ( $raw['type'] ?? 'any' ) === 'any' );
            foreach ( ( $raw['conditions'] ?? [] ) as $rule ) {
                $r = $rule_from(
                    (string) ( $rule['field'] ?? '' ),
                    (string) ( $rule['operator'] ?? '=' ),
                    $rule['value'] ?? '',
                    $ff_ops
                );
                if ( ! $r ) continue;
                // ANY (OR semantics) → one rule per group.
                // ALL (AND semantics) → single group with all rules.
                if ( $is_any )            $groups[] = [ $r ];
                elseif ( ! $groups )      $groups   = [ [ $r ] ];
                else                      $groups[0][] = $r;
            }
        } elseif ( $source === 'gravity' ) {
            if ( ! is_array( $raw ) ) return [ $groups, $action ];
            $action = ( ( $raw['actionType'] ?? 'show' ) === 'hide' ) ? 'hide' : 'show';
            $is_any = ( ( $raw['logicType']  ?? 'all' )  === 'any' );
            foreach ( ( $raw['rules'] ?? [] ) as $rule ) {
                $r = $rule_from(
                    (string) ( $rule['fieldId'] ?? '' ),
                    strtolower( (string) ( $rule['operator'] ?? 'is' ) ),
                    $rule['value'] ?? '',
                    $gf_ops
                );
                if ( ! $r ) continue;
                if ( $is_any )            $groups[] = [ $r ];
                elseif ( ! $groups )      $groups   = [ [ $r ] ];
                else                      $groups[0][] = $r;
            }
        }
        return [ $groups, $action ];
    }

    private static function import_wpforms_subs( $external_id, $new_form_id, $form ) {
        global $wpdb;
        $te = $wpdb->prefix . 'wpforms_entries';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$te'" ) ) return 0;
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT entry_id, fields, date FROM $te WHERE form_id = %d", $external_id ), ARRAY_A );
        $count = 0;
        // Map WPForms field ids -> labels from the form JSON
        $post = get_post( $external_id );
        $def  = $post ? json_decode( $post->post_content, true ) : null;
        $id_to_label = [];
        if ( is_array( $def['fields'] ?? null ) ) {
            foreach ( $def['fields'] as $fid => $fld ) {
                $key = is_array( $fld ) ? ( $fld['id'] ?? $fid ) : $fid;
                $id_to_label[ (string) $key ] = (string) ( $fld['label'] ?? 'Field ' . $key );
            }
        }
        foreach ( $rows as $r ) {
            $fields = json_decode( $r['fields'], true );
            $data   = [];
            if ( is_array( $fields ) ) {
                foreach ( $fields as $fid => $val ) {
                    $label = $id_to_label[ (string) $fid ] ?? ( 'Field ' . $fid );
                    $v = is_array( $val ) ? ( $val['value'] ?? wp_json_encode( $val ) ) : $val;
                    $data[ $label ] = is_scalar( $v ) ? (string) $v : wp_json_encode( $v );
                }
            }
            $extra = [ 'ip' => '', 'country' => '', 'device' => '', 'browser' => '' ];
            self::insert_sub_with_date( $new_form_id, $data, $extra, $r['date'] );
            $count++;
        }
        return $count;
    }

    /* =====================================================================
     * Source adapter: Fluent Forms
     * ================================================================== */

    private static function import_fluentform_form( $external_id ) {
        global $wpdb;
        $t   = $wpdb->prefix . 'fluentform_forms';
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE id = %d", $external_id ), ARRAY_A );
        if ( ! $row ) return new WP_Error( 'ff_missing', "Fluent Form #$external_id not found." );
        $def = json_decode( $row['form_fields'], true );
        if ( ! is_array( $def ) || ! isset( $def['fields'] ) ) return new WP_Error( 'ff_parse', 'Could not parse Fluent Form fields JSON.' );

        $warnings = [];
        $steps_acc = [];
        $current   = [];
        $id_map    = [];
        $raw_log   = [];

        foreach ( $def['fields'] as $fld ) {
            $element = (string) ( $fld['element'] ?? 'input_text' );
            if ( $element === 'step_start' || $element === 'form_step' ) {
                if ( $current ) $steps_acc[] = $current;
                $current = [];
                continue;
            }
            $map = self::ff_element_map();
            $target = $map[ $element ] ?? null;
            if ( $target === null ) {
                $warnings[] = "Fluent Forms element '$element' — mapped to text.";
                $target = 'text';
            } elseif ( $target === '__skip__' ) {
                continue;
            }

            $attrs   = is_array( $fld['attributes'] ?? null ) ? $fld['attributes'] : [];
            $sett    = is_array( $fld['settings']   ?? null ) ? $fld['settings']   : [];
            $label   = (string) ( $sett['label'] ?? $attrs['name'] ?? self::humanize_label( $element ) );
            $field   = self::new_field( $target, $label );
            $field['required']    = ! empty( $sett['validation_rules']['required']['value'] ) || ! empty( $attrs['required'] );
            $field['placeholder'] = (string) ( $attrs['placeholder'] ?? '' );
            $field['help']        = (string) ( $sett['help_message'] ?? '' );
            $field['defaultValue']= (string) ( $attrs['value'] ?? '' );

            if ( in_array( $target, [ 'select', 'radio', 'checkbox' ], true ) ) {
                $opts = [];
                if ( ! empty( $sett['advanced_options'] ) && is_array( $sett['advanced_options'] ) ) {
                    foreach ( $sett['advanced_options'] as $o ) {
                        if ( isset( $o['label'] ) ) $opts[] = (string) $o['label'];
                    }
                }
                if ( $opts ) $field['options'] = $opts;
            }
            // Track id mapping for conditional-logic translation. FF uses
            // the field's attribute name as its key inside conditional rules.
            $src_id = (string) ( $attrs['name'] ?? '' );
            if ( $src_id ) $id_map[ $src_id ] = $field['id'];
            if ( ! empty( $sett['conditional_logics'] ) ) $raw_log[ $src_id ] = $sett['conditional_logics'];
            // Fidelity boost — merge Fluent's "attributes" + "settings"
            // shapes into the helper which only reads top-level keys.
            self::translate_field_meta( $field, array_merge( $attrs, $sett ) );
            self::translate_file_settings( $field, array_merge( $attrs, $sett ) );
            $current[] = $field;
        }
        if ( $current ) $steps_acc[] = $current;

        $form = self::blank_form( $row['title'] ?: 'Imported Fluent Form' );
        if ( count( $steps_acc ) > 1 ) {
            $form['steps'] = [];
            foreach ( $steps_acc as $i => $sf ) {
                $form['steps'][] = self::new_step( 'Step ' . ( $i + 1 ), $sf );
            }
        } elseif ( count( $steps_acc ) === 1 ) {
            $form['steps'][0]['fields'] = $steps_acc[0];
        }

        // Conditional-logic translation pass.
        $applied = 0;
        foreach ( $form['steps'] as &$step ) {
            foreach ( $step['fields'] as &$f_ref ) {
                $src_id = array_search( $f_ref['id'], $id_map, true );
                if ( $src_id === false || empty( $raw_log[ $src_id ] ) ) continue;
                list( $groups, $act ) = self::translate_conditional_rules( $raw_log[ $src_id ], $id_map, 'fluent' );
                if ( $groups ) {
                    $f_ref['logicGroups'] = $groups;
                    $f_ref['logic']       = array_merge( [], ...$groups );
                    $f_ref['logicAction'] = $act;
                    $applied++;
                }
            }
            unset( $f_ref );
        }
        unset( $step );
        if ( $applied ) $warnings[] = "Translated conditional logic on $applied field(s). Review for accuracy.";

        return [ 'form' => $form, 'warnings' => $warnings ];
    }

    private static function ff_element_map() {
        return [
            'input_text'             => 'text',
            'input_email'            => 'email',
            'input_url'              => 'url',
            'input_password'         => 'password',
            'input_number'           => 'number',
            'input_tel'              => 'tel',
            'phone'                  => 'tel',
            'textarea'               => 'textarea',
            'select'                 => 'select',
            'select_country'         => 'country',
            'multi_select'           => 'multiselect',
            'input_radio'            => 'radio',
            'input_checkbox'         => 'checkbox',
            'gdpr_agreement'         => 'checkbox',
            'terms_and_condition'    => 'checkbox',
            'input_date'             => 'date',
            'datetime'               => 'date',
            'input_file'             => 'file',
            'input_image'            => 'file',
            'ratings'                => 'rating',
            'rangeslider'            => 'range',
            'input_hidden'           => 'hidden',
            'custom_html'            => 'html',
            'section_break'          => 'html',
            'recaptcha'              => '__skip__',
            'hcaptcha'               => '__skip__',
            'turnstile'              => '__skip__',
        ];
    }

    private static function import_fluentform_subs( $external_id, $new_form_id, $form ) {
        global $wpdb;
        $te = $wpdb->prefix . 'fluentform_submissions';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$te'" ) ) return 0;
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT response, ip, created_at FROM $te WHERE form_id = %d", $external_id ), ARRAY_A );
        // Build name->label map from the source form fields
        $t = $wpdb->prefix . 'fluentform_forms';
        $src = $wpdb->get_var( $wpdb->prepare( "SELECT form_fields FROM $t WHERE id = %d", $external_id ) );
        $name_to_label = [];
        $def = json_decode( $src, true );
        if ( is_array( $def['fields'] ?? null ) ) {
            foreach ( $def['fields'] as $fld ) {
                $n = $fld['attributes']['name'] ?? '';
                $l = $fld['settings']['label']  ?? $n;
                if ( $n ) $name_to_label[ $n ] = (string) $l;
            }
        }
        $count = 0;
        foreach ( $rows as $r ) {
            $resp = json_decode( $r['response'], true );
            $data = [];
            if ( is_array( $resp ) ) {
                foreach ( $resp as $k => $v ) {
                    $label = $name_to_label[ $k ] ?? $k;
                    $data[ $label ] = is_scalar( $v ) ? (string) $v : wp_json_encode( $v );
                }
            }
            self::insert_sub_with_date( $new_form_id, $data, [ 'ip' => $r['ip'] ?? '' ], $r['created_at'] );
            $count++;
        }
        return $count;
    }

    /* =====================================================================
     * Source adapter: Gravity Forms
     * ================================================================== */

    private static function import_gravity_form( $external_id ) {
        global $wpdb;
        $tm = $wpdb->prefix . 'gf_form_meta';
        $t  = $wpdb->prefix . 'gf_form';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$tm'" ) ) {
            $tm = $wpdb->prefix . 'rg_form_meta';
            $t  = $wpdb->prefix . 'rg_form';
        }
        $title = (string) $wpdb->get_var( $wpdb->prepare( "SELECT title FROM $t WHERE id = %d", $external_id ) );
        $meta  = $wpdb->get_var( $wpdb->prepare( "SELECT display_meta FROM $tm WHERE form_id = %d", $external_id ) );
        $def   = json_decode( $meta, true );
        if ( ! is_array( $def ) ) return new WP_Error( 'gf_parse', 'Could not parse Gravity Forms display_meta.' );

        $warnings = [];
        $map = [
            'text'        => 'text',
            'textarea'    => 'textarea',
            'select'      => 'select',
            'multiselect' => 'multiselect',
            'number'      => 'number',
            'checkbox'    => 'checkbox',
            'radio'       => 'radio',
            'hidden'      => 'hidden',
            'html'        => 'html',
            'section'     => 'html',
            'page'        => '__step__',
            'date'        => 'date',
            'time'        => 'time',
            'phone'       => 'tel',
            'email'       => 'email',
            'website'     => 'url',
            'fileupload'  => 'file',
            'list'        => 'textarea',
            'name'        => 'text',
            'address'     => 'text',
            'consent'     => 'checkbox',
        ];

        $steps_acc = [];
        $current   = [];
        $id_map    = [];
        $raw_log   = [];
        $fields    = is_array( $def['fields'] ?? null ) ? $def['fields'] : [];
        foreach ( $fields as $fld ) {
            $type = (string) ( $fld['type'] ?? 'text' );
            if ( ! isset( $map[ $type ] ) ) {
                $warnings[] = "Gravity Forms type '$type' — mapped to text.";
                $target = 'text';
            } else {
                $target = $map[ $type ];
            }
            if ( $target === '__step__' ) {
                if ( $current ) $steps_acc[] = $current;
                $current = [];
                continue;
            }
            $label = (string) ( $fld['label'] ?? self::humanize_label( $type ) );
            $field = self::new_field( $target, $label );
            $field['required']    = ! empty( $fld['isRequired'] );
            $field['placeholder'] = (string) ( $fld['placeholder'] ?? '' );
            $field['help']        = (string) ( $fld['description'] ?? '' );
            $field['defaultValue']= (string) ( $fld['defaultValue']  ?? '' );

            if ( in_array( $target, [ 'select', 'multiselect', 'radio', 'checkbox' ], true ) ) {
                $choices = is_array( $fld['choices'] ?? null ) ? $fld['choices'] : [];
                $opts    = [];
                foreach ( $choices as $c ) {
                    if ( is_array( $c ) && isset( $c['text'] ) ) $opts[] = (string) $c['text'];
                }
                if ( $opts ) $field['options'] = $opts;
            }
            // Track id mapping for conditional-logic translation.
            $src_id = (string) ( $fld['id'] ?? '' );
            if ( $src_id ) $id_map[ $src_id ] = $field['id'];
            if ( ! empty( $fld['conditionalLogic'] ) ) $raw_log[ $src_id ] = $fld['conditionalLogic'];
            // Fidelity boost — Gravity Forms uses 'cssClass' + 'errorMessage'.
            self::translate_field_meta( $field, $fld );
            self::translate_file_settings( $field, $fld );
            $current[] = $field;
        }
        if ( $current ) $steps_acc[] = $current;

        $form = self::blank_form( $title ?: 'Imported Gravity Form' );
        if ( count( $steps_acc ) > 1 ) {
            $form['steps'] = [];
            foreach ( $steps_acc as $i => $sf ) {
                $form['steps'][] = self::new_step( 'Step ' . ( $i + 1 ), $sf );
            }
        } elseif ( count( $steps_acc ) === 1 ) {
            $form['steps'][0]['fields'] = $steps_acc[0];
        }

        // Notification recipient
        if ( ! empty( $def['notifications'] ) && is_array( $def['notifications'] ) ) {
            $first = reset( $def['notifications'] );
            if ( is_array( $first ) && ! empty( $first['to'] ) ) {
                $form['settings']['notifications']['admin']['to'] = self::strip_wpf_tags( $first['to'] );
                if ( ! empty( $first['subject'] ) ) $form['settings']['notifications']['admin']['subject'] = self::strip_wpf_tags( $first['subject'] );
            }
        }

        // Conditional-logic translation pass.
        $applied = 0;
        foreach ( $form['steps'] as &$step ) {
            foreach ( $step['fields'] as &$f_ref ) {
                $src_id = array_search( $f_ref['id'], $id_map, true );
                if ( $src_id === false || empty( $raw_log[ $src_id ] ) ) continue;
                list( $groups, $act ) = self::translate_conditional_rules( $raw_log[ $src_id ], $id_map, 'gravity' );
                if ( $groups ) {
                    $f_ref['logicGroups'] = $groups;
                    $f_ref['logic']       = array_merge( [], ...$groups );
                    $f_ref['logicAction'] = $act;
                    $applied++;
                }
            }
            unset( $f_ref );
        }
        unset( $step );
        if ( $applied ) $warnings[] = "Translated conditional logic on $applied field(s). Review for accuracy.";

        return [ 'form' => $form, 'warnings' => $warnings ];
    }

    private static function import_gravity_subs( $external_id, $new_form_id, $form ) {
        global $wpdb;
        $te = $wpdb->prefix . 'gf_entry';
        $tem= $wpdb->prefix . 'gf_entry_meta';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$te'" ) ) {
            $te = $wpdb->prefix . 'rg_lead';
            $tem= $wpdb->prefix . 'rg_lead_detail';
            if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$te'" ) ) return 0;
        }
        // Build field-id -> label map
        $tm  = $wpdb->prefix . 'gf_form_meta';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$tm'" ) ) $tm = $wpdb->prefix . 'rg_form_meta';
        $meta = $wpdb->get_var( $wpdb->prepare( "SELECT display_meta FROM $tm WHERE form_id = %d", $external_id ) );
        $def  = json_decode( $meta, true );
        $id_to_label = [];
        if ( is_array( $def['fields'] ?? null ) ) {
            foreach ( $def['fields'] as $fld ) {
                $id_to_label[ (string) ( $fld['id'] ?? '' ) ] = (string) ( $fld['label'] ?? 'Field' );
            }
        }
        $entries = $wpdb->get_results( $wpdb->prepare( "SELECT id, date_created, ip FROM $te WHERE form_id = %d AND status = 'active'", $external_id ), ARRAY_A );
        $count   = 0;
        foreach ( $entries as $e ) {
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT meta_key, meta_value FROM $tem WHERE entry_id = %d", $e['id'] ), ARRAY_A );
            $data = [];
            foreach ( $rows as $r ) {
                $fid   = preg_replace( '/\.\d+$/', '', $r['meta_key'] );
                $label = $id_to_label[ $fid ] ?? ( 'Field ' . $fid );
                $data[ $label ] = (string) $r['meta_value'];
            }
            self::insert_sub_with_date( $new_form_id, $data, [ 'ip' => $e['ip'] ?? '' ], $e['date_created'] );
            $count++;
        }
        return $count;
    }

    /* =====================================================================
     * Source adapter: Ninja Forms
     * ================================================================== */

    private static function import_ninja_form( $external_id ) {
        global $wpdb;
        $tf = $wpdb->prefix . 'nf3_forms';
        $tx = $wpdb->prefix . 'nf3_fields';
        $title = $wpdb->get_var( $wpdb->prepare( "SELECT title FROM $tf WHERE id = %d", $external_id ) );
        $rows  = $wpdb->get_results( $wpdb->prepare( "SELECT id, label, type, field_label, settings FROM $tx WHERE parent_id = %d ORDER BY `order` ASC, id ASC", $external_id ), ARRAY_A );

        $warnings = [];
        $map = [
            'textbox'        => 'text',
            'email'          => 'email',
            'phone'          => 'tel',
            'firstname'      => 'text',
            'lastname'       => 'text',
            'address'        => 'text',
            'address2'       => 'text',
            'city'           => 'text',
            'state'          => 'text',
            'zip'            => 'text',
            'country'        => 'country',
            'number'         => 'number',
            'textarea'       => 'textarea',
            'listselect'     => 'select',
            'listmultiselect'=> 'multiselect',
            'listcountry'    => 'country',
            'listradio'      => 'radio',
            'listcheckbox'   => 'checkbox',
            'date'           => 'date',
            'hidden'         => 'hidden',
            'html'           => 'html',
            'submit'         => null,
            'recaptcha'      => null,
            'starrating'     => 'rating',
            'rating'         => 'rating',
            'file_upload'    => 'file',
            'file'           => 'file',
        ];

        $fields = [];
        foreach ( $rows as $r ) {
            $type   = (string) $r['type'];
            $target = $map[ $type ] ?? null;
            if ( $target === null ) {
                if ( ! isset( $map[ $type ] ) ) {
                    $warnings[] = "Ninja Forms type '$type' — mapped to text.";
                    $target = 'text';
                } else continue;
            }
            $label  = (string) ( $r['label'] ?: $r['field_label'] ?: self::humanize_label( $type ) );
            $sett   = is_string( $r['settings'] ) ? maybe_unserialize( $r['settings'] ) : $r['settings'];
            $sett   = is_array( $sett ) ? $sett : [];
            $field  = self::new_field( $target, $label );
            $field['required']    = ! empty( $sett['required'] );
            $field['placeholder'] = (string) ( $sett['placeholder']  ?? '' );
            $field['help']        = (string) ( $sett['description']  ?? '' );
            $field['defaultValue']= (string) ( $sett['default_value']?? '' );
            if ( in_array( $target, [ 'select', 'multiselect', 'radio', 'checkbox' ], true ) ) {
                $opts = [];
                $opt_src = $sett['options'] ?? [];
                if ( is_array( $opt_src ) ) {
                    foreach ( $opt_src as $o ) {
                        if ( is_array( $o ) && isset( $o['label'] ) ) $opts[] = (string) $o['label'];
                    }
                }
                if ( $opts ) $field['options'] = $opts;
            }
            $fields[] = $field;
        }

        $form = self::blank_form( $title ?: 'Imported Ninja Form' );
        $form['steps'][0]['fields'] = $fields;
        return [ 'form' => $form, 'warnings' => $warnings ];
    }

    private static function import_ninja_subs( $external_id, $new_form_id, $form ) {
        global $wpdb;
        // Ninja Forms stores submissions as custom posts (nf_sub) with each
        // field value in a postmeta entry keyed by field id (_field_123).
        $subs = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID, post_date FROM {$wpdb->posts} WHERE post_type = 'nf_sub' AND post_parent = %d AND post_status = 'publish'",
            $external_id
        ), ARRAY_A );
        // Build field-id -> label map
        $tx = $wpdb->prefix . 'nf3_fields';
        $field_rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, label, field_label, type FROM $tx WHERE parent_id = %d", $external_id ), ARRAY_A );
        $id_to_label = [];
        $skip = [ 'submit', 'recaptcha', 'html' ];
        foreach ( $field_rows as $fr ) {
            if ( in_array( $fr['type'], $skip, true ) ) continue;
            $id_to_label[ (string) $fr['id'] ] = (string) ( $fr['label'] ?: $fr['field_label'] ?: 'Field ' . $fr['id'] );
        }
        $count = 0;
        foreach ( $subs as $s ) {
            $metas = get_post_meta( (int) $s['ID'] );
            $data  = [];
            foreach ( $metas as $k => $v ) {
                if ( strpos( $k, '_field_' ) !== 0 ) continue;
                $fid   = substr( $k, 7 );
                $label = $id_to_label[ $fid ] ?? null;
                if ( ! $label ) continue;
                $val   = is_array( $v ) ? reset( $v ) : $v;
                $data[ $label ] = is_scalar( $val ) ? (string) $val : wp_json_encode( $val );
            }
            self::insert_sub_with_date( $new_form_id, $data, [], $s['post_date'] );
            $count++;
        }
        return $count;
    }

    /* =====================================================================
     * Source adapter: Formidable Forms
     * ================================================================== */

    private static function import_formidable_form( $external_id ) {
        global $wpdb;
        $tf = $wpdb->prefix . 'frm_forms';
        $tx = $wpdb->prefix . 'frm_fields';
        $title = $wpdb->get_var( $wpdb->prepare( "SELECT name FROM $tf WHERE id = %d", $external_id ) );
        $rows  = $wpdb->get_results( $wpdb->prepare( "SELECT id, name, type, options, required, field_options FROM $tx WHERE form_id = %d ORDER BY field_order ASC", $external_id ), ARRAY_A );

        $warnings = [];
        $map = [
            'text'      => 'text',
            'email'     => 'email',
            'url'       => 'url',
            'phone'     => 'tel',
            'number'    => 'number',
            'textarea'  => 'textarea',
            'select'    => 'select',
            'radio'     => 'radio',
            'checkbox'  => 'checkbox',
            'date'      => 'date',
            'time'      => 'time',
            'file'      => 'file',
            'hidden'    => 'hidden',
            'html'      => 'html',
            'divider'   => 'html',
            'break'     => '__step__',
            'name'      => 'text',
            'address'   => 'text',
            'tag'       => 'select',
            'rte'       => 'textarea',
            'password'  => 'password',
            'star'      => 'rating',
            'range'     => 'range',
        ];

        $steps_acc = [];
        $current   = [];
        foreach ( $rows as $r ) {
            $type   = (string) $r['type'];
            $target = $map[ $type ] ?? null;
            if ( $target === null ) {
                $warnings[] = "Formidable type '$type' — mapped to text.";
                $target = 'text';
            }
            if ( $target === '__step__' ) {
                if ( $current ) $steps_acc[] = $current;
                $current = [];
                continue;
            }
            $label = (string) ( $r['name'] ?: self::humanize_label( $type ) );
            $field = self::new_field( $target, $label );
            $field['required'] = ! empty( $r['required'] );
            // options column stores serialized choices for select/radio/checkbox
            if ( in_array( $target, [ 'select', 'radio', 'checkbox' ], true ) ) {
                $opt_data = maybe_unserialize( $r['options'] );
                $opts = [];
                if ( is_array( $opt_data ) ) {
                    foreach ( $opt_data as $o ) {
                        if ( is_string( $o ) && $o !== '' ) $opts[] = $o;
                        elseif ( is_array( $o ) && isset( $o['label'] ) ) $opts[] = (string) $o['label'];
                    }
                }
                if ( $opts ) $field['options'] = $opts;
            }
            // field_options stores serialized per-field metadata (placeholder/desc etc)
            $fo = maybe_unserialize( $r['field_options'] );
            if ( is_array( $fo ) ) {
                if ( ! empty( $fo['blank'] ) ) {/* keep label as-is */}
                if ( ! empty( $fo['description'] ) ) $field['help']        = (string) $fo['description'];
                if ( ! empty( $fo['placeholder'] ) ) $field['placeholder'] = (string) $fo['placeholder'];
            }
            $current[] = $field;
        }
        if ( $current ) $steps_acc[] = $current;

        $form = self::blank_form( $title ?: 'Imported Formidable Form' );
        if ( count( $steps_acc ) > 1 ) {
            $form['steps'] = [];
            foreach ( $steps_acc as $i => $sf ) {
                $form['steps'][] = self::new_step( 'Step ' . ( $i + 1 ), $sf );
            }
        } elseif ( count( $steps_acc ) === 1 ) {
            $form['steps'][0]['fields'] = $steps_acc[0];
        }

        return [ 'form' => $form, 'warnings' => $warnings ];
    }

    private static function import_formidable_subs( $external_id, $new_form_id, $form ) {
        global $wpdb;
        $ti  = $wpdb->prefix . 'frm_items';
        $tm  = $wpdb->prefix . 'frm_item_metas';
        $tx  = $wpdb->prefix . 'frm_fields';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$ti'" ) ) return 0;
        $entries = $wpdb->get_results( $wpdb->prepare( "SELECT id, created_at, ip FROM $ti WHERE form_id = %d", $external_id ), ARRAY_A );
        $id_to_label = [];
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, name FROM $tx WHERE form_id = %d", $external_id ), ARRAY_A );
        foreach ( $rows as $r ) $id_to_label[ (string) $r['id'] ] = (string) $r['name'];

        $count = 0;
        foreach ( $entries as $e ) {
            $metas = $wpdb->get_results( $wpdb->prepare( "SELECT field_id, meta_value FROM $tm WHERE item_id = %d", $e['id'] ), ARRAY_A );
            $data  = [];
            foreach ( $metas as $m ) {
                $label = $id_to_label[ (string) $m['field_id'] ] ?? ( 'Field ' . $m['field_id'] );
                $val   = maybe_unserialize( $m['meta_value'] );
                $data[ $label ] = is_array( $val ) ? wp_json_encode( $val ) : (string) $val;
            }
            self::insert_sub_with_date( $new_form_id, $data, [ 'ip' => $e['ip'] ?? '' ], $e['created_at'] );
            $count++;
        }
        return $count;
    }

    /* =====================================================================
     * Source adapter: Everest Forms
     * ================================================================== */

    private static function import_everest_form( $external_id ) {
        $post = get_post( $external_id );
        if ( ! $post || $post->post_type !== 'everest_form' ) return new WP_Error( 'evf_missing', "Everest form #$external_id not found." );
        $struct = get_post_meta( $external_id, 'evf_form_template', true );
        $struct = is_string( $struct ) ? maybe_unserialize( $struct ) : $struct;
        if ( ! is_array( $struct ) || empty( $struct['form_fields'] ) ) {
            // Fall back to post_content JSON
            $struct = json_decode( $post->post_content, true );
        }
        if ( ! is_array( $struct ) ) return new WP_Error( 'evf_parse', 'Could not parse Everest form structure.' );

        $warnings = [];
        $map = [
            'first-name'   => 'text',
            'last-name'    => 'text',
            'text'         => 'text',
            'textarea'     => 'textarea',
            'email'        => 'email',
            'url'          => 'url',
            'phone'        => 'tel',
            'number'       => 'number',
            'select'       => 'select',
            'radio'        => 'radio',
            'checkbox'     => 'checkbox',
            'address'      => 'text',
            'country'      => 'country',
            'date-time'    => 'date',
            'file-upload'  => 'file',
            'image-upload' => 'file',
            'hidden'       => 'hidden',
            'html'         => 'html',
            'divider'      => 'html',
            'rating'       => 'rating',
            'recaptcha'    => '__skip__',
        ];

        $fields_in = $struct['form_fields'] ?? [];
        $fields    = [];
        foreach ( $fields_in as $fld ) {
            $type   = (string) ( $fld['type'] ?? 'text' );
            $target = $map[ $type ] ?? null;
            if ( $target === null ) {
                $warnings[] = "Everest Forms type '$type' — mapped to text.";
                $target = 'text';
            } elseif ( $target === '__skip__' ) continue;
            $label  = (string) ( $fld['label'] ?? self::humanize_label( $type ) );
            $field  = self::new_field( $target, $label );
            $field['required']    = ! empty( $fld['required'] );
            $field['placeholder'] = (string) ( $fld['placeholder']  ?? '' );
            $field['help']        = (string) ( $fld['description']  ?? '' );
            if ( in_array( $target, [ 'select', 'radio', 'checkbox' ], true ) ) {
                $choices = $fld['choices'] ?? [];
                $opts = [];
                if ( is_array( $choices ) ) {
                    foreach ( $choices as $c ) {
                        if ( is_array( $c ) && isset( $c['label'] ) ) $opts[] = (string) $c['label'];
                        elseif ( is_string( $c ) ) $opts[] = $c;
                    }
                }
                if ( $opts ) $field['options'] = $opts;
            }
            $fields[] = $field;
        }

        $form = self::blank_form( $post->post_title ?: 'Imported Everest Form' );
        $form['steps'][0]['fields'] = $fields;
        return [ 'form' => $form, 'warnings' => $warnings ];
    }

    private static function import_everest_subs( $external_id, $new_form_id, $form ) {
        global $wpdb;
        $te = $wpdb->prefix . 'evf_entries';
        $tm = $wpdb->prefix . 'evf_entrymeta';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$te'" ) ) return 0;
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT entry_id, date_created, fields, user_ip_address FROM $te WHERE form_id = %d", $external_id ), ARRAY_A );
        $count = 0;
        foreach ( $rows as $r ) {
            $vals = json_decode( $r['fields'], true );
            $data = [];
            if ( is_array( $vals ) ) {
                foreach ( $vals as $k => $v ) {
                    $label = is_array( $v ) && isset( $v['name'] ) ? $v['name'] : $k;
                    $val   = is_array( $v ) && isset( $v['value'] ) ? $v['value'] : $v;
                    $data[ $label ] = is_scalar( $val ) ? (string) $val : wp_json_encode( $val );
                }
            }
            self::insert_sub_with_date( $new_form_id, $data, [ 'ip' => $r['user_ip_address'] ?? '' ], $r['date_created'] );
            $count++;
        }
        return $count;
    }

    /* =====================================================================
     * Helpers — blank form, blank field, label humanize, submission upsert
     * ================================================================== */

    private static function blank_form( $title ) {
        return [
            'title'       => $title,
            'description' => '',
            'status'      => 'draft',
            'steps'       => [
                self::new_step( 'Step 1', [] ),
            ],
            'settings'    => [
                'submitButton' => 'Submit',
                'successMessage' => 'Thank you — your submission was received.',
                'notifications' => [
                    'admin' => [ 'enabled' => true, 'to' => get_option( 'admin_email' ), 'subject' => 'New form submission' ],
                    'user'  => [ 'enabled' => false ],
                ],
            ],
            'migrated_from' => '',  // overwritten by caller via log
        ];
    }

    private static function new_step( $name, $fields ) {
        return [
            'id'     => 'step_' . wp_generate_password( 6, false ),
            'name'   => $name,
            'fields' => $fields,
        ];
    }

    private static function new_field( $type, $label ) {
        $id_safe = strtolower( preg_replace( '/[^a-z0-9]/i', '_', $label ) );
        return [
            'id'          => 'fld_' . wp_generate_password( 6, false ) . '_' . substr( $id_safe, 0, 16 ),
            'type'        => $type,
            'label'       => $label,
            'placeholder' => '',
            'help'        => '',
            'required'    => false,
            'options'     => in_array( $type, [ 'select', 'multiselect', 'radio', 'checkbox' ], true ) ? [ 'Option 1', 'Option 2' ] : [],
            'defaultValue'=> '',
        ];
    }

    private static function humanize_label( $raw ) {
        $raw = (string) $raw;
        $raw = str_replace( [ '-', '_' ], ' ', $raw );
        return ucwords( trim( $raw ) ) ?: 'Field';
    }

    /* =====================================================================
     * Shared fidelity helpers — replace silent drops with translations.
     *
     * Every source adapter calls these so we stop losing data customers
     * notice the moment they go live with the migrated form.
     * ================================================================== */

    /**
     * Translate a raw notification payload (admin + user emails) into the
     * FormCraft settings.notifications shape. Mostly the same keys across
     * source plugins, with merge-tag translation done by replace_merge_tags().
     */
    public static function translate_notifications( $form, $raw_notifications, $source ) {
        if ( ! is_array( $raw_notifications ) || empty( $raw_notifications ) ) return $form;
        $first = is_array( reset( $raw_notifications ) ) ? reset( $raw_notifications ) : $raw_notifications;

        $form['settings']['notifications']['admin']['enabled'] = true;
        if ( ! empty( $first['to'] ) ) {
            $form['settings']['notifications']['admin']['to'] =
                self::replace_merge_tags( (string) $first['to'], $source );
        } elseif ( ! empty( $first['email'] ) ) {
            $form['settings']['notifications']['admin']['to'] =
                self::replace_merge_tags( (string) $first['email'], $source );
        }
        if ( ! empty( $first['subject'] ) ) {
            $form['settings']['notifications']['admin']['subject'] =
                self::replace_merge_tags( (string) $first['subject'], $source );
        }
        if ( ! empty( $first['message'] ) ) {
            $form['settings']['notifications']['admin']['body'] =
                self::replace_merge_tags( (string) $first['message'], $source );
        } elseif ( ! empty( $first['body'] ) ) {
            $form['settings']['notifications']['admin']['body'] =
                self::replace_merge_tags( (string) $first['body'], $source );
        }
        if ( ! empty( $first['from_email'] ) ) {
            $form['settings']['notifications']['admin']['fromEmail'] = (string) $first['from_email'];
        }
        if ( ! empty( $first['from_name'] ) ) {
            $form['settings']['notifications']['admin']['fromName'] = (string) $first['from_name'];
        }
        return $form;
    }

    /**
     * Translate a confirmation block (post-submit message OR redirect URL)
     * into the FormCraft settings shape. Handles the three confirmation
     * types every major source supports: message / redirect / page.
     */
    public static function translate_confirmation( $form, $raw_confirmation, $source ) {
        if ( ! is_array( $raw_confirmation ) ) return $form;
        $type = strtolower( (string) ( $raw_confirmation['type'] ?? '' ) );
        if ( $type === 'message' || ! empty( $raw_confirmation['message'] ) ) {
            $form['settings']['successMessage'] = wp_kses_post(
                (string) ( $raw_confirmation['message'] ?? $form['settings']['successMessage'] )
            );
        } elseif ( $type === 'redirect' || ! empty( $raw_confirmation['url'] ) || ! empty( $raw_confirmation['redirect_url'] ) ) {
            $form['settings']['afterSubmit']['action'] = 'redirect';
            $form['settings']['afterSubmit']['redirectUrl'] = esc_url_raw(
                (string) ( $raw_confirmation['url']
                    ?? $raw_confirmation['redirect_url']
                    ?? $raw_confirmation['queryString']
                    ?? '' )
            );
        } elseif ( $type === 'page' && ! empty( $raw_confirmation['page'] ) ) {
            $form['settings']['afterSubmit']['action'] = 'redirect';
            $form['settings']['afterSubmit']['redirectUrl'] = get_permalink( (int) $raw_confirmation['page'] );
        }
        return $form;
    }

    /**
     * Translate file-upload settings (allowed types + max size) at the
     * field level. The source plugins use a dozen different shapes for
     * this; we normalise to FormCraft's `allowedExtensions` (csv) +
     * `maxFileSize` (MB).
     */
    public static function translate_file_settings( &$field, $raw_field ) {
        if ( $field['type'] !== 'file' && $field['type'] !== 'image' ) return;
        $exts = '';
        if ( ! empty( $raw_field['extensions'] ) )            $exts = (string) $raw_field['extensions'];
        elseif ( ! empty( $raw_field['allowed_extensions'] ) ) $exts = (string) $raw_field['allowed_extensions'];
        elseif ( ! empty( $raw_field['allowed_types'] ) )      $exts = (string) $raw_field['allowed_types'];
        elseif ( ! empty( $raw_field['file_extensions'] ) )    $exts = (string) $raw_field['file_extensions'];
        if ( $exts ) $field['allowedExtensions'] = preg_replace( '/[^a-z0-9,]/i', '', strtolower( $exts ) );

        $size = 0;
        if ( ! empty( $raw_field['max_size'] ) )          $size = (int) $raw_field['max_size'];
        elseif ( ! empty( $raw_field['maxFileSize'] ) )    $size = (int) $raw_field['maxFileSize'];
        elseif ( ! empty( $raw_field['max_file_size'] ) )  $size = (int) $raw_field['max_file_size'];
        // Common: source stored bytes, KB, or MB — auto-detect by magnitude.
        if ( $size > 1024 * 1024 ) $size = (int) round( $size / 1024 / 1024 );
        elseif ( $size > 1024 )    $size = (int) round( $size / 1024 );
        if ( $size > 0 ) $field['maxFileSize'] = $size;
    }

    /**
     * Translate per-field custom error message + CSS class. Source plugins
     * call these slightly different names; we accept all the common ones.
     */
    public static function translate_field_meta( &$field, $raw_field ) {
        $err = $raw_field['error_message']
            ?? $raw_field['required_message']
            ?? $raw_field['validation_message']
            ?? $raw_field['requiredMessage']
            ?? '';
        if ( $err ) $field['errorMessage'] = wp_strip_all_tags( (string) $err );

        $cls = $raw_field['css']
            ?? $raw_field['css_class']
            ?? $raw_field['cssClass']
            ?? $raw_field['classes']
            ?? '';
        if ( $cls ) {
            // Sanitize to safe class chars (letters, digits, hyphen, space).
            $cls = preg_replace( '/[^a-z0-9_\- ]/i', '', (string) $cls );
            $field['cssClass'] = trim( $cls );
        }
    }

    /**
     * Translate form-level AJAX vs full-reload submit mode. Most source
     * plugins ship AJAX-by-default; we honour whatever the admin chose.
     */
    public static function translate_submit_mode( $form, $raw_settings ) {
        if ( isset( $raw_settings['ajax_submit'] ) ) {
            $form['settings']['ajaxSubmit'] = (bool) $raw_settings['ajax_submit'];
        } elseif ( isset( $raw_settings['enable_ajax'] ) ) {
            $form['settings']['ajaxSubmit'] = (bool) $raw_settings['enable_ajax'];
        } elseif ( isset( $raw_settings['ajax'] ) ) {
            $form['settings']['ajaxSubmit'] = (bool) $raw_settings['ajax'];
        }
        return $form;
    }

    /**
     * Convert source-plugin merge tags into FormCraft's {field-label}
     * placeholder syntax. Handles the most common patterns:
     *   {field_id="email"}    (WPForms)
     *   {inputs.email}         (Fluent Forms)
     *   {Field 1:1}            (Gravity Forms)
     *   {fields[name]}         (Forminator)
     *   %email%                (Caldera)
     *   [your-email]           (Contact Form 7)
     * Best-effort — when the source uses an internal field id with no
     * obvious match, we leave it intact so the admin can clean up.
     */
    public static function replace_merge_tags( $text, $source ) {
        $text = (string) $text;
        if ( $text === '' ) return $text;
        // CF7: [your-email] / [your-name] → {Your Email} / {Your Name}
        if ( $source === 'cf7' ) {
            $text = preg_replace_callback( '/\[([a-zA-Z0-9_\-]+)\]/', function ( $m ) {
                return '{' . self::humanize_label( $m[1] ) . '}';
            }, $text );
        }
        // WPForms: {field_id="X"} → {field_id_X} (admin re-binds visually)
        $text = preg_replace( '/\{field_id="([^"]+)"\}/', '{field_$1}', $text );
        // Fluent Forms: {inputs.email} → {Email}
        $text = preg_replace_callback( '/\{inputs\.([a-zA-Z0-9_\-]+)\}/', function ( $m ) {
            return '{' . self::humanize_label( $m[1] ) . '}';
        }, $text );
        // Gravity Forms: {Field Label:7} → {Field Label}
        $text = preg_replace( '/\{([^:}]+):\d+\}/', '{$1}', $text );
        // Forminator: {fields[name]} → {Name}
        $text = preg_replace_callback( '/\{fields\[([a-zA-Z0-9_\-]+)\]\}/', function ( $m ) {
            return '{' . self::humanize_label( $m[1] ) . '}';
        }, $text );
        // Caldera: %field_slug% → {Field Slug}
        $text = preg_replace_callback( '/%([a-zA-Z0-9_\-]+)%/', function ( $m ) {
            return '{' . self::humanize_label( $m[1] ) . '}';
        }, $text );
        return $text;
    }

    private static function count_form_fields( $form ) {
        $n = 0;
        foreach ( (array) ( $form['steps'] ?? [] ) as $step ) {
            $n += count( $step['fields'] ?? [] );
        }
        return $n;
    }

    /**
     * Insert a submission preserving the original creation date.
     * Mirrors FCP_DB::insert_submission but lets us pass an explicit date.
     */
    private static function insert_sub_with_date( $form_id, $data, $extra, $created_at ) {
        global $wpdb;
        $name  = $data['name'] ?? $data['Full Name'] ?? $data['Name'] ?? $data['email'] ?? '';
        $email = $data['email'] ?? $data['Email Address'] ?? $data['Email'] ?? '';
        // Email-shaped fallback
        if ( ! $email ) {
            foreach ( $data as $v ) {
                if ( is_string( $v ) && is_email( $v ) ) { $email = $v; break; }
            }
        }
        $created = $created_at ? date( 'Y-m-d H:i:s', strtotime( (string) $created_at ) ) : current_time( 'mysql' );
        $wpdb->insert( FCP_DB::subs_table(), [
            'form_id'         => (int) $form_id,
            'data'            => wp_json_encode( $data ),
            'submitter_name'  => sanitize_text_field( $name ),
            'submitter_email' => sanitize_email( $email ),
            'ip_address'      => $extra['ip']  ?? '',
            'user_agent'      => '',
            'country'         => $extra['country'] ?? '',
            'device'          => '',
            'browser'         => '',
            'is_spam'         => 0,
            'is_read'         => 1,    // imported entries are marked read so they don't inflate the "new" badge
            'created_at'      => $created,
        ] );
        $sid = (int) $wpdb->insert_id;
        $wpdb->query( $wpdb->prepare( "UPDATE " . FCP_DB::forms_table() . " SET submissions = submissions + 1 WHERE id = %d", $form_id ) );

        // Submission source attribution — every imported entry gets tagged
        // with `migrated_from: <source>:<external_id>` in the data JSON so
        // admins can later filter "show me only entries imported from
        // WPForms" or audit which migrations they came from. The marker
        // sits under a `_meta` namespace so it never collides with a real
        // field label.
        if ( $sid && ! empty( $extra['migrated_from'] ) ) {
            $row = $wpdb->get_var( $wpdb->prepare(
                "SELECT data FROM " . FCP_DB::subs_table() . " WHERE id = %d",
                $sid
            ) );
            $payload = json_decode( $row, true );
            if ( is_array( $payload ) ) {
                $payload['_meta'] = [ 'migrated_from' => (string) $extra['migrated_from'] ];
                $wpdb->update(
                    FCP_DB::subs_table(),
                    [ 'data' => wp_json_encode( $payload ) ],
                    [ 'id'   => $sid ]
                );
            }
        }
        return $sid;
    }

    /* =====================================================================
     * Migration log — small dedicated table + history endpoints
     * ================================================================== */

    public static function log_table() {
        global $wpdb;
        return $wpdb->prefix . 'fcp_migrations';
    }

    public static function ensure_log_table() {
        global $wpdb;
        $table = self::log_table();
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            source VARCHAR(30) NOT NULL,
            source_form_id BIGINT UNSIGNED NOT NULL,
            new_form_id BIGINT UNSIGNED NOT NULL,
            form_title VARCHAR(255) NOT NULL DEFAULT '',
            fields_count INT UNSIGNED NOT NULL DEFAULT 0,
            subs_count INT UNSIGNED NOT NULL DEFAULT 0,
            warnings LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            rolled_back_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY new_form_id (new_form_id),
            KEY source (source)
        ) $charset;";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    private static function log_migration( $row ) {
        global $wpdb;
        self::ensure_log_table();
        $wpdb->insert( self::log_table(), [
            'source'         => $row['source'],
            'source_form_id' => (int) $row['source_form_id'],
            'new_form_id'    => (int) $row['new_form_id'],
            'form_title'     => substr( (string) $row['form_title'], 0, 255 ),
            'fields_count'   => (int) $row['fields_count'],
            'subs_count'     => (int) $row['subs_count'],
            'warnings'       => wp_json_encode( $row['warnings'] ?? [] ),
            'created_at'     => current_time( 'mysql' ),
        ] );
        return $wpdb->insert_id;
    }

    public static function history( $limit = 100 ) {
        global $wpdb;
        self::ensure_log_table();
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . self::log_table() . " ORDER BY created_at DESC LIMIT %d",
            (int) $limit
        ), ARRAY_A );
        $sources = self::sources();
        foreach ( $rows as &$r ) {
            $r['id']             = (int) $r['id'];
            $r['source_form_id'] = (int) $r['source_form_id'];
            $r['new_form_id']    = (int) $r['new_form_id'];
            $r['fields_count']   = (int) $r['fields_count'];
            $r['subs_count']     = (int) $r['subs_count'];
            $r['warnings']       = json_decode( $r['warnings'], true ) ?: [];
            $r['source_label']   = $sources[ $r['source'] ]['name'] ?? $r['source'];
            $r['rolled_back']    = ! empty( $r['rolled_back_at'] );
        }
        return $rows;
    }

    /**
     * Rollback = delete the FormCraft form that was created by this migration
     * AND every submission attached to it. The source plugin's data is never
     * touched.
     */
    public static function rollback( $migration_id ) {
        global $wpdb;
        self::ensure_log_table();
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . self::log_table() . " WHERE id = %d", (int) $migration_id ), ARRAY_A );
        if ( ! $row ) return new WP_Error( 'not_found', 'Migration record not found.' );
        if ( ! empty( $row['rolled_back_at'] ) ) return new WP_Error( 'already', 'This migration was already rolled back.' );

        FCP_DB::delete_form( (int) $row['new_form_id'] );
        $wpdb->update(
            self::log_table(),
            [ 'rolled_back_at' => current_time( 'mysql' ) ],
            [ 'id' => (int) $migration_id ]
        );
        return true;
    }

    /* =====================================================================
     * Site-wide shortcode auto-replacement (post-migration cleanup).
     *
     * After a successful migration the admin's content still references
     * the OLD shortcode (e.g. `[wpforms id="42"]`). The admin would have
     * to find every post + page + widget by hand. This scanner runs the
     * swap site-wide in one pass.
     *
     * Source shortcode patterns we recognise:
     *   [contact-form-7 id="42" title="…"]
     *   [wpforms id="42" title="…"]
     *   [fluentform id="42"]
     *   [gravityform id="42" title="…"]
     *   [ninja_form id=42]
     *   [formidable id="42"]
     *   [everest_form id="42"]
     *   [forminator_form id="42"]
     *   [caldera_form id="CF59abc"]
     *
     * Replace target: [formcraft id="<new_id>"]
     * ================================================================== */

    public static function replace_shortcodes_site_wide( $source, $old_id, $new_form_id ) {
        global $wpdb;

        $patterns = [
            'cf7'         => '/\[contact-form-7\s+(?:[^\]]*?\s+)?id=["\']?(' . preg_quote( (string) $old_id, '/' ) . ')["\']?[^\]]*\]/i',
            'wpforms'     => '/\[wpforms\s+(?:[^\]]*?\s+)?id=["\']?(' . preg_quote( (string) $old_id, '/' ) . ')["\']?[^\]]*\]/i',
            'fluentform'  => '/\[fluentform\s+(?:[^\]]*?\s+)?id=["\']?(' . preg_quote( (string) $old_id, '/' ) . ')["\']?[^\]]*\]/i',
            'gravity'     => '/\[gravityform[s]?\s+(?:[^\]]*?\s+)?id=["\']?(' . preg_quote( (string) $old_id, '/' ) . ')["\']?[^\]]*\]/i',
            'ninja'       => '/\[ninja_form\s+(?:[^\]]*?\s+)?id=["\']?(' . preg_quote( (string) $old_id, '/' ) . ')["\']?[^\]]*\]/i',
            'formidable'  => '/\[formidable\s+(?:[^\]]*?\s+)?id=["\']?(' . preg_quote( (string) $old_id, '/' ) . ')["\']?[^\]]*\]/i',
            'everest'     => '/\[everest_form\s+(?:[^\]]*?\s+)?id=["\']?(' . preg_quote( (string) $old_id, '/' ) . ')["\']?[^\]]*\]/i',
            'forminator'  => '/\[forminator_form\s+(?:[^\]]*?\s+)?id=["\']?(' . preg_quote( (string) $old_id, '/' ) . ')["\']?[^\]]*\]/i',
            'caldera'     => '/\[caldera_form\s+(?:[^\]]*?\s+)?id=["\']?(' . preg_quote( (string) $old_id, '/' ) . ')["\']?[^\]]*\]/i',
        ];
        if ( ! isset( $patterns[ $source ] ) ) {
            return new WP_Error( 'bad_source', 'No shortcode pattern for source: ' . $source );
        }
        $pattern     = $patterns[ $source ];
        $replacement = '[formcraft id="' . (int) $new_form_id . '"]';

        $report = [ 'posts' => 0, 'widgets' => 0, 'locations' => [] ];

        // ---- Scan post_content across every public post type ----
        // Limit to 5000 posts per pass — protects shared hosts from a 50k+
        // post scan timing out. The UI can show "still N posts to scan" if
        // the count returned > 5000.
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID, post_type, post_title, post_content
             FROM {$wpdb->posts}
             WHERE post_status IN ('publish','draft','pending','private','future')
               AND post_content LIKE %s
             LIMIT 5000",
            '%' . $wpdb->esc_like( '[' ) . '%'
        ), ARRAY_A );
        foreach ( $rows as $row ) {
            if ( preg_match( $pattern, $row['post_content'] ) ) {
                $new_content = preg_replace( $pattern, $replacement, $row['post_content'] );
                if ( $new_content !== $row['post_content'] ) {
                    wp_update_post( [
                        'ID'           => (int) $row['ID'],
                        'post_content' => $new_content,
                    ] );
                    $report['posts']++;
                    $report['locations'][] = [
                        'type'  => $row['post_type'],
                        'id'    => (int) $row['ID'],
                        'title' => $row['post_title'],
                    ];
                }
            }
        }

        // ---- Sidebar text widgets + block widgets ----
        $sidebars  = get_option( 'sidebars_widgets', [] );
        $text_opts = get_option( 'widget_text', [] );
        if ( is_array( $text_opts ) ) {
            foreach ( $text_opts as $idx => $w ) {
                if ( ! is_array( $w ) || empty( $w['text'] ) ) continue;
                if ( preg_match( $pattern, $w['text'] ) ) {
                    $text_opts[ $idx ]['text'] = preg_replace( $pattern, $replacement, $w['text'] );
                    $report['widgets']++;
                }
            }
            update_option( 'widget_text', $text_opts );
        }
        $block_opts = get_option( 'widget_block', [] );
        if ( is_array( $block_opts ) ) {
            foreach ( $block_opts as $idx => $w ) {
                if ( ! is_array( $w ) || empty( $w['content'] ) ) continue;
                if ( preg_match( $pattern, $w['content'] ) ) {
                    $block_opts[ $idx ]['content'] = preg_replace( $pattern, $replacement, $w['content'] );
                    $report['widgets']++;
                }
            }
            update_option( 'widget_block', $block_opts );
        }

        return $report;
    }

    /* =====================================================================
     * Source adapter: Forminator (WPMU DEV)
     *
     * Forminator stores forms as the 'forminator_forms' CPT, with the
     * full form definition in `forminator_form_meta` post-meta as a
     * serialized array shaped roughly as:
     *   [
     *     'fields'       => [ wrapper_groups => [ field_defs ] ],
     *     'settings'     => [ form-level options + email templates ],
     *     'notifications'=> [ admin/user emails ],
     *   ]
     * ================================================================== */

    private static function import_forminator_form( $external_id ) {
        $post = get_post( (int) $external_id );
        if ( ! $post || $post->post_type !== 'forminator_forms' ) {
            return new WP_Error( 'fm_missing', "Forminator form #$external_id not found." );
        }
        $meta = get_post_meta( $external_id, 'forminator_form_meta', true );
        $def  = is_string( $meta ) ? maybe_unserialize( $meta ) : $meta;
        if ( ! is_array( $def ) ) return new WP_Error( 'fm_parse', 'Could not parse Forminator form meta.' );

        $warnings = [];
        // Forminator field element key -> FormCraft field type
        $map = [
            'text'              => 'text',
            'name'              => 'name',
            'email'             => 'email',
            'phone'             => 'tel',
            'number'            => 'number',
            'currency'          => 'number',
            'url'               => 'url',
            'textarea'          => 'textarea',
            'select'            => 'select',
            'radio'             => 'radio',
            'checkbox'          => 'checkbox',
            'date'              => 'date',
            'time'              => 'time',
            'consent'           => 'gdpr',
            'gdprcheckbox'      => 'gdpr',
            'rating'            => 'rating',
            'upload'            => 'file',
            'postdata'          => 'text',
            'address'           => 'text',
            'website'           => 'url',
            'hidden'            => 'hidden',
            'html'              => 'html',
            'section'           => 'section',
            'page-break'        => '__step__',
            'captcha'           => 'captcha',
            'recaptcha'         => 'captcha',
            'signature'         => 'text',
            'stripe'            => '__skip__',
            'paypal'            => '__skip__',
        ];

        $steps_acc = [];
        $current   = [];
        $id_map    = [];
        $raw_log   = [];
        $field_wrappers = is_array( $def['fields'] ?? null ) ? $def['fields'] : [];

        foreach ( $field_wrappers as $wrapper ) {
            // Each wrapper is a row in the form; it may carry multiple
            // side-by-side fields. We flatten them into the linear list.
            $fields = isset( $wrapper['fields'] ) && is_array( $wrapper['fields'] )
                ? $wrapper['fields'] : [ $wrapper ];
            foreach ( $fields as $fld ) {
                $element = (string) ( $fld['type'] ?? $fld['element_id'] ?? 'text' );
                // Forminator element_ids look like "text-1", "email-2" — strip the suffix
                $element_key = preg_replace( '/-\d+$/', '', $element );
                $target = $map[ $element_key ] ?? null;
                if ( $target === null ) {
                    $warnings[] = "Forminator element '$element' — mapped to text.";
                    $target = 'text';
                } elseif ( $target === '__skip__' ) {
                    $warnings[] = "Skipped unsupported Forminator element '$element'.";
                    continue;
                } elseif ( $target === '__step__' ) {
                    if ( $current ) $steps_acc[] = $current;
                    $current = [];
                    continue;
                }

                $label = (string) ( $fld['field_label'] ?? $fld['label'] ?? self::humanize_label( $element_key ) );
                $field = self::new_field( $target, $label );
                $field['required']    = ! empty( $fld['required'] );
                $field['placeholder'] = (string) ( $fld['placeholder'] ?? '' );
                $field['help']        = (string) ( $fld['description'] ?? '' );
                $field['defaultValue']= (string) ( $fld['default_value'] ?? '' );
                $field['errorMessage']= (string) ( $fld['required_message'] ?? '' );

                if ( in_array( $target, [ 'select', 'radio', 'checkbox' ], true ) ) {
                    $opts = [];
                    if ( ! empty( $fld['options'] ) && is_array( $fld['options'] ) ) {
                        foreach ( $fld['options'] as $o ) {
                            if ( isset( $o['label'] ) )       $opts[] = (string) $o['label'];
                            elseif ( isset( $o['value'] ) )   $opts[] = (string) $o['value'];
                            elseif ( is_string( $o ) )        $opts[] = $o;
                        }
                    }
                    if ( $opts ) $field['options'] = $opts;
                }
                if ( $target === 'rating' ) {
                    $field['max'] = isset( $fld['max_rating'] ) ? (int) $fld['max_rating'] : 5;
                }

                $src_id = (string) ( $fld['element_id'] ?? $element );
                if ( $src_id ) $id_map[ $src_id ] = $field['id'];
                if ( ! empty( $fld['conditions'] ) ) $raw_log[ $src_id ] = $fld['conditions'];
                $current[] = $field;
            }
        }
        if ( $current ) $steps_acc[] = $current;

        $form = self::blank_form( $post->post_title ?: 'Imported Forminator Form' );
        if ( count( $steps_acc ) > 1 ) {
            $form['steps'] = [];
            foreach ( $steps_acc as $i => $sf ) $form['steps'][] = self::new_step( 'Step ' . ($i + 1), $sf );
        } elseif ( count( $steps_acc ) === 1 ) {
            $form['steps'][0]['fields'] = $steps_acc[0];
        }

        // Settings → notifications + confirmation
        $settings = is_array( $def['settings'] ?? null ) ? $def['settings'] : [];
        if ( ! empty( $settings['notifications'][0]['email-recipients'] ) ) {
            $form['settings']['notifications']['admin']['to'] =
                self::strip_wpf_tags( (string) $settings['notifications'][0]['email-recipients'] );
        }
        if ( ! empty( $settings['notifications'][0]['email-subject'] ) ) {
            $form['settings']['notifications']['admin']['subject'] =
                self::strip_wpf_tags( (string) $settings['notifications'][0]['email-subject'] );
        }
        if ( ! empty( $settings['thankyou-message'] ) ) {
            $form['settings']['successMessage'] = wp_strip_all_tags( (string) $settings['thankyou-message'] );
        } elseif ( ! empty( $settings['redirect-url'] ) ) {
            $form['settings']['afterSubmit']['action']      = 'redirect';
            $form['settings']['afterSubmit']['redirectUrl'] = (string) $settings['redirect-url'];
        }
        if ( ! empty( $settings['submission-indicator-label'] ) ) {
            $form['settings']['submitLabel'] = (string) $settings['submission-indicator-label'];
        }

        return [ 'form' => $form, 'warnings' => $warnings ];
    }

    private static function import_forminator_subs( $external_id, $new_form_id, $form ) {
        global $wpdb;
        $te  = $wpdb->prefix . 'frmt_form_entry';
        $tm  = $wpdb->prefix . 'frmt_form_entry_meta';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$te'" ) ) return 0;
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT entry_id, date_created FROM $te WHERE form_id = %d AND is_spam = 0",
            (int) $external_id
        ), ARRAY_A );
        $count = 0;
        foreach ( $rows as $r ) {
            $metas = $wpdb->get_results( $wpdb->prepare(
                "SELECT meta_key, meta_value FROM $tm WHERE entry_id = %d",
                (int) $r['entry_id']
            ), ARRAY_A );
            $data = [];
            foreach ( $metas as $m ) {
                // Forminator meta_key looks like "text-1" — use the form definition's labels
                // when we have them, otherwise fall back to the slug.
                $val = maybe_unserialize( $m['meta_value'] );
                if ( is_array( $val ) ) $val = wp_json_encode( $val );
                $data[ ucfirst( str_replace( '-', ' ', $m['meta_key'] ) ) ] = (string) $val;
            }
            self::insert_sub_with_date( (int) $new_form_id, $data, [
                'ip' => '', 'country' => '', 'device' => '', 'browser' => '',
                'migrated_from' => 'forminator:' . $external_id,
            ], $r['date_created'] );
            $count++;
        }
        return $count;
    }

    /* =====================================================================
     * Source adapter: Caldera Forms (discontinued, legacy refugees welcome)
     *
     * Caldera stores forms in the `_caldera_forms` wp_options row (a flat
     * registry keyed by form id) plus optional per-form options keyed by
     * the form id directly (e.g. option_name="CF59abc..."). The full form
     * definition lives in the per-form option.
     * ================================================================== */

    private static function import_caldera_form( $external_id ) {
        $forms_index = get_option( '_caldera_forms', [] );
        if ( ! is_array( $forms_index ) || ! isset( $forms_index[ $external_id ] ) ) {
            return new WP_Error( 'cf_missing', "Caldera form #$external_id not found." );
        }
        $stub  = $forms_index[ $external_id ];
        $full  = get_option( $external_id, $stub );
        if ( ! is_array( $full ) ) return new WP_Error( 'cf_parse', 'Could not parse Caldera form.' );

        $warnings = [];
        // Caldera field type slug -> FormCraft field type
        $map = [
            'text'             => 'text',
            'email'            => 'email',
            'phone'            => 'tel',
            'phone_better'     => 'tel',
            'paragraph'        => 'textarea',
            'dropdown'         => 'select',
            'radio'            => 'radio',
            'checkbox'         => 'checkbox',
            'toggle_switch'    => 'toggle',
            'date_picker'      => 'date',
            'date'             => 'date',
            'file'             => 'file',
            'advanced_file'    => 'file',
            'star_rating'      => 'rating',
            'hidden'           => 'hidden',
            'html'             => 'html',
            'section_break'    => 'section',
            'page_break'       => '__step__',
            'number'           => 'number',
            'range_slider'     => 'range',
            'color_picker'     => 'text',
            'calculation'      => 'calculation',
            'summary'          => 'html',
            'gdpr'             => 'gdpr',
            'recaptcha'        => 'captcha',
            'states_dropdown'  => 'select',
            'us_states'        => 'select',
            'credit_card_number' => '__skip__',
            'credit_card_cvc'    => '__skip__',
            'credit_card_exp'    => '__skip__',
        ];

        $fields_def = isset( $full['fields'] ) && is_array( $full['fields'] ) ? $full['fields'] : [];
        $layout     = isset( $full['layout_grid']['structure'] ) ? (string) $full['layout_grid']['structure'] : '';
        // Caldera lays fields out as "12|6,6|4,4,4|fld1.id:fld2.id" — we
        // don't preserve the column layout; FormCraft auto-stacks fields
        // for now. Order is taken from the order in which `$fields_def`
        // iterates (Caldera keys = `fld_XXXX` ids).
        $steps_acc = [];
        $current   = [];
        $id_map    = [];
        $raw_log   = [];

        foreach ( $fields_def as $fld_id => $fld ) {
            $type   = strtolower( (string) ( $fld['type'] ?? 'text' ) );
            $target = $map[ $type ] ?? null;
            if ( $target === null ) {
                $warnings[] = "Caldera field type '$type' — mapped to text.";
                $target = 'text';
            } elseif ( $target === '__skip__' ) {
                $warnings[] = "Skipped Caldera credit-card field '$type'. Use FormCraft's Payment Method field with Stripe instead.";
                continue;
            } elseif ( $target === '__step__' ) {
                if ( $current ) $steps_acc[] = $current;
                $current = [];
                continue;
            }

            $label = (string) ( $fld['label'] ?? self::humanize_label( $type ) );
            $field = self::new_field( $target, $label );
            $field['required']     = ! empty( $fld['required'] );
            $field['placeholder']  = (string) ( $fld['config']['placeholder'] ?? '' );
            $field['help']         = (string) ( $fld['caption'] ?? '' );
            $field['defaultValue'] = (string) ( $fld['config']['default'] ?? '' );

            if ( in_array( $target, [ 'select', 'radio', 'checkbox' ], true ) ) {
                $opts = [];
                if ( ! empty( $fld['config']['option'] ) && is_array( $fld['config']['option'] ) ) {
                    foreach ( $fld['config']['option'] as $o ) {
                        if ( isset( $o['label'] ) ) $opts[] = (string) $o['label'];
                        elseif ( isset( $o['value'] ) ) $opts[] = (string) $o['value'];
                    }
                }
                if ( $opts ) $field['options'] = $opts;
            }
            if ( $target === 'rating' ) {
                $field['max'] = isset( $fld['config']['number'] ) ? (int) $fld['config']['number'] : 5;
            }
            if ( $target === 'calculation' && ! empty( $fld['config']['formula'] ) ) {
                // Caldera uses %fieldId% — convert to {Label} placeholders.
                $formula = (string) $fld['config']['formula'];
                $formula = preg_replace_callback( '/%([^%]+)%/', function ( $m ) use ( $fields_def ) {
                    $ref = $m[1];
                    foreach ( $fields_def as $fid => $f ) {
                        if ( $fid === $ref || ( $f['slug'] ?? '' ) === $ref ) {
                            return '{' . ( $f['label'] ?? $fid ) . '}';
                        }
                    }
                    return $m[0];
                }, $formula );
                $field['formula'] = $formula;
            }

            $id_map[ $fld_id ] = $field['id'];
            if ( ! empty( $fld['conditions']['type'] ) && ! empty( $fld['conditions']['group'] ) ) {
                $raw_log[ $fld_id ] = $fld['conditions'];
            }
            $current[] = $field;
        }
        if ( $current ) $steps_acc[] = $current;

        $form = self::blank_form( $full['name'] ?? $stub['name'] ?? 'Imported Caldera Form' );
        if ( count( $steps_acc ) > 1 ) {
            $form['steps'] = [];
            foreach ( $steps_acc as $i => $sf ) $form['steps'][] = self::new_step( 'Step ' . ($i + 1), $sf );
        } elseif ( count( $steps_acc ) === 1 ) {
            $form['steps'][0]['fields'] = $steps_acc[0];
        }

        // Mailer settings → admin notification
        if ( ! empty( $full['mailer']['enable_mailer'] ) ) {
            if ( ! empty( $full['mailer']['recipients'] ) ) {
                $form['settings']['notifications']['admin']['to'] =
                    self::strip_wpf_tags( (string) $full['mailer']['recipients'] );
            }
            if ( ! empty( $full['mailer']['email_subject'] ) ) {
                $form['settings']['notifications']['admin']['subject'] =
                    self::strip_wpf_tags( (string) $full['mailer']['email_subject'] );
            }
            if ( ! empty( $full['mailer']['email_message'] ) ) {
                $form['settings']['notifications']['admin']['body'] =
                    self::strip_wpf_tags( (string) $full['mailer']['email_message'] );
            }
        }
        if ( ! empty( $full['success'] ) ) {
            $form['settings']['successMessage'] = wp_strip_all_tags( (string) $full['success'] );
        }

        return [ 'form' => $form, 'warnings' => $warnings ];
    }

    private static function import_caldera_subs( $external_id, $new_form_id, $form ) {
        global $wpdb;
        $te = $wpdb->prefix . 'cf_form_entries';
        $tv = $wpdb->prefix . 'cf_form_entry_values';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '$te'" ) ) return 0;
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, datestamp FROM $te WHERE form_id = %s AND status = 'active'",
            $external_id
        ), ARRAY_A );
        $count = 0;
        foreach ( $rows as $r ) {
            $vals = $wpdb->get_results( $wpdb->prepare(
                "SELECT slug, value FROM $tv WHERE entry_id = %d",
                (int) $r['id']
            ), ARRAY_A );
            $data = [];
            foreach ( $vals as $v ) {
                $data[ ucfirst( str_replace( '_', ' ', $v['slug'] ) ) ] = (string) $v['value'];
            }
            self::insert_sub_with_date( (int) $new_form_id, $data, [
                'ip' => '', 'country' => '', 'device' => '', 'browser' => '',
                'migrated_from' => 'caldera:' . $external_id,
            ], $r['datestamp'] );
            $count++;
        }
        return $count;
    }
}
