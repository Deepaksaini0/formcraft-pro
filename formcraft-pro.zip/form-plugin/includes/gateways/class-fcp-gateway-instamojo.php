<?php
/**
 * Instamojo payment gateway adapter (Payment Request API).
 *
 * Flow:
 *   1) create_order() - POST /api/1.1/payment-requests/ → returns longurl
 *   2) Front-end redirects to longurl (Instamojo hosted page)
 *   3) On success, Instamojo redirects back to redirect_url with ?payment_request_id=…&payment_id=…
 *   4) verify_payment() - GETs the payment request → confirms status === 'Credit'
 *
 * Required $cfg fields:
 *   api_key
 *   auth_token
 *   salt        (optional, used by some older webhook flavors)
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FCP_Gateway_Instamojo extends FCP_Gateway_Base {

    public function slug() { return 'instamojo'; }

    private function base_url() {
        return $this->test_mode
            ? 'https://test.instamojo.com/api/1.1'
            : 'https://www.instamojo.com/api/1.1';
    }
    private function auth_headers() {
        return [
            'X-Api-Key'    => $this->cfg['api_key'],
            'X-Auth-Token' => $this->cfg['auth_token'],
        ];
    }

    public function create_order( $args ) {
        if ( empty( $this->cfg['api_key'] ) || empty( $this->cfg['auth_token'] ) ) {
            return new WP_Error( 'config', 'Instamojo credentials are not set in Payment Gateway settings.' );
        }
        $amount = (float) ( $args['amount'] ?? 0 );
        if ( $amount <= 0 ) return new WP_Error( 'bad_amount', 'Payment amount must be greater than zero.' );

        $prefill = isset( $args['prefill'] ) ? (array) $args['prefill'] : [];
        $body = [
            'purpose'        => isset( $args['name'] ) ? substr( $args['name'], 0, 30 ) : 'Form payment',
            'amount'         => (string) $amount,
            'phone'          => isset( $prefill['contact'] ) ? $prefill['contact'] : '',
            'buyer_name'     => isset( $prefill['name'] )    ? $prefill['name']    : '',
            'redirect_url'   => isset( $args['return_url'] ) ? $args['return_url'] : home_url( '/' ),
            'send_email'     => 'false',
            'allow_repeated_payments' => 'false',
        ];
        if ( ! empty( $prefill['email'] ) && is_email( $prefill['email'] ) ) {
            $body['email']      = $prefill['email'];
        }

        $res = $this->http( $this->base_url() . '/payment-requests/', [
            'method'  => 'POST',
            'headers' => $this->auth_headers(),
            'body'    => $body,
        ] );
        if ( is_wp_error( $res ) ) return $res;

        $pr = isset( $res['payment_request'] ) ? $res['payment_request'] : [];
        if ( empty( $pr['id'] ) || empty( $pr['longurl'] ) ) {
            return new WP_Error( 'bad_response', 'Instamojo did not return a payment request URL.' );
        }
        return [
            'provider' => 'instamojo',
            'order_id' => $pr['id'],
            'amount'   => $amount,
            'currency' => 'INR',
            'checkout' => [ 'redirect_url' => $pr['longurl'] ],
        ];
    }

    public function verify_payment( $args ) {
        $pr_id      = isset( $args['payment_request_id'] ) ? $args['payment_request_id'] : ( $args['order_id'] ?? '' );
        $payment_id = isset( $args['payment_id'] )         ? $args['payment_id']         : '';
        if ( ! $pr_id ) return new WP_Error( 'bad_request', 'Missing Instamojo payment_request_id.' );

        $res = $this->http( $this->base_url() . '/payment-requests/' . urlencode( $pr_id ) . '/', [
            'method'  => 'GET',
            'headers' => $this->auth_headers(),
        ] );
        if ( is_wp_error( $res ) ) return $res;

        $pr   = $res['payment_request'] ?? [];
        $paid = false; $captured = [];
        foreach ( $pr['payments'] ?? [] as $p ) {
            if ( ( $p['status'] ?? '' ) === 'Credit' ) {
                $paid     = true;
                $captured = $p;
                if ( $payment_id && ( $p['payment_id'] ?? '' ) === $payment_id ) break;
            }
        }
        if ( ! $paid ) return new WP_Error( 'payment_not_complete', 'No successful payment found on this Instamojo request.' );

        return [
            'verified'   => true,
            'payment_id' => $captured['payment_id'] ?? $payment_id,
            'order_id'   => $pr_id,
            'amount'     => (float) ( $captured['amount'] ?? $pr['amount'] ?? 0 ),
            'currency'   => 'INR',
            'method'     => $captured['instrument_type'] ?? 'instamojo',
            'email'      => $pr['email'] ?? '',
            'contact'    => $pr['phone'] ?? '',
        ];
    }
}
