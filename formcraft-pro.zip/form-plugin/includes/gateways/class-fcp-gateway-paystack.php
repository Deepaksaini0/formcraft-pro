<?php
/**
 * Paystack payment gateway adapter (Africa — Nigeria, Ghana, South
 * Africa, Kenya, Egypt). Supports cards, bank transfer, USSD, mobile
 * money, Apple Pay, QR code, and EFT.
 *
 * Flow:
 *   1) create_order() → POST /transaction/initialize → returns hosted
 *      checkout URL + reference
 *   2) Front-end redirects browser to that URL
 *   3) On success, Paystack redirects back to callback_url with
 *      ?reference=…&trxref=…
 *   4) verify_payment() → GET /transaction/verify/{reference} →
 *      checks status === 'success'
 *   5) handle_webhook() verifies HMAC-SHA512 signature, then re-fetches
 *      via API for authoritative status
 *
 * Required $cfg fields:
 *   secret_key  - sk_test_… / sk_live_…
 *   public_key  - pk_test_… / pk_live_… (front-end only, optional here)
 *
 * Currencies: NGN (kobo), GHS (pesewas), ZAR (cents), USD (cents),
 * KES (cents), EGP (piastres). Amount is always in the smallest unit
 * (multiply major-unit by 100).
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FCP_Gateway_Paystack extends FCP_Gateway_Base {

    public function slug() { return 'paystack'; }

    private function api( $path, $method = 'GET', $body = null ) {
        $args = [
            'method'  => $method,
            'headers' => [
                'Authorization' => 'Bearer ' . trim( (string) ( $this->cfg['secret_key'] ?? '' ) ),
                'Content-Type'  => 'application/json',
                'Cache-Control' => 'no-cache',
            ],
            'timeout' => 20,
        ];
        if ( $body !== null ) $args['body'] = wp_json_encode( $body );
        return $this->http( 'https://api.paystack.co' . $path, $args );
    }

    public function create_order( $args ) {
        if ( empty( $this->cfg['secret_key'] ) ) {
            return new WP_Error( 'config', 'Paystack secret key is not set in Payment Gateway settings.' );
        }
        $amount   = (float) ( $args['amount'] ?? 0 );
        $currency = isset( $args['currency'] ) ? strtoupper( $args['currency'] ) : 'NGN';
        if ( $amount <= 0 ) return new WP_Error( 'bad_amount', 'Payment amount must be greater than zero.' );

        // Paystack only accepts these 6 currencies. Refuse others early
        // with a clear message rather than letting Paystack reject.
        $allowed = [ 'NGN', 'GHS', 'ZAR', 'USD', 'KES', 'EGP' ];
        if ( ! in_array( $currency, $allowed, true ) ) {
            return new WP_Error( 'bad_currency', 'Paystack only supports: ' . implode( ', ', $allowed ) );
        }

        $email = isset( $args['prefill']['email'] ) ? (string) $args['prefill']['email'] : '';
        if ( ! is_email( $email ) ) {
            // Paystack REQUIRES email — fall back to a per-site sentinel so
            // the API doesn't reject. The actual customer will enter their
            // email on the hosted checkout.
            $email = 'unknown+' . wp_generate_password( 8, false, false ) . '@' . wp_parse_url( home_url(), PHP_URL_HOST );
        }

        $ref = $this->gen_ref();
        $return_url = isset( $args['return_url'] ) ? $args['return_url'] : home_url( '/' );

        $body = [
            'email'        => $email,
            'amount'       => (int) round( $amount * 100 ), // smallest unit
            'currency'     => $currency,
            'reference'    => $ref,
            'callback_url' => add_query_arg( [ 'fcp_payment_ref' => $ref, 'fcp_gateway' => 'paystack' ], $return_url ),
            'metadata'     => [
                'custom_fields' => [],
                'notes'         => isset( $args['notes'] ) ? (array) $args['notes'] : [],
                'site'          => home_url(),
            ],
        ];

        $res = $this->api( '/transaction/initialize', 'POST', $body );
        if ( is_wp_error( $res ) ) return $res;

        if ( empty( $res['status'] ) || empty( $res['data']['authorization_url'] ) ) {
            return new WP_Error( 'no_checkout', 'Paystack did not return a checkout URL.' );
        }

        return [
            'provider'  => 'paystack',
            'order_id'  => $ref,
            'amount'    => $amount,
            'currency'  => $currency,
            'checkout'  => [
                'redirect_url' => $res['data']['authorization_url'],
                'reference'    => $ref,
                'access_code'  => $res['data']['access_code'] ?? '',
            ],
        ];
    }

    public function verify_payment( $args ) {
        $reference = isset( $args['reference'] ) ? (string) $args['reference'] : '';
        if ( ! $reference ) {
            return new WP_Error( 'bad_request', 'Missing Paystack reference.' );
        }
        $res = $this->api( '/transaction/verify/' . rawurlencode( $reference ) );
        if ( is_wp_error( $res ) ) return $res;

        $data   = $res['data'] ?? [];
        $status = $data['status'] ?? '';
        if ( $status !== 'success' ) {
            return new WP_Error( 'payment_failed', 'Payment status: ' . $status, [ 'response' => $data ] );
        }

        return [
            'verified'   => true,
            'payment_id' => isset( $data['id'] ) ? (string) $data['id'] : $reference,
            'order_id'   => $reference,
            'amount'     => isset( $data['amount'] ) ? ( (int) $data['amount'] / 100 ) : 0,
            'currency'   => $data['currency'] ?? '',
            'method'     => $data['channel']  ?? '',
            'email'      => $data['customer']['email'] ?? '',
        ];
    }

    public function handle_webhook( $body, $headers ) {
        $secret = $this->cfg['secret_key'] ?? '';
        if ( ! $secret ) return new WP_Error( 'config', 'Paystack secret key not configured.' );

        $sig = '';
        foreach ( $headers as $k => $v ) {
            if ( strtolower( $k ) === 'x-paystack-signature' ) { $sig = is_array( $v ) ? $v[0] : $v; break; }
        }
        // Paystack uses HMAC-SHA512 over the raw body, with the SECRET KEY
        // as the signing key.
        $expected = hash_hmac( 'sha512', $body, $secret );
        if ( ! hash_equals( $expected, $sig ) ) {
            return new WP_Error( 'signature_mismatch', 'Invalid Paystack webhook signature.' );
        }
        $payload = json_decode( $body, true );
        return [
            'event'   => $payload['event'] ?? '',
            'payload' => $payload,
        ];
    }

    public function refund( $payment_id, $amount = null ) {
        $body = [ 'transaction' => $payment_id ];
        if ( $amount !== null ) $body['amount'] = (int) round( ( (float) $amount ) * 100 );
        $res = $this->api( '/refund', 'POST', $body );
        if ( is_wp_error( $res ) ) return $res;
        $data = $res['data'] ?? [];
        return [
            'refund_id' => isset( $data['id'] ) ? (string) $data['id'] : '',
            'amount'    => isset( $data['amount'] ) ? ( (int) $data['amount'] / 100 ) : 0,
            'status'    => $data['status'] ?? '',
        ];
    }
}
