<?php
/**
 * FormCraft Pro — Square (Checkout API) gateway.
 *
 * Uses Square's Payment Links API — generates a hosted checkout URL the
 * visitor is redirected to. No card data touches our servers. Square
 * redirects back to return_url with ?order_id, which we then verify via
 * the Orders API.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FCP_Gateway_Square extends FCP_Gateway_Base {

    public function slug() { return 'square'; }

    private function api_base() {
        return $this->test_mode
            ? 'https://connect.squareupsandbox.com'
            : 'https://connect.squareup.com';
    }

    public function create_order( $args ) {
        $token = $this->cfg['access_token'] ?? '';
        $loc   = $this->cfg['location_id']  ?? '';
        if ( ! $token || ! $loc ) {
            return new WP_Error( 'unconfigured', 'Square needs Access Token + Location ID. Get them at squareup.com → Developer Dashboard.' );
        }
        $currency = strtoupper( $args['currency'] ?? 'USD' );
        // Square wants amounts in the lowest denomination (cents for USD).
        $amount   = (int) round( ( (float) $args['amount'] ) * 100 );
        if ( $amount < 1 ) return new WP_Error( 'bad_amount', 'Amount must be > 0' );

        $idempotency = wp_generate_password( 32, false );
        $payload = [
            'idempotency_key' => $idempotency,
            'quick_pay' => [
                'name'        => substr( (string) ( $args['name'] ?? 'FormCraft submission' ), 0, 250 ),
                'price_money' => [ 'amount' => $amount, 'currency' => $currency ],
                'location_id' => $loc,
            ],
            'checkout_options' => [
                'redirect_url'           => isset( $args['return_url'] ) ? esc_url_raw( $args['return_url'] ) : home_url( '/' ),
                'ask_for_shipping_address' => false,
            ],
            'description' => substr( (string) ( $args['description'] ?? '' ), 0, 250 ),
        ];

        $res = $this->http( $this->api_base() . '/v2/online-checkout/payment-links', [
            'method'  => 'POST',
            'headers' => [
                'Authorization'  => 'Bearer ' . $token,
                'Content-Type'   => 'application/json',
                'Square-Version' => '2024-01-18',
            ],
            'body' => wp_json_encode( $payload ),
        ] );
        if ( is_wp_error( $res ) ) return $res;
        $link = $res['payment_link'] ?? null;
        if ( ! $link || empty( $link['url'] ) ) {
            $err = isset( $res['errors'][0]['detail'] ) ? $res['errors'][0]['detail'] : 'Square rejected the request.';
            return new WP_Error( 'square_failed', $err );
        }
        return [
            'gateway'     => 'square',
            'order_id'    => $link['order_id']    ?? '',
            'payment_url' => $link['url'],
            'amount'      => $amount / 100,
            'currency'    => $currency,
        ];
    }

    public function verify_payment( $args ) {
        $token = $this->cfg['access_token'] ?? '';
        $order = isset( $args['order_id'] ) ? sanitize_text_field( $args['order_id'] ) : '';
        if ( ! $order ) return new WP_Error( 'missing_order', 'Square order id is required to verify.' );

        $res = $this->http( $this->api_base() . '/v2/orders/' . rawurlencode( $order ), [
            'method'  => 'GET',
            'headers' => [
                'Authorization'  => 'Bearer ' . $token,
                'Square-Version' => '2024-01-18',
            ],
        ] );
        if ( is_wp_error( $res ) ) return $res;
        $o = $res['order'] ?? null;
        if ( ! $o ) return new WP_Error( 'not_found', 'Order not found on Square.' );
        // state COMPLETED + total_money.amount == net = success
        if ( ( $o['state'] ?? '' ) !== 'COMPLETED' ) {
            return new WP_Error( 'not_paid', 'Square order is not yet completed (state: ' . ( $o['state'] ?? '?' ) . ')' );
        }
        return [
            'payment_id' => $o['tenders'][0]['id'] ?? $order,
            'order_id'   => $order,
            'amount'     => isset( $o['total_money']['amount'] ) ? ( (int) $o['total_money']['amount'] / 100 ) : null,
            'currency'   => $o['total_money']['currency'] ?? 'USD',
        ];
    }
}
