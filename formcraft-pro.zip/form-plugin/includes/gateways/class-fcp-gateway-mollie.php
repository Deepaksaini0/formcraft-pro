<?php
/**
 * Mollie payment gateway adapter (EU — iDEAL, Bancontact, SOFORT, cards,
 * Klarna BNPL, PayPal, Apple Pay, and 20+ other European payment methods).
 *
 * Flow:
 *   1) create_order() → POST /v2/payments → returns hosted checkout URL
 *   2) Front-end redirects to that URL
 *   3) On success, Mollie redirects back to redirectUrl with the payment id
 *      embedded (we append fcp_payment_id={id} via the return URL)
 *   4) verify_payment() → GET /v2/payments/{id} → checks status === 'paid'
 *   5) handle_webhook() processes async status changes
 *
 * Required $cfg fields:
 *   api_key  - test_xxx or live_xxx
 *
 * Mollie does NOT need a webhook secret — webhooks are POSTs containing
 * just an id; we re-verify status by hitting the API with our key, so
 * even a spoofed webhook can't lie about payment status.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FCP_Gateway_Mollie extends FCP_Gateway_Base {

    public function slug() { return 'mollie'; }

    private function api( $path, $method = 'GET', $body = null ) {
        $args = [
            'method'  => $method,
            'headers' => [
                'Authorization' => 'Bearer ' . trim( (string) ( $this->cfg['api_key'] ?? '' ) ),
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
            ],
            'timeout' => 20,
        ];
        if ( $body !== null ) $args['body'] = wp_json_encode( $body );
        return $this->http( 'https://api.mollie.com/v2' . $path, $args );
    }

    public function create_order( $args ) {
        if ( empty( $this->cfg['api_key'] ) ) {
            return new WP_Error( 'config', 'Mollie API key is not set in Payment Gateway settings.' );
        }
        $amount   = (float) ( $args['amount'] ?? 0 );
        $currency = isset( $args['currency'] ) ? strtoupper( $args['currency'] ) : 'EUR';
        if ( $amount <= 0 ) return new WP_Error( 'bad_amount', 'Payment amount must be greater than zero.' );

        // Mollie wants amount as a STRING with exactly the right number of decimals.
        // Most currencies use 2 (EUR, USD, GBP). JPY uses 0. We use 2 across the
        // board — Mollie will reject unsupported precision per currency.
        $value = number_format( $amount, 2, '.', '' );

        $return_url = isset( $args['return_url'] ) ? $args['return_url'] : home_url( '/' );
        $description = isset( $args['description'] ) ? $args['description'] : ( get_bloginfo( 'name' ) . ' — Form payment' );
        $ref         = $this->gen_ref();

        $body = [
            'amount' => [ 'currency' => $currency, 'value' => $value ],
            'description' => substr( (string) $description, 0, 255 ),
            'redirectUrl' => add_query_arg( [ 'fcp_payment_ref' => $ref, 'fcp_gateway' => 'mollie' ], $return_url ),
            // webhook is optional but recommended for async status notifications
            'webhookUrl'  => rest_url( 'formcraft/v1/payments/webhook/mollie' ),
            'metadata'    => [
                'ref' => $ref,
                'notes' => isset( $args['notes'] ) ? (array) $args['notes'] : [],
            ],
        ];

        if ( ! empty( $args['prefill']['email'] ) && is_email( $args['prefill']['email'] ) ) {
            // Mollie doesn't accept email at the payment level (it does at
            // /customers), but their checkout asks for it. Leave it.
        }

        $res = $this->api( '/payments', 'POST', $body );
        if ( is_wp_error( $res ) ) return $res;

        $checkout_url = $res['_links']['checkout']['href'] ?? '';
        if ( ! $checkout_url ) {
            return new WP_Error( 'no_checkout', 'Mollie did not return a checkout URL.' );
        }

        return [
            'provider'     => 'mollie',
            'order_id'     => $res['id'],
            'amount'       => $amount,
            'currency'     => $currency,
            // The form-engine sees this and does location.href = checkout_url
            'checkout'     => [
                'redirect_url' => $checkout_url,
                'payment_id'   => $res['id'],
            ],
        ];
    }

    public function verify_payment( $args ) {
        $payment_id = isset( $args['payment_id'] ) ? (string) $args['payment_id'] : '';
        if ( ! $payment_id ) {
            return new WP_Error( 'bad_request', 'Missing Mollie payment id.' );
        }
        $payment = $this->api( '/payments/' . rawurlencode( $payment_id ) );
        if ( is_wp_error( $payment ) ) return $payment;

        $status = $payment['status'] ?? '';
        if ( $status !== 'paid' ) {
            return new WP_Error( 'payment_failed', 'Payment status: ' . $status, [ 'response' => $payment ] );
        }

        $amount = isset( $payment['amount']['value'] ) ? (float) $payment['amount']['value'] : 0;
        return [
            'verified'   => true,
            'payment_id' => $payment_id,
            'order_id'   => $payment_id,
            'amount'     => $amount,
            'currency'   => $payment['amount']['currency'] ?? '',
            'method'     => $payment['method'] ?? '',
            'email'      => $payment['details']['consumerName'] ?? '',
        ];
    }

    public function handle_webhook( $body, $headers ) {
        // Mollie webhooks are POST application/x-www-form-urlencoded with
        // just `id=tr_xxx`. We re-fetch the payment via API to learn the
        // real status — the webhook itself is never authoritative.
        parse_str( $body, $form );
        $id = isset( $form['id'] ) ? (string) $form['id'] : '';
        if ( ! $id ) return new WP_Error( 'bad_webhook', 'Mollie webhook missing payment id.' );

        $payment = $this->api( '/payments/' . rawurlencode( $id ) );
        if ( is_wp_error( $payment ) ) return $payment;

        return [
            'event'   => 'payment.' . ( $payment['status'] ?? 'unknown' ),
            'payload' => $payment,
        ];
    }

    public function refund( $payment_id, $amount = null ) {
        // Fetch payment to get currency
        $payment = $this->api( '/payments/' . rawurlencode( $payment_id ) );
        if ( is_wp_error( $payment ) ) return $payment;
        $currency = $payment['amount']['currency'] ?? 'EUR';

        $body = [];
        if ( $amount !== null ) {
            $body['amount'] = [ 'currency' => $currency, 'value' => number_format( (float) $amount, 2, '.', '' ) ];
        }
        $res = $this->api( '/payments/' . rawurlencode( $payment_id ) . '/refunds', 'POST', $body );
        if ( is_wp_error( $res ) ) return $res;
        return [
            'refund_id' => $res['id'] ?? '',
            'amount'    => isset( $res['amount']['value'] ) ? (float) $res['amount']['value'] : 0,
            'status'    => $res['status'] ?? '',
        ];
    }
}
