<?php
/**
 * Razorpay payment gateway adapter.
 *
 * Flow:
 *   1) create_order()  - calls Razorpay /orders API → returns order_id + key for the front-end
 *   2) Front-end opens Razorpay Checkout (checkout.js) using these details
 *   3) On payment success, Razorpay returns { razorpay_payment_id, razorpay_order_id, razorpay_signature }
 *   4) verify_payment() - HMAC-SHA256 verifies the signature server-side
 *   5) Optionally handle_webhook() processes async events
 *
 * Tested fields the gateway expects in $cfg:
 *   key_id          - API key (test prefix: rzp_test_, live prefix: rzp_live_)
 *   key_secret      - API secret
 *   webhook_secret  - shared secret for webhook signature verification
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FCP_Gateway_Razorpay extends FCP_Gateway_Base {

    public function slug() { return 'razorpay'; }

    private function api_url( $path ) {
        return 'https://api.razorpay.com/v1' . $path;
    }
    private function auth_header() {
        return 'Basic ' . base64_encode( $this->cfg['key_id'] . ':' . $this->cfg['key_secret'] );
    }

    public function create_order( $args ) {
        if ( empty( $this->cfg['key_id'] ) || empty( $this->cfg['key_secret'] ) ) {
            return new WP_Error( 'config', 'Razorpay keys are not set in Payment Gateway settings.' );
        }
        $amount   = (float) ( $args['amount'] ?? 0 );
        $currency = isset( $args['currency'] ) ? strtoupper( $args['currency'] ) : 'INR';
        if ( $amount <= 0 ) return new WP_Error( 'bad_amount', 'Payment amount must be greater than zero.' );

        // Razorpay expects amount in the smallest unit (paise for INR).
        $payload = [
            'amount'   => (int) round( $amount * 100 ),
            'currency' => $currency,
            'receipt'  => $this->gen_ref(),
            'notes'    => isset( $args['notes'] ) ? (array) $args['notes'] : [],
        ];

        $res = $this->http( $this->api_url( '/orders' ), [
            'method'  => 'POST',
            'headers' => [
                'Authorization' => $this->auth_header(),
                'Content-Type'  => 'application/json',
            ],
            'body'    => wp_json_encode( $payload ),
        ] );
        if ( is_wp_error( $res ) ) return $res;

        return [
            'provider'    => 'razorpay',
            'order_id'    => $res['id'],
            'amount'      => $amount,
            'amount_minor'=> $res['amount'],
            'currency'    => $res['currency'],
            // Front-end checkout config:
            'checkout'    => [
                'key'         => $this->cfg['key_id'],
                'order_id'    => $res['id'],
                'amount'      => $res['amount'],
                'currency'    => $res['currency'],
                'name'        => isset( $args['name'] )        ? $args['name']        : get_bloginfo( 'name' ),
                'description' => isset( $args['description'] ) ? $args['description'] : 'Form payment',
                'prefill'     => isset( $args['prefill'] )     ? $args['prefill']     : [],
            ],
        ];
    }

    public function verify_payment( $args ) {
        $payment_id = isset( $args['razorpay_payment_id'] ) ? $args['razorpay_payment_id'] : '';
        $order_id   = isset( $args['razorpay_order_id'] )   ? $args['razorpay_order_id']   : '';
        $signature  = isset( $args['razorpay_signature'] )  ? $args['razorpay_signature']  : '';
        if ( ! $payment_id || ! $order_id || ! $signature ) {
            return new WP_Error( 'bad_request', 'Missing payment id, order id, or signature.' );
        }

        // Razorpay signature = HMAC-SHA256( order_id . "|" . payment_id, key_secret )
        $expected = hash_hmac( 'sha256', $order_id . '|' . $payment_id, $this->cfg['key_secret'] );
        if ( ! hash_equals( $expected, $signature ) ) {
            return new WP_Error( 'signature_mismatch', 'Payment signature verification failed.' );
        }

        // Fetch the payment for audit (amount, status, method, etc.)
        $payment = $this->http( $this->api_url( '/payments/' . urlencode( $payment_id ) ), [
            'headers' => [ 'Authorization' => $this->auth_header() ],
        ] );
        if ( is_wp_error( $payment ) ) return $payment;

        if ( $payment['status'] !== 'captured' && $payment['status'] !== 'authorized' ) {
            return new WP_Error( 'payment_failed', 'Payment status: ' . $payment['status'] );
        }

        return [
            'verified'  => true,
            'payment_id'=> $payment_id,
            'order_id'  => $order_id,
            'amount'    => $payment['amount'] / 100,
            'currency'  => $payment['currency'],
            'method'    => isset( $payment['method'] ) ? $payment['method'] : '',
            'email'     => isset( $payment['email'] )  ? $payment['email']  : '',
            'contact'   => isset( $payment['contact'] )? $payment['contact']: '',
        ];
    }

    public function handle_webhook( $body, $headers ) {
        $secret = isset( $this->cfg['webhook_secret'] ) ? $this->cfg['webhook_secret'] : '';
        if ( ! $secret ) return new WP_Error( 'config', 'Razorpay webhook secret not configured.' );

        $sig = '';
        foreach ( $headers as $k => $v ) {
            if ( strtolower( $k ) === 'x-razorpay-signature' ) { $sig = is_array( $v ) ? $v[0] : $v; break; }
        }
        $expected = hash_hmac( 'sha256', $body, $secret );
        if ( ! hash_equals( $expected, $sig ) ) {
            return new WP_Error( 'signature_mismatch', 'Invalid webhook signature.' );
        }

        $payload = json_decode( $body, true );
        return [
            'event'   => isset( $payload['event'] ) ? $payload['event'] : '',
            'payload' => $payload,
        ];
    }

    public function refund( $payment_id, $amount = null ) {
        $body = [];
        if ( $amount !== null ) $body['amount'] = (int) round( ( (float) $amount ) * 100 );
        $res = $this->http( $this->api_url( '/payments/' . urlencode( $payment_id ) . '/refund' ), [
            'method'  => 'POST',
            'headers' => [
                'Authorization' => $this->auth_header(),
                'Content-Type'  => 'application/json',
            ],
            'body'    => wp_json_encode( $body ),
        ] );
        if ( is_wp_error( $res ) ) return $res;
        return [
            'refund_id' => $res['id'],
            'amount'    => $res['amount'] / 100,
            'status'    => $res['status'],
        ];
    }
}
