<?php
/**
 * Stripe payment gateway adapter (Checkout Sessions — redirect flow).
 *
 * Flow:
 *   1) create_order() - POST to /checkout/sessions → returns hosted checkout URL
 *   2) Front-end redirects browser to that URL
 *   3) On success, Stripe redirects back to your success_url with ?session_id={CHECKOUT_SESSION_ID}
 *   4) verify_payment() - GETs that session and confirms payment_status === 'paid'
 *   5) Webhook handles async payment_intent.succeeded events as a backup
 *
 * Required $cfg fields:
 *   secret_key       - sk_test_… / sk_live_…
 *   publishable_key  - pk_test_… (not used server-side, but exposed to front)
 *   webhook_secret   - whsec_… for webhook signature verification
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FCP_Gateway_Stripe extends FCP_Gateway_Base {

    public function slug() { return 'stripe'; }

    private function api( $path, $method = 'GET', $body = [] ) {
        $url     = 'https://api.stripe.com/v1' . $path;
        $headers = [
            'Authorization' => 'Bearer ' . $this->cfg['secret_key'],
            'Content-Type'  => 'application/x-www-form-urlencoded',
        ];
        $args = [ 'method' => $method, 'headers' => $headers, 'timeout' => 30 ];
        if ( $body ) $args['body'] = http_build_query( $body, '', '&' );
        return $this->http( $url, $args );
    }

    public function create_order( $args ) {
        if ( empty( $this->cfg['secret_key'] ) ) {
            return new WP_Error( 'config', 'Stripe secret key is not set in Payment Gateway settings.' );
        }
        $amount   = (float) ( $args['amount'] ?? 0 );
        $currency = isset( $args['currency'] ) ? strtolower( $args['currency'] ) : 'usd';
        if ( $amount <= 0 ) return new WP_Error( 'bad_amount', 'Payment amount must be greater than zero.' );

        // Stripe wants amount in smallest currency unit (cents).
        $name        = isset( $args['name'] )        ? $args['name']        : ( get_bloginfo( 'name' ) . ' — Form payment' );
        $description = isset( $args['description'] ) ? $args['description'] : '';
        $return_url  = isset( $args['return_url'] )  ? $args['return_url']  : home_url( '/' );

        $body = [
            'mode'                 => 'payment',
            'payment_method_types[0]' => 'card',
            'line_items[0][quantity]' => 1,
            'line_items[0][price_data][currency]'      => $currency,
            'line_items[0][price_data][unit_amount]'   => (int) round( $amount * 100 ),
            'line_items[0][price_data][product_data][name]' => $name,
            'success_url'          => add_query_arg( [ 'session_id' => '{CHECKOUT_SESSION_ID}', 'fcp_payment' => 'success' ], $return_url ),
            'cancel_url'           => add_query_arg( [ 'fcp_payment' => 'cancel' ], $return_url ),
        ];
        if ( $description ) $body['line_items[0][price_data][product_data][description]'] = $description;
        if ( ! empty( $args['prefill']['email'] ) && is_email( $args['prefill']['email'] ) ) {
            $body['customer_email'] = $args['prefill']['email'];
        }

        $res = $this->api( '/checkout/sessions', 'POST', $body );
        if ( is_wp_error( $res ) ) return $res;

        return [
            'provider'  => 'stripe',
            'order_id'  => $res['id'],
            'amount'    => $amount,
            'currency'  => strtoupper( $currency ),
            // Front-end will redirect to this URL.
            'checkout'  => [
                'redirect_url' => $res['url'],
                'session_id'   => $res['id'],
                'publishable_key' => isset( $this->cfg['publishable_key'] ) ? $this->cfg['publishable_key'] : '',
            ],
        ];
    }

    public function verify_payment( $args ) {
        $session_id = isset( $args['session_id'] ) ? $args['session_id']
                    : ( isset( $args['stripe_session_id'] ) ? $args['stripe_session_id'] : '' );
        if ( ! $session_id ) return new WP_Error( 'bad_request', 'Missing Stripe session id.' );

        $session = $this->api( '/checkout/sessions/' . urlencode( $session_id ) );
        if ( is_wp_error( $session ) ) return $session;

        if ( ( $session['payment_status'] ?? '' ) !== 'paid' ) {
            return new WP_Error( 'payment_not_complete', 'Stripe reports payment_status = ' . ( $session['payment_status'] ?? 'unknown' ) );
        }
        return [
            'verified'  => true,
            'payment_id'=> isset( $session['payment_intent'] ) ? $session['payment_intent'] : $session_id,
            'order_id'  => $session_id,
            'amount'    => ( $session['amount_total'] ?? 0 ) / 100,
            'currency'  => strtoupper( $session['currency'] ?? '' ),
            'method'    => 'card',
            'email'     => $session['customer_details']['email']   ?? '',
            'contact'   => $session['customer_details']['phone']   ?? '',
        ];
    }

    public function handle_webhook( $body, $headers ) {
        $secret = isset( $this->cfg['webhook_secret'] ) ? $this->cfg['webhook_secret'] : '';
        if ( ! $secret ) return new WP_Error( 'config', 'Stripe webhook secret not configured.' );

        // Stripe-Signature: t=…,v1=…
        $sig_header = '';
        foreach ( $headers as $k => $v ) {
            if ( strtolower( $k ) === 'stripe-signature' ) { $sig_header = is_array( $v ) ? $v[0] : $v; break; }
        }
        if ( ! $sig_header ) return new WP_Error( 'no_signature', 'No Stripe-Signature header.' );

        $parts = []; foreach ( explode( ',', $sig_header ) as $part ) {
            list( $k, $v ) = array_pad( explode( '=', $part, 2 ), 2, '' );
            $parts[ trim( $k ) ] = trim( $v );
        }
        if ( empty( $parts['t'] ) || empty( $parts['v1'] ) ) {
            return new WP_Error( 'bad_signature', 'Malformed Stripe-Signature header.' );
        }
        $expected = hash_hmac( 'sha256', $parts['t'] . '.' . $body, $secret );
        if ( ! hash_equals( $expected, $parts['v1'] ) ) {
            return new WP_Error( 'signature_mismatch', 'Stripe webhook signature mismatch.' );
        }

        $payload = json_decode( $body, true );
        return [
            'event'   => isset( $payload['type'] ) ? $payload['type'] : '',
            'payload' => $payload,
        ];
    }

    public function refund( $payment_id, $amount = null ) {
        $body = [ 'payment_intent' => $payment_id ];
        if ( $amount !== null ) $body['amount'] = (int) round( ( (float) $amount ) * 100 );
        $res = $this->api( '/refunds', 'POST', $body );
        if ( is_wp_error( $res ) ) return $res;
        return [
            'refund_id' => $res['id'],
            'amount'    => $res['amount'] / 100,
            'status'    => $res['status'],
        ];
    }
}
