<?php
/**
 * Mercado Pago payment gateway adapter (Latin America — Brazil, Argentina,
 * Mexico, Chile, Colombia, Peru, Uruguay, Venezuela).
 *
 * Critically includes Pix (Brazil's instant payment, ~40% of Brazilian
 * e-commerce volume in 2026), plus cards, boleto, cash, wallets, and
 * MercadoCredito (BNPL).
 *
 * Flow:
 *   1) create_order() → POST /checkout/preferences → returns init_point
 *      (hosted Mercado Pago Checkout Pro page)
 *   2) Front-end redirects to init_point
 *   3) On success, MP redirects back to back_urls.success with
 *      ?payment_id={id}&status=approved&external_reference={ref}
 *   4) verify_payment() → GET /v1/payments/{id} → status === 'approved'
 *   5) handle_webhook() processes async notifications
 *
 * Required $cfg fields:
 *   access_token  - TEST-... or APP_USR-...
 *   public_key    - front-end SDK key (optional here)
 *
 * Currencies: BRL, ARS, MXN, CLP, COP, PEN, UYU, VES (whole-unit
 * amounts — no 100x like Stripe/Razorpay). Currency is set by the
 * MP account country, NOT the request — your access_token region
 * determines the accepted currency.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FCP_Gateway_MercadoPago extends FCP_Gateway_Base {

    public function slug() { return 'mercadopago'; }

    private function api( $path, $method = 'GET', $body = null ) {
        $args = [
            'method'  => $method,
            'headers' => [
                'Authorization' => 'Bearer ' . trim( (string) ( $this->cfg['access_token'] ?? '' ) ),
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
            ],
            'timeout' => 20,
        ];
        if ( $body !== null ) $args['body'] = wp_json_encode( $body );
        return $this->http( 'https://api.mercadopago.com' . $path, $args );
    }

    public function create_order( $args ) {
        if ( empty( $this->cfg['access_token'] ) ) {
            return new WP_Error( 'config', 'Mercado Pago access token is not set in Payment Gateway settings.' );
        }
        $amount   = (float) ( $args['amount'] ?? 0 );
        $currency = isset( $args['currency'] ) ? strtoupper( $args['currency'] ) : 'BRL';
        if ( $amount <= 0 ) return new WP_Error( 'bad_amount', 'Payment amount must be greater than zero.' );

        // Mercado Pago supports these LatAm currencies.
        $allowed = [ 'BRL', 'ARS', 'MXN', 'CLP', 'COP', 'PEN', 'UYU', 'VES' ];
        if ( ! in_array( $currency, $allowed, true ) ) {
            return new WP_Error( 'bad_currency', 'Mercado Pago supports: ' . implode( ', ', $allowed ) );
        }

        $ref         = $this->gen_ref();
        $return_url  = isset( $args['return_url'] )  ? $args['return_url']  : home_url( '/' );
        $title       = isset( $args['name'] )        ? $args['name']        : ( get_bloginfo( 'name' ) . ' — Form payment' );

        $payload = [
            'items' => [ [
                'title'       => mb_substr( (string) $title, 0, 255 ),
                'quantity'    => 1,
                'unit_price'  => round( $amount, 2 ),
                'currency_id' => $currency,
            ] ],
            'back_urls' => [
                'success' => add_query_arg( [ 'fcp_payment_ref' => $ref, 'fcp_gateway' => 'mercadopago', 'fcp_status' => 'success' ], $return_url ),
                'failure' => add_query_arg( [ 'fcp_payment_ref' => $ref, 'fcp_gateway' => 'mercadopago', 'fcp_status' => 'failure' ], $return_url ),
                'pending' => add_query_arg( [ 'fcp_payment_ref' => $ref, 'fcp_gateway' => 'mercadopago', 'fcp_status' => 'pending' ], $return_url ),
            ],
            'auto_return'        => 'approved',
            'external_reference' => $ref,
            'notification_url'   => rest_url( 'formcraft/v1/payments/webhook/mercadopago' ),
            'statement_descriptor' => mb_substr( (string) get_bloginfo( 'name' ), 0, 22 ),
        ];
        if ( ! empty( $args['prefill']['email'] ) && is_email( $args['prefill']['email'] ) ) {
            $payload['payer'] = [ 'email' => $args['prefill']['email'] ];
        }

        $res = $this->api( '/checkout/preferences', 'POST', $payload );
        if ( is_wp_error( $res ) ) return $res;

        // Test access tokens get a separate "sandbox" checkout URL. Live
        // tokens use init_point. Pick whichever the API returns.
        $checkout = ! empty( $res['init_point'] )
            ? $res['init_point']
            : ( $res['sandbox_init_point'] ?? '' );
        if ( ! $checkout ) {
            return new WP_Error( 'no_checkout', 'Mercado Pago did not return a checkout URL.' );
        }

        return [
            'provider'  => 'mercadopago',
            'order_id'  => $res['id'] ?? $ref,
            'amount'    => $amount,
            'currency'  => $currency,
            'checkout'  => [
                'redirect_url'   => $checkout,
                'preference_id'  => $res['id'] ?? '',
                'reference'      => $ref,
            ],
        ];
    }

    public function verify_payment( $args ) {
        // Two ways to arrive here:
        //   1) Mercado Pago redirects back with ?payment_id={id}
        //   2) We poll by external_reference if the redirect missed payment_id
        $payment_id = isset( $args['payment_id'] ) ? (string) $args['payment_id'] : '';
        $reference  = isset( $args['reference'] )  ? (string) $args['reference']  : '';

        if ( $payment_id ) {
            $payment = $this->api( '/v1/payments/' . rawurlencode( $payment_id ) );
            if ( is_wp_error( $payment ) ) return $payment;
        } elseif ( $reference ) {
            // Search by our external_reference
            $search = $this->api( '/v1/payments/search?external_reference=' . rawurlencode( $reference ) );
            if ( is_wp_error( $search ) ) return $search;
            $payment = ! empty( $search['results'][0] ) ? $search['results'][0] : [];
            if ( ! $payment ) {
                return new WP_Error( 'no_payment', 'No Mercado Pago payment found for reference ' . $reference );
            }
        } else {
            return new WP_Error( 'bad_request', 'Need either payment_id or reference to verify.' );
        }

        $status = $payment['status'] ?? '';
        if ( $status !== 'approved' ) {
            return new WP_Error( 'payment_failed', 'Payment status: ' . $status, [ 'response' => $payment ] );
        }

        return [
            'verified'   => true,
            'payment_id' => isset( $payment['id'] ) ? (string) $payment['id'] : $payment_id,
            'order_id'   => $payment['external_reference'] ?? $reference,
            'amount'     => isset( $payment['transaction_amount'] ) ? (float) $payment['transaction_amount'] : 0,
            'currency'   => $payment['currency_id'] ?? '',
            'method'     => $payment['payment_method_id'] ?? '',
            'email'      => $payment['payer']['email'] ?? '',
        ];
    }

    public function handle_webhook( $body, $headers ) {
        // Mercado Pago webhooks come as JSON with { action, data: { id } }.
        // The webhook itself is not signature-authenticated by default —
        // we re-fetch the payment via our access_token to confirm.
        $payload = json_decode( $body, true );
        $payment_id = $payload['data']['id'] ?? '';
        if ( ! $payment_id ) return new WP_Error( 'bad_webhook', 'Mercado Pago webhook missing data.id' );

        $payment = $this->api( '/v1/payments/' . rawurlencode( $payment_id ) );
        if ( is_wp_error( $payment ) ) return $payment;

        return [
            'event'   => 'payment.' . ( $payment['status'] ?? 'unknown' ),
            'payload' => $payment,
        ];
    }

    public function refund( $payment_id, $amount = null ) {
        $body = $amount !== null ? [ 'amount' => round( (float) $amount, 2 ) ] : null;
        $res = $this->api( '/v1/payments/' . rawurlencode( $payment_id ) . '/refunds', 'POST', $body );
        if ( is_wp_error( $res ) ) return $res;
        return [
            'refund_id' => isset( $res['id'] ) ? (string) $res['id'] : '',
            'amount'    => isset( $res['amount'] ) ? (float) $res['amount'] : 0,
            'status'    => $res['status'] ?? '',
        ];
    }
}
