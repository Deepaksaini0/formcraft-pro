<?php
/**
 * FormCraft Pro — Authorize.net (Accept Hosted) gateway.
 *
 * Uses Authorize.net's Accept Hosted Payment Page so we never touch raw
 * card data (avoids PCI scope). The flow:
 *   1. create_order() → POST getHostedPaymentPageRequest → token
 *   2. Front-end auto-submits a form to test.authorize.net/payment/payment
 *      (or production) with that token; user pays on Authorize.net's page.
 *   3. Authorize.net redirects back to our return_url with the txn id;
 *      verify_payment() looks the txn up via getTransactionDetailsRequest.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FCP_Gateway_Authorize extends FCP_Gateway_Base {

    public function slug() { return 'authorize'; }

    private function api_url() {
        return $this->test_mode
            ? 'https://apitest.authorize.net/xml/v1/request.api'
            : 'https://api.authorize.net/xml/v1/request.api';
    }
    private function hosted_url() {
        return $this->test_mode
            ? 'https://test.authorize.net/payment/payment'
            : 'https://accept.authorize.net/payment/payment';
    }

    public function create_order( $args ) {
        $login  = $this->cfg['login_id']        ?? '';
        $key    = $this->cfg['transaction_key'] ?? '';
        if ( ! $login || ! $key ) {
            return new WP_Error( 'unconfigured', 'Authorize.net needs both API Login ID and Transaction Key.' );
        }
        $amount   = number_format( (float) $args['amount'], 2, '.', '' );
        $ref      = $this->gen_ref();
        $return   = isset( $args['return_url'] ) ? $args['return_url'] : home_url( '/' );

        $payload = [
            'getHostedPaymentPageRequest' => [
                'merchantAuthentication' => [ 'name' => $login, 'transactionKey' => $key ],
                'refId'                  => $ref,
                'transactionRequest'     => [
                    'transactionType' => 'authCaptureTransaction',
                    'amount'          => $amount,
                    'order'           => [
                        'invoiceNumber' => substr( $ref, 0, 20 ),
                        'description'   => substr( (string) ( $args['description'] ?? 'FormCraft submission' ), 0, 255 ),
                    ],
                ],
                'hostedPaymentSettings' => [ 'setting' => [
                    [ 'settingName' => 'hostedPaymentReturnOptions',
                      'settingValue' => wp_json_encode( [ 'showReceipt' => true, 'url' => $return, 'urlText' => 'Continue', 'cancelUrl' => $return, 'cancelUrlText' => 'Cancel' ] ) ],
                    [ 'settingName' => 'hostedPaymentButtonOptions',
                      'settingValue' => wp_json_encode( [ 'text' => 'Pay' ] ) ],
                    [ 'settingName' => 'hostedPaymentOrderOptions',
                      'settingValue' => wp_json_encode( [ 'show' => true, 'merchantName' => get_bloginfo( 'name' ) ] ) ],
                ]],
            ],
        ];
        $res = $this->http( $this->api_url(), [
            'method'  => 'POST',
            'headers' => [ 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( $payload ),
        ] );
        if ( is_wp_error( $res ) ) return $res;
        $token = $res['token'] ?? '';
        if ( ! $token ) {
            $err = isset( $res['messages']['message'][0]['text'] ) ? $res['messages']['message'][0]['text'] : 'Unknown error';
            return new WP_Error( 'authorize_failed', 'Authorize.net rejected the request: ' . $err );
        }
        return [
            'gateway'    => 'authorize',
            'order_id'   => $ref,
            'token'      => $token,
            'hosted_url' => $this->hosted_url(),
            'amount'     => (float) $amount,
            'currency'   => $args['currency'] ?? 'USD',
        ];
    }

    public function verify_payment( $args ) {
        $login = $this->cfg['login_id']        ?? '';
        $key   = $this->cfg['transaction_key'] ?? '';
        $txn   = isset( $args['transaction_id'] ) ? sanitize_text_field( $args['transaction_id'] ) : '';
        if ( ! $txn ) return new WP_Error( 'missing_txn', 'Authorize.net transaction id is required to verify.' );

        $payload = [
            'getTransactionDetailsRequest' => [
                'merchantAuthentication' => [ 'name' => $login, 'transactionKey' => $key ],
                'transId'                => $txn,
            ],
        ];
        $res = $this->http( $this->api_url(), [
            'method'  => 'POST',
            'headers' => [ 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( $payload ),
        ] );
        if ( is_wp_error( $res ) ) return $res;
        $t = $res['transaction'] ?? null;
        if ( ! is_array( $t ) ) return new WP_Error( 'not_found', 'Transaction not found on Authorize.net.' );
        $status = $t['transactionStatus'] ?? '';
        $ok = in_array( $status, [ 'capturedPendingSettlement', 'settledSuccessfully', 'authorizedPendingCapture' ], true );
        if ( ! $ok ) return new WP_Error( 'not_paid', 'Authorize.net status: ' . $status );
        return [
            'payment_id' => $txn,
            'amount'     => isset( $t['authAmount'] ) ? (float) $t['authAmount'] : null,
            'currency'   => 'USD',
            'order_id'   => $t['refTransId'] ?? '',
        ];
    }
}
