<?php
/**
 * FormCraft Pro - WP-CLI command set.
 *
 * Registered as `wp fcp ...` (also aliased `wp formcraft ...`). The class
 * intentionally has no constructor — WP_CLI instantiates subcommand classes
 * lazily, and we want zero side-effects in non-CLI requests.
 *
 * Quick reference:
 *
 *   wp fcp list                           # list every FormCraft form
 *   wp fcp get 42                         # show one form (full JSON)
 *   wp fcp create --title="Contact"       # blank form
 *   wp fcp delete 42                      # delete (with --yes to skip prompt)
 *   wp fcp duplicate 42                   # copy a form
 *   wp fcp status 42 active               # change form status
 *
 *   wp fcp export 42 --file=contact.json  # write to file (omit for stdout)
 *   wp fcp import contact.json            # create from file
 *
 *   wp fcp subs list 42                   # list a form's submissions
 *   wp fcp subs export 42 --file=out.csv  # export CSV / JSON
 *   wp fcp subs delete 999                # remove one submission
 *
 *   wp fcp migrate detect                 # detect competing form plugins
 *   wp fcp migrate list cf7               # list CF7 forms available to import
 *   wp fcp migrate import wpforms 5 --include-subs
 *   wp fcp migrate import-all gravity --include-subs
 *   wp fcp migrate history
 *   wp fcp migrate rollback 3
 *
 *   wp fcp stats                          # overall counts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) {
    return;
}

class FCP_CLI {

    /**
     * List all FormCraft forms.
     *
     * ## OPTIONS
     *
     * [--status=<status>]
     * : Filter by status. Accepts: active, draft, paused, archived.
     *
     * [--format=<format>]
     * : Output format. Default: table. Accepts: table, csv, json, yaml, count, ids.
     *
     * [--fields=<fields>]
     * : Comma-separated columns. Default: id,slug,title,status,submissions,views,updated_at.
     *
     * ## EXAMPLES
     *
     *     wp fcp list
     *     wp fcp list --status=active --format=json
     *     wp fcp list --fields=id,title,submissions
     *
     * @subcommand list
     */
    public function list_forms( $args, $assoc_args ) {
        global $wpdb;
        $table = FCP_DB::forms_table();
        $where = '1=1';
        if ( ! empty( $assoc_args['status'] ) ) {
            $where .= $wpdb->prepare( ' AND status = %s', $assoc_args['status'] );
        }
        $rows = $wpdb->get_results( "SELECT id, slug, title, status, submissions, views, updated_at FROM $table WHERE $where ORDER BY updated_at DESC", ARRAY_A );
        $rows = $rows ?: [];
        $fields = isset( $assoc_args['fields'] )
            ? array_map( 'trim', explode( ',', $assoc_args['fields'] ) )
            : [ 'id', 'slug', 'title', 'status', 'submissions', 'views', 'updated_at' ];
        $format = $assoc_args['format'] ?? 'table';
        \WP_CLI\Utils\format_items( $format, $rows, $fields );
    }

    /**
     * Show one form's full JSON definition.
     *
     * ## OPTIONS
     *
     * <id>
     * : Form ID.
     *
     * [--format=<format>]
     * : json (default) or yaml.
     *
     * @synopsis <id> [--format=<format>]
     */
    public function get( $args, $assoc_args ) {
        $id = (int) $args[0];
        $form = FCP_DB::get_form( $id );
        if ( ! $form ) WP_CLI::error( "Form #$id not found." );
        $format = $assoc_args['format'] ?? 'json';
        if ( $format === 'yaml' && function_exists( 'yaml_emit' ) ) {
            WP_CLI::log( yaml_emit( $form ) );
        } else {
            WP_CLI::log( wp_json_encode( $form, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) );
        }
    }

    /**
     * Create a blank form.
     *
     * ## OPTIONS
     *
     * --title=<title>
     * : Form title (required).
     *
     * [--status=<status>]
     * : Initial status. Default: draft.
     *
     * [--porcelain]
     * : Output just the new form ID.
     *
     * ## EXAMPLES
     *
     *     wp fcp create --title="Contact Us" --status=active
     */
    public function create( $args, $assoc_args ) {
        $title = $assoc_args['title'] ?? '';
        if ( $title === '' ) WP_CLI::error( '--title is required.' );
        $status = $assoc_args['status'] ?? 'draft';
        $form = [
            'title'  => $title,
            'status' => $status,
            'steps'  => [ [ 'id' => 'step_' . wp_generate_password( 6, false ), 'name' => 'Step 1', 'fields' => [] ] ],
            'settings' => [
                'submitButton'   => 'Submit',
                'successMessage' => 'Thank you — your submission was received.',
                'notifications'  => [
                    'admin' => [ 'enabled' => true, 'to' => get_option( 'admin_email' ), 'subject' => 'New form submission' ],
                ],
            ],
        ];
        $id = FCP_DB::insert_form( $form );
        if ( ! $id ) WP_CLI::error( 'Could not insert form.' );
        if ( ! empty( $assoc_args['porcelain'] ) ) {
            WP_CLI::log( (string) $id );
        } else {
            WP_CLI::success( "Form #$id created — \"$title\" ($status)" );
        }
    }

    /**
     * Delete a form (and ALL its submissions).
     *
     * ## OPTIONS
     *
     * <id>
     * : Form ID.
     *
     * [--yes]
     * : Skip confirmation.
     *
     * @synopsis <id> [--yes]
     */
    public function delete( $args, $assoc_args ) {
        $id = (int) $args[0];
        $form = FCP_DB::get_form( $id );
        if ( ! $form ) WP_CLI::error( "Form #$id not found." );
        WP_CLI::confirm( "Delete form #$id (\"{$form['title']}\") and all its submissions?", $assoc_args );
        FCP_DB::delete_form( $id );
        WP_CLI::success( "Form #$id deleted." );
    }

    /**
     * Duplicate a form (status forced to draft).
     *
     * ## OPTIONS
     *
     * <id>
     * : Source form ID.
     *
     * [--title=<title>]
     * : Override the new title. Default: appends " (copy)".
     *
     * [--porcelain]
     * : Output just the new form ID.
     *
     * @synopsis <id> [--title=<title>] [--porcelain]
     */
    public function duplicate( $args, $assoc_args ) {
        $id = (int) $args[0];
        $form = FCP_DB::get_form( $id );
        if ( ! $form ) WP_CLI::error( "Form #$id not found." );
        unset( $form['id'], $form['slug'], $form['wpId'], $form['views'], $form['submissions'], $form['created_at'], $form['updated_at'] );
        $form['title']  = $assoc_args['title'] ?? ( $form['title'] . ' (copy)' );
        $form['status'] = 'draft';
        $new = FCP_DB::insert_form( $form );
        if ( ! $new ) WP_CLI::error( 'Could not duplicate the form.' );
        if ( ! empty( $assoc_args['porcelain'] ) ) {
            WP_CLI::log( (string) $new );
        } else {
            WP_CLI::success( "Form #$id duplicated → new form #$new" );
        }
    }

    /**
     * Change a form's status.
     *
     * ## OPTIONS
     *
     * <id>
     * : Form ID.
     *
     * <status>
     * : New status. One of: active, draft, paused, archived.
     *
     * @synopsis <id> <status>
     */
    public function status( $args, $assoc_args ) {
        global $wpdb;
        $id = (int) $args[0];
        $new = (string) $args[1];
        if ( ! in_array( $new, [ 'active', 'draft', 'paused', 'archived' ], true ) ) {
            WP_CLI::error( "Invalid status. Allowed: active, draft, paused, archived." );
        }
        $form = FCP_DB::get_form( $id );
        if ( ! $form ) WP_CLI::error( "Form #$id not found." );
        $wpdb->update( FCP_DB::forms_table(), [ 'status' => $new, 'updated_at' => current_time( 'mysql' ) ], [ 'id' => $id ] );
        WP_CLI::success( "Form #$id status: {$form['status']} → $new" );
    }

    /**
     * Export a form to JSON (file or stdout).
     *
     * ## OPTIONS
     *
     * <id>
     * : Form ID.
     *
     * [--file=<path>]
     * : Write to file instead of stdout.
     *
     * ## EXAMPLES
     *
     *     wp fcp export 42 --file=contact.json
     *     wp fcp export 42 > contact.json
     *
     * @synopsis <id> [--file=<path>]
     */
    public function export( $args, $assoc_args ) {
        $id   = (int) $args[0];
        $form = FCP_DB::get_form( $id );
        if ( ! $form ) WP_CLI::error( "Form #$id not found." );
        // Strip server identifiers so the JSON can be re-imported cleanly.
        unset( $form['id'], $form['slug'], $form['wpId'], $form['views'], $form['submissions'], $form['created_at'], $form['updated_at'] );
        $json = wp_json_encode( $form, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
        if ( ! empty( $assoc_args['file'] ) ) {
            $path = $assoc_args['file'];
            if ( false === file_put_contents( $path, $json ) ) WP_CLI::error( "Could not write $path" );
            WP_CLI::success( "Exported form #$id → $path (" . strlen( $json ) . " bytes)" );
        } else {
            WP_CLI::log( $json );
        }
    }

    /**
     * Import a form from a JSON file.
     *
     * ## OPTIONS
     *
     * <file>
     * : Path to a JSON file (or `-` for stdin).
     *
     * [--suffix=<text>]
     * : Optional suffix appended to the title.
     *
     * [--porcelain]
     * : Output just the new form ID.
     *
     * @synopsis <file> [--suffix=<text>] [--porcelain]
     */
    public function import( $args, $assoc_args ) {
        $file = $args[0];
        $raw  = ( $file === '-' ) ? file_get_contents( 'php://stdin' ) : @file_get_contents( $file );
        if ( $raw === false ) WP_CLI::error( "Could not read $file" );
        $form = json_decode( $raw, true );
        if ( ! is_array( $form ) || empty( $form['steps'] ) ) WP_CLI::error( 'Invalid JSON — must include title + steps[].' );
        unset( $form['id'], $form['slug'], $form['wpId'], $form['views'], $form['submissions'], $form['created_at'], $form['updated_at'] );
        $form['title']  = ( $form['title'] ?? 'Imported Form' ) . ( ! empty( $assoc_args['suffix'] ) ? ' ' . $assoc_args['suffix'] : ' (imported)' );
        $form['status'] = 'draft';
        $id = FCP_DB::insert_form( $form );
        if ( ! $id ) WP_CLI::error( 'Could not insert form.' );
        FCP_DB::insert_revision( $id, $form, 'Imported via WP-CLI' );
        if ( ! empty( $assoc_args['porcelain'] ) ) {
            WP_CLI::log( (string) $id );
        } else {
            WP_CLI::success( "Imported as form #$id (\"{$form['title']}\")" );
        }
    }

    /**
     * Show overall stats.
     */
    public function stats( $args, $assoc_args ) {
        global $wpdb;
        $forms = FCP_DB::forms_table();
        $subs  = FCP_DB::subs_table();
        $out = [
            'total_forms'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $forms" ),
            'active_forms'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $forms WHERE status = 'active'" ),
            'draft_forms'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $forms WHERE status = 'draft'" ),
            'total_views'     => (int) $wpdb->get_var( "SELECT COALESCE(SUM(views),0) FROM $forms" ),
            'total_subs'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $subs WHERE is_spam = 0 AND is_abandoned = 0" ),
            'spam_subs'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $subs WHERE is_spam = 1" ),
            'abandoned'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $subs WHERE is_abandoned = 1" ),
        ];
        \WP_CLI\Utils\format_items( 'table', [ $out ], array_keys( $out ) );
    }
}

/**
 * Submission subcommands — registered as `wp fcp subs ...`
 */
class FCP_CLI_Submissions {

    /**
     * List submissions for a form.
     *
     * ## OPTIONS
     *
     * <form_id>
     * : Form ID.
     *
     * [--format=<format>]
     * : table (default), csv, json, ids, count.
     *
     * [--limit=<n>]
     * : Max rows. Default: 100.
     *
     * [--spam]
     * : Include spam (excluded by default).
     *
     * @subcommand list
     * @synopsis <form_id> [--format=<format>] [--limit=<n>] [--spam]
     */
    public function list_subs( $args, $assoc_args ) {
        global $wpdb;
        $fid   = (int) $args[0];
        $limit = (int) ( $assoc_args['limit'] ?? 100 );
        $where = $wpdb->prepare( 'form_id = %d AND is_abandoned = 0', $fid );
        if ( empty( $assoc_args['spam'] ) ) $where .= ' AND is_spam = 0';
        $rows = $wpdb->get_results(
            "SELECT id, submitter_name, submitter_email, country, is_read, is_spam, created_at FROM " . FCP_DB::subs_table() . " WHERE $where ORDER BY created_at DESC LIMIT " . max( 1, $limit ),
            ARRAY_A
        );
        $rows = $rows ?: [];
        $fields = [ 'id', 'submitter_name', 'submitter_email', 'country', 'is_read', 'is_spam', 'created_at' ];
        \WP_CLI\Utils\format_items( $assoc_args['format'] ?? 'table', $rows, $fields );
    }

    /**
     * Export submissions to CSV or JSON.
     *
     * ## OPTIONS
     *
     * <form_id>
     * : Form ID.
     *
     * [--file=<path>]
     * : Output file (default: stdout).
     *
     * [--format=<format>]
     * : csv (default) or json.
     *
     * [--limit=<n>]
     * : Max rows. Default: all.
     *
     * @subcommand export
     * @synopsis <form_id> [--file=<path>] [--format=<format>] [--limit=<n>]
     */
    public function export( $args, $assoc_args ) {
        global $wpdb;
        $fid    = (int) $args[0];
        $format = $assoc_args['format'] ?? 'csv';
        $limit  = isset( $assoc_args['limit'] ) ? max( 1, (int) $assoc_args['limit'] ) : 1000000;
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, submitter_name, submitter_email, country, ip_address, data, created_at FROM " . FCP_DB::subs_table() . " WHERE form_id = %d AND is_abandoned = 0 AND is_spam = 0 ORDER BY created_at DESC LIMIT %d",
            $fid, $limit
        ), ARRAY_A );
        $rows = $rows ?: [];
        // Expand the per-submission data JSON into columns
        $columns = [ 'id', 'submitter_name', 'submitter_email', 'country', 'ip_address', 'created_at' ];
        $expanded = [];
        $data_keys = [];
        foreach ( $rows as $r ) {
            $d = json_decode( $r['data'], true );
            $d = is_array( $d ) ? $d : [];
            foreach ( array_keys( $d ) as $k ) $data_keys[ $k ] = true;
            $expanded[] = array_merge( array_diff_key( $r, [ 'data' => 1 ] ), $d );
        }
        $columns = array_merge( $columns, array_keys( $data_keys ) );

        if ( $format === 'json' ) {
            $out = wp_json_encode( $expanded, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
        } else {
            // CSV
            $fp = fopen( 'php://temp', 'w+' );
            fputcsv( $fp, $columns );
            foreach ( $expanded as $row ) {
                $line = [];
                foreach ( $columns as $c ) {
                    $v = $row[ $c ] ?? '';
                    $line[] = is_scalar( $v ) ? (string) $v : wp_json_encode( $v );
                }
                fputcsv( $fp, $line );
            }
            rewind( $fp );
            $out = stream_get_contents( $fp );
            fclose( $fp );
        }

        if ( ! empty( $assoc_args['file'] ) ) {
            if ( false === file_put_contents( $assoc_args['file'], $out ) ) WP_CLI::error( 'Could not write file.' );
            WP_CLI::success( count( $expanded ) . " submissions → {$assoc_args['file']}" );
        } else {
            WP_CLI::log( $out );
        }
    }

    /**
     * Delete a submission.
     *
     * ## OPTIONS
     *
     * <id>
     * : Submission ID.
     *
     * [--yes]
     * : Skip confirmation.
     *
     * @synopsis <id> [--yes]
     */
    public function delete( $args, $assoc_args ) {
        $id = (int) $args[0];
        $row = FCP_DB::get_submission( $id );
        if ( ! $row ) WP_CLI::error( "Submission #$id not found." );
        WP_CLI::confirm( "Delete submission #$id?", $assoc_args );
        FCP_DB::delete_submission( $id );
        WP_CLI::success( "Submission #$id deleted." );
    }
}

/**
 * 1-Click migration subcommands — registered as `wp fcp migrate ...`
 */
class FCP_CLI_Migrate {

    /**
     * Detect installed competing form plugins.
     *
     * ## OPTIONS
     *
     * [--format=<format>]
     * : table (default), json, yaml.
     */
    public function detect( $args, $assoc_args ) {
        if ( ! class_exists( 'FCP_Migrator' ) ) WP_CLI::error( 'Migrator unavailable.' );
        $sources = FCP_Migrator::detect_plugins();
        $rows = [];
        foreach ( $sources as $key => $s ) {
            $rows[] = [
                'source'  => $key,
                'name'    => $s['name'],
                'active'  => $s['active'] ? 'yes' : '-',
                'forms'   => $s['count'],
                'version' => $s['version'] ?? '-',
            ];
        }
        \WP_CLI\Utils\format_items( $assoc_args['format'] ?? 'table', $rows, [ 'source', 'name', 'active', 'forms', 'version' ] );
    }

    /**
     * List the forms available in a source plugin.
     *
     * ## OPTIONS
     *
     * <source>
     * : Source key: cf7, wpforms, fluentform, gravity, ninja, formidable, everest.
     *
     * [--format=<format>]
     * : table (default), json, csv.
     *
     * @subcommand list
     * @synopsis <source> [--format=<format>]
     */
    public function list_source_forms( $args, $assoc_args ) {
        if ( ! class_exists( 'FCP_Migrator' ) ) WP_CLI::error( 'Migrator unavailable.' );
        $source = (string) $args[0];
        $forms  = FCP_Migrator::list_forms( $source );
        \WP_CLI\Utils\format_items( $assoc_args['format'] ?? 'table', $forms, [ 'id', 'title', 'fields', 'submissions' ] );
    }

    /**
     * Import one form from a source plugin.
     *
     * ## OPTIONS
     *
     * <source>
     * : Source key.
     *
     * <id>
     * : Source form ID.
     *
     * [--include-subs]
     * : Also migrate the form's submissions.
     *
     * [--suffix=<text>]
     * : Suffix appended to the imported form's title.
     *
     * [--porcelain]
     * : Output only the new form ID on success.
     *
     * ## EXAMPLES
     *
     *     wp fcp migrate import wpforms 12 --include-subs
     *     wp fcp migrate import cf7 7 --suffix="(from CF7)"
     *
     * @subcommand import
     * @synopsis <source> <id> [--include-subs] [--suffix=<text>] [--porcelain]
     */
    public function import_one( $args, $assoc_args ) {
        if ( ! class_exists( 'FCP_Migrator' ) ) WP_CLI::error( 'Migrator unavailable.' );
        $source = (string) $args[0];
        $id     = (int) $args[1];
        $opts   = [
            'include_submissions' => ! empty( $assoc_args['include-subs'] ),
            'suffix'              => $assoc_args['suffix'] ?? '',
        ];
        $r = FCP_Migrator::import( $source, $id, $opts );
        if ( is_wp_error( $r ) ) WP_CLI::error( $r->get_error_message() );
        if ( ! empty( $assoc_args['porcelain'] ) ) {
            WP_CLI::log( (string) $r['new_form_id'] );
            return;
        }
        WP_CLI::success( sprintf(
            'Imported %s form #%d → FormCraft form #%d (%d fields, %d submissions%s)',
            $source, $id, $r['new_form_id'], $r['fields_count'], $r['submissions_count'],
            count( $r['warnings'] ) ? ', ' . count( $r['warnings'] ) . ' warning(s)' : ''
        ) );
        foreach ( $r['warnings'] as $w ) WP_CLI::warning( $w );
    }

    /**
     * Import every form from a source plugin.
     *
     * ## OPTIONS
     *
     * <source>
     * : Source key.
     *
     * [--include-subs]
     * : Also migrate submissions.
     *
     * [--suffix=<text>]
     * : Suffix for each imported form's title.
     *
     * [--yes]
     * : Skip the count confirmation prompt.
     *
     * @subcommand import-all
     * @synopsis <source> [--include-subs] [--suffix=<text>] [--yes]
     */
    public function import_all( $args, $assoc_args ) {
        if ( ! class_exists( 'FCP_Migrator' ) ) WP_CLI::error( 'Migrator unavailable.' );
        $source = (string) $args[0];
        $forms  = FCP_Migrator::list_forms( $source );
        if ( ! $forms ) WP_CLI::error( "No forms found in source: $source" );
        WP_CLI::confirm( sprintf( 'Import all %d forms from %s?', count( $forms ), $source ), $assoc_args );
        $opts = [
            'include_submissions' => ! empty( $assoc_args['include-subs'] ),
            'suffix'              => $assoc_args['suffix'] ?? '',
        ];
        $ok = 0; $fail = 0; $field_total = 0; $sub_total = 0; $warn_total = 0;
        $progress = \WP_CLI\Utils\make_progress_bar( "Migrating $source", count( $forms ) );
        foreach ( $forms as $f ) {
            $r = FCP_Migrator::import( $source, (int) $f['id'], $opts );
            if ( is_wp_error( $r ) ) {
                $fail++;
                WP_CLI::warning( "{$f['title']}: " . $r->get_error_message() );
            } else {
                $ok++;
                $field_total += (int) $r['fields_count'];
                $sub_total   += (int) $r['submissions_count'];
                $warn_total  += count( $r['warnings'] );
            }
            $progress->tick();
        }
        $progress->finish();
        WP_CLI::success( sprintf(
            '%d imported, %d failed · %d fields · %d submissions%s',
            $ok, $fail, $field_total, $sub_total,
            $warn_total ? " · $warn_total warning(s)" : ''
        ) );
    }

    /**
     * Show recent migration history.
     *
     * ## OPTIONS
     *
     * [--format=<format>]
     * : table (default), json, csv.
     *
     * [--limit=<n>]
     * : Default: 50.
     */
    public function history( $args, $assoc_args ) {
        if ( ! class_exists( 'FCP_Migrator' ) ) WP_CLI::error( 'Migrator unavailable.' );
        $rows = FCP_Migrator::history( (int) ( $assoc_args['limit'] ?? 50 ) );
        $view = [];
        foreach ( $rows as $r ) {
            $view[] = [
                'id'             => $r['id'],
                'source'         => $r['source'],
                'source_form_id' => $r['source_form_id'],
                'new_form_id'    => $r['new_form_id'],
                'form_title'     => $r['form_title'],
                'fields'         => $r['fields_count'],
                'subs'           => $r['subs_count'],
                'warnings'       => count( $r['warnings'] ),
                'rolled_back'    => $r['rolled_back'] ? 'yes' : '-',
                'created_at'     => $r['created_at'],
            ];
        }
        \WP_CLI\Utils\format_items(
            $assoc_args['format'] ?? 'table',
            $view,
            [ 'id', 'source', 'source_form_id', 'new_form_id', 'form_title', 'fields', 'subs', 'warnings', 'rolled_back', 'created_at' ]
        );
    }

    /**
     * Roll back a migration (deletes the imported FormCraft form + its migrated submissions).
     *
     * ## OPTIONS
     *
     * <id>
     * : Migration ID (from `wp fcp migrate history`).
     *
     * [--yes]
     * : Skip confirmation.
     *
     * @synopsis <id> [--yes]
     */
    public function rollback( $args, $assoc_args ) {
        if ( ! class_exists( 'FCP_Migrator' ) ) WP_CLI::error( 'Migrator unavailable.' );
        $id = (int) $args[0];
        WP_CLI::confirm( "Roll back migration #$id? The imported form and its migrated submissions will be deleted (source data untouched).", $assoc_args );
        $r = FCP_Migrator::rollback( $id );
        if ( is_wp_error( $r ) ) WP_CLI::error( $r->get_error_message() );
        WP_CLI::success( "Migration #$id rolled back." );
    }
}

/* -----------------------------------------------------------
 * Register the command tree
 * -------------------------------------------------------- */
WP_CLI::add_command( 'fcp',       'FCP_CLI' );
WP_CLI::add_command( 'fcp subs',  'FCP_CLI_Submissions' );
WP_CLI::add_command( 'fcp migrate','FCP_CLI_Migrate' );

// Friendly alias — `wp formcraft ...` works identically to `wp fcp ...`
WP_CLI::add_command( 'formcraft',         'FCP_CLI' );
WP_CLI::add_command( 'formcraft subs',    'FCP_CLI_Submissions' );
WP_CLI::add_command( 'formcraft migrate', 'FCP_CLI_Migrate' );
