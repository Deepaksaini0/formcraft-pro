<?php
/**
 * FormCraft Pro - Internationalization layer.
 *
 * Three concerns:
 *  1. WPML / Polylang registration — when a form is saved, register every
 *     translatable string (form title, field labels, field help, success
 *     message, submit text) with both plugins. Either or both may be active.
 *  2. Auto-translation — call DeepL, Google Translate, or Anthropic to
 *     translate a batch of strings into a target language. Provider picked
 *     based on which API key the admin configured under Settings → AI.
 *  3. Read-side resolution — at render time, swap labels for their
 *     translated versions if the visitor's language differs from the
 *     form's source language. Hooks into WPML/Polylang current-language
 *     detection when available; otherwise reads the form's settings.language.
 *
 * Storage: translations live on the form record itself (form.settings.
 * translations), keyed by string key → { lang: text }. WPML/Polylang
 * registration is fire-and-forget — they read from the form schema each
 * page load, no separate storage.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_I18n {

    const DEEPL_ENDPOINT     = 'https://api-free.deepl.com/v2/translate';
    const DEEPL_PRO_ENDPOINT = 'https://api.deepl.com/v2/translate';
    const GOOGLE_ENDPOINT    = 'https://translation.googleapis.com/language/translate/v2';

    /**
     * Register a form's translatable strings with WPML + Polylang. Safe
     * no-op when neither plugin is active — both fire only via
     * `do_action`/`function_exists`, so the host site doesn't pay any
     * cost when not using either.
     *
     * Called from FCP_DB::save_form() after persistence.
     */
    public static function register_form_strings( $form ) {
        if ( ! is_array( $form ) ) return;
        $form_id = isset( $form['id'] ) ? (int) $form['id'] : 0;
        if ( ! $form_id ) return;
        $domain  = 'formcraft-pro:' . $form_id;

        $strings = self::collect_strings( $form );
        if ( ! $strings ) return;

        // WPML — uses do_action hook. Plugin handles missing gracefully.
        if ( function_exists( 'do_action' ) ) {
            foreach ( $strings as $key => $text ) {
                do_action( 'wpml_register_single_string', $domain, $key, $text );
            }
        }
        // Polylang — uses function_exists check.
        if ( function_exists( 'pll_register_string' ) ) {
            foreach ( $strings as $key => $text ) {
                pll_register_string( $key, $text, $domain, mb_strlen( $text ) > 80 );
            }
        }
    }

    /**
     * Translate a string using WPML/Polylang if available, else falls
     * back to the form's stored translations table, else returns
     * the original.
     */
    public static function translate( $text, $key, $form_id ) {
        $domain = 'formcraft-pro:' . (int) $form_id;
        // WPML
        if ( function_exists( 'apply_filters' ) ) {
            $out = apply_filters( 'wpml_translate_single_string', $text, $domain, $key );
            if ( is_string( $out ) && $out !== '' ) return $out;
        }
        // Polylang
        if ( function_exists( 'pll__' ) ) {
            $out = pll__( $text );
            if ( is_string( $out ) && $out !== $text ) return $out;
        }
        return $text;
    }

    /**
     * Extract every translatable string from a form schema into a flat
     * key → text map. Keys are stable across saves so WPML/Polylang
     * keep their translations.
     */
    private static function collect_strings( $form ) {
        $out = [];
        if ( ! empty( $form['title'] ) )                          $out['title']        = (string) $form['title'];
        if ( ! empty( $form['description'] ) )                    $out['description']  = (string) $form['description'];
        if ( ! empty( $form['settings']['submitText'] ) )         $out['submit_text']  = (string) $form['settings']['submitText'];
        if ( ! empty( $form['settings']['successMessage'] ) )     $out['success_msg']  = (string) $form['settings']['successMessage'];
        $steps = isset( $form['steps'] ) && is_array( $form['steps'] ) ? $form['steps'] : [];
        foreach ( $steps as $si => $step ) {
            if ( ! empty( $step['title'] ) ) $out["step_{$si}_title"] = (string) $step['title'];
            $fields = isset( $step['fields'] ) && is_array( $step['fields'] ) ? $step['fields'] : [];
            foreach ( $fields as $fi => $field ) {
                $base = "step_{$si}_field_{$fi}_";
                if ( ! empty( $field['label'] ) )       $out[ $base . 'label' ]    = (string) $field['label'];
                if ( ! empty( $field['placeholder'] ) ) $out[ $base . 'placeholder' ] = (string) $field['placeholder'];
                if ( ! empty( $field['help'] ) )        $out[ $base . 'help' ]     = (string) $field['help'];
                if ( ! empty( $field['options'] ) && is_array( $field['options'] ) ) {
                    foreach ( $field['options'] as $oi => $opt ) {
                        if ( is_string( $opt ) && $opt !== '' ) $out[ $base . "opt_{$oi}" ] = $opt;
                    }
                }
            }
        }
        return $out;
    }

    /**
     * Batch-translate a list of strings into the target language.
     * Picks the first configured provider in this order: DeepL, Google
     * Translate, Anthropic (the existing AI key). Returns an array of
     * translated strings (same order as input). On error, returns WP_Error.
     */
    public static function batch_translate( $strings, $target_lang, $source_lang = 'en' ) {
        $strings = array_values( array_filter( array_map( 'strval', (array) $strings ) ) );
        if ( ! $strings ) return [];
        $target_lang = strtolower( substr( preg_replace( '/[^a-zA-Z\-]/', '', (string) $target_lang ), 0, 5 ) );
        if ( ! $target_lang ) return new WP_Error( 'bad_target', 'Target language required', [ 'status' => 400 ] );
        $settings = get_option( 'fcp_settings', [] );
        $i18n_cfg = isset( $settings['i18n'] ) ? $settings['i18n'] : [];
        if ( ! empty( $i18n_cfg['deepl_key'] ) ) {
            return self::translate_via_deepl( $strings, $target_lang, $source_lang, $i18n_cfg );
        }
        if ( ! empty( $i18n_cfg['google_key'] ) ) {
            return self::translate_via_google( $strings, $target_lang, $source_lang, $i18n_cfg['google_key'] );
        }
        if ( class_exists( 'FCP_AI' ) ) {
            return self::translate_via_anthropic( $strings, $target_lang, $source_lang );
        }
        return new WP_Error( 'no_provider', 'No translation provider configured. Add a DeepL key, Google Translate key, or Anthropic key under Settings.', [ 'status' => 400 ] );
    }

    private static function translate_via_deepl( $strings, $target_lang, $source_lang, $cfg ) {
        $endpoint = ! empty( $cfg['deepl_pro'] ) ? self::DEEPL_PRO_ENDPOINT : self::DEEPL_ENDPOINT;
        $body = [
            'auth_key'    => $cfg['deepl_key'],
            'target_lang' => strtoupper( $target_lang ),
            'source_lang' => strtoupper( $source_lang ),
        ];
        $http_body = http_build_query( $body );
        foreach ( $strings as $s ) $http_body .= '&text=' . rawurlencode( $s );
        $resp = wp_remote_post( $endpoint, [
            'timeout' => 25,
            'headers' => [ 'content-type' => 'application/x-www-form-urlencoded' ],
            'body'    => $http_body,
        ] );
        if ( is_wp_error( $resp ) ) return $resp;
        $code = wp_remote_retrieve_response_code( $resp );
        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error( 'deepl_http_' . $code, 'DeepL returned HTTP ' . $code, [ 'status' => 502 ] );
        }
        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        $out = [];
        if ( isset( $body['translations'] ) && is_array( $body['translations'] ) ) {
            foreach ( $body['translations'] as $t ) $out[] = (string) ( $t['text'] ?? '' );
        }
        return $out;
    }

    private static function translate_via_google( $strings, $target_lang, $source_lang, $key ) {
        $resp = wp_remote_post( self::GOOGLE_ENDPOINT . '?key=' . rawurlencode( $key ), [
            'timeout' => 25,
            'headers' => [ 'content-type' => 'application/json' ],
            'body'    => wp_json_encode( [
                'q'      => $strings,
                'source' => $source_lang,
                'target' => $target_lang,
                'format' => 'text',
            ] ),
        ] );
        if ( is_wp_error( $resp ) ) return $resp;
        $code = wp_remote_retrieve_response_code( $resp );
        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error( 'google_http_' . $code, 'Google Translate returned HTTP ' . $code, [ 'status' => 502 ] );
        }
        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        $out = [];
        if ( isset( $body['data']['translations'] ) && is_array( $body['data']['translations'] ) ) {
            foreach ( $body['data']['translations'] as $t ) $out[] = (string) ( $t['translatedText'] ?? '' );
        }
        return $out;
    }

    private static function translate_via_anthropic( $strings, $target_lang, $source_lang ) {
        $list = '';
        foreach ( $strings as $i => $s ) $list .= ( $i + 1 ) . '. ' . str_replace( "\n", ' ', $s ) . "\n";
        $system = "Translate the numbered lines from {$source_lang} to {$target_lang}. Reply with EXACTLY the same numbered list, same order, translations only — no commentary, no markdown, no extra blank lines. Preserve curly-brace tokens like {Name} verbatim.";
        $r = FCP_AI::call_translate( $system, $list, count( $strings ) * 60 + 100 );
        if ( is_wp_error( $r ) ) return $r;
        // Parse the numbered response back into an array
        $lines = preg_split( '/\r?\n/', trim( $r ) );
        $out = array_fill( 0, count( $strings ), '' );
        foreach ( $lines as $line ) {
            if ( preg_match( '/^\s*(\d+)\.\s+(.+)$/', $line, $m ) ) {
                $idx = (int) $m[1] - 1;
                if ( $idx >= 0 && $idx < count( $strings ) ) $out[ $idx ] = trim( $m[2] );
            }
        }
        // Fallback for any unparsed lines — keep original
        foreach ( $strings as $i => $s ) if ( $out[ $i ] === '' ) $out[ $i ] = $s;
        return $out;
    }
}
