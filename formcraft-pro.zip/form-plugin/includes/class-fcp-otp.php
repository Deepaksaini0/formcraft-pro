<?php
/**
 * FormCraft Pro — OTP (one-time password) sender + verifier.
 *
 * Issues a short numeric code, stores it in a WordPress transient keyed by
 * the target (email or phone) + form id, and sends it via the configured
 * channel: email (uses existing SMTP), Twilio SMS, or MSG91 SMS. The
 * companion REST endpoints in class-fcp-rest.php expose send + verify.
 *
 * Storage model: each code is stored under transient
 *   fcp_otp_<sha1(target+form_id)>
 * with the value [ 'code' => '123456', 'attempts' => 0, 'sent_at' => ts ].
 * Codes expire after 5 minutes (or the configured TTL).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_OTP {

    const TTL_SECONDS   = 300; // 5 minutes
    const MAX_ATTEMPTS  = 5;
    const RATE_LIMIT_SECONDS = 60; // 1 send per minute per (target+form)

    public static function settings() {
        $all = get_option( 'fcp_settings', [] );
        return isset( $all['otp'] ) ? $all['otp'] : [];
    }

    /**
     * Send a new OTP to the given target. Returns:
     *   [ 'ok' => true,  'channel' => str, 'cooldown' => int ]
     *   WP_Error on failure.
     */
    public static function send( $target, $channel, $form_id = 0, $form_title = '' ) {
        $target = self::sanitize_target( $target, $channel );
        if ( is_wp_error( $target ) ) return $target;

        // Cooldown — prevent flood. Same target+form can only request once per minute.
        $key  = self::storage_key( $target, $form_id );
        $cool = 'fcp_otp_cool_' . $key;
        $last = (int) get_transient( $cool );
        if ( $last && ( time() - $last ) < self::RATE_LIMIT_SECONDS ) {
            $wait = self::RATE_LIMIT_SECONDS - ( time() - $last );
            return new WP_Error( 'otp_cooldown', 'Please wait ' . $wait . ' seconds before requesting another code.', [ 'status' => 429 ] );
        }

        // IP rate limit — at most 5 sends per IP per 10 minutes regardless of target.
        $ip = FCP_DB::get_ip();
        if ( $ip ) {
            $ip_key = 'fcp_otp_ip_' . md5( $ip );
            $ip_ct  = (int) get_transient( $ip_key );
            if ( $ip_ct >= 5 ) {
                return new WP_Error( 'otp_rate_limited', 'Too many OTP requests from this IP. Try again in a few minutes.', [ 'status' => 429 ] );
            }
            set_transient( $ip_key, $ip_ct + 1, 10 * MINUTE_IN_SECONDS );
        }

        $code = self::generate_code();
        set_transient( 'fcp_otp_' . $key, [
            'code'     => $code,
            'attempts' => 0,
            'sent_at'  => time(),
            'channel'  => $channel,
            'target'   => $target,
        ], self::TTL_SECONDS );
        set_transient( $cool, time(), self::RATE_LIMIT_SECONDS );

        // Dispatch
        $title = $form_title ?: get_bloginfo( 'name' );
        $sent  = false;
        switch ( $channel ) {
            case 'email':
                $sent = self::send_email( $target, $code, $title );
                break;
            case 'twilio':
                $sent = self::send_twilio( $target, $code, $title );
                break;
            case 'msg91':
                $sent = self::send_msg91( $target, $code, $title );
                break;
            default:
                return new WP_Error( 'bad_channel', 'Unsupported OTP channel: ' . $channel, [ 'status' => 400 ] );
        }
        if ( is_wp_error( $sent ) ) {
            // Roll back the transient so the visitor isn't stranded with an
            // unverifiable code if the provider failed.
            delete_transient( 'fcp_otp_' . $key );
            delete_transient( $cool );
            return $sent;
        }
        return [
            'ok'       => true,
            'channel'  => $channel,
            'cooldown' => self::RATE_LIMIT_SECONDS,
            'ttl'      => self::TTL_SECONDS,
        ];
    }

    /**
     * Verify a submitted code. Returns true on match, WP_Error on mismatch /
     * expiry. On a wrong code, the attempt count is bumped — too many wrong
     * tries invalidates the code so an attacker can't brute force a 6-digit.
     */
    public static function verify( $target, $channel, $code, $form_id = 0 ) {
        $target = self::sanitize_target( $target, $channel );
        if ( is_wp_error( $target ) ) return $target;
        $code = preg_replace( '/\D/', '', (string) $code );
        if ( strlen( $code ) < 4 ) {
            return new WP_Error( 'otp_bad_code', 'Please enter the code you received.', [ 'status' => 400 ] );
        }
        $key   = self::storage_key( $target, $form_id );
        $state = get_transient( 'fcp_otp_' . $key );
        if ( ! is_array( $state ) ) {
            return new WP_Error( 'otp_expired', 'No code on file — please request a new one.', [ 'status' => 410 ] );
        }
        if ( (int) ( $state['attempts'] ?? 0 ) >= self::MAX_ATTEMPTS ) {
            delete_transient( 'fcp_otp_' . $key );
            return new WP_Error( 'otp_locked', 'Too many wrong attempts — please request a new code.', [ 'status' => 429 ] );
        }
        if ( ! hash_equals( (string) $state['code'], $code ) ) {
            $state['attempts'] = (int) ( $state['attempts'] ?? 0 ) + 1;
            // Re-save with the remaining TTL the transient currently has.
            // WordPress doesn't expose the remaining TTL directly, so we use
            // sent_at + TTL_SECONDS as a close-enough cap.
            $remaining = max( 30, ( $state['sent_at'] + self::TTL_SECONDS ) - time() );
            set_transient( 'fcp_otp_' . $key, $state, $remaining );
            return new WP_Error( 'otp_wrong', 'Incorrect code. ' . ( self::MAX_ATTEMPTS - $state['attempts'] ) . ' attempt(s) left.', [ 'status' => 400 ] );
        }
        // Success — consume the code so it can't be reused.
        delete_transient( 'fcp_otp_' . $key );
        return true;
    }

    private static function generate_code() {
        // 6-digit zero-padded — wp_rand is preferred over mt_rand inside WP.
        return str_pad( (string) wp_rand( 0, 999999 ), 6, '0', STR_PAD_LEFT );
    }

    private static function storage_key( $target, $form_id ) {
        return sha1( strtolower( $target ) . '|' . (int) $form_id );
    }

    private static function sanitize_target( $target, $channel ) {
        $target = trim( (string) $target );
        if ( $target === '' ) {
            return new WP_Error( 'otp_no_target', 'No phone number / email provided.', [ 'status' => 400 ] );
        }
        if ( $channel === 'email' ) {
            if ( ! is_email( $target ) ) {
                return new WP_Error( 'otp_bad_email', 'That email address looks invalid.', [ 'status' => 400 ] );
            }
            return sanitize_email( $target );
        }
        // SMS — normalize to E.164ish (leading +, digits only). Accepts
        // "+91 98765 43210", "91 98765 43210", "9876543210" and forces a
        // leading "+" if missing. The default country code comes from
        // settings (so naked 10-digit Indian numbers still go through MSG91).
        $digits = preg_replace( '/[^\d+]/', '', $target );
        if ( $digits === '' ) {
            return new WP_Error( 'otp_bad_phone', 'That phone number looks invalid.', [ 'status' => 400 ] );
        }
        if ( strpos( $digits, '+' ) !== 0 ) {
            $cfg     = self::settings();
            $cc      = isset( $cfg['default_cc'] ) ? trim( (string) $cfg['default_cc'] ) : '+91';
            $cc      = $cc ? preg_replace( '/[^\d+]/', '', $cc ) : '+91';
            if ( strpos( $cc, '+' ) !== 0 ) $cc = '+' . $cc;
            $digits  = $cc . ltrim( $digits, '0' );
        }
        if ( strlen( $digits ) < 7 ) {
            return new WP_Error( 'otp_bad_phone', 'That phone number is too short.', [ 'status' => 400 ] );
        }
        return $digits;
    }

    /* ----------------- Channel: Email ----------------- */
    private static function send_email( $to, $code, $form_title ) {
        $subject = sprintf( '%s — Verification Code: %s', wp_strip_all_tags( $form_title ), $code );
        $body    = '<p>Hi,</p>'
                 . '<p>Your verification code is:</p>'
                 . '<p style="font-size:28px;font-weight:700;letter-spacing:6px;background:#f1f5f9;padding:14px 20px;border-radius:8px;display:inline-block;">' . esc_html( $code ) . '</p>'
                 . '<p style="color:#64748b;">This code expires in ' . (int) ( self::TTL_SECONDS / 60 ) . ' minutes. If you didn\'t request this, you can safely ignore this message.</p>';
        $headers = [ 'Content-Type: text/html; charset=UTF-8' ];
        $ok = wp_mail( $to, $subject, $body, $headers );
        if ( ! $ok ) {
            return new WP_Error( 'otp_email_failed', 'Could not send the verification email. Check your SMTP setup under Email Settings.' );
        }
        return true;
    }

    /* ----------------- Channel: Twilio ----------------- */
    private static function send_twilio( $to, $code, $form_title ) {
        $cfg  = self::settings();
        $tw   = isset( $cfg['twilio'] ) ? $cfg['twilio'] : [];
        $sid  = isset( $tw['account_sid'] ) ? trim( $tw['account_sid'] ) : '';
        $auth = isset( $tw['auth_token'] )  ? trim( $tw['auth_token'] )  : '';
        $from = isset( $tw['from_number'] ) ? trim( $tw['from_number'] ) : '';
        if ( ! $sid || ! $auth || ! $from ) {
            return new WP_Error( 'otp_twilio_unconfigured', 'Twilio is not configured — add your Account SID, Auth Token and From Number under Settings → OTP / SMS.' );
        }
        // Pre-check: Twilio rejects when To == From. Catching it here gives
        // the visitor a friendlier message than the raw API error.
        $norm = fn( $n ) => preg_replace( '/\D/', '', (string) $n );
        if ( $norm( $to ) === $norm( $from ) ) {
            return new WP_Error(
                'otp_twilio_same_number',
                'You can\'t send the code to the same number that\'s configured as the Twilio "From Number". Use a different phone number, or buy a proper Twilio number to send from.'
            );
        }
        $url = 'https://api.twilio.com/2010-04-01/Accounts/' . rawurlencode( $sid ) . '/Messages.json';
        $msg = sprintf( '%s verification code: %s. Expires in %d minutes.',
            wp_strip_all_tags( $form_title ),
            $code,
            (int) ( self::TTL_SECONDS / 60 )
        );
        $resp = wp_remote_post( $url, [
            'timeout' => 15,
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode( $sid . ':' . $auth ),
            ],
            'body' => [
                'To'   => $to,
                'From' => $from,
                'Body' => $msg,
            ],
        ] );
        if ( is_wp_error( $resp ) ) {
            return new WP_Error( 'otp_twilio_http', 'Twilio request failed: ' . $resp->get_error_message() );
        }
        $code_http = wp_remote_retrieve_response_code( $resp );
        $body      = json_decode( wp_remote_retrieve_body( $resp ), true );
        if ( $code_http < 200 || $code_http >= 300 ) {
            $err_code = is_array( $body ) && isset( $body['code'] )    ? (int) $body['code']    : 0;
            $err_msg  = is_array( $body ) && isset( $body['message'] ) ? $body['message']       : 'HTTP ' . $code_http;
            // Map common Twilio error codes to actionable messages.
            // https://www.twilio.com/docs/api/errors
            $friendly = self::twilio_friendly_error( $err_code, $err_msg );
            return new WP_Error( 'otp_twilio_failed', $friendly );
        }
        return true;
    }

    /**
     * Convert raw Twilio error codes into something a non-developer admin can
     * act on. Falls back to the raw message for codes we don't recognize.
     */
    private static function twilio_friendly_error( $code, $raw ) {
        switch ( $code ) {
            case 21212: return 'Your Twilio "From Number" is invalid. Set a Twilio-purchased number (starts with "+", e.g. +12025550100).';
            case 21266: // "To and From cannot be the same"
            case 21617: return 'Twilio won\'t send a message to the same number that\'s sending it. Try a different recipient number, or buy a Twilio number to use as From.';
            case 21408: return 'Twilio doesn\'t allow sending to this region from your account. Enable Geo Permissions in the Twilio console.';
            case 21610: return 'This number has unsubscribed from your Twilio account. Re-subscribe it from the Twilio console before retrying.';
            case 21211: return 'The recipient phone number isn\'t valid. Use international format with a leading "+", e.g. +14155552671.';
            case 21219: return 'Your Twilio trial account can only send to verified numbers. Verify the recipient at twilio.com/console/phone-numbers/verified, or upgrade to a paid account.';
            case 21606: return 'The Twilio "From Number" isn\'t SMS-capable or isn\'t owned by your account. Use a Twilio-purchased SMS number.';
            case 20003: return 'Twilio authentication failed. Re-check your Account SID + Auth Token.';
            default:    return 'Twilio rejected the message' . ( $code ? ' (code ' . $code . ')' : '' ) . ': ' . $raw;
        }
    }

    /* ----------------- Channel: MSG91 ----------------- */
    private static function send_msg91( $to, $code, $form_title ) {
        $cfg     = self::settings();
        $m       = isset( $cfg['msg91'] ) ? $cfg['msg91'] : [];
        $authkey = isset( $m['auth_key'] )   ? trim( $m['auth_key'] )   : '';
        $tplid   = isset( $m['template_id'] ) ? trim( $m['template_id'] ) : '';
        $sender  = isset( $m['sender_id'] )   ? trim( $m['sender_id'] )   : '';
        if ( ! $authkey ) {
            return new WP_Error( 'otp_msg91_unconfigured', 'MSG91 is not configured — add your Auth Key (and DLT template ID, if in India) under Settings → OTP / SMS.' );
        }
        // MSG91 wants the phone number without the leading "+".
        $clean_to = ltrim( $to, '+' );

        // Prefer MSG91's OTP API which renders the code into a DLT-approved
        // template. Falls back to the generic Flow API if no template id is set.
        if ( $tplid ) {
            $url = 'https://control.msg91.com/api/v5/otp?template_id=' . rawurlencode( $tplid )
                 . '&mobile=' . rawurlencode( $clean_to )
                 . '&authkey=' . rawurlencode( $authkey )
                 . '&otp=' . rawurlencode( $code );
            $resp = wp_remote_get( $url, [ 'timeout' => 15 ] );
        } else {
            $body = wp_json_encode( [
                'sender'     => $sender ?: 'FCPOTP',
                'route'      => '4',
                'country'    => '0',
                'sms'        => [[
                    'message' => sprintf( '%s verification code: %s. Expires in %d minutes.',
                        wp_strip_all_tags( $form_title ),
                        $code,
                        (int) ( self::TTL_SECONDS / 60 )
                    ),
                    'to'      => [ $clean_to ],
                ]],
            ] );
            $resp = wp_remote_post( 'https://api.msg91.com/api/v2/sendsms', [
                'timeout' => 15,
                'headers' => [
                    'authkey'      => $authkey,
                    'Content-Type' => 'application/json',
                ],
                'body' => $body,
            ] );
        }
        if ( is_wp_error( $resp ) ) {
            return new WP_Error( 'otp_msg91_http', 'MSG91 request failed: ' . $resp->get_error_message() );
        }
        $code_http = wp_remote_retrieve_response_code( $resp );
        $body_str  = wp_remote_retrieve_body( $resp );
        $parsed    = json_decode( $body_str, true );
        if ( $code_http >= 200 && $code_http < 300 ) {
            // MSG91 returns { "type":"success", "message":"<id>" } on success
            if ( is_array( $parsed ) && isset( $parsed['type'] ) && $parsed['type'] === 'error' ) {
                return new WP_Error( 'otp_msg91_failed', 'MSG91 rejected the message: ' . ( $parsed['message'] ?? 'unknown' ) );
            }
            return true;
        }
        return new WP_Error( 'otp_msg91_failed', 'MSG91 HTTP ' . $code_http . ': ' . substr( $body_str, 0, 200 ) );
    }
}
