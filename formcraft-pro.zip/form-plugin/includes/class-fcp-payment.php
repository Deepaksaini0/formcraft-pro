<?php
/**
 * FormCraft Pro - Payment manager.
 *
 * Routes payment requests to the right gateway adapter. Each gateway
 * lives in includes/gateways/ and implements the FCP_Gateway interface:
 *
 *   create_order( $args )   → returns checkout-ready order data
 *   verify_payment( $args ) → returns true/false (and amount paid)
 *   handle_webhook( $body, $headers ) → processes async events
 *
 * Keeps the REST layer thin — class-fcp-rest.php just dispatches
 * here, the gateway does the work.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once FCP_PATH . 'includes/gateways/class-fcp-gateway-razorpay.php';
require_once FCP_PATH . 'includes/gateways/class-fcp-gateway-stripe.php';
require_once FCP_PATH . 'includes/gateways/class-fcp-gateway-cashfree.php';
require_once FCP_PATH . 'includes/gateways/class-fcp-gateway-instamojo.php';
require_once FCP_PATH . 'includes/gateways/class-fcp-gateway-paypal.php';
require_once FCP_PATH . 'includes/gateways/class-fcp-gateway-authorize.php';
require_once FCP_PATH . 'includes/gateways/class-fcp-gateway-square.php';
require_once FCP_PATH . 'includes/gateways/class-fcp-gateway-mollie.php';
require_once FCP_PATH . 'includes/gateways/class-fcp-gateway-paystack.php';
require_once FCP_PATH . 'includes/gateways/class-fcp-gateway-mercadopago.php';

class FCP_Payment {

    /**
     * Return an instantiated gateway for the given slug, or WP_Error.
     */
    public static function get_gateway( $slug ) {
        $settings = get_option( 'fcp_settings', [] );
        $cfg      = isset( $settings['payment'][ $slug ] ) ? $settings['payment'][ $slug ] : [];
        $test     = ! empty( $settings['payment']['test_mode'] );

        if ( empty( $cfg['enabled'] ) ) {
            return new WP_Error( 'disabled', sprintf( '%s is not enabled in Payment Gateway settings.', ucfirst( $slug ) ) );
        }

        switch ( $slug ) {
            case 'razorpay':    return new FCP_Gateway_Razorpay(    $cfg, $test );
            case 'stripe':      return new FCP_Gateway_Stripe(      $cfg, $test );
            case 'cashfree':    return new FCP_Gateway_Cashfree(    $cfg, $test );
            case 'instamojo':   return new FCP_Gateway_Instamojo(   $cfg, $test );
            case 'paypal':      return new FCP_Gateway_PayPal(      $cfg, $test );
            case 'authorize':   return new FCP_Gateway_Authorize(   $cfg, $test );
            case 'square':      return new FCP_Gateway_Square(      $cfg, $test );
            case 'mollie':      return new FCP_Gateway_Mollie(      $cfg, $test );
            case 'paystack':    return new FCP_Gateway_Paystack(    $cfg, $test );
            case 'mercadopago': return new FCP_Gateway_MercadoPago( $cfg, $test );
        }
        return new WP_Error( 'unknown_gateway', 'Unknown payment gateway: ' . $slug );
    }

    /**
     * Map gateway slug → human label for UI.
     */
    public static function label( $slug ) {
        $labels = [
            'razorpay'    => 'Razorpay',
            'stripe'      => 'Stripe',
            'cashfree'    => 'Cashfree',
            'instamojo'   => 'Instamojo',
            'paypal'      => 'PayPal',
            'authorize'   => 'Authorize.net',
            'square'      => 'Square',
            'mollie'      => 'Mollie',
            'paystack'    => 'Paystack',
            'mercadopago' => 'Mercado Pago',
        ];
        return $labels[ $slug ] ?? ucfirst( $slug );
    }
}

/**
 * Shared base class with helpers each gateway can reuse.
 */
abstract class FCP_Gateway_Base {
    protected $cfg;
    protected $test_mode;

    public function __construct( $cfg, $test_mode = false ) {
        $this->cfg       = is_array( $cfg ) ? $cfg : [];
        $this->test_mode = (bool) $test_mode;
    }

    /** Quick wrapper for wp_remote_request returning decoded JSON or WP_Error. */
    protected function http( $url, $args = [] ) {
        $args = array_merge( [ 'timeout' => 30 ], $args );
        $res  = wp_remote_request( $url, $args );
        if ( is_wp_error( $res ) ) return $res;
        $code = wp_remote_retrieve_response_code( $res );
        $body = wp_remote_retrieve_body( $res );
        $json = json_decode( $body, true );
        if ( $code < 200 || $code >= 300 ) {
            $msg = is_array( $json ) && isset( $json['error']['description'] )
                ? $json['error']['description']
                : ( is_array( $json ) && isset( $json['message'] ) ? $json['message'] : $body );
            return new WP_Error( 'http_' . $code, $msg, [ 'status' => $code, 'response' => $json ] );
        }
        return is_array( $json ) ? $json : [];
    }

    /** Generate a unique idempotency-safe order reference. */
    protected function gen_ref() {
        return 'fcp_' . wp_generate_password( 10, false );
    }

    abstract public function slug();
    abstract public function create_order( $args );
    abstract public function verify_payment( $args );
    public function handle_webhook( $body, $headers ) { return new WP_Error( 'not_implemented', 'Webhook not implemented for this gateway.' ); }
    public function refund( $payment_id, $amount = null ) { return new WP_Error( 'not_implemented', 'Refunds not implemented for this gateway.' ); }
}
