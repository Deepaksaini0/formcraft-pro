/* ============================================================
   FormCraft Pro - WordPress Bridge
   Activates whenever the admin pages are loaded inside wp-admin.
   The WordPress context (REST base, nonce, current user) arrives
   in the URL on the very first iframe load, but is then persisted
   to sessionStorage so it survives every subsequent in-iframe
   navigation (e.g. clicking sidebar links inside the iframe).
   ============================================================ */
(function (global) {
    "use strict";

    const SS    = window.sessionStorage;
    const params = new URLSearchParams(location.search);

    // ---- Persist or recover the WP context --------------------
    function persist(k, v) { if (v) SS.setItem(k, v); }
    if (params.get("wp_user") === "1" && params.get("wp_rest")) {
        persist("fcp_wp_rest",       params.get("wp_rest"));
        persist("fcp_wp_nonce",      params.get("wp_nonce"));
        persist("fcp_wp_user",       "1");
        persist("fcp_wp_user_id",    params.get("wp_user_id"));
        persist("fcp_wp_user_name",  params.get("wp_user_name"));
        persist("fcp_wp_user_email", params.get("wp_user_email"));
        persist("fcp_wp_user_role",  params.get("wp_user_role"));
        if (params.get("fcpv")) persist("fcp_v", params.get("fcpv"));
    }

    // Detect when the user has upgraded the plugin — drop the cached
    // localStorage state so refreshed JS sees a clean slate that will
    // re-sync from the server.
    const cachedVer  = SS.getItem("fcp_last_seen_version");
    const currentVer = params.get("fcpv") || SS.getItem("fcp_v") || "";
    if (currentVer && cachedVer && cachedVer !== currentVer && typeof FCData !== "undefined") {
        const fresh = FCData.load();
        fresh.ui.wpSyncDone = false; // force a re-sync on next page
        FCData.save(fresh);
    }
    if (currentVer) SS.setItem("fcp_last_seen_version", currentVer);
    const restBase  = params.get("wp_rest")  || SS.getItem("fcp_wp_rest");
    const restNonce = params.get("wp_nonce") || SS.getItem("fcp_wp_nonce");
    const wpFlag    = params.get("wp_user")  || SS.getItem("fcp_wp_user");
    const inWP      = wpFlag === "1" && restBase && restNonce;

    if (!inWP) {
        global.FCBridge = { enabled: false };
        return; // standalone HTML mode — leave demo state intact
    }

    function initials(name) {
        if (!name) return "A";
        const parts = name.trim().split(/\s+/);
        if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
        return parts[0].slice(0, 2).toUpperCase();
    }

    // ---- Apply WP user + wipe demo data exactly once ----------
    if (typeof FCData !== "undefined") {
        const state    = FCData.load();
        const userName = decodeURIComponent(params.get("wp_user_name")  || SS.getItem("fcp_wp_user_name")  || "Administrator");
        const userMail = decodeURIComponent(params.get("wp_user_email") || SS.getItem("fcp_wp_user_email") || "");
        const userRole = decodeURIComponent(params.get("wp_user_role")  || SS.getItem("fcp_wp_user_role")  || "Administrator");
        const userId   = params.get("wp_user_id") || SS.getItem("fcp_wp_user_id") || "current";

        if (!state.ui.wpSyncDone) {
            // First time inside WP — wipe the standalone demo data so
            // the dashboard starts empty.
            state.forms       = [];
            state.submissions = [];
            state.ui.wpSyncDone = true;
        }

        // Always refresh the current user across the UI.
        state.users = [{
            id:        "u_wp_" + userId,
            name:      userName,
            email:     userMail,
            role:      userRole,
            status:    "active",
            avatar:    initials(userName),
            lastLogin: new Date().toISOString()
        }];
        state.user = {
            name:   userName,
            email:  userMail,
            role:   userRole,
            avatar: initials(userName)
        };
        state.ui.onboarded = true; // skip the standalone onboarding wizard
        FCData.save(state);
    }

    // ---- REST client ------------------------------------------
    function req(path, opts) {
        opts = opts || {};
        return fetch(restBase.replace(/\/$/, "") + "/" + path.replace(/^\//, ""), {
            method: opts.method || "GET",
            credentials: "same-origin",
            headers: {
                "Content-Type": "application/json",
                "X-WP-Nonce": restNonce
            },
            body: opts.body ? JSON.stringify(opts.body) : undefined
        }).then(r => r.text().then(txt => {
            // Some endpoints (DELETE, status-only updates) return an empty
            // body or a 204. Falling back to {} instead of letting JSON.parse
            // explode means callers can safely .then() on every response.
            let json = {};
            if (txt) {
                try { json = JSON.parse(txt); }
                catch (e) { json = { _raw: txt }; }
            }
            return r.ok ? json : Promise.reject(json);
        }));
    }

    // Truthy check that handles MySQL's stringy "0"/"1" values.
    const truthy = v => v === true || v === 1 || v === "1";

    // Map a server-side submission row into the shape used by the admin UI.
    function mapSubmission(s, forms) {
        const data    = (typeof s.data === "string") ? JSON.parse(s.data || "{}") : (s.data || {});
        const formId  = parseInt(s.form_id, 10);
        const matched = (forms || []).find(f => parseInt(f.wpId, 10) === formId);
        return {
            id:        "sub_" + s.id,
            wpId:      parseInt(s.id, 10),
            formId:    "form_" + formId,
            formTitle: (matched || {}).title || "—",
            name:      s.submitter_name || "Anonymous",
            email:     s.submitter_email || "",
            phone:     data.phone || data.Phone || "",
            ip:        s.ip_address || "",
            country:   s.country || "",
            browser:   s.browser || "",
            device:    s.device || "",
            read:      truthy(s.is_read),
            spam:      truthy(s.is_spam),
            notes:     s.notes || "",
            paymentStatus:   s.payment_status   || "none",
            paymentProvider: s.payment_provider || "",
            paymentId:       s.payment_id       || "",
            paymentAmount:   parseFloat(s.payment_amount) || 0,
            paymentCurrency: s.payment_currency || "",
            paidAt:          s.paid_at || "",
            couponCode:           s.coupon_code            || "",
            couponDiscount:       parseFloat(s.coupon_discount)        || 0,
            couponOriginalAmount: parseFloat(s.coupon_original_amount) || 0,
            wcOrderId:     parseInt(s.wc_order_id, 10) || 0,
            wcOrderStatus: s.wc_order_status || "",
            wcOrderTotal:  parseFloat(s.wc_order_total) || 0,
            wcOrderUrl:    s.wc_order_url || "",
            approvalStatus: s.approval_status || "none",
            approvalNote:   s.approval_note   || "",
            journey:        s.journey || "",
            createdAt: (s.created_at || "").replace(" ", "T") + "Z",
            data:      data
        };
    }

    function mapForm(f) {
        return { ...f, id: "form_" + f.id, wpId: f.id };
    }

    const Bridge = {
        enabled: true,
        version: currentVer,
        ctx: { restBase, restNonce },

        listForms:        ()        => req("forms"),
        getForm:    (id)            => req("forms/" + id),
        createForm: (form)          => req("forms",         { method: "POST",   body: form }),
        updateForm: (id, form)      => req("forms/" + id,   { method: "PUT",    body: form }),
        deleteForm: (id)            => req("forms/" + id,   { method: "DELETE" }),
        importForm: (form)          => req("forms/import",  { method: "POST",   body: { form } }),
        setFormStatus: (id, status) => req("forms/" + id + "/status", { method: "POST", body: { status } }),
        listRevisions:   (id)       => req("forms/" + id + "/revisions"),
        restoreRevision: (id, rid)  => req("forms/" + id + "/revisions/" + rid + "/restore", { method: "POST", body: {} }),
        getDropoff:      (id, days) => req("forms/" + id + "/dropoff" + (days ? "?days=" + days : "")),

        listSubmissions: (qs)       => req("submissions" + (qs ? "?" + qs : "")),
        getSubmission:   (id)       => req("submissions/" + id),
        updateSubmission:(id, c)    => req("submissions/" + id, { method: "PUT", body: c }),
        deleteSubmission:(id)       => req("submissions/" + id, { method: "DELETE" }),
        verifyPayment:   (id, verified, note) => req("submissions/" + id + "/verify-payment", { method: "POST", body: { verified: !!verified, note: note || "" } }),
        approveSubmission: (id, decision, note) => req("submissions/" + id + "/approve", { method: "POST", body: { decision: decision, note: note || "" } }),
        // v2.52 — Submission workflow endpoints
        setSubmissionAssignee:    (id, userId)              => req("submissions/" + id + "/assignee",    { method: "POST", body: { user_id: userId || null } }),
        addSubmissionComment:     (id, text)                => req("submissions/" + id + "/comment",     { method: "POST", body: { text } }),
        inlineEditSubmissionField:(id, field, value)        => req("submissions/" + id + "/field",       { method: "POST", body: { field, value } }),
        sendReplyEmail:           (id, subject, message)    => req("submissions/" + id + "/reply-email", { method: "POST", body: { subject, message } }),
        markSubmissionSpam:       (id, spam)                => req("submissions/" + id + "/mark-spam",   { method: "POST", body: { spam: !!spam } }),
        listWpUsers:              ()                        => req("users-list"),

        getSettings:    ()          => req("settings"),
        updateSettings: (s)         => req("settings", { method: "PUT", body: s }),
        getStats:       ()          => req("stats"),
        submit: (formId, data)      => req("forms/" + formId + "/submit", { method: "POST", body: { data } }),

        listCoupons:    ()              => req("coupons"),
        createCoupon:   (c)             => req("coupons",       { method: "POST",   body: c }),
        updateCoupon:   (id, c)         => req("coupons/" + id, { method: "PUT",    body: c }),
        deleteCoupon:   (id)            => req("coupons/" + id, { method: "DELETE" }),
        validateCoupon: (code, amount, formId) => req("coupons/validate", { method: "POST", body: { code, amount, form_id: formId } }),

        listWebhooks:   ()              => req("webhooks"),
        createWebhook:  (w)             => req("webhooks",       { method: "POST",   body: w }),
        updateWebhook:  (id, w)         => req("webhooks/" + id, { method: "PUT",    body: w }),
        deleteWebhook:  (id)            => req("webhooks/" + id, { method: "DELETE" }),
        testWebhook:    (id)            => req("webhooks/" + id + "/test", { method: "POST", body: {} }),

        aiGenerateForm:   (prompt)              => req("ai/generate-form",    { method: "POST", body: { prompt } }),
        // v2.58 — AI Smart Layer
        aiDetectPurpose:  (form)                => req("ai/detect-purpose",   { method: "POST", body: { form } }),
        aiNormalizeLabels:(labels)              => req("ai/normalize-labels", { method: "POST", body: { labels } }),
        aiSuggestFields:  (form)                => req("ai/suggest-fields",   { method: "POST", body: { form } }),
        aiDraftReply:     (subId, tone)         => req("ai/draft-reply",      { method: "POST", body: { sub_id: subId, tone: tone || "professional" } }),
        aiCategorize:     (subId)               => req("ai/categorize",       { method: "POST", body: { sub_id: subId } }),
        aiSentiment:      (subId)               => req("ai/sentiment",        { method: "POST", body: { sub_id: subId } }),
        aiOcr:            (subId, field, url)   => req("ai/ocr",              { method: "POST", body: { sub_id: subId || 0, field: field || "", image_url: url || "" } }),
        // v2.59 — i18n batch translation (DeepL → Google → Anthropic, picked server-side)
        i18nTranslate:    (strings, target, src) => req("i18n/translate",     { method: "POST", body: { strings, target_lang: target, source_lang: src || "en" } }),
        // v2.61 — Security depth: 2FA, audit log, GDPR, RTBF
        // v2.61.1 — Path is /twofa/ not /2fa/. Some shared hosts'
        // WAFs (Cloudflare, Sucuri, Wordfence basic) treat REST paths
        // starting with a digit as suspicious and 404 them at the edge.
        twofaStatus:      ()                    => req("twofa/status"),
        twofaEnroll:      ()                    => req("twofa/enroll",        { method: "POST", body: {} }),
        twofaConfirm:     (code)                => req("twofa/confirm",       { method: "POST", body: { code } }),
        twofaVerify:      (code)                => req("twofa/verify",        { method: "POST", body: { code } }),
        twofaDisable:     (code)                => req("twofa/disable",       { method: "POST", body: { code } }),
        auditList:        (params)              => req("audit/list" + (params ? "?" + new URLSearchParams(params).toString() : "")),
        auditSummary:     ()                    => req("audit/summary"),
        piiInventory:     ()                    => req("pii/inventory"),
        piiLookup:        (email)               => req("pii/lookup",          { method: "POST", body: { email } }),
        piiForget:        (email, hard)         => req("pii/forget",          { method: "POST", body: { email, hard_delete: !!hard } }),
        // v2.64 — SaaS / monetization layer
        saasBrandGet:     ()                    => req("saas/brand"),
        saasBrandSave:    (brand)               => req("saas/brand",          { method: "POST", body: brand }),
        saasLicenseGet:   ()                    => req("saas/license"),
        saasLicenseSave:  (server)              => req("saas/license",        { method: "POST", body: { license_server: server } }),
        saasActivate:     (key)                 => req("saas/license/activate",   { method: "POST", body: { key } }),
        saasDeactivate:   ()                    => req("saas/license/deactivate", { method: "POST", body: {} }),
        saasUsage:        ()                    => req("saas/usage"),
        saasEmbedToken:   (formId, ttl)         => req("saas/embed-token",    { method: "POST", body: { form_id: formId, ttl: ttl || 3600 } }),
        // v2.65 — Help / onboarding / diagnostics
        helpDiagnostics:  ()                    => req("help/diagnostics"),
        helpTips:         ()                    => req("help/tips"),
        helpTutorials:    ()                    => req("help/tutorials"),
        spamLog:        (limit)         => req("spam-log" + (limit ? "?limit=" + limit : "")),

        wcStatus:       ()              => req("wc/status"),
        wcProducts:     (search)        => req("wc/products" + (search ? "?search=" + encodeURIComponent(search) : "")),

        listFormUsers:  (qs)            => req("form-users" + (qs ? "?" + qs : "")),
        updateFormUser: (id, body)      => req("form-users/" + id, { method: "PUT",    body: body }),
        deleteFormUser: (id)            => req("form-users/" + id, { method: "DELETE" }),

        getMembership:  ()              => req("membership"),
        setMembership:  (enabled)       => req("membership", { method: "POST", body: { enabled: !!enabled } }),

        listAbandoned:    (qs)              => req("abandoned" + (qs ? "?" + qs : "")),
        deleteAbandoned:  (id)              => req("abandoned/" + id, { method: "DELETE" }),
        sendAbandonedRecovery: (id)         => req("abandoned/" + id + "/recover", { method: "POST", body: {} }),

        // 1-Click Migration
        migratorDetect:           ()       => req("migrator/detect"),
        migratorListForms:        (source) => req("migrator/" + encodeURIComponent(source) + "/forms"),
        migratorImport:           (body)   => req("migrator/import", { method: "POST", body }),
        migratorDryRun:           (body)   => req("migrator/dry-run", { method: "POST", body }),
        migratorHistory:          ()       => req("migrator/history"),
        migratorRollback:         (id)     => req("migrator/rollback/" + id, { method: "POST", body: {} }),
        migratorCompatibility:    ()       => req("migrator/compatibility"),
        migratorReplaceShortcodes:(body)   => req("migrator/replace-shortcodes", { method: "POST", body }),
        migratorTestNotification: (formId) => req("migrator/test-notification", { method: "POST", body: { form_id: formId } }),
        sendDigestNow:            ()        => req("digest/send-now", { method: "POST", body: {} }),

        airtableTest:       (pat)            => req("integrations/airtable/test",   { method: "POST", body: { pat: pat || "" } }),
        airtableListBases:  ()               => req("integrations/airtable/bases"),
        airtableListTables: (baseId)         => req("integrations/airtable/tables?base=" + encodeURIComponent(baseId)),

        /**
         * Re-fetch all submissions from the server, map them, persist
         * to localStorage, and return the mapped array. Use this after
         * any bulk action so the UI reflects authoritative server state
         * (no race conditions with the initial async sync).
         */
        syncSubmissions: function () {
            return Bridge.listSubmissions().then(subs => {
                if (typeof FCData === "undefined") return [];
                const s = FCData.load();
                s.submissions = Array.isArray(subs) ? subs.map(sb => mapSubmission(sb, s.forms)) : [];
                FCData.save(s);
                return s.submissions;
            });
        },

        /**
         * Re-fetch all forms (used after duplicate / import / delete).
         */
        syncForms: function () {
            return Bridge.listForms().then(forms => {
                if (typeof FCData === "undefined") return [];
                const s = FCData.load();
                s.forms = Array.isArray(forms) ? forms.map(mapForm) : [];
                FCData.save(s);
                return s.forms;
            });
        },

        /**
         * Create or update a form against WordPress and rewrite the local
         * cache so the form's `id` becomes "form_<wpId>" once persisted.
         * Returns { form, isNew, oldId }.
         */
        saveForm: function (form) {
            const oldId    = form.id;
            const isUpdate = !!form.wpId;
            const payload  = JSON.parse(JSON.stringify(form));
            delete payload.id; // server owns the numeric id

            const promise = isUpdate
                ? Bridge.updateForm(form.wpId, payload)
                : Bridge.createForm(payload);

            return promise.then(saved => {
                form.wpId  = saved.id;
                form.id    = "form_" + saved.id;
                if (saved.views       !== undefined) form.views       = saved.views;
                if (saved.submissions !== undefined) form.submissions = saved.submissions;
                if (saved.created_at)               form.createdAt    = saved.created_at;
                if (saved.updated_at)               form.updatedAt    = saved.updated_at;

                // Rewrite the local cache: drop the old (random) id row and
                // upsert the new wpId-based row.
                if (typeof FCData !== "undefined") {
                    const s = FCData.load();
                    s.forms = s.forms.filter(f => f.id !== oldId && f.id !== form.id);
                    s.forms.unshift(form);
                    FCData.save(s);
                }

                return { form: form, isNew: !isUpdate, oldId: oldId };
            });
        }
    };

    global.FCBridge = Bridge;

    /* --------------------------------------------------------
     * Async sync: pull live forms / submissions / settings and
     * mirror them into localStorage, then dispatch a DOM event
     * so pages can re-render with fresh data.
     * -------------------------------------------------------- */
    if (typeof FCData !== "undefined") {
        Promise.all([ Bridge.listForms(), Bridge.listSubmissions(), Bridge.getSettings() ])
            .then(([forms, subs, settings]) => {
                const state = FCData.load();

                state.forms       = Array.isArray(forms) ? forms.map(mapForm) : [];
                state.submissions = Array.isArray(subs)  ? subs.map(sb => mapSubmission(sb, state.forms)) : [];

                if (settings) {
                    // Pull every general-tab field straight from the server-side
                    // defaults so the WordPress timezone, currency, locale, etc.
                    // appear pre-filled on first load instead of the bundled JS
                    // seeds. Falls back to the JS seed only when the server omits
                    // a key (e.g. on very old installs that haven't been re-saved).
                    state.settings.general.siteName   = settings.general?.site_name   || state.settings.general.siteName;
                    state.settings.general.adminEmail = settings.general?.admin_email || state.settings.general.adminEmail;
                    state.settings.general.timezone   = settings.general?.timezone    || state.settings.general.timezone;
                    state.settings.general.currency   = settings.general?.currency    || state.settings.general.currency;
                    state.settings.general.dateFormat = settings.general?.date_format || state.settings.general.dateFormat;
                    state.settings.general.language   = settings.general?.language    || state.settings.general.language;
                    state.settings.recaptcha = {
                        enabled:        !!settings.recaptcha?.enabled,
                        provider:       settings.recaptcha?.provider || "recaptcha",
                        version:        settings.recaptcha?.version  || "v3",
                        siteKey:        settings.recaptcha?.site_key || "",
                        secretKey:      settings.recaptcha?.secret_key || "",
                        autoInject:     !!settings.recaptcha?.auto_inject,
                        scoreThreshold: settings.recaptcha?.score_threshold || 0.5,
                        hcaptcha: {
                            siteKey:   settings.recaptcha?.hcaptcha?.site_key   || "",
                            secretKey: settings.recaptcha?.hcaptcha?.secret_key || ""
                        },
                        turnstile: {
                            siteKey:   settings.recaptcha?.turnstile?.site_key   || "",
                            secretKey: settings.recaptcha?.turnstile?.secret_key || ""
                        }
                    };
                    state.settings.maps = {
                        google_api_key: settings.maps?.google_api_key || ""
                    };
                    state.settings.ai = {
                        enabled: !!(settings.ai?.enabled),
                        api_key: settings.ai?.api_key || "",
                        model:   settings.ai?.model   || "claude-haiku-4-5-20251001"
                    };
                    state.settings.otp = {
                        default_cc:      settings.otp?.default_cc      || "+91",
                        default_channel: settings.otp?.default_channel || "email",
                        twilio: {
                            enabled:     !!(settings.otp?.twilio?.enabled),
                            account_sid: settings.otp?.twilio?.account_sid || "",
                            auth_token:  settings.otp?.twilio?.auth_token  || "",
                            from_number: settings.otp?.twilio?.from_number || ""
                        },
                        msg91: {
                            enabled:     !!(settings.otp?.msg91?.enabled),
                            auth_key:    settings.otp?.msg91?.auth_key    || "",
                            template_id: settings.otp?.msg91?.template_id || "",
                            sender_id:   settings.otp?.msg91?.sender_id   || ""
                        }
                    };
                    state.settings.integrations = {
                        mailchimp: {
                            enabled:     !!(settings.integrations?.mailchimp?.enabled),
                            api_key:     settings.integrations?.mailchimp?.api_key     || "",
                            audience_id: settings.integrations?.mailchimp?.audience_id || "",
                            datacenter:  settings.integrations?.mailchimp?.datacenter  || ""
                        },
                        hubspot: {
                            enabled:   !!(settings.integrations?.hubspot?.enabled),
                            api_token: settings.integrations?.hubspot?.api_token || ""
                        },
                        slack: {
                            enabled:     !!(settings.integrations?.slack?.enabled),
                            webhook_url: settings.integrations?.slack?.webhook_url || ""
                        },
                        activecampaign: {
                            enabled: !!(settings.integrations?.activecampaign?.enabled),
                            api_url: settings.integrations?.activecampaign?.api_url || "",
                            api_key: settings.integrations?.activecampaign?.api_key || "",
                            list_id: settings.integrations?.activecampaign?.list_id || ""
                        },
                        convertkit: {
                            enabled:    !!(settings.integrations?.convertkit?.enabled),
                            api_key:    settings.integrations?.convertkit?.api_key    || "",
                            api_secret: settings.integrations?.convertkit?.api_secret || "",
                            form_id:    settings.integrations?.convertkit?.form_id    || ""
                        },
                        salesforce: {
                            enabled:       !!(settings.integrations?.salesforce?.enabled),
                            client_id:     settings.integrations?.salesforce?.client_id     || "",
                            client_secret: settings.integrations?.salesforce?.client_secret || "",
                            refresh_token: settings.integrations?.salesforce?.refresh_token || "",
                            instance_url:  settings.integrations?.salesforce?.instance_url  || ""
                        },
                        zoho_crm: {
                            enabled:       !!(settings.integrations?.zoho_crm?.enabled),
                            client_id:     settings.integrations?.zoho_crm?.client_id     || "",
                            client_secret: settings.integrations?.zoho_crm?.client_secret || "",
                            refresh_token: settings.integrations?.zoho_crm?.refresh_token || "",
                            region:        settings.integrations?.zoho_crm?.region        || "com",
                            module:        settings.integrations?.zoho_crm?.module        || "Leads"
                        },
                        dropbox: {
                            enabled:      !!(settings.integrations?.dropbox?.enabled),
                            access_token: settings.integrations?.dropbox?.access_token || "",
                            folder_path:  settings.integrations?.dropbox?.folder_path  || "/FormCraft"
                        },
                        google_drive: {
                            enabled:       !!(settings.integrations?.google_drive?.enabled),
                            client_id:     settings.integrations?.google_drive?.client_id     || "",
                            client_secret: settings.integrations?.google_drive?.client_secret || "",
                            refresh_token: settings.integrations?.google_drive?.refresh_token || "",
                            folder_id:     settings.integrations?.google_drive?.folder_id     || ""
                        },
                        zapier: { enabled: !!(settings.integrations?.zapier?.enabled) },
                        brevo: {
                            enabled: !!(settings.integrations?.brevo?.enabled),
                            api_key: settings.integrations?.brevo?.api_key || "",
                            list_id: settings.integrations?.brevo?.list_id || ""
                        },
                        aweber: {
                            enabled:      !!(settings.integrations?.aweber?.enabled),
                            access_token: settings.integrations?.aweber?.access_token || "",
                            account_id:   settings.integrations?.aweber?.account_id   || "",
                            list_id:      settings.integrations?.aweber?.list_id      || ""
                        },
                        campaign_monitor: {
                            enabled: !!(settings.integrations?.campaign_monitor?.enabled),
                            api_key: settings.integrations?.campaign_monitor?.api_key || "",
                            list_id: settings.integrations?.campaign_monitor?.list_id || ""
                        },
                        breeze: {
                            enabled:     !!(settings.integrations?.breeze?.enabled),
                            webhook_url: settings.integrations?.breeze?.webhook_url || "",
                            api_key:     settings.integrations?.breeze?.api_key     || ""
                        },
                        agile_crm: {
                            enabled: !!(settings.integrations?.agile_crm?.enabled),
                            domain:  settings.integrations?.agile_crm?.domain  || "",
                            email:   settings.integrations?.agile_crm?.email   || "",
                            api_key: settings.integrations?.agile_crm?.api_key || ""
                        },
                        mailgun: {
                            enabled:    !!(settings.integrations?.mailgun?.enabled),
                            api_key:    settings.integrations?.mailgun?.api_key    || "",
                            domain:     settings.integrations?.mailgun?.domain     || "",
                            region:     settings.integrations?.mailgun?.region     || "us",
                            from_email: settings.integrations?.mailgun?.from_email || "",
                            from_name:  settings.integrations?.mailgun?.from_name  || "",
                            to_email:   settings.integrations?.mailgun?.to_email   || "{admin}",
                            subject:    settings.integrations?.mailgun?.subject    || "",
                            body:       settings.integrations?.mailgun?.body       || ""
                        },
                        postmark: {
                            enabled:        !!(settings.integrations?.postmark?.enabled),
                            server_token:   settings.integrations?.postmark?.server_token   || "",
                            message_stream: settings.integrations?.postmark?.message_stream || "outbound",
                            from_email:     settings.integrations?.postmark?.from_email     || "",
                            from_name:      settings.integrations?.postmark?.from_name      || "",
                            to_email:       settings.integrations?.postmark?.to_email       || "{admin}",
                            subject:        settings.integrations?.postmark?.subject        || "",
                            body:           settings.integrations?.postmark?.body           || ""
                        },
                        sendgrid: {
                            enabled:    !!(settings.integrations?.sendgrid?.enabled),
                            api_key:    settings.integrations?.sendgrid?.api_key    || "",
                            from_email: settings.integrations?.sendgrid?.from_email || "",
                            from_name:  settings.integrations?.sendgrid?.from_name  || "",
                            to_email:   settings.integrations?.sendgrid?.to_email   || "{admin}",
                            subject:    settings.integrations?.sendgrid?.subject    || "",
                            body:       settings.integrations?.sendgrid?.body       || ""
                        },
                        airtable: {
                            enabled: !!(settings.integrations?.airtable?.enabled),
                            pat:     settings.integrations?.airtable?.pat || ""
                        }
                    };
                    // Ad platforms / social posting / messaging — pass straight
                    // through. The schema is registry-driven on both sides so
                    // we don't need a per-key map here.
                    if (settings.ad_platforms && typeof settings.ad_platforms === "object") {
                        state.settings.ad_platforms = settings.ad_platforms;
                    }
                    // Role permissions matrix — admin-editable in users.html.
                    if (settings.role_permissions && typeof settings.role_permissions === "object") {
                        state.settings.rolePermissions = settings.role_permissions;
                    }
                    if (settings.scheduled_reports && typeof settings.scheduled_reports === "object") {
                        state.settings.scheduled_reports = settings.scheduled_reports;
                    }
                    state.settings.email = {
                        smtpHost:              settings.email?.smtp_host || "",
                        smtpPort:              settings.email?.smtp_port || 587,
                        smtpUser:              settings.email?.smtp_user || "",
                        smtpPass:              settings.email?.smtp_pass || "",
                        encryption:            settings.email?.encryption || "tls",
                        fromName:              settings.email?.from_name  || "",
                        fromEmail:             settings.email?.from_email || "",
                        adminRecipients:       settings.email?.admin_recipients || "",
                        sendUserConfirmation:  !!settings.email?.send_user,
                        sendAdminNotification: !!settings.email?.send_admin,
                        confirmationSubject:   settings.email?.confirmation_subject || "",
                        confirmationBody:      settings.email?.confirmation_body || "",
                        templates:             Array.isArray(settings.email?.templates) ? settings.email.templates : null
                    };
                }

                FCData.save(state);
                document.documentElement.dataset.fcpBridge = "ready";
                document.dispatchEvent(new CustomEvent("fcp:bridge-ready", { detail: state }));
            })
            .catch(err => {
                console.warn("FCBridge initial sync failed:", err);
                document.documentElement.dataset.fcpBridge = "error";
                document.dispatchEvent(new CustomEvent("fcp:bridge-error", { detail: err }));
            });
    }
})(window);
