/* ============================================================
   FormCraft Pro - Shared App Layer
   Sidebar, theme, navigation, toasts, modal, helpers.
   ============================================================ */
(function (global) {
    "use strict";

    const ICONS = {
        // Lightweight inline SVG icon set (24x24 viewBox)
        dashboard: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/></svg>',
        forms: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>',
        submissions: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16v12H4z"/><path d="M4 8h16"/><path d="M9 20l3 2 3-2"/></svg>',
        integrations: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
        analytics: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="M7 15l4-6 3 4 5-7"/></svg>',
        settings: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .4 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.4 1.7 1.7 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.4l-.1.1a2 2 0 0 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .4-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.4-1.8l-.1-.1A2 2 0 0 1 6.9 4l.1.1a1.7 1.7 0 0 0 1.8.4H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.4l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.4 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
        users: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13A4 4 0 0 1 16 11"/></svg>',
        help: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 1 1 5.8 1c0 2-3 3-3 3"/><circle cx="12" cy="17" r="0.5" fill="currentColor"/></svg>',
        search: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>',
        bell: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10 21a2 2 0 0 0 4 0"/></svg>',
        moon: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>',
        sun: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',
        menu: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>',
        chevronRight: '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>',
        plus: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
        edit: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4z"/></svg>',
        trash: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>',
        copy: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',
        eye: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>',
        download: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>',
        upload: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>',
        check: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>',
        x: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>',
        more: '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/></svg>',
        drag: '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><circle cx="9" cy="6" r="1.4"/><circle cx="15" cy="6" r="1.4"/><circle cx="9" cy="12" r="1.4"/><circle cx="15" cy="12" r="1.4"/><circle cx="9" cy="18" r="1.4"/><circle cx="15" cy="18" r="1.4"/></svg>',
        arrowRight: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 5l7 7-7 7"/></svg>',
        arrowLeft: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>',
        save: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8M7 3v5h8"/></svg>',
        play: '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M6 4l14 8-14 8z"/></svg>',
        desktop: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>',
        tablet: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><circle cx="12" cy="18" r="0.5" fill="currentColor"/></svg>',
        mobile: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="7" y="2" width="10" height="20" rx="2"/><circle cx="12" cy="18" r="0.5" fill="currentColor"/></svg>',
        mail: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M22 6l-10 7L2 6"/></svg>',
        shield: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
        eyeoff: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a18.45 18.45 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><path d="M1 1l22 22"/></svg>',
        info: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>',
        zap: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>',
        star: '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>',
        clock: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>',
        externalLink: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6M10 14L21 3"/></svg>',
        ban: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M4.93 4.93l14.14 14.14"/></svg>',
        send: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/></svg>',
        refresh: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>',
        // Field type icons (used in palette)
        type:  '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7V4h16v3M9 20h6M12 4v16"/></svg>',
        textarea: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9h10M7 13h10M7 17h6"/></svg>',
        atSign: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-4 8"/></svg>',
        phone: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.37 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.33 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg>',
        hash: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9h16M4 15h16M10 3l-2 18M16 3l-2 18"/></svg>',
        lock: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
        link: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/></svg>',
        eyeoff2: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a18.45 18.45 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><path d="M1 1l22 22"/></svg>',
        listDown: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M8 10l4 4 4-4"/></svg>',
        radio: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3" fill="currentColor"/></svg>',
        checksq: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M9 12l2 2 4-4"/></svg>',
        toggle: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="7" width="18" height="10" rx="5"/><circle cx="16" cy="12" r="2" fill="currentColor"/></svg>',
        file: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>',
        image: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-5-5L5 21"/></svg>',
        calendar: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>',
        slider: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 12h16"/><circle cx="14" cy="12" r="3" fill="currentColor"/></svg>',
        palette: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="13.5" cy="6.5" r="1.5"/><circle cx="17.5" cy="10.5" r="1.5"/><circle cx="8.5" cy="7.5" r="1.5"/><circle cx="6.5" cy="12.5" r="1.5"/><path d="M12 22a10 10 0 1 1 10-10c0 2.5-3 4-4 4h-3a2 2 0 0 0-1 4 1.5 1.5 0 0 1-1 2z"/></svg>',
        sign: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 20h20"/><path d="M5 16c2-3 4-6 6-6 3 0 2 6 5 6 1 0 2-1 4-2"/></svg>',
        otp: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="6" width="3.5" height="12" rx="1"/><rect x="9" y="6" width="3.5" height="12" rx="1"/><rect x="15" y="6" width="3.5" height="12" rx="1"/></svg>',
        captcha: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M8 12l2.5 2.5L16 9"/></svg>',
        building: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 7h2M7 11h2M7 15h2M13 7h4M13 11h4M13 15h4"/></svg>',
        pin: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
        credit: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/></svg>',
        layout: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>',
        divider: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 12h18"/></svg>',
        code: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 18l6-6-6-6M8 6L2 12l6 6"/></svg>',
        message: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-9 8.5 8.5 8.5 0 0 1-4-1L3 21l1-5a8.5 8.5 0 1 1 17-4.5z"/></svg>',
        trending: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 6l-9.5 9.5L8 10 1 17"/><path d="M17 6h6v6"/></svg>',
        grid: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>',
        folder: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>',
        // Additional icons used to replace emoji throughout the plugin —
        // each is currentColor-friendly so it picks up the surrounding text
        // color, can be scaled by setting font-size on the parent.
        lockClosed: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
        userLock: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="7" r="4"/><path d="M5 21v-1a7 7 0 0 1 7-7h0a7 7 0 0 1 4 1.2"/><rect x="14" y="15" width="8" height="6" rx="1"/><path d="M16 15v-2a2 2 0 0 1 4 0v2"/></svg>',
        globe: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
        cash: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="3"/><path d="M6 12h.01M18 12h.01"/></svg>',
        idea: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18h6M10 22h4M12 2a7 7 0 0 0-4 12.7c.6.5 1 1.3 1 2.1V18h6v-1.2c0-.8.4-1.6 1-2.1A7 7 0 0 0 12 2z"/></svg>',
        videoCam: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 7l-7 5 7 5V7z"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>',
        phoneIn: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.8a2 2 0 0 1-.45 2.11L8 9.91a16 16 0 0 0 6 6l1.27-1.36a2 2 0 0 1 2.11-.45c.9.34 1.84.57 2.8.7A2 2 0 0 1 22 16.92z"/></svg>',
        searchSm: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35"/></svg>',
        sourceGoogle: '<svg width="14" height="14" viewBox="0 0 24 24"><path d="M22.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.4h5.9a5 5 0 0 1-2.2 3.3v2.7h3.5c2-1.9 3.3-4.7 3.3-8.1z" fill="#4285F4"/><path d="M12 23c3 0 5.5-1 7.3-2.7l-3.5-2.7c-1 .7-2.3 1-3.8 1-2.9 0-5.4-2-6.3-4.7H1.9v2.8A11 11 0 0 0 12 23z" fill="#34A853"/><path d="M5.7 13.9a6.6 6.6 0 0 1 0-4.2V6.9H1.9a11 11 0 0 0 0 9.8z" fill="#FBBC05"/><path d="M12 5.5c1.6 0 3 .6 4.2 1.7l3.1-3.1A11 11 0 0 0 12 1 11 11 0 0 0 1.9 6.9l3.8 2.8C6.6 7 9 5.5 12 5.5z" fill="#EA4335"/></svg>',
        sourceFacebook: '<svg width="14" height="14" viewBox="0 0 24 24" fill="#1877F2"><path d="M24 12.07C24 5.4 18.63 0 12 0S0 5.4 0 12.07c0 6 4.39 10.97 10.13 11.85v-8.38H7.08v-3.47h3.05V9.43c0-3 1.79-4.67 4.53-4.67 1.31 0 2.69.23 2.69.23v2.95h-1.52c-1.5 0-1.96.93-1.96 1.88v2.26h3.34l-.53 3.47h-2.8v8.38C19.61 23.04 24 18.07 24 12.07z"/></svg>',
        sourceLinkedIn: '<svg width="14" height="14" viewBox="0 0 24 24" fill="#0A66C2"><path d="M20.45 20.45h-3.55v-5.57c0-1.33-.03-3.04-1.85-3.04-1.86 0-2.14 1.45-2.14 2.95v5.66H9.36V9h3.4v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28zM5.34 7.43a2.06 2.06 0 1 1 0-4.13 2.06 2.06 0 0 1 0 4.13zm1.78 13.02H3.56V9h3.56v11.45zM22.22 0H1.77C.79 0 0 .78 0 1.74v20.52C0 23.22.79 24 1.77 24h20.45c.98 0 1.78-.78 1.78-1.74V1.74C24 .78 23.2 0 22.22 0z"/></svg>',
        sourceTwitter: '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
        sourceWhatsApp: '<svg width="14" height="14" viewBox="0 0 24 24" fill="#25D366"><path d="M12 2a10 10 0 0 0-8.49 15.35L2 22l4.79-1.49A10 10 0 1 0 12 2zm0 18a8 8 0 0 1-4.07-1.11l-.29-.17-2.85.89.92-2.78-.19-.3a8 8 0 1 1 6.48 3.47zm4.4-6c-.24-.12-1.42-.7-1.64-.78s-.38-.12-.54.12-.62.78-.76.94-.28.18-.52.06a6.5 6.5 0 0 1-1.93-1.2 7.2 7.2 0 0 1-1.33-1.66c-.14-.24 0-.36.11-.48s.24-.28.36-.42a1.7 1.7 0 0 0 .24-.4.44.44 0 0 0 0-.42c-.06-.12-.54-1.3-.74-1.78s-.4-.4-.54-.4h-.46a.88.88 0 0 0-.64.3 2.68 2.68 0 0 0-.84 2 4.66 4.66 0 0 0 1 2.48 10.7 10.7 0 0 0 4.1 3.62 4.66 4.66 0 0 0 2.8.58 2.32 2.32 0 0 0 1.52-1.08 1.88 1.88 0 0 0 .14-1.08c-.06-.1-.22-.16-.46-.28z"/></svg>',
        sourceYouTube: '<svg width="14" height="14" viewBox="0 0 24 24" fill="#FF0000"><path d="M23.5 6.5a3 3 0 0 0-2.1-2.1C19.5 4 12 4 12 4s-7.5 0-9.4.4A3 3 0 0 0 .5 6.5 31 31 0 0 0 0 12a31 31 0 0 0 .5 5.5 3 3 0 0 0 2.1 2.1c1.9.4 9.4.4 9.4.4s7.5 0 9.4-.4a3 3 0 0 0 2.1-2.1A31 31 0 0 0 24 12a31 31 0 0 0-.5-5.5zM9.5 15.5v-7l6.5 3.5z"/></svg>',
        sourceReddit: '<svg width="14" height="14" viewBox="0 0 24 24" fill="#FF4500"><path d="M12 0a12 12 0 1 0 12 12A12 12 0 0 0 12 0zm6.7 13.4a3.4 3.4 0 0 1-.4 1.4 4.8 4.8 0 0 1-1 1.4 5.6 5.6 0 0 1-1.5 1c-.5.3-1.1.5-1.7.6a8.9 8.9 0 0 1-1.9.2 8.9 8.9 0 0 1-1.9-.2 6.7 6.7 0 0 1-1.7-.6 5.6 5.6 0 0 1-1.5-1 4.8 4.8 0 0 1-1-1.4 3.4 3.4 0 0 1-.4-1.4 3.4 3.4 0 0 1 3.4-3.4 3.3 3.3 0 0 1 1.4.3 8 8 0 0 1 1.8-.5l1-3.6a.4.4 0 0 1 .4-.3l2.6.6a.4.4 0 0 1 .3.5.4.4 0 0 1-.4.3l-2.2-.5-.7 2.7a8 8 0 0 1 2.6.7 3.3 3.3 0 0 1 1.4-.3 3.4 3.4 0 0 1 3.4 3.4z"/></svg>',
        sourceDirect: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.07 0l3.93-3.93a5 5 0 0 0-7.07-7.07L13 3"/><path d="M14 11a5 5 0 0 0-7.07 0l-3.93 3.93a5 5 0 0 0 7.07 7.07L11 21"/></svg>'
    };

    // ---------- Sidebar / Topbar ----------
    const NAV = [
        { id: "dashboard",    label: "Dashboard",       icon: "dashboard", href: "dashboard.html" },
        { id: "forms",        label: "Forms",           icon: "forms", children: [
            { id: "forms-all",     label: "All Forms",         href: "forms.html" },
            { id: "forms-new",     label: "Create New Form",   href: "form-builder.html?new=1" },
            { id: "forms-multi",   label: "Multi-Step Forms",  href: "forms.html?type=multi" },
            { id: "forms-tpl",     label: "Templates",         href: "templates.html" },
            { id: "forms-draft",   label: "Draft Forms",       href: "forms.html?status=draft" }
        ]},
        { id: "submissions", label: "Submissions",     icon: "submissions", badge: "new", children: [
            { id: "sub-all",   label: "All Entries",   href: "submissions.html" },
            { id: "sub-spam",  label: "Spam Entries",  href: "submissions.html?spam=1" },
            { id: "sub-abandoned", label: "Abandoned Entries", href: "abandoned.html" },
            { id: "sub-export",label: "Export Data",   href: "submissions.html?export=1" }
        ]},
        { id: "form-users", label: "Form Users", icon: "users", href: "form-users.html" },
        { id: "integrations", label: "Integrations",   icon: "integrations", children: [
            { id: "int-recaptcha", label: "Google reCAPTCHA", href: "recaptcha.html" },
            { id: "int-smtp",      label: "SMTP Email",       href: "email-settings.html" },
            { id: "int-payment",   label: "Payment Gateways", href: "payment-gateways.html" },
            { id: "int-coupons",   label: "Coupons",          href: "coupons.html" },
            { id: "int-webhooks",  label: "Webhooks",         href: "integrations.html?tab=webhooks" },
            { id: "int-zapier",    label: "Zapier",           href: "integrations.html?tab=zapier" },
            { id: "int-crm",       label: "CRM Integrations", href: "integrations.html?tab=crm" }
        ]},
        { id: "analytics", label: "Analytics", icon: "analytics", children: [
            { id: "an-views", label: "Views",                 href: "analytics.html?tab=views" },
            { id: "an-conv",  label: "Conversion Tracking",   href: "analytics.html?tab=conv" },
            { id: "an-dev",   label: "Device Reports",        href: "analytics.html?tab=device" }
        ]},
        { id: "settings", label: "Settings", icon: "settings", children: [
            { id: "set-gen",   label: "General Settings", href: "settings.html?tab=general" },
            { id: "set-email", label: "Email Settings",   href: "email-settings.html" },
            { id: "set-style", label: "Form Styling",     href: "settings.html?tab=styling" },
            { id: "set-sec",   label: "Security",         href: "settings.html?tab=security" }
        ]},
        { id: "users", label: "Users & Permissions", icon: "users", href: "users.html" },
        { id: "help",  label: "Help & Docs",          icon: "help",  href: "docs.html" }
    ];

    function renderSidebar(activeKey) {
        const ver  = (window.FCBridge && FCBridge.version) ? FCBridge.version : "2.11.0";
        const html = `
        <div class="brand">
            <div class="brand-logo">FC</div>
            <div class="brand-text">FormCraft<span style="color:var(--brand-500)"> Pro</span></div>
            <div class="brand-tag">v${ver}</div>
        </div>
        ${NAV.map(item => navItemHTML(item, activeKey)).join("")}`;
        return html;
    }

    function navItemHTML(item, activeKey) {
        const isActive = activeKey === item.id || (item.children && item.children.some(c => c.id === activeKey));
        if (item.children) {
            return `
            <div class="nav-item ${isActive ? "open" : ""}" data-toggle="${item.id}">
                ${ICONS[item.icon] || ""}
                <span class="nav-label">${item.label}</span>
                ${item.badge ? `<span class="nav-badge">${item.badge}</span>` : ""}
                <span class="nav-arrow">${ICONS.chevronRight}</span>
            </div>
            <div class="nav-children ${isActive ? "open" : ""}" data-group="${item.id}">
                ${item.children.map(c => `<div class="nav-child ${activeKey === c.id ? "active" : ""}" data-href="${c.href}">${c.label}</div>`).join("")}
            </div>`;
        }
        return `<div class="nav-item ${isActive ? "active" : ""}" data-href="${item.href}">
            ${ICONS[item.icon] || ""}
            <span class="nav-label">${item.label}</span>
        </div>`;
    }

    function renderTopbar(state) {
        return `
        <button class="menu-toggle" id="menuToggle" title="Toggle sidebar">${ICONS.menu}</button>
        <div class="search">
            ${ICONS.search}
            <input type="search" placeholder="Search forms, submissions, settings…" id="globalSearch">
        </div>
        <div class="topbar-actions">
            <button class="icon-btn" id="themeToggle" title="Toggle theme">${state.ui.theme === "dark" ? ICONS.sun : ICONS.moon}</button>
            <div class="fcp-notif-wrap" style="position:relative;">
                <button class="icon-btn" id="notifBtn" title="Notifications">${ICONS.bell}<span class="fcp-notif-dot" id="notifDot" style="display:none;"></span></button>
                <div class="fcp-notif-panel" id="notifPanel" style="display:none;"></div>
            </div>
            <button class="icon-btn" title="Help" data-href="docs.html">${ICONS.help}</button>
            <div class="avatar" title="${state.user.name}" id="avatarBtn">${state.user.avatar}</div>
        </div>`;
    }

    /**
     * Build the notification feed from real data: recent submissions (newest
     * first, last 15) + recent payment events. Unread = item is_read flag,
     * unread count drives the red dot + badge on the bell.
     */
    function buildNotifications(state) {
        const subs = (state.submissions || []).slice().sort(
            (a, b) => new Date(b.createdAt) - new Date(a.createdAt)
        );
        const items = [];
        subs.slice(0, 15).forEach(s => {
            const isSpam   = s.spam;
            const wasPaid  = s.paymentStatus === "paid";
            const isFailed = s.paymentStatus === "failed";
            let icon  = "submissions";
            let title = `New submission on ${s.formTitle || "a form"}`;
            let kind  = "info";
            if (isSpam) {
                icon = "shield"; title = `Spam blocked on ${s.formTitle || "a form"}`; kind = "warn";
            } else if (wasPaid) {
                icon = "credit"; title = `Payment received from ${s.name || "a visitor"}`; kind = "ok";
            } else if (isFailed) {
                icon = "alert"; title = `Payment failed on ${s.formTitle || "a form"}`; kind = "err";
            }
            items.push({
                id:        s.id,
                icon, title, kind,
                subtitle:  s.name ? `${s.name}${s.email ? " · " + s.email : ""}` : (s.email || ""),
                createdAt: s.createdAt,
                unread:    !s.read,
                href:      "submission-detail.html?id=" + s.id,
            });
        });
        return items;
    }

    /**
     * Re-render the bell + dropdown content from the latest state. Called
     * once on shell build, again on the "fcp:bridge-ready" event (after the
     * WP REST sync hydrates the local cache with server data).
     */
    function renderNotifPanel() {
        const state    = FCData.load();
        const items    = buildNotifications(state);
        const dot      = document.getElementById("notifDot");
        const panel    = document.getElementById("notifPanel");
        if (!dot || !panel) return;
        const unread   = items.filter(i => i.unread).length;
        if (unread > 0) {
            dot.style.display    = "";
            dot.textContent      = unread > 9 ? "9+" : String(unread);
        } else {
            dot.style.display    = "none";
            dot.textContent      = "";
        }
        const iconMap = {
            submissions: ICONS.submissions, shield: ICONS.shield,
            credit:      ICONS.credit || ICONS.zap, alert: ICONS.alert || ICONS.warn || ICONS.shield,
        };
        const headerHtml = `
            <div class="fcp-notif-head">
                <strong>Notifications</strong>
                ${unread > 0 ? `<button class="btn btn-outline btn-sm" id="notifClear">Mark all read</button>` : ''}
            </div>`;
        let body;
        if (items.length === 0) {
            body = `<div class="fcp-notif-empty">${ICONS.bell}<div style="margin-top:8px;">No activity yet.</div><div class="text-muted text-sm">New submissions show up here.</div></div>`;
        } else {
            body = `<div class="fcp-notif-list">${items.map(it => `
                <a class="fcp-notif-item ${it.unread ? 'unread' : ''}" href="${it.href}" data-id="${it.id}">
                    <span class="fcp-notif-icon fcp-notif-${it.kind}">${iconMap[it.icon] || ICONS.bell}</span>
                    <span class="fcp-notif-body">
                        <span class="fcp-notif-title">${escapeHtml(it.title)}</span>
                        ${it.subtitle ? `<span class="fcp-notif-sub">${escapeHtml(it.subtitle)}</span>` : ''}
                        <span class="fcp-notif-time">${fmtDate(it.createdAt)}</span>
                    </span>
                    ${it.unread ? `<span class="fcp-notif-pill"></span>` : ''}
                </a>`).join("")}</div>`;
        }
        panel.innerHTML = headerHtml + body + `
            <div class="fcp-notif-foot">
                <a href="submissions.html">View all submissions →</a>
            </div>`;

        // Wire "Mark all read" — bulk-update the unread submission rows on
        // the server so the WP admin menu badge + this panel sync together.
        const clear = document.getElementById("notifClear");
        if (clear) {
            clear.addEventListener("click", e => {
                e.preventDefault();
                e.stopPropagation();
                const s = FCData.load();
                const targets = (s.submissions || []).filter(x => !x.read && x.wpId);
                targets.forEach(x => { x.read = true; });
                FCData.save(s);
                if (window.FCBridge && FCBridge.enabled) {
                    Promise.all(targets.map(x =>
                        FCBridge.updateSubmission(x.wpId, { is_read: 1 }).catch(() => {})
                    )).then(() => renderNotifPanel());
                } else {
                    renderNotifPanel();
                }
                toast("All notifications marked as read", "success");
            });
        }
    }

    function buildShell(activeKey) {
        const state = FCData.load();
        document.documentElement.setAttribute("data-theme", state.ui.theme || "light");
        const app = document.createElement("div");
        app.className = "app" + (state.ui.sidebarCollapsed ? " collapsed" : "");
        app.innerHTML = `
            <aside class="sidebar" id="sidebar"></aside>
            <div class="mobile-backdrop" id="mobileBackdrop"></div>
            <div class="main">
                <header class="topbar" id="topbar"></header>
                <main class="content" id="content"></main>
            </div>`;
        document.body.appendChild(app);

        document.getElementById("sidebar").innerHTML = renderSidebar(activeKey);
        document.getElementById("topbar").innerHTML  = renderTopbar(state);

        attachShellHandlers(app, state);
        return { app, content: document.getElementById("content"), state };
    }

    /**
     * Reverse-map of slug_to_view() from class-fcp-admin.php.
     * Used to translate an iframe-internal href (e.g. "forms.html") into
     * the corresponding WP admin URL (e.g. "admin.php?page=formcraft-pro-forms")
     * so the outer WordPress sidebar stays in sync with the iframe content.
     * Without this, every iframe nav left WP highlighting "Dashboard"
     * because the outer URL never changed.
     */
    const VIEW_TO_SLUG = {
        "dashboard.html":         "formcraft-pro",
        "forms.html":             "formcraft-pro-forms",
        "form-builder.html":      "formcraft-pro-new-form",
        "templates.html":         "formcraft-pro-templates",
        "migrate.html":           "formcraft-pro-migrate",
        "submissions.html":       "formcraft-pro-submissions",
        "submission-detail.html": "formcraft-pro-submissions",
        "abandoned.html":         "formcraft-pro-abandoned",
        "form-users.html":        "formcraft-pro-form-users",
        "analytics.html":         "formcraft-pro-analytics",
        "recaptcha.html":         "formcraft-pro-recaptcha",
        "email-settings.html":    "formcraft-pro-email",
        "payment-gateways.html":  "formcraft-pro-payments",
        "coupons.html":           "formcraft-pro-coupons",
        "integrations.html":      "formcraft-pro-integrations",
        "ad-platforms.html":      "formcraft-pro-ad-platforms",
        "settings.html":          "formcraft-pro-settings",
        "users.html":             "formcraft-pro-users",
        "docs.html":              "formcraft-pro-docs"
    };

    /**
     * Resolve a relative href like "forms.html?status=draft" against the
     * WP admin shell URL so navigation updates both the iframe and the
     * WordPress sidebar highlight. Returns null when called outside an
     * iframe — caller falls back to plain location.href.
     */
    function toWpAdminUrl(href) {
        try {
            const top = window.top;
            if (top === window) return null;            // not iframed
            const adminBase = (top.location.pathname || "").replace(/[^/]*$/, "") + "admin.php";
            const qIdx = href.indexOf("?");
            const path = qIdx === -1 ? href : href.slice(0, qIdx);
            const slug = VIEW_TO_SLUG[path];
            if (!slug) return null;
            const extra = qIdx === -1 ? "" : href.slice(qIdx + 1);
            // Drop the iframe-only `new=1` marker — the slug already maps
            // to "form-builder.html?new=1" via slug_to_view(), so passing
            // it again would noop. Keep every other query param.
            const filtered = extra.split("&")
                .filter(p => p && p !== "new=1")
                .join("&");
            return adminBase + "?page=" + slug + (filtered ? "&" + filtered : "");
        } catch (e) {
            // Cross-origin top frame (shouldn't happen in WP admin but just
            // in case) — fall back to plain iframe nav.
            return null;
        }
    }

    function attachShellHandlers(app, state) {
        // Sidebar nav navigation — when iframed inside wp-admin, navigate
        // the TOP-LEVEL window so WordPress's sidebar highlight follows.
        // Outside the iframe (e.g. opening the HTML directly during dev),
        // fall back to in-page navigation.
        app.querySelectorAll("[data-href]").forEach(el => {
            el.addEventListener("click", e => {
                e.stopPropagation();
                const href = el.dataset.href;
                const wpUrl = toWpAdminUrl(href);
                if (wpUrl) {
                    window.top.location.href = wpUrl;
                } else {
                    location.href = href;
                }
            });
        });
        // Sidebar dropdown toggle
        app.querySelectorAll("[data-toggle]").forEach(el => {
            el.addEventListener("click", () => {
                const group = el.dataset.toggle;
                const children = app.querySelector(`[data-group="${group}"]`);
                if (!children) return;
                children.classList.toggle("open");
                el.classList.toggle("open");
            });
        });
        // Theme toggle
        document.getElementById("themeToggle").addEventListener("click", () => {
            const s = FCData.load();
            s.ui.theme = (s.ui.theme === "dark") ? "light" : "dark";
            FCData.save(s);
            document.documentElement.setAttribute("data-theme", s.ui.theme);
            document.getElementById("themeToggle").innerHTML = s.ui.theme === "dark" ? ICONS.sun : ICONS.moon;
        });
        // Sidebar collapse
        document.getElementById("menuToggle").addEventListener("click", () => {
            if (window.innerWidth < 901) {
                app.classList.toggle("mobile-open");
                return;
            }
            app.classList.toggle("collapsed");
            const s = FCData.load();
            s.ui.sidebarCollapsed = app.classList.contains("collapsed");
            FCData.save(s);
        });
        document.getElementById("mobileBackdrop").addEventListener("click", () => app.classList.remove("mobile-open"));

        // Global search — route through toWpAdminUrl so the WP sidebar
        // jumps to Submissions when the visitor hits Enter on a query.
        const search = document.getElementById("globalSearch");
        if (search) {
            search.addEventListener("keypress", e => {
                if (e.key === "Enter") {
                    const q = search.value.trim();
                    if (!q) return;
                    const href  = "submissions.html?q=" + encodeURIComponent(q);
                    const wpUrl = toWpAdminUrl(href);
                    if (wpUrl) window.top.location.href = wpUrl;
                    else location.href = href;
                }
            });
        }

        // ─── Cmd+K command palette (v2.50) ───
        // Jump-anywhere modal: Ctrl/Cmd+K to open, type to filter actions,
        // Enter or click to execute. Avoids the trip to the sidebar for
        // every navigation. Same UX pattern as Linear, Notion, Vercel.
        document.addEventListener("keydown", e => {
            // Cmd/Ctrl + K → open palette
            if ((e.metaKey || e.ctrlKey) && (e.key === "k" || e.key === "K")) {
                e.preventDefault();
                openCommandPalette();
            }
            // "?" alone (not inside an input) → keyboard cheatsheet
            if (e.key === "?" && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) {
                e.preventDefault();
                openKeyboardCheatSheet();
            }
            // Esc closes either modal
            if (e.key === "Escape") {
                const m = document.getElementById("fcp-cmdk") || document.getElementById("fcp-cheatsheet");
                if (m) m.remove();
            }
        });

        // Notification bell — toggles the dropdown, closes on outside click
        // or Escape. The panel content is built on every open from the latest
        // local state so reloads aren't needed when new submissions sync.
        const notifBtn   = document.getElementById("notifBtn");
        const notifPanel = document.getElementById("notifPanel");
        if (notifBtn && notifPanel) {
            renderNotifPanel();
            notifBtn.addEventListener("click", e => {
                e.stopPropagation();
                if (notifPanel.style.display === "none" || !notifPanel.style.display) {
                    renderNotifPanel();
                    notifPanel.style.display = "block";
                } else {
                    notifPanel.style.display = "none";
                }
            });
            // Close when clicking outside the panel.
            document.addEventListener("click", e => {
                if (!notifPanel.contains(e.target) && e.target !== notifBtn && !notifBtn.contains(e.target)) {
                    notifPanel.style.display = "none";
                }
            });
            document.addEventListener("keydown", e => {
                if (e.key === "Escape") notifPanel.style.display = "none";
            });
            // Refresh the panel whenever the WP bridge finishes hydrating
            // local state from the server (covers initial page load + any
            // explicit re-sync that pages do after bulk actions).
            document.addEventListener("fcp:bridge-ready", () => renderNotifPanel());
        }

        // Avatar menu
        document.getElementById("avatarBtn").addEventListener("click", () => {
            modal({
                title: state.user.name,
                body: `
                    <div style="text-align:center; padding:8px 0 14px;">
                        <div class="avatar" style="width:64px;height:64px;font-size:22px;margin:0 auto 10px;">${state.user.avatar}</div>
                        <div class="fw-700">${state.user.name}</div>
                        <div class="text-muted text-sm">${state.user.email}</div>
                        <div class="badge badge-brand mt-2">${state.user.role}</div>
                    </div>
                    <div style="display:grid;gap:6px;">
                        <a class="btn btn-outline" href="users.html">Account Settings</a>
                        <a class="btn btn-outline" href="settings.html">Preferences</a>
                        <button class="btn btn-outline" onclick="FCApp.resetDemo()">Reset Demo Data</button>
                        <a class="btn btn-danger" href="index.html">Sign out</a>
                    </div>`,
                footer: ""
            });
        });
    }

    // ---------- Toast / Modal ----------
    function toast(message, type) {
        let stack = document.getElementById("toast-stack");
        if (!stack) {
            stack = document.createElement("div");
            stack.id = "toast-stack";
            document.body.appendChild(stack);
        }
        const el = document.createElement("div");
        el.className = "toast " + (type || "");
        el.innerHTML = `<span>${message}</span>`;
        stack.appendChild(el);
        setTimeout(() => { el.style.opacity = "0"; el.style.transform = "translateX(40px)"; el.style.transition = "0.3s"; }, 2700);
        setTimeout(() => el.remove(), 3100);
    }

    function modal({ title, body, footer, size }) {
        const back = document.createElement("div");
        back.className = "modal-backdrop open";
        back.innerHTML = `
            <div class="modal ${size || ""}">
                <div class="modal-header">
                    <div class="modal-title">${title || ""}</div>
                    <button class="action-btn" data-close>${ICONS.x}</button>
                </div>
                <div class="modal-body">${body || ""}</div>
                ${footer === undefined ? `<div class="modal-footer"><button class="btn btn-outline" data-close>Close</button></div>`
                    : (footer ? `<div class="modal-footer">${footer}</div>` : "")}
            </div>`;
        document.body.appendChild(back);
        back.addEventListener("click", e => {
            if (e.target === back || e.target.hasAttribute("data-close")) back.remove();
        });
        back.querySelectorAll("[data-close]").forEach(b => b.addEventListener("click", () => back.remove()));
        return back;
    }

    function confirm(msg, onYes) {
        const m = modal({
            title: "Are you sure?",
            body: `<p>${msg}</p>`,
            footer: `<button class="btn btn-outline" data-close>Cancel</button>
                     <button class="btn btn-danger" id="confirmYes">Confirm</button>`
        });
        m.querySelector("#confirmYes").addEventListener("click", () => { onYes && onYes(); m.remove(); });
    }

    // ---------- Helpers ----------
    function fmtDate(iso) {
        const d = new Date(iso);
        const diff = Date.now() - d.getTime();
        const mins = Math.floor(diff / 60000);
        if (mins < 1) return "just now";
        if (mins < 60) return mins + "m ago";
        const hours = Math.floor(mins / 60);
        if (hours < 24) return hours + "h ago";
        const days = Math.floor(hours / 24);
        if (days < 7) return days + "d ago";
        return d.toLocaleDateString();
    }
    function fmtDateLong(iso) {
        return new Date(iso).toLocaleString();
    }
    function fmtNumber(n) {
        if (n === null || n === undefined) return "0";
        if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
        if (n >= 1_000) return (n / 1_000).toFixed(1).replace(/\.0$/, "") + "K";
        return n.toString();
    }
    function escapeHtml(s) {
        if (s === null || s === undefined) return "";
        return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
    }
    function qs(name) {
        return new URLSearchParams(location.search).get(name);
    }

    /**
     * Currency code → display symbol. Covers everything the auto-currency
     * detector can return. Falls back to the code itself when unknown
     * (e.g. "ABC" → "ABC") so the form still shows something sensible.
     */
    const CURRENCY_SYMBOLS = {
        USD: "$", CAD: "C$", AUD: "A$", NZD: "NZ$", SGD: "S$", HKD: "HK$",
        EUR: "€", GBP: "£", JPY: "¥", CNY: "¥", CHF: "CHF",
        INR: "₹", PKR: "₨", LKR: "Rs", NPR: "Rs", BDT: "৳",
        SEK: "kr", NOK: "kr", DKK: "kr", ISK: "kr",
        PLN: "zł", CZK: "Kč", HUF: "Ft", RON: "lei", BGN: "лв", RSD: "дин",
        UAH: "₴", TRY: "₺", RUB: "₽",
        KRW: "₩", TWD: "NT$", THB: "฿", PHP: "₱", IDR: "Rp", MYR: "RM", VND: "₫", ILS: "₪", KHR: "៛", MMK: "K",
        AED: "AED", SAR: "SAR", QAR: "QAR", KWD: "KWD", BHD: "BHD", OMR: "OMR", JOD: "JOD", LBP: "LBP", EGP: "E£",
        ZAR: "R", NGN: "₦", KES: "KSh", GHS: "GH₵", MAD: "MAD", TND: "TND", DZD: "DA",
        BRL: "R$", MXN: "$", ARS: "$", CLP: "$", COP: "$", PEN: "S/", UYU: "$U", VES: "Bs",
        KZT: "₸", BYN: "Br"
    };
    function currencySymbol(code) {
        if (!code) return "$";
        const up = String(code).toUpperCase();
        return CURRENCY_SYMBOLS[up] || up;
    }

    function resetDemo() {
        if (window.confirm("Reset all demo data to defaults? This will erase your changes.")) {
            FCData.reset();
            location.reload();
        }
    }

    /**
     * Return the WP shortcode string for a form, e.g. [formcraft id="1"].
     * Uses wpId when present (WordPress mode), falls back to the local
     * string id otherwise.
     */
    function getShortcode(form) {
        if (!form) return "";
        const id = (form.wpId !== undefined && form.wpId !== null) ? form.wpId : form.id;
        return `[formcraft id="${id}"]`;
    }

    /**
     * Copy text to clipboard with a graceful fallback for non-secure
     * contexts (iframes, http). Shows a toast on success/failure.
     */
    function copyToClipboard(text, successMsg) {
        const msg = successMsg || "Copied to clipboard";
        const done = () => toast(msg, "success");
        const fail = () => toast("Copy failed — select and copy manually", "error");

        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text).then(done).catch(() => fallback());
        } else {
            fallback();
        }
        function fallback() {
            try {
                const ta = document.createElement("textarea");
                ta.value = text;
                ta.style.position = "fixed";
                ta.style.opacity = "0";
                document.body.appendChild(ta);
                ta.select();
                const ok = document.execCommand("copy");
                document.body.removeChild(ta);
                ok ? done() : fail();
            } catch (e) { fail(); }
        }
    }

    /**
     * Open the unified "Embed this form" modal — shortcode (primary)
     * plus direct URL + HTML embed snippet as fallbacks.
     */
    function openEmbedModal(form) {
        const sc = getShortcode(form);
        const id = (form.wpId !== undefined && form.wpId !== null) ? form.wpId : form.id;
        const directUrl = (function () {
            // Inside WordPress: use the pretty rewrite URL
            //   https://site.com/formcraft-pro/{form-slug}/
            // Derive the site root from the REST base the bridge captured
            // on iframe boot. Falls back to the standalone HTML page when
            // running outside WP (no slug or no bridge).
            if (window.FCBridge && FCBridge.enabled && FCBridge.ctx && FCBridge.ctx.restBase && form.slug) {
                const siteRoot = FCBridge.ctx.restBase.replace(/\/wp-json\/.+$/, "");
                return siteRoot + "/formcraft-pro/" + encodeURIComponent(form.slug) + "/";
            }
            const base = location.origin + location.pathname.replace(/[^/]*$/, "");
            return base + "public/form.html?id=" + encodeURIComponent(id);
        })();
        // Universal iframe embed: works on ANY HTML page (W3Schools sandbox,
        // CodePen, static sites, other CMSes). It points back at the pretty
        // URL on this WordPress install, so all submissions / payments /
        // emails happen on the WP side exactly as if the visitor had gone
        // to the form directly. No CDN, no CORS, no script-loading needed.
        const iframeEmbed = directUrl
            ? `<iframe src="${directUrl}" width="100%" height="800" style="border:0;max-width:760px;display:block;margin:0 auto;" loading="lazy" title="${escapeHtml(form.title)}"><\/iframe>`
            : `<!-- Save the form first to generate an embed URL -->`;
        // Popup-window button embed: works around third-party cookie blocking
        // (InfinityFree / Cloudflare / aggressive trackers). The button click
        // opens the form in a top-level browser window which is 1st-party
        // context — cookies, sessions, payments all behave normally.
        const popupEmbed = directUrl
            ? `<a href="${directUrl}" target="_blank" rel="noopener" onclick="window.open(this.href,'fcForm','width=760,height=900,scrollbars=yes,resizable=yes');return false;" style="display:inline-block;padding:14px 28px;background:#6366f1;color:#fff;font:600 15px system-ui,sans-serif;text-decoration:none;border-radius:8px;">Open ${escapeHtml(form.title)} →<\/a>`
            : `<!-- Save the form first -->`;

        const phpSnippet = "<?php echo do_shortcode('" + sc + "'); ?>";
        modal({
            title: "Embed “" + escapeHtml(form.title) + "”",
            size: "lg",
            body: `
                <div style="background:linear-gradient(135deg,var(--brand-50),var(--bg-soft));border:1px solid var(--brand-200);border-radius:12px;padding:16px;margin-bottom:18px;">
                    <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.06em;color:var(--brand-700);margin-bottom:8px;">⭐ Recommended · WordPress Shortcode</div>
                    <div class="input-group">
                        <input class="form-control" id="fcpEmbedShortcode" value="${escapeHtml(sc)}" readonly style="font-family:var(--mono);font-weight:700;font-size:15px;background:#fff;color:#0f172a;" onclick="this.select()">
                        <button class="btn btn-primary" onclick="FCApp.copyToClipboard(document.getElementById('fcpEmbedShortcode').value, 'Shortcode copied!')">${ICONS.copy} Copy</button>
                    </div>
                    <div class="form-help" style="margin-top:8px;color:var(--text-muted, #64748b);">Paste this into any WordPress page, post or widget to display the form.</div>
                </div>

                <div class="form-group">
                    <label class="form-label">PHP / Theme Template</label>
                    <textarea class="form-control" rows="2" readonly onclick="this.select()" style="font-family:var(--mono);font-size:13px;background:#fff;color:#0f172a;resize:vertical;white-space:pre;overflow:auto;" id="fcpEmbedPhp">${escapeHtml(phpSnippet)}</textarea>
                    <div style="display:flex;justify-content:flex-end;margin-top:6px;">
                        <button class="btn btn-outline btn-sm" onclick="FCApp.copyToClipboard(document.getElementById('fcpEmbedPhp').value, 'PHP snippet copied!')">${ICONS.copy} Copy PHP</button>
                    </div>
                    <div class="form-help" style="color:var(--text-muted, #64748b);">Use in a theme template file (header.php, page.php, etc.).</div>
                </div>

                <div class="form-group">
                    <label class="form-label">Direct Link (share or use as a landing page)</label>
                    <div class="input-group">
                        <input class="form-control" value="${escapeHtml(directUrl)}" readonly onclick="this.select()" id="fcpEmbedUrl" style="background:#fff;color:#0f172a;">
                        <a class="btn btn-primary" href="${escapeHtml(directUrl)}" target="_blank" rel="noopener" title="Open in a new tab">${ICONS.externalLink || ICONS.eye || ""} Open</a>
                        <button class="btn btn-outline" onclick="FCApp.copyToClipboard(document.getElementById('fcpEmbedUrl').value, 'URL copied!')">${ICONS.copy}</button>
                    </div>
                    <div class="form-help" style="color:var(--text-muted, #64748b);">Anyone with this link can open the form in their own browser — perfect for sharing in email, WhatsApp or social.</div>
                </div>

                <div class="form-group">
                    <label class="form-label">HTML Embed (iframe — for non-WordPress sites)</label>
                    <textarea class="form-control" rows="3" readonly onclick="this.select()" style="font-family:var(--mono);font-size:13px;background:#fff;color:#0f172a;" id="fcpEmbedHtml">${escapeHtml(iframeEmbed)}</textarea>
                    <div style="display:flex;justify-content:flex-end;margin-top:6px;">
                        <button class="btn btn-outline btn-sm" onclick="FCApp.copyToClipboard(document.getElementById('fcpEmbedHtml').value, 'Embed code copied!')">${ICONS.copy} Copy iframe code</button>
                    </div>
                    <div class="form-help" style="color:var(--text-muted, #64748b);">Paste into Wix, Shopify, Webflow, static sites, etc. <strong>Note:</strong> some free hosts (InfinityFree, etc.) block iframe loads via third-party cookie checks. If the iframe shows a "Cookies not enabled" page, use the Popup Button below instead.</div>
                </div>

                <div class="form-group">
                    <label class="form-label">Popup Button (works on any host, including free ones)</label>
                    <textarea class="form-control" rows="3" readonly onclick="this.select()" style="font-family:var(--mono);font-size:13px;background:#fff;color:#0f172a;" id="fcpEmbedPopup">${escapeHtml(popupEmbed)}</textarea>
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-top:6px;gap:8px;flex-wrap:wrap;">
                        <div style="padding:6px 12px;background:#eef2ff;border:1px solid #c7d2fe;border-radius:6px;font-size:12px;">
                            Preview: <a href="${escapeHtml(directUrl)}" target="_blank" rel="noopener" onclick="window.open(this.href,'fcFormPreview','width=760,height=900,scrollbars=yes,resizable=yes');return false;" style="display:inline-block;padding:6px 14px;background:#6366f1;color:#fff;font:600 13px system-ui;text-decoration:none;border-radius:5px;margin-left:6px;">Open ${escapeHtml(form.title)} →</a>
                        </div>
                        <button class="btn btn-outline btn-sm" onclick="FCApp.copyToClipboard(document.getElementById('fcpEmbedPopup').value, 'Popup button copied!')">${ICONS.copy} Copy button code</button>
                    </div>
                    <div class="form-help" style="color:var(--text-muted, #64748b);">Click the button → form opens in a new browser window. Works around third-party cookie blocking, mobile Safari restrictions, and CSP rules. Recommended when iframe fails.</div>
                </div>

                <!-- v2.51 — Advanced embed modes: popup / floating / slide-in / bar -->
                <details style="background:linear-gradient(135deg,#fef3c7,#fffbeb);border:1px solid #fcd34d;border-radius:10px;padding:14px;margin-top:6px;">
                    <summary style="cursor:pointer;font-weight:700;font-size:14px;color:#78350f;">🚀 Advanced embed modes — popup, floating button, slide-in, bar</summary>
                    <div style="margin-top:14px;">
                        ${renderAdvancedEmbeds(form, directUrl)}
                    </div>
                </details>

                <!-- v2.51 — QR code generator -->
                <details style="background:linear-gradient(135deg,#dcfce7,#f0fdf4);border:1px solid #86efac;border-radius:10px;padding:14px;margin-top:10px;">
                    <summary style="cursor:pointer;font-weight:700;font-size:14px;color:#14532d;">📱 QR code — share this form on print materials</summary>
                    <div style="margin-top:14px;display:flex;gap:18px;align-items:center;flex-wrap:wrap;">
                        <img src="https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=8&data=${encodeURIComponent(directUrl)}"
                             alt="QR code for ${escapeHtml(form.title)}"
                             style="width:220px;height:220px;background:#fff;border:1px solid #cbd5e1;border-radius:8px;">
                        <div style="flex:1;min-width:200px;">
                            <p style="margin:0 0 8px;font-size:13px;color:#166534;line-height:1.55;">
                                Visitors scan this with any smartphone camera and the form opens in their browser.
                                Drop the PNG onto flyers, event signage, product packaging, business cards.
                            </p>
                            <a class="btn btn-primary btn-sm" download="form-${id}-qr.png"
                               href="https://api.qrserver.com/v1/create-qr-code/?size=600x600&margin=8&data=${encodeURIComponent(directUrl)}">
                                ${ICONS.download} Download high-res PNG
                            </a>
                        </div>
                    </div>
                </details>

                <!-- v2.55 — Email signature embed -->
                <details style="background:linear-gradient(135deg,#fae8ff,#fdf4ff);border:1px solid #d8b4fe;border-radius:10px;padding:14px;margin-top:10px;">
                    <summary style="cursor:pointer;font-weight:700;font-size:14px;color:#6b21a8;">✉ Email signature embed — drop a branded link into every email you send</summary>
                    <div style="margin-top:14px;">
                        ${renderSignatureEmbed(form, directUrl)}
                    </div>
                </details>

                <!-- v2.55 — Custom domain mapping -->
                <details style="background:linear-gradient(135deg,#e0e7ff,#eef2ff);border:1px solid #a5b4fc;border-radius:10px;padding:14px;margin-top:10px;">
                    <summary style="cursor:pointer;font-weight:700;font-size:14px;color:#3730a3;">🔗 Custom domain — host the form at <code>forms.yourbrand.com</code></summary>
                    <div style="margin-top:14px;">
                        ${renderCustomDomainPanel(form, directUrl)}
                    </div>
                </details>
            `,
            footer: `<button class="btn btn-primary" data-close>Done</button>`
        });
    }

    /**
     * v2.55 — Email signature embed.
     * Generates email-client-safe HTML signatures that link to the form
     * with auto-attached UTM tags so admins can measure how many leads
     * came from "the link in my email." Three templates:
     *   1. Compact button — single coloured CTA, fits any signature
     *   2. Banner with logo + tagline — pulls site name from FCBridge
     *   3. Plain text link — for plaintext-only signatures
     * Every variant adds ?utm_source=email_signature&utm_medium=email
     * &utm_campaign=<form.slug> so the Analytics → UTM tab can show
     * "Email signature sent 12 leads this month".
     */
    function renderSignatureEmbed(form, directUrl) {
        const siteName = (window.FCBridge && FCBridge.ctx && FCBridge.ctx.siteName) || "your business";
        // Append UTM params so leads from signatures are attributable.
        const sep = directUrl.indexOf("?") === -1 ? "?" : "&";
        const sigUrl = directUrl + sep + "utm_source=email_signature&utm_medium=email&utm_campaign=" + encodeURIComponent(form.slug || ("form-" + form.id));
        const label = (form.cta || form.settings?.submitText || "Get in touch").replace(/[<>]/g, "");

        // Template 1: Compact CTA button (works in Gmail, Outlook, Apple Mail)
        const btnSig =
            `<a href="${sigUrl}" style="display:inline-block;background:#6366f1;color:#fff !important;padding:9px 18px;border-radius:6px;font:600 14px Arial,sans-serif;text-decoration:none;">${escapeHtml(label)} →</a>`;

        // Template 2: Two-line banner with form title + tagline
        const bannerSig =
            `<table cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;font:14px Arial,sans-serif;color:#0f172a;">
  <tr>
    <td style="padding:10px 14px;background:linear-gradient(135deg,#6366f1,#8b5cf6);border-radius:8px;">
      <a href="${sigUrl}" style="color:#fff !important;text-decoration:none;">
        <div style="font-weight:700;font-size:14px;color:#fff;">📋 ${escapeHtml(form.title)}</div>
        <div style="font-size:12px;color:#e0e7ff;margin-top:2px;">${escapeHtml(label)} — takes 30 seconds →</div>
      </a>
    </td>
  </tr>
</table>`;

        // Template 3: Plain text fallback (for plaintext signatures)
        const textSig = `${form.title} — ${label}: ${sigUrl}`;

        return `
            <p style="margin:0 0 10px;font-size:12.5px;color:#6b21a8;">
                Three ready-to-paste signature variants. Every click is tagged with <code>utm_source=email_signature</code> so the Analytics → UTM tab shows how many leads came from emails.
            </p>

            <!-- Compact button -->
            <div style="margin-top:14px;">
                <div style="font-weight:800;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#6b21a8;margin-bottom:6px;">1. Compact button</div>
                <div style="background:#fff;border:1px solid #d8b4fe;border-radius:8px;padding:14px;margin-bottom:6px;">
                    <div style="font-size:12px;color:#64748b;margin-bottom:4px;">Preview:</div>
                    <div>${btnSig}</div>
                </div>
                <textarea class="form-control" rows="3" readonly onclick="this.select()" style="font-family:var(--mono);font-size:11.5px;background:#fff;color:#0f172a;" id="fcpSigBtn">${escapeHtml(btnSig)}</textarea>
                <div style="display:flex;justify-content:flex-end;margin-top:6px;">
                    <button class="btn btn-outline btn-sm" onclick="FCApp.copyToClipboard(document.getElementById('fcpSigBtn').value, 'Button signature copied — paste into your email signature settings.')">${ICONS.copy} Copy HTML</button>
                </div>
            </div>

            <!-- Banner -->
            <div style="margin-top:14px;">
                <div style="font-weight:800;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#6b21a8;margin-bottom:6px;">2. Banner with title + tagline</div>
                <div style="background:#fff;border:1px solid #d8b4fe;border-radius:8px;padding:14px;margin-bottom:6px;">
                    <div style="font-size:12px;color:#64748b;margin-bottom:4px;">Preview:</div>
                    <div>${bannerSig}</div>
                </div>
                <textarea class="form-control" rows="6" readonly onclick="this.select()" style="font-family:var(--mono);font-size:11.5px;background:#fff;color:#0f172a;" id="fcpSigBanner">${escapeHtml(bannerSig)}</textarea>
                <div style="display:flex;justify-content:flex-end;margin-top:6px;">
                    <button class="btn btn-outline btn-sm" onclick="FCApp.copyToClipboard(document.getElementById('fcpSigBanner').value, 'Banner signature copied.')">${ICONS.copy} Copy HTML</button>
                </div>
            </div>

            <!-- Plain text -->
            <div style="margin-top:14px;">
                <div style="font-weight:800;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#6b21a8;margin-bottom:6px;">3. Plain text (for plaintext signatures)</div>
                <textarea class="form-control" rows="2" readonly onclick="this.select()" style="font-family:var(--mono);font-size:12px;background:#fff;color:#0f172a;" id="fcpSigText">${escapeHtml(textSig)}</textarea>
                <div style="display:flex;justify-content:flex-end;margin-top:6px;">
                    <button class="btn btn-outline btn-sm" onclick="FCApp.copyToClipboard(document.getElementById('fcpSigText').value, 'Plain-text signature copied.')">${ICONS.copy} Copy text</button>
                </div>
            </div>

            <div style="margin-top:14px;padding:10px 12px;background:#fff;border:1px dashed #d8b4fe;border-radius:8px;font-size:12px;color:#6b21a8;line-height:1.55;">
                <strong>📌 Where to paste:</strong>
                <ul style="margin:6px 0 0;padding-left:20px;">
                    <li><strong>Gmail:</strong> Settings → General → Signature → click the HTML icon → paste</li>
                    <li><strong>Outlook:</strong> File → Options → Mail → Signatures → paste into the Edit box</li>
                    <li><strong>Apple Mail:</strong> Mail → Preferences → Signatures → drag the rendered HTML in</li>
                    <li><strong>Hubspot / Salesforce / etc.:</strong> User settings → Email signature → HTML mode</li>
                </ul>
            </div>
        `;
    }

    /**
     * v2.55 — Custom domain mapping.
     * Lets the admin host the form at e.g. `forms.acme.com/contact` instead
     * of `acme.com/formcraft-pro/contact/`. The plugin itself can't intercept
     * requests on a different domain, so this is a configuration helper:
     *
     *   1. Admin enters the desired custom domain
     *   2. We generate the DNS instruction (CNAME → primary domain)
     *   3. We generate a hosting-provider reverse-proxy snippet
     *      (Nginx, Apache, Cloudflare Workers, Vercel rewrite)
     *   4. "Verify" button does a best-effort fetch + checks the
     *      response is our form HTML
     *
     * Stored in form.customDomain so the embed URLs use it where possible.
     */
    function renderCustomDomainPanel(form, directUrl) {
        const primaryHost = (function () {
            try { return new URL(directUrl).hostname; } catch (e) { return location.hostname; }
        })();
        const cd = form.customDomain || "";
        const slug = form.slug || ("form-" + form.id);
        const proposedUrl = cd ? ("https://" + cd + "/" + slug + "/") : "";

        return `
            <p style="margin:0 0 12px;font-size:12.5px;color:#3730a3;">
                Serve this form from your own subdomain instead of <code>${escapeHtml(primaryHost)}</code>. Better branding for client-facing forms.
            </p>

            <div class="form-group">
                <label class="form-label" style="color:#3730a3;">Custom domain</label>
                <div style="display:flex;gap:8px;">
                    <input class="form-control" id="fcpCustomDomain" value="${escapeHtml(cd)}" placeholder="forms.acme.com" style="flex:1;font-family:var(--mono);">
                    <button class="btn btn-primary btn-sm" onclick="window.saveCustomDomain('${form.id}')">${ICONS.save || "💾"} Save</button>
                    <button class="btn btn-outline btn-sm" id="fcpDomainVerifyBtn" onclick="window.verifyCustomDomain()" ${cd ? "" : "disabled"}>↻ Verify</button>
                </div>
                <div class="form-help" style="color:#3730a3;">Hostname only — no <code>https://</code>, no trailing slash.</div>
                <div id="fcpDomainStatus" style="margin-top:6px;font-size:12px;"></div>
            </div>

            ${cd ? `
                <div style="margin-top:14px;padding:12px;background:#fff;border:1px solid #a5b4fc;border-radius:8px;">
                    <div style="font-weight:800;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#3730a3;margin-bottom:8px;">Step 1 — DNS</div>
                    <p style="margin:0 0 6px;font-size:12.5px;color:#0f172a;">In your DNS provider (Cloudflare, GoDaddy, Route 53, etc.) add this record for <code>${escapeHtml(cd)}</code>:</p>
                    <table style="width:100%;font-family:var(--mono);font-size:12px;background:#f8fafc;border-radius:6px;padding:0;margin:6px 0 0;">
                        <tr style="background:#eef2ff;"><th style="padding:6px 10px;text-align:left;">Type</th><th style="text-align:left;">Name</th><th style="text-align:left;">Value</th></tr>
                        <tr><td style="padding:8px 10px;font-weight:700;">CNAME</td><td>${escapeHtml(cd.split(".")[0])}</td><td>${escapeHtml(primaryHost)}</td></tr>
                    </table>
                </div>

                <div style="margin-top:10px;padding:12px;background:#fff;border:1px solid #a5b4fc;border-radius:8px;">
                    <div style="font-weight:800;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#3730a3;margin-bottom:8px;">Step 2 — Reverse-proxy snippet</div>
                    <p style="margin:0 0 6px;font-size:12.5px;color:#0f172a;">Add ONE of these to your host so requests to <code>${escapeHtml(cd)}</code> serve the form from <code>${escapeHtml(primaryHost)}</code>:</p>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px;">
                        <details><summary style="cursor:pointer;font-weight:700;font-size:12px;">Nginx</summary>
                            <pre style="margin:6px 0 0;font-size:11px;background:#0f172a;color:#a5b4fc;padding:10px;border-radius:6px;overflow:auto;line-height:1.5;">server {
  listen 443 ssl;
  server_name ${escapeHtml(cd)};
  location / {
    proxy_pass https://${escapeHtml(primaryHost)}/formcraft-pro/;
    proxy_set_header Host ${escapeHtml(primaryHost)};
  }
}</pre>
                        </details>
                        <details><summary style="cursor:pointer;font-weight:700;font-size:12px;">Cloudflare Worker</summary>
                            <pre style="margin:6px 0 0;font-size:11px;background:#0f172a;color:#a5b4fc;padding:10px;border-radius:6px;overflow:auto;line-height:1.5;">addEventListener("fetch", e =&gt; {
  const u = new URL(e.request.url);
  u.hostname = "${escapeHtml(primaryHost)}";
  u.pathname = "/formcraft-pro" + u.pathname;
  e.respondWith(fetch(u, e.request));
});</pre>
                        </details>
                        <details><summary style="cursor:pointer;font-weight:700;font-size:12px;">Apache .htaccess</summary>
                            <pre style="margin:6px 0 0;font-size:11px;background:#0f172a;color:#a5b4fc;padding:10px;border-radius:6px;overflow:auto;line-height:1.5;">RewriteEngine On
RewriteCond %{HTTP_HOST} ^${escapeHtml(cd)}$ [NC]
RewriteRule ^(.*)$ https://${escapeHtml(primaryHost)}/formcraft-pro/$1 [P,L]</pre>
                        </details>
                        <details><summary style="cursor:pointer;font-weight:700;font-size:12px;">Vercel / Next rewrite</summary>
                            <pre style="margin:6px 0 0;font-size:11px;background:#0f172a;color:#a5b4fc;padding:10px;border-radius:6px;overflow:auto;line-height:1.5;">{
  "rewrites": [{
    "source": "/:path*",
    "destination": "https://${escapeHtml(primaryHost)}/formcraft-pro/:path*",
    "has": [{
      "type": "host",
      "value": "${escapeHtml(cd)}"
    }]
  }]
}</pre>
                        </details>
                    </div>
                </div>

                <div style="margin-top:10px;padding:12px;background:linear-gradient(135deg,#dcfce7,#f0fdf4);border:1px solid #86efac;border-radius:8px;">
                    <div style="font-weight:800;font-size:11px;text-transform:uppercase;letter-spacing:0.05em;color:#14532d;margin-bottom:6px;">Step 3 — Your custom URL</div>
                    <code style="font-size:14px;font-weight:700;color:#14532d;background:#fff;padding:6px 10px;border-radius:6px;display:inline-block;">${escapeHtml(proposedUrl)}</code>
                    <div style="margin-top:8px;font-size:11.5px;color:#166534;">Once Steps 1 + 2 are done, this URL will serve the form. Use it in print, ads, or share directly.</div>
                </div>
            ` : `
                <div style="margin-top:10px;padding:14px;background:#fff;border:1px dashed #a5b4fc;border-radius:8px;text-align:center;color:#3730a3;font-size:12px;">
                    Enter a custom domain above to see the DNS + reverse-proxy setup instructions.
                </div>
            `}
        `;
    }

    // v2.55 — Custom domain action handlers
    window.saveCustomDomain = function (formId) {
        const inp = document.getElementById("fcpCustomDomain");
        const value = (inp.value || "").trim().toLowerCase()
            .replace(/^https?:\/\//, "")
            .replace(/\/+$/, "");
        if (value && !/^[a-z0-9.-]+\.[a-z]{2,}$/.test(value)) {
            toast("That doesn't look like a valid hostname. Use something like forms.acme.com — no slashes, no protocol.", "warning");
            return;
        }
        const s = FCData.load();
        const f = s.forms.find(x => x.id === formId);
        if (!f) return;
        f.customDomain = value;
        FCData.save(s);
        if (window.FCBridge && FCBridge.enabled && FCBridge.saveForm) {
            FCBridge.saveForm(f).catch(err => toast(err.message || "Server save failed", "error"));
        }
        toast(value ? "Custom domain saved — refresh to see updated setup steps." : "Custom domain cleared.", "success");
        // Re-render the modal panel inline by closing + re-opening
        document.querySelector(".modal-overlay")?.remove();
        setTimeout(() => openEmbedModal(f), 100);
    };

    window.verifyCustomDomain = function () {
        const inp = document.getElementById("fcpCustomDomain");
        const status = document.getElementById("fcpDomainStatus");
        const cd = (inp.value || "").trim();
        if (!cd) return;
        status.innerHTML = `<span style="color:#64748b;">⏱ Checking ${escapeHtml(cd)}…</span>`;
        // Best-effort fetch — same-origin policy will block reading the
        // response body from a different host, but a successful network
        // round-trip (no-cors mode) tells us DNS resolves.
        fetch("https://" + cd + "/", { mode: "no-cors", cache: "no-store" })
            .then(() => {
                status.innerHTML = `<span style="color:#16a34a;">✓ DNS resolves. If the URL still shows the wrong page, the reverse-proxy snippet (Step 2) isn't active yet — your hosting provider may take 5-15 minutes to propagate.</span>`;
            })
            .catch(() => {
                status.innerHTML = `<span style="color:#dc2626;">✗ Couldn't reach <code>${escapeHtml(cd)}</code>. Check Step 1 (DNS CNAME) is saved + has propagated. DNS changes can take up to 24 hours.</span>`;
            });
    };

    /**
     * Renders the Advanced Embed Modes builder — a small "code generator"
     * UI where the admin picks a mode (popup / floating / slide-in / bar)
     * + trigger + position, and we live-render the matching <script> tag
     * for them to paste into their site. One unified loader handles all
     * four modes via data-mode + data-trigger attributes.
     */
    function renderAdvancedEmbeds(form, directUrl) {
        // The loader URL — points back at this WP install's plugin asset.
        const loaderUrl = (window.FCBridge && FCBridge.enabled && FCBridge.ctx && FCBridge.ctx.restBase)
            ? FCBridge.ctx.restBase.replace(/\/wp-json\/.+$/, "") + "/wp-content/plugins/formcraft-pro/assets/js/embed-loader.js"
            : (location.origin + location.pathname.replace(/[^/]*$/, "") + "assets/js/embed-loader.js");
        const formId = (form.wpId !== undefined && form.wpId !== null) ? form.wpId : form.id;

        // Hidden state stored in a closure on window so the input handlers can mutate.
        const w = window._fcpEmbedAdv = window._fcpEmbedAdv || {
            mode: "popup", trigger: "button", position: "bottom-right",
            label: "Get a Quote", color: "#6366f1", delay: 3000
        };
        // Stash IDs so the inline repaint helper can rebuild the snippet
        // without re-running the modal renderer.
        w._lastFormId  = formId;
        w._lastFormUrl = directUrl;
        // Regenerate snippet from current state.
        function snippet() {
            const attrs = [
                'src="' + loaderUrl + '"',
                'data-form-id="' + formId + '"',
                'data-form-url="' + directUrl + '"',
                'data-mode="' + w.mode + '"',
            ];
            if (w.mode === "popup") {
                attrs.push('data-trigger="' + w.trigger + '"');
                if (w.trigger === "time")   attrs.push('data-delay="' + w.delay + '"');
                if (w.trigger === "scroll") attrs.push('data-scroll-pct="60"');
            }
            if (w.mode === "floating") {
                attrs.push('data-position="' + w.position + '"');
                attrs.push('data-button-label="' + w.label.replace(/"/g, '&quot;') + '"');
                attrs.push('data-button-color="' + w.color + '"');
            }
            if (w.mode === "slidein") {
                attrs.push('data-position="' + w.position + '"');
                attrs.push('data-trigger="' + (w.trigger === "button" ? "time" : w.trigger) + '"');
                if (w.trigger === "time") attrs.push('data-delay="' + w.delay + '"');
            }
            if (w.mode === "bar") attrs.push('data-position="' + w.position + '"');

            // For popup mode with "button" trigger, include a sample button
            // visitor can click. Other modes are self-mounting.
            const button = (w.mode === "popup" && w.trigger === "button") ? `
<button data-fcp-popup="${formId}" style="padding:12px 22px;background:${w.color};color:#fff;border:0;border-radius:8px;font:600 14px system-ui;cursor:pointer;">
  ${escapeHtml(w.label)}
</button>` : "";

            return button + (button ? "\n" : "") + `<script ${attrs.join(" ")}></` + `script>`;
        }
        function repaint() {
            document.getElementById("fcpAdvSnippet").value = snippet();
        }
        setTimeout(repaint, 0);

        return `
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:12px;">
                ${[
                    { id:"popup",    label:"💬 Popup",         desc:"Centered modal" },
                    { id:"floating", label:"🔘 Floating",       desc:"Fixed button" },
                    { id:"slidein",  label:"↗️ Slide-in",       desc:"Bottom card" },
                    { id:"bar",      label:"━ Bar",             desc:"Top / bottom strip" },
                ].map(m => `
                    <button type="button"
                            onclick="window._fcpEmbedAdv.mode='${m.id}'; document.querySelectorAll('[data-emb-mode]').forEach(b=>b.classList.toggle('is-active', b.dataset.embMode==='${m.id}')); window._fcpEmbedAdvRepaint && window._fcpEmbedAdvRepaint();"
                            data-emb-mode="${m.id}"
                            class="${w.mode === m.id ? "is-active" : ""}"
                            style="background:${w.mode === m.id ? "#fff" : "rgba(255,255,255,.5)"};border:1.5px solid ${w.mode === m.id ? "#f59e0b" : "#fcd34d"};border-radius:8px;padding:10px;cursor:pointer;text-align:left;">
                        <div style="font-weight:700;font-size:13px;color:#78350f;">${m.label}</div>
                        <div style="font-size:11px;color:#92400e;">${m.desc}</div>
                    </button>
                `).join("")}
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px;font-size:12px;color:#78350f;">
                <label>
                    <div style="font-weight:700;margin-bottom:4px;">Trigger</div>
                    <select class="form-control" onchange="window._fcpEmbedAdv.trigger=this.value; window._fcpEmbedAdvRepaint && window._fcpEmbedAdvRepaint();">
                        <option value="button">Button click (manual)</option>
                        <option value="time">After N seconds</option>
                        <option value="scroll">On scroll-depth 60%</option>
                        <option value="exit">On exit intent</option>
                    </select>
                </label>
                <label>
                    <div style="font-weight:700;margin-bottom:4px;">Position</div>
                    <select class="form-control" onchange="window._fcpEmbedAdv.position=this.value; window._fcpEmbedAdvRepaint && window._fcpEmbedAdvRepaint();">
                        <option value="bottom-right">Bottom-right</option>
                        <option value="bottom-left">Bottom-left</option>
                        <option value="top-right">Top-right</option>
                        <option value="top-left">Top-left</option>
                    </select>
                </label>
                <label>
                    <div style="font-weight:700;margin-bottom:4px;">Button label</div>
                    <input class="form-control" value="Get a Quote" onchange="window._fcpEmbedAdv.label=this.value; window._fcpEmbedAdvRepaint && window._fcpEmbedAdvRepaint();">
                </label>
                <label>
                    <div style="font-weight:700;margin-bottom:4px;">Button colour</div>
                    <input class="form-control" type="color" value="#6366f1" onchange="window._fcpEmbedAdv.color=this.value; window._fcpEmbedAdvRepaint && window._fcpEmbedAdvRepaint();">
                </label>
            </div>

            <label style="display:block;font-weight:700;font-size:12px;color:#78350f;margin-bottom:4px;">Paste this snippet into the page where you want the form to appear:</label>
            <textarea class="form-control" id="fcpAdvSnippet" rows="5" readonly style="font-family:var(--mono);font-size:12px;background:#fff;color:#0f172a;" onclick="this.select()"></textarea>
            <div style="display:flex;justify-content:space-between;align-items:center;margin-top:8px;gap:8px;flex-wrap:wrap;">
                <span style="font-size:11px;color:#92400e;">Works on any HTML page — WordPress, Shopify, Wix, plain HTML.</span>
                <button class="btn btn-outline btn-sm" onclick="FCApp.copyToClipboard(document.getElementById('fcpAdvSnippet').value, 'Snippet copied!')">${ICONS.copy} Copy snippet</button>
            </div>
        `;
    }
    // Expose repaint so the inline-rendered controls can update the snippet
    // without inline JS having to know the helper's name.
    window._fcpEmbedAdvRepaint = function () {
        const el = document.getElementById("fcpAdvSnippet");
        if (!el || !window._fcpEmbedAdv) return;
        // Trigger the snippet rebuild by re-rendering — simplest path.
        // The closure's `repaint` is inaccessible from here, so we run a
        // copy of the snippet logic.
        const w = window._fcpEmbedAdv;
        const loaderUrl = (window.FCBridge && FCBridge.enabled && FCBridge.ctx && FCBridge.ctx.restBase)
            ? FCBridge.ctx.restBase.replace(/\/wp-json\/.+$/, "") + "/wp-content/plugins/formcraft-pro/assets/js/embed-loader.js"
            : (location.origin + location.pathname.replace(/[^/]*$/, "") + "assets/js/embed-loader.js");
        const formId = w._lastFormId;
        const formUrl= w._lastFormUrl;
        const attrs = [
            'src="' + loaderUrl + '"',
            'data-form-id="' + formId + '"',
            'data-form-url="' + formUrl + '"',
            'data-mode="' + w.mode + '"',
        ];
        if (w.mode === "popup") {
            attrs.push('data-trigger="' + w.trigger + '"');
            if (w.trigger === "time")   attrs.push('data-delay="' + w.delay + '"');
            if (w.trigger === "scroll") attrs.push('data-scroll-pct="60"');
        }
        if (w.mode === "floating") {
            attrs.push('data-position="' + w.position + '"');
            attrs.push('data-button-label="' + w.label.replace(/"/g, '&quot;') + '"');
            attrs.push('data-button-color="' + w.color + '"');
        }
        if (w.mode === "slidein") {
            attrs.push('data-position="' + w.position + '"');
            attrs.push('data-trigger="' + (w.trigger === "button" ? "time" : w.trigger) + '"');
            if (w.trigger === "time") attrs.push('data-delay="' + w.delay + '"');
        }
        if (w.mode === "bar") attrs.push('data-position="' + w.position + '"');
        const button = (w.mode === "popup" && w.trigger === "button") ?
            `<button data-fcp-popup="${formId}" style="padding:12px 22px;background:${w.color};color:#fff;border:0;border-radius:8px;font:600 14px system-ui;cursor:pointer;">${w.label}</button>\n` : "";
        el.value = button + `<script ${attrs.join(" ")}></` + `script>`;
    };

    // Onboarding
    function maybeShowOnboarding() {
        const s = FCData.load();
        if (s.ui.onboarded) return;
        let step = 0;
        const steps = [
            { title: "Welcome to FormCraft Pro", body: "The most modern multi-step form builder. Let's give you a quick tour — it takes 30 seconds.", img: "👋" },
            { title: "Build with drag & drop", body: "Drag fields from the palette into your canvas. Configure them in the settings panel. Multi-step support is built-in.", img: "🧩" },
            { title: "Track & convert", body: "Every form has analytics, conversion tracking, and submission management. Spam filtering and reCAPTCHA come built-in.", img: "📈" },
            { title: "You're ready!", body: "Start by exploring the sample forms or build your first form from scratch.", img: "🚀" }
        ];
        const wrap = document.createElement("div");
        wrap.className = "onboard open";
        document.body.appendChild(wrap);
        function render() {
            const c = steps[step];
            wrap.innerHTML = `
              <div class="onboard-card">
                <div class="step-dots">${steps.map((_, i) => `<span class="step-dot ${i === step ? "active" : ""}"></span>`).join("")}</div>
                <div style="font-size:54px;">${c.img}</div>
                <h2 style="margin:14px 0 8px;">${c.title}</h2>
                <p class="text-muted" style="max-width:380px;margin:0 auto 22px;">${c.body}</p>
                <div style="display:flex;gap:10px;justify-content:center;">
                    <button class="btn btn-outline" id="skipBtn">Skip tour</button>
                    <button class="btn btn-primary" id="nextBtn">${step === steps.length - 1 ? "Get started" : "Next"} ${ICONS.arrowRight}</button>
                </div>
              </div>`;
            wrap.querySelector("#skipBtn").onclick = finish;
            wrap.querySelector("#nextBtn").onclick = () => {
                if (step === steps.length - 1) finish();
                else { step++; render(); }
            };
        }
        function finish() {
            const s = FCData.load();
            s.ui.onboarded = true;
            FCData.save(s);
            wrap.remove();
        }
        render();
    }

    // ───────────────────────────────────────────────────────────────
    // Cmd+K command palette + Keyboard cheat sheet (v2.50)
    // ───────────────────────────────────────────────────────────────
    // Static command catalogue — same hrefs as the sidebar NAV, plus a
    // few action shortcuts. Each command has {label, hint, icon, run}.
    // The palette filters as the admin types and runs the matched
    // command's `run()` on Enter / click.
    const CMDK_COMMANDS = [
        // ─── Navigation ───
        { label: "Dashboard",                 hint: "Home overview",                       cat: "Go to", href: "dashboard.html" },
        { label: "All Forms",                 hint: "Manage existing forms",               cat: "Go to", href: "forms.html" },
        { label: "Create New Form",           hint: "Start a blank form",                  cat: "Go to", href: "form-builder.html?new=1" },
        { label: "Templates",                 hint: "Pre-built form starters",             cat: "Go to", href: "templates.html" },
        { label: "Submissions",               hint: "All entries",                         cat: "Go to", href: "submissions.html" },
        { label: "Abandoned Entries",         hint: "Partial / unfinished",                cat: "Go to", href: "abandoned.html" },
        { label: "Form Users",                hint: "Self-serve user store",               cat: "Go to", href: "form-users.html" },
        { label: "Integrations",              hint: "Mailchimp / Slack / CRMs",            cat: "Go to", href: "integrations.html" },
        { label: "Ad Platforms",              hint: "Meta / Google / TikTok / LinkedIn",   cat: "Go to", href: "ad-platforms.html" },
        { label: "Import & Migration",        hint: "WPForms / Fluent / Gravity → here",   cat: "Go to", href: "migrate.html" },
        { label: "Analytics",                 hint: "Conversion + device reports",         cat: "Go to", href: "analytics.html" },
        { label: "reCAPTCHA",                 hint: "Spam protection",                     cat: "Go to", href: "recaptcha.html" },
        { label: "Email Settings",            hint: "SMTP configuration",                  cat: "Go to", href: "email-settings.html" },
        { label: "Payment Gateways",          hint: "Stripe / Razorpay / UPI / etc.",      cat: "Go to", href: "payment-gateways.html" },
        { label: "Coupons",                   hint: "Discount codes",                      cat: "Go to", href: "coupons.html" },
        { label: "Users & Permissions",       hint: "Team roles",                          cat: "Go to", href: "users.html" },
        { label: "Settings",                  hint: "Global plugin config",                cat: "Go to", href: "settings.html" },
        { label: "Documentation",             hint: "Help + guides",                       cat: "Go to", href: "docs.html" },
        // ─── Actions ───
        { label: "Toggle dark mode",          hint: "Switch theme",                        cat: "Action", run: () => document.getElementById("themeToggle")?.click() },
        { label: "Show keyboard shortcuts",   hint: "Cheat sheet",                         cat: "Action", run: () => openKeyboardCheatSheet() },
        { label: "Toggle reduced motion",     hint: "Accessibility — kill animations",     cat: "Action", run: () => toggleReducedMotion() },
        { label: "Reset demo data",           hint: "Restore the bundled sample data",     cat: "Action", run: () => resetDemo() },
    ];

    /**
     * Reduced-motion override. Stores the choice in localStorage and
     * applies it at boot before render so animations don't briefly flash.
     * Stacks on top of the @media (prefers-reduced-motion: reduce) rule —
     * either signal turns motion off.
     */
    function applyReducedMotionPref() {
        const on = localStorage.getItem("fcp_reduce_motion") === "1";
        document.documentElement.setAttribute("data-reduce-motion", on ? "1" : "0");
        return on;
    }
    function toggleReducedMotion() {
        const on = !(localStorage.getItem("fcp_reduce_motion") === "1");
        localStorage.setItem("fcp_reduce_motion", on ? "1" : "0");
        applyReducedMotionPref();
        toast(on ? "Reduced motion ON — animations disabled." : "Reduced motion OFF.", "success");
    }
    applyReducedMotionPref();

    function openCommandPalette() {
        if (document.getElementById("fcp-cmdk")) return;
        const m = document.createElement("div");
        m.id = "fcp-cmdk";
        m.innerHTML = `
            <div class="fcp-cmdk-back"></div>
            <div class="fcp-cmdk-box" role="dialog" aria-label="Command palette">
                <input class="fcp-cmdk-input" placeholder="Type to filter… (try 'forms', 'integrations', 'dark')" autofocus>
                <div class="fcp-cmdk-list" tabindex="-1"></div>
                <div class="fcp-cmdk-foot">
                    <span><kbd>↑</kbd><kbd>↓</kbd> navigate</span>
                    <span><kbd>↵</kbd> open</span>
                    <span><kbd>Esc</kbd> close</span>
                </div>
            </div>`;
        document.body.appendChild(m);
        const input = m.querySelector(".fcp-cmdk-input");
        const list  = m.querySelector(".fcp-cmdk-list");
        let cursor = 0;

        function paint() {
            const q = input.value.trim().toLowerCase();
            const visible = CMDK_COMMANDS.filter(c =>
                !q || c.label.toLowerCase().includes(q) || c.hint.toLowerCase().includes(q) || c.cat.toLowerCase().includes(q)
            );
            if (cursor >= visible.length) cursor = Math.max(0, visible.length - 1);
            list.innerHTML = visible.length ? visible.map((c, i) => `
                <div class="fcp-cmdk-item ${i === cursor ? "is-active" : ""}" data-i="${i}">
                    <span class="fcp-cmdk-cat">${c.cat}</span>
                    <div>
                        <div class="fcp-cmdk-lbl">${escapeHtml(c.label)}</div>
                        <div class="fcp-cmdk-hint">${escapeHtml(c.hint)}</div>
                    </div>
                </div>
            `).join("") : `<div class="fcp-cmdk-empty">No matches. Try a different word.</div>`;
            list.querySelectorAll(".fcp-cmdk-item").forEach(el => {
                el.addEventListener("click", () => run(visible[parseInt(el.dataset.i, 10)]));
                el.addEventListener("mouseover", () => { cursor = parseInt(el.dataset.i, 10); paint(); });
            });
        }
        function run(cmd) {
            m.remove();
            if (!cmd) return;
            if (cmd.run) cmd.run();
            else if (cmd.href) {
                // Translate to WP admin URL when iframed so the WP sidebar
                // highlight follows. Falls back to in-frame nav otherwise.
                const wpUrl = typeof toWpAdminUrl === "function" ? toWpAdminUrl(cmd.href) : null;
                if (wpUrl) window.top.location.href = wpUrl;
                else        location.href = cmd.href;
            }
        }
        input.addEventListener("input", () => { cursor = 0; paint(); });
        input.addEventListener("keydown", e => {
            const visible = CMDK_COMMANDS.filter(c => {
                const q = input.value.trim().toLowerCase();
                return !q || c.label.toLowerCase().includes(q) || c.hint.toLowerCase().includes(q) || c.cat.toLowerCase().includes(q);
            });
            if (e.key === "ArrowDown") { e.preventDefault(); cursor = Math.min(visible.length - 1, cursor + 1); paint(); }
            if (e.key === "ArrowUp")   { e.preventDefault(); cursor = Math.max(0, cursor - 1); paint(); }
            if (e.key === "Enter")     { e.preventDefault(); run(visible[cursor]); }
        });
        m.querySelector(".fcp-cmdk-back").addEventListener("click", () => m.remove());
        paint();
    }

    function openKeyboardCheatSheet() {
        if (document.getElementById("fcp-cheatsheet")) return;
        const rows = [
            [ ["Ctrl", "K"],          "Open command palette" ],
            [ ["?"],                  "Show this cheat sheet" ],
            [ ["Ctrl", "S"],          "Save current form (in builder)" ],
            [ ["Ctrl", "Z"],          "Undo last change (in builder)" ],
            [ ["Ctrl", "Shift", "Z"], "Redo (in builder)" ],
            [ ["Esc"],                "Close modal / palette" ],
            [ ["Tab"],                "Move to next field" ],
            [ ["/"],                  "Focus search bar" ],
        ];
        const m = document.createElement("div");
        m.id = "fcp-cheatsheet";
        m.innerHTML = `
            <div class="fcp-cmdk-back"></div>
            <div class="fcp-cheat-box" role="dialog" aria-label="Keyboard shortcuts">
                <div class="fcp-cheat-head">⌨ Keyboard shortcuts</div>
                <table class="fcp-cheat-tbl">
                    ${rows.map(([keys, label]) => `
                        <tr>
                            <td>${keys.map(k => `<kbd>${k}</kbd>`).join(" + ")}</td>
                            <td>${escapeHtml(label)}</td>
                        </tr>
                    `).join("")}
                </table>
                <div style="text-align:right;margin-top:14px;">
                    <button class="btn btn-outline btn-sm" onclick="document.getElementById('fcp-cheatsheet').remove()">Close</button>
                </div>
            </div>`;
        document.body.appendChild(m);
        m.querySelector(".fcp-cmdk-back").addEventListener("click", () => m.remove());
    }

    // Style for Cmd+K palette + cheat sheet — injected once to avoid
    // bloating every HTML view's own <style> block.
    if (!document.getElementById("fcp-cmdk-styles")) {
        const s = document.createElement("style");
        s.id = "fcp-cmdk-styles";
        s.textContent = `
            #fcp-cmdk, #fcp-cheatsheet { position:fixed; inset:0; z-index:99999; display:flex; align-items:flex-start; justify-content:center; padding-top:12vh; }
            .fcp-cmdk-back { position:absolute; inset:0; background:rgba(15,23,42,.45); backdrop-filter:blur(2px); }
            .fcp-cmdk-box, .fcp-cheat-box { position:relative; width:560px; max-width:92vw; background:#fff; border-radius:14px; box-shadow:0 24px 64px rgba(15,23,42,.35); overflow:hidden; }
            .fcp-cmdk-input { width:100%; border:0; border-bottom:1px solid #e2e8f0; padding:18px 22px; font-size:16px; outline:none; box-sizing:border-box; }
            .fcp-cmdk-list  { max-height:50vh; overflow-y:auto; padding:6px; }
            .fcp-cmdk-item  { display:flex; align-items:center; gap:12px; padding:10px 14px; border-radius:8px; cursor:pointer; }
            .fcp-cmdk-item.is-active { background:#eef2ff; }
            .fcp-cmdk-cat   { font-size:9.5px; font-weight:800; letter-spacing:0.08em; text-transform:uppercase; color:#6366f1; background:#eef2ff; padding:3px 8px; border-radius:999px; flex-shrink:0; min-width:50px; text-align:center; }
            .fcp-cmdk-item.is-active .fcp-cmdk-cat { background:#fff; }
            .fcp-cmdk-lbl   { font-weight:700; font-size:13.5px; color:#0f172a; }
            .fcp-cmdk-hint  { font-size:11.5px; color:#64748b; margin-top:2px; }
            .fcp-cmdk-empty { padding:30px; text-align:center; color:#94a3b8; font-size:13px; }
            .fcp-cmdk-foot  { display:flex; gap:14px; padding:10px 18px; background:#f8fafc; border-top:1px solid #e2e8f0; font-size:11px; color:#64748b; }
            .fcp-cmdk-foot kbd { background:#fff; border:1px solid #cbd5e1; border-radius:4px; padding:1px 5px; font-family:var(--mono); font-size:10.5px; box-shadow:0 1px 1px rgba(15,23,42,.06); margin:0 1px; }
            .fcp-cheat-box  { padding:24px; }
            .fcp-cheat-head { font-size:16px; font-weight:800; color:#0f172a; margin-bottom:14px; }
            .fcp-cheat-tbl  { width:100%; border-collapse:collapse; }
            .fcp-cheat-tbl td { padding:8px 0; font-size:13px; color:#475569; border-bottom:1px solid #f1f5f9; }
            .fcp-cheat-tbl td:first-child { width:180px; }
            .fcp-cheat-tbl kbd { background:#f1f5f9; border:1px solid #cbd5e1; border-radius:4px; padding:2px 7px; font-family:var(--mono); font-size:11px; font-weight:700; color:#0f172a; box-shadow:0 1px 1px rgba(15,23,42,.08); }
        `;
        document.head.appendChild(s);
    }

    global.FCApp = {
        ICONS, NAV,
        buildShell, renderSidebar, renderTopbar,
        toast, modal, confirm,
        fmtDate, fmtDateLong, fmtNumber, escapeHtml, qs,
        currencySymbol,
        resetDemo, maybeShowOnboarding,
        getShortcode, copyToClipboard, openEmbedModal,
        openCommandPalette, openKeyboardCheatSheet
    };
})(window);
