/* ============================================================
   FormCraft Pro - Multi-step Form Renderer (public + preview)
   ============================================================ */
(function (global) {
    "use strict";

    /* ─── v2.59 — i18n table for built-in UI strings ───
       Covers the 18 languages most common in WordPress installs. Admin
       string overrides (form.settings.translations[key][lang]) win over
       this table — the table is the fallback. Falls back to the English
       key if no translation exists at all. Keep keys SHORT and stable —
       they're referenced from form-engine, fields.js, and the public
       templates. */
    const FCP_LANG_MAP = {
        en: { submit:"Submit", submitting:"Submitting…", loading:"Loading…", next:"Next", previous:"Previous", required:"Required", optional:"optional", success:"Thanks! Your submission has been received.", another:"Submit another response", cancel:"Cancel", error:"Something went wrong. Please try again.", invalid_email:"Please enter a valid email.", invalid_phone:"Please enter a valid phone number.", upload:"Upload", remove:"Remove", select:"Select…", search:"Search…", step:"Step", of:"of" },
        es: { submit:"Enviar", submitting:"Enviando…", loading:"Cargando…", next:"Siguiente", previous:"Anterior", required:"Obligatorio", optional:"opcional", success:"¡Gracias! Hemos recibido tu envío.", another:"Enviar otra respuesta", cancel:"Cancelar", error:"Algo salió mal. Por favor, inténtalo de nuevo.", invalid_email:"Introduce un correo válido.", invalid_phone:"Introduce un teléfono válido.", upload:"Subir", remove:"Eliminar", select:"Seleccionar…", search:"Buscar…", step:"Paso", of:"de" },
        fr: { submit:"Envoyer", submitting:"Envoi…", loading:"Chargement…", next:"Suivant", previous:"Précédent", required:"Requis", optional:"facultatif", success:"Merci ! Votre envoi a bien été reçu.", another:"Envoyer une autre réponse", cancel:"Annuler", error:"Une erreur est survenue. Réessayez.", invalid_email:"Saisissez un e-mail valide.", invalid_phone:"Saisissez un téléphone valide.", upload:"Téléverser", remove:"Supprimer", select:"Sélectionner…", search:"Rechercher…", step:"Étape", of:"sur" },
        de: { submit:"Absenden", submitting:"Wird gesendet…", loading:"Wird geladen…", next:"Weiter", previous:"Zurück", required:"Erforderlich", optional:"optional", success:"Danke! Wir haben Ihre Eingabe erhalten.", another:"Weitere Antwort senden", cancel:"Abbrechen", error:"Etwas ist schiefgelaufen. Bitte erneut versuchen.", invalid_email:"Bitte eine gültige E-Mail eingeben.", invalid_phone:"Bitte eine gültige Telefonnummer eingeben.", upload:"Hochladen", remove:"Entfernen", select:"Auswählen…", search:"Suchen…", step:"Schritt", of:"von" },
        it: { submit:"Invia", submitting:"Invio…", loading:"Caricamento…", next:"Avanti", previous:"Indietro", required:"Obbligatorio", optional:"facoltativo", success:"Grazie! Abbiamo ricevuto il tuo invio.", another:"Invia un'altra risposta", cancel:"Annulla", error:"Qualcosa è andato storto. Riprova.", invalid_email:"Inserisci un'email valida.", invalid_phone:"Inserisci un numero di telefono valido.", upload:"Carica", remove:"Rimuovi", select:"Seleziona…", search:"Cerca…", step:"Passaggio", of:"di" },
        pt: { submit:"Enviar", submitting:"Enviando…", loading:"Carregando…", next:"Próximo", previous:"Anterior", required:"Obrigatório", optional:"opcional", success:"Obrigado! Recebemos o seu envio.", another:"Enviar outra resposta", cancel:"Cancelar", error:"Algo deu errado. Tente novamente.", invalid_email:"Informe um e-mail válido.", invalid_phone:"Informe um telefone válido.", upload:"Enviar arquivo", remove:"Remover", select:"Selecione…", search:"Buscar…", step:"Etapa", of:"de" },
        nl: { submit:"Verzenden", submitting:"Verzenden…", loading:"Laden…", next:"Volgende", previous:"Vorige", required:"Verplicht", optional:"optioneel", success:"Bedankt! Je inzending is ontvangen.", another:"Nog een antwoord verzenden", cancel:"Annuleer", error:"Er ging iets mis. Probeer het opnieuw.", invalid_email:"Voer een geldig e-mailadres in.", invalid_phone:"Voer een geldig telefoonnummer in.", upload:"Uploaden", remove:"Verwijderen", select:"Selecteer…", search:"Zoeken…", step:"Stap", of:"van" },
        pl: { submit:"Wyślij", submitting:"Wysyłanie…", loading:"Ładowanie…", next:"Dalej", previous:"Wstecz", required:"Wymagane", optional:"opcjonalnie", success:"Dziękujemy! Twoje zgłoszenie zostało wysłane.", another:"Wyślij kolejną odpowiedź", cancel:"Anuluj", error:"Coś poszło nie tak. Spróbuj ponownie.", invalid_email:"Podaj prawidłowy adres e-mail.", invalid_phone:"Podaj prawidłowy numer telefonu.", upload:"Prześlij", remove:"Usuń", select:"Wybierz…", search:"Szukaj…", step:"Krok", of:"z" },
        ru: { submit:"Отправить", submitting:"Отправка…", loading:"Загрузка…", next:"Далее", previous:"Назад", required:"Обязательно", optional:"необязательно", success:"Спасибо! Ваша заявка получена.", another:"Отправить ещё один ответ", cancel:"Отменить", error:"Что-то пошло не так. Попробуйте ещё раз.", invalid_email:"Введите корректный e-mail.", invalid_phone:"Введите корректный номер телефона.", upload:"Загрузить", remove:"Удалить", select:"Выбрать…", search:"Поиск…", step:"Шаг", of:"из" },
        tr: { submit:"Gönder", submitting:"Gönderiliyor…", loading:"Yükleniyor…", next:"İleri", previous:"Geri", required:"Zorunlu", optional:"isteğe bağlı", success:"Teşekkürler! Gönderiminiz alındı.", another:"Başka bir yanıt gönder", cancel:"İptal", error:"Bir şeyler ters gitti. Lütfen tekrar deneyin.", invalid_email:"Geçerli bir e-posta girin.", invalid_phone:"Geçerli bir telefon numarası girin.", upload:"Yükle", remove:"Kaldır", select:"Seç…", search:"Ara…", step:"Adım", of:"/" },
        hi: { submit:"भेजें", submitting:"भेजा जा रहा है…", loading:"लोड हो रहा है…", next:"आगे", previous:"पीछे", required:"आवश्यक", optional:"वैकल्पिक", success:"धन्यवाद! आपकी प्रविष्टि मिल गई है।", another:"एक और प्रतिक्रिया भेजें", cancel:"रद्द करें", error:"कुछ गलत हो गया। कृपया पुनः प्रयास करें।", invalid_email:"मान्य ईमेल दर्ज करें।", invalid_phone:"मान्य फ़ोन नंबर दर्ज करें।", upload:"अपलोड", remove:"हटाएँ", select:"चुनें…", search:"खोजें…", step:"चरण", of:"में से" },
        ar: { submit:"إرسال", submitting:"جارٍ الإرسال…", loading:"جارٍ التحميل…", next:"التالي", previous:"السابق", required:"مطلوب", optional:"اختياري", success:"شكراً لك! لقد استلمنا طلبك.", another:"إرسال إجابة أخرى", cancel:"إلغاء", error:"حدث خطأ ما. حاول مرة أخرى.", invalid_email:"يرجى إدخال بريد إلكتروني صالح.", invalid_phone:"يرجى إدخال رقم هاتف صالح.", upload:"تحميل", remove:"إزالة", select:"اختر…", search:"بحث…", step:"الخطوة", of:"من" },
        he: { submit:"שליחה", submitting:"שולח…", loading:"טוען…", next:"הבא", previous:"הקודם", required:"חובה", optional:"רשות", success:"תודה! הטופס התקבל.", another:"לשלוח תשובה נוספת", cancel:"ביטול", error:"משהו השתבש. נסו שוב.", invalid_email:"יש להזין כתובת דוא\"ל תקינה.", invalid_phone:"יש להזין מספר טלפון תקין.", upload:"העלאה", remove:"הסרה", select:"בחירה…", search:"חיפוש…", step:"שלב", of:"מתוך" },
        fa: { submit:"ارسال", submitting:"در حال ارسال…", loading:"در حال بارگذاری…", next:"بعدی", previous:"قبلی", required:"الزامی", optional:"اختیاری", success:"متشکریم! ارسال شما دریافت شد.", another:"ارسال پاسخ دیگر", cancel:"لغو", error:"خطایی رخ داد. لطفاً دوباره تلاش کنید.", invalid_email:"یک ایمیل معتبر وارد کنید.", invalid_phone:"یک شماره تلفن معتبر وارد کنید.", upload:"بارگذاری", remove:"حذف", select:"انتخاب…", search:"جستجو…", step:"مرحله", of:"از" },
        ur: { submit:"جمع کرائیں", submitting:"جمع ہو رہا ہے…", loading:"لوڈ ہو رہا ہے…", next:"اگلا", previous:"پچھلا", required:"لازمی", optional:"اختیاری", success:"شکریہ! آپ کی درخواست موصول ہو گئی۔", another:"ایک اور جواب جمع کرائیں", cancel:"منسوخ", error:"کچھ غلط ہوا۔ دوبارہ کوشش کریں۔", invalid_email:"درست ای میل درج کریں۔", invalid_phone:"درست فون نمبر درج کریں۔", upload:"اپلوڈ", remove:"ہٹائیں", select:"منتخب کریں…", search:"تلاش…", step:"مرحلہ", of:"میں سے" },
        zh: { submit:"提交", submitting:"提交中…", loading:"加载中…", next:"下一步", previous:"上一步", required:"必填", optional:"选填", success:"谢谢！我们已收到您的提交。", another:"再提交一份", cancel:"取消", error:"出错了，请重试。", invalid_email:"请输入有效的电子邮件。", invalid_phone:"请输入有效的电话号码。", upload:"上传", remove:"移除", select:"请选择…", search:"搜索…", step:"第", of:"步，共" },
        ja: { submit:"送信", submitting:"送信中…", loading:"読み込み中…", next:"次へ", previous:"戻る", required:"必須", optional:"任意", success:"ありがとうございます！送信を受け付けました。", another:"別の回答を送信", cancel:"キャンセル", error:"エラーが発生しました。再度お試しください。", invalid_email:"有効なメールアドレスを入力してください。", invalid_phone:"有効な電話番号を入力してください。", upload:"アップロード", remove:"削除", select:"選択…", search:"検索…", step:"ステップ", of:"/" },
        ko: { submit:"제출", submitting:"제출 중…", loading:"불러오는 중…", next:"다음", previous:"이전", required:"필수", optional:"선택", success:"감사합니다! 제출이 접수되었습니다.", another:"다른 응답 제출", cancel:"취소", error:"문제가 발생했습니다. 다시 시도해 주세요.", invalid_email:"유효한 이메일을 입력하세요.", invalid_phone:"유효한 전화번호를 입력하세요.", upload:"업로드", remove:"제거", select:"선택…", search:"검색…", step:"단계", of:"/" },
        vi: { submit:"Gửi", submitting:"Đang gửi…", loading:"Đang tải…", next:"Tiếp", previous:"Quay lại", required:"Bắt buộc", optional:"tùy chọn", success:"Cảm ơn! Chúng tôi đã nhận được biểu mẫu.", another:"Gửi câu trả lời khác", cancel:"Hủy", error:"Đã xảy ra lỗi. Vui lòng thử lại.", invalid_email:"Vui lòng nhập email hợp lệ.", invalid_phone:"Vui lòng nhập số điện thoại hợp lệ.", upload:"Tải lên", remove:"Xóa", select:"Chọn…", search:"Tìm…", step:"Bước", of:"/" },
        th: { submit:"ส่ง", submitting:"กำลังส่ง…", loading:"กำลังโหลด…", next:"ถัดไป", previous:"ย้อนกลับ", required:"จำเป็น", optional:"ไม่บังคับ", success:"ขอบคุณ! เราได้รับการส่งของคุณแล้ว", another:"ส่งคำตอบอีก", cancel:"ยกเลิก", error:"เกิดข้อผิดพลาด ลองอีกครั้ง", invalid_email:"กรุณาใส่อีเมลที่ถูกต้อง", invalid_phone:"กรุณาใส่เบอร์โทรศัพท์ที่ถูกต้อง", upload:"อัปโหลด", remove:"ลบ", select:"เลือก…", search:"ค้นหา…", step:"ขั้นตอน", of:"จาก" },
        id: { submit:"Kirim", submitting:"Mengirim…", loading:"Memuat…", next:"Lanjut", previous:"Kembali", required:"Wajib", optional:"opsional", success:"Terima kasih! Kiriman Anda telah diterima.", another:"Kirim jawaban lain", cancel:"Batal", error:"Terjadi kesalahan. Silakan coba lagi.", invalid_email:"Masukkan email yang valid.", invalid_phone:"Masukkan nomor telepon yang valid.", upload:"Unggah", remove:"Hapus", select:"Pilih…", search:"Cari…", step:"Langkah", of:"dari" }
    };

    /* RTL language codes — drives dir="rtl" on the form root + CSS flips. */
    const FCP_RTL_LANGS = new Set([ "ar", "he", "fa", "ur", "ps", "sd", "yi", "dv", "ku" ]);

    /* Resolve a built-in string with admin overrides falling back to the
       table. Always coerces to a non-empty string so call sites are
       safe to escape + render without an undefined check. */
    function fcpI18n(form, key, vars) {
        const lang   = (form && form.settings && form.settings.language) || "en";
        const over   = (form && form.settings && form.settings.translations && form.settings.translations[key]) || null;
        let out      = (over && over[lang]) || (FCP_LANG_MAP[lang] && FCP_LANG_MAP[lang][key]) || FCP_LANG_MAP.en[key] || key;
        if (vars) Object.keys(vars).forEach(k => { out = out.replace("{" + k + "}", vars[k]); });
        return out;
    }

    /* Look up an admin-supplied translation for a custom string (field
       label, help text, button label). Falls back to the original. */
    function fcpT(form, scope, original) {
        if (!form || !form.settings || !form.settings.translations) return original;
        const lang   = form.settings.language || "en";
        if (lang === "en") return original;
        const tr = form.settings.translations[scope];
        return (tr && tr[lang]) || original;
    }

    /* Resolve final text direction. "auto" picks RTL when the language
       is in the RTL set; admin can force "ltr" or "rtl" to override. */
    function fcpDirection(form) {
        const settings = (form && form.settings) || {};
        if (settings.direction === "ltr" || settings.direction === "rtl") return settings.direction;
        return FCP_RTL_LANGS.has(settings.language || "en") ? "rtl" : "ltr";
    }

    // Expose for fields.js + admin builder preview.
    global.FCP_I18N = { LANG_MAP: FCP_LANG_MAP, RTL_LANGS: FCP_RTL_LANGS, t: fcpI18n, tCustom: fcpT, dir: fcpDirection };

    /* ─── v2.60 — Service worker registration ───
       Registers /wp-content/plugins/form-plugin/assets/js/fcp-sw.js so
       returning visitors can keep filling the form offline + queued
       submissions auto-replay on reconnect. The SW URL is set by the
       host page via window.FCP_SW_URL. Falls back to a no-op when the
       browser doesn't support service workers, or the URL is missing.
       Skip in admin-builder preview (we don't want the SW intercepting
       the admin's own fetch calls). */
    function registerFcpServiceWorker() {
        if (!("serviceWorker" in navigator)) return;
        if (!global.FCP_SW_URL) return;
        // Skip when this page is the WP admin (URL contains /wp-admin/).
        if (/\/wp-admin\//.test(location.pathname)) return;
        navigator.serviceWorker.register(global.FCP_SW_URL, { scope: "/" }).then(reg => {
            // When the SW reports a queued submission was sent, surface a toast.
            navigator.serviceWorker.addEventListener("message", (e) => {
                if (!e.data) return;
                if (e.data.type === "fcp-queued") {
                    if (window.FCApp) FCApp.toast("You're offline. Your submission is queued and will send when you're back online.", "info");
                } else if (e.data.type === "fcp-sent" && e.data.count) {
                    if (window.FCApp) FCApp.toast("✓ " + e.data.count + " queued submission" + (e.data.count > 1 ? "s" : "") + " sent.", "success");
                }
            });
            // Ask the SW to drain on connection back.
            window.addEventListener("online", () => {
                if (reg.active) reg.active.postMessage({ type: "fcp-replay-queue" });
            });
            // Use the Background Sync API when available — survives tab close.
            if ("SyncManager" in window) {
                reg.sync && reg.sync.register("fcp-flush").catch(() => {});
            }
        }).catch(() => { /* silent — SW is best-effort */ });
    }
    registerFcpServiceWorker();

    /* v2.67.2 — FCMapHelpers — shared map runtime.
       Owns the Leaflet boot + tile-layer factory + per-field init.
       Lives at the IIFE level so BOTH the public form renderer AND the
       admin form-builder canvas can call FCMapHelpers.bootIn(element).
       Pre-2.67.2 this code only ran inside renderPublicForm, so the
       admin canvas showed an empty grey box where the map should be. */
    const FCMapHelpers = (function () {
        function bootIn(container) {
            const fields = container.querySelectorAll(".fcp-map-field");
            if (!fields.length) return;
            loadLeaflet()
                .then(() => fields.forEach(initMapField))
                .catch((err) => {
                    // v2.67.3 — Surface the failure in each map canvas so
                    // the admin sees WHY the map didn't render (network
                    // blocked, CDN down, etc.) instead of a silent grey box.
                    fields.forEach(wrap => {
                        const c = wrap.querySelector("[data-fcp-map-canvas]");
                        if (c && !wrap._fcpMapInitialised) {
                            c.style.display = "flex";
                            c.style.alignItems = "center";
                            c.style.justifyContent = "center";
                            c.style.textAlign = "center";
                            c.style.padding = "20px";
                            c.innerHTML = `<div>
                                <div style="font-size:32px;margin-bottom:8px;">🗺</div>
                                <div style="font-weight:700;color:#7f1d1d;margin-bottom:4px;">Couldn't load the map runtime</div>
                                <div style="font-size:12px;color:#991b1b;">Leaflet failed to load from all CDNs (unpkg / jsdelivr / cdnjs). Your host or browser may be blocking these. Check the browser console for details.</div>
                            </div>`;
                        }
                    });
                    if (window.console) console.error("[FormCraft Map] Leaflet load failed:", err);
                });
        }
        function loadLeaflet() {
            if (window.L) return Promise.resolve(window.L);
            if (window._fcpLeafletLoading) return window._fcpLeafletLoading;
            // v2.67.3 — Try multiple CDNs in sequence. Some shared hosts
            // + corporate networks block unpkg.com (we hit this on rf.gd).
            // jsdelivr + cdnjs are the standard fallbacks. If all three
            // fail we reject loudly so the caller can show a "Couldn't
            // load map" message instead of silently leaving a grey box.
            const cdns = [
                { css: "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css",                 js: "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" },
                { css: "https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.css",      js: "https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js" },
                { css: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.css", js: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.js" }
            ];
            function tryCdn(i) {
                return new Promise((resolve, reject) => {
                    if (i >= cdns.length) return reject(new Error("All CDNs failed"));
                    const { css, js } = cdns[i];
                    if (!document.querySelector('link[data-fcp-leaflet-css]')) {
                        const link = document.createElement("link");
                        link.rel = "stylesheet";
                        link.href = css;
                        link.setAttribute("data-fcp-leaflet-css", "1");
                        document.head.appendChild(link);
                    }
                    const script = document.createElement("script");
                    script.src = js;
                    script.setAttribute("data-fcp-leaflet-js", String(i));
                    script.onload  = () => resolve(window.L);
                    script.onerror = () => {
                        script.remove();
                        tryCdn(i + 1).then(resolve, reject);
                    };
                    document.head.appendChild(script);
                });
            }
            window._fcpLeafletLoading = tryCdn(0);
            return window._fcpLeafletLoading;
        }
        function addTileLayer(L, map, provider, apiKey, customUrl) {
            switch (provider) {
                case "carto_light":
                    L.tileLayer("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png", { attribution: '&copy; OSM &copy; CARTO', subdomains: "abcd", maxZoom: 19 }).addTo(map); return;
                case "carto_dark":
                    L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",  { attribution: '&copy; OSM &copy; CARTO', subdomains: "abcd", maxZoom: 19 }).addTo(map); return;
                case "mapbox_streets":
                case "mapbox_satellite": {
                    if (!apiKey) return fallback(L, map, "Mapbox needs an access token");
                    const style = provider === "mapbox_satellite" ? "mapbox/satellite-streets-v12" : "mapbox/streets-v12";
                    L.tileLayer(`https://api.mapbox.com/styles/v1/${style}/tiles/{z}/{x}/{y}?access_token=${encodeURIComponent(apiKey)}`, {
                        attribution: '&copy; Mapbox &copy; OSM', tileSize: 512, zoomOffset: -1, maxZoom: 22
                    }).addTo(map); return;
                }
                case "maptiler_streets":
                    if (!apiKey) return fallback(L, map, "MapTiler needs an API key");
                    L.tileLayer(`https://api.maptiler.com/maps/streets-v2/{z}/{x}/{y}.png?key=${encodeURIComponent(apiKey)}`, {
                        attribution: '&copy; MapTiler &copy; OSM', tileSize: 512, zoomOffset: -1, maxZoom: 22
                    }).addTo(map); return;
                case "stadia_outdoors":
                    if (!apiKey) return fallback(L, map, "Stadia needs an API key");
                    L.tileLayer(`https://tiles.stadiamaps.com/tiles/outdoors/{z}/{x}/{y}{r}.png?api_key=${encodeURIComponent(apiKey)}`, {
                        attribution: '&copy; Stadia &copy; OSM', maxZoom: 20
                    }).addTo(map); return;
                case "google_streets":
                case "google_satellite":
                case "google_hybrid":
                    loadGoogleMaps(apiKey).then(() => {
                        const t = provider === "google_satellite" ? "satellite" : provider === "google_hybrid" ? "hybrid" : "roadmap";
                        L.gridLayer.googleMutant({ type: t }).addTo(map);
                    }).catch(() => fallback(L, map, "Google Maps load failed"));
                    return;
                case "custom":
                    if (!customUrl) return fallback(L, map, "Custom tile URL is empty");
                    L.tileLayer(customUrl, { attribution: '&copy; map data', maxZoom: 22 }).addTo(map); return;
                case "osm":
                default:
                    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
                        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>', maxZoom: 19
                    }).addTo(map);
            }
        }
        function fallback(L, map, msg) {
            try { if (window.console) console.warn("[FormCraft Map] " + msg + " — falling back to OpenStreetMap."); } catch (e) {}
            L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: '&copy; OpenStreetMap', maxZoom: 19 }).addTo(map);
        }
        function loadGoogleMaps(apiKey) {
            if (window._fcpGoogleLoading) return window._fcpGoogleLoading;
            window._fcpGoogleLoading = new Promise((resolve, reject) => {
                if (!apiKey) return reject(new Error("Missing Google Maps API key"));
                const s = document.createElement("script");
                s.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(apiKey)}&loading=async`;
                s.async = true;
                s.onload = () => {
                    const mut = document.createElement("script");
                    mut.src = "https://unpkg.com/leaflet.gridlayer.googlemutant@0.14.1/dist/Leaflet.GoogleMutant.js";
                    mut.onload  = () => resolve();
                    mut.onerror = () => reject(new Error("Failed to load GoogleMutant"));
                    document.head.appendChild(mut);
                };
                s.onerror = () => reject(new Error("Failed to load Google Maps SDK"));
                document.head.appendChild(s);
            });
            return window._fcpGoogleLoading;
        }
        function initMapField(wrap) {
            if (wrap._fcpMapInitialised) return;
            wrap._fcpMapInitialised = true;
            const L          = window.L;
            const canvas     = wrap.querySelector("[data-fcp-map-canvas]");
            const valueInput = wrap.querySelector("[data-fcp-map-value]");
            const readout    = wrap.querySelector("[data-fcp-map-readout]");
            const search     = wrap.querySelector("[data-fcp-map-search]");
            const locateBtn  = wrap.querySelector("[data-fcp-map-locate]");
            const initLat    = parseFloat(wrap.getAttribute("data-init-lat")) || 28.6139;
            const initLng    = parseFloat(wrap.getAttribute("data-init-lng")) || 77.2090;
            const initZoom   = parseInt(wrap.getAttribute("data-init-zoom"), 10) || 5;
            const allowClick = wrap.getAttribute("data-allow-click") !== "0";
            const mode       = wrap.getAttribute("data-mode") || "pin_visitor";
            const bizLat     = parseFloat(wrap.getAttribute("data-biz-lat"));
            const bizLng     = parseFloat(wrap.getAttribute("data-biz-lng"));
            const bizLabel   = wrap.getAttribute("data-biz-label") || "Our location";
            const bizAddress = wrap.getAttribute("data-biz-address") || "";
            const showBiz    = !isNaN(bizLat) && !isNaN(bizLng) && (mode === "show_business" || mode === "both");
            const provider   = wrap.getAttribute("data-provider")   || "osm";
            const apiKey     = wrap.getAttribute("data-api-key")    || "";
            const customUrl  = wrap.getAttribute("data-custom-url") || "";

            const map = L.map(canvas, { scrollWheelZoom: false }).setView([initLat, initLng], initZoom);
            addTileLayer(L, map, provider, apiKey, customUrl);

            if (showBiz) {
                const bizIcon = L.divIcon({
                    className: "fcp-biz-pin",
                    html: `<div style="position:relative;width:36px;height:46px;transform:translate(-18px,-46px);">
                        <div style="width:36px;height:36px;border-radius:50%;background:#ef4444;border:3px solid #fff;box-shadow:0 4px 10px rgba(0,0,0,.25);display:flex;align-items:center;justify-content:center;font-size:18px;">🏢</div>
                        <div style="width:0;height:0;border-left:8px solid transparent;border-right:8px solid transparent;border-top:12px solid #ef4444;position:absolute;bottom:-2px;left:10px;"></div>
                    </div>`,
                    iconSize: [36, 46], iconAnchor: [18, 46]
                });
                L.marker([bizLat, bizLng], { icon: bizIcon, interactive: true, keyboard: false })
                    .addTo(map)
                    .bindPopup(`<strong>${escapeHtml(bizLabel)}</strong>${bizAddress ? `<br>${escapeHtml(bizAddress)}` : ""}`);
                if (mode === "show_business") {
                    valueInput.value = JSON.stringify({ address: bizAddress || bizLabel, lat: +bizLat.toFixed(6), lng: +bizLng.toFixed(6) });
                }
            }

            let marker = null;
            function setPin(lat, lng, address) {
                if (!marker) {
                    marker = L.marker([lat, lng], { draggable: true }).addTo(map);
                    marker.on("dragend", () => {
                        const p = marker.getLatLng();
                        reverseGeocode(p.lat, p.lng).then(a => commit(p.lat, p.lng, a));
                    });
                } else { marker.setLatLng([lat, lng]); }
                commit(lat, lng, address);
            }
            function commit(lat, lng, address) {
                const payload = { address: address || "", lat: +lat.toFixed(6), lng: +lng.toFixed(6) };
                valueInput.value = JSON.stringify(payload);
                if (readout) readout.innerHTML = `📍 <strong>${escapeHtml(payload.address || "Pin dropped")}</strong>
                    <span style="color:var(--text-muted);font-family:var(--mono);font-size:11px;margin-left:6px;">${payload.lat}, ${payload.lng}</span>`;
            }
            function escapeHtml(s) { return String(s||"").replace(/[<>&"]/g, c => ({"<":"&lt;",">":"&gt;","&":"&amp;","\"":"&quot;"}[c])); }
            function reverseGeocode(lat, lng) {
                return fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}`, { headers: { "Accept": "application/json" } })
                    .then(r => r.json()).then(j => j.display_name || "").catch(() => "");
            }
            function forwardGeocode(query) {
                return fetch(`https://nominatim.openstreetmap.org/search?format=jsonv2&q=${encodeURIComponent(query)}&limit=1`, { headers: { "Accept": "application/json" } })
                    .then(r => r.json()).then(arr => arr[0] || null).catch(() => null);
            }

            if (allowClick) map.on("click", e => reverseGeocode(e.latlng.lat, e.latlng.lng).then(a => setPin(e.latlng.lat, e.latlng.lng, a)));
            if (search) search.addEventListener("keydown", e => {
                if (e.key !== "Enter") return;
                e.preventDefault();
                const q = search.value.trim(); if (!q) return;
                forwardGeocode(q).then(hit => {
                    if (!hit) { if (readout) readout.textContent = "No matches for that query."; return; }
                    const lat = parseFloat(hit.lat), lng = parseFloat(hit.lon);
                    map.setView([lat, lng], 14);
                    setPin(lat, lng, hit.display_name);
                });
            });
            if (locateBtn) locateBtn.addEventListener("click", () => {
                if (!navigator.geolocation) return;
                locateBtn.disabled = true; locateBtn.textContent = "…";
                navigator.geolocation.getCurrentPosition(pos => {
                    const lat = pos.coords.latitude, lng = pos.coords.longitude;
                    map.setView([lat, lng], 15);
                    reverseGeocode(lat, lng).then(a => setPin(lat, lng, a));
                    locateBtn.disabled = false; locateBtn.textContent = "📍";
                }, () => { locateBtn.disabled = false; locateBtn.textContent = "📍"; });
            });

            if (valueInput.value) {
                try {
                    const p = JSON.parse(valueInput.value);
                    if (p.lat && p.lng) setPin(parseFloat(p.lat), parseFloat(p.lng), p.address || "");
                } catch (e) {}
            }
            setTimeout(() => map.invalidateSize(), 100);
        }
        return { bootIn, loadLeaflet };
    })();
    global.FCMap = FCMapHelpers;  // Admin form-builder can call window.FCMap.bootIn(canvas)

    function renderPublicForm(container, form, opts) {
        opts = opts || {};

        // v2.63.2 — Lazy-field state lives at this scope so the sibling
        // helpers (flushLazyFields / wireLazyObserver / upgradeLazyField,
        // defined alongside `render` not inside it) can read them. render()
        // reassigns these on every pass; the helpers read them as-is.
        const LAZY_THRESHOLD = 15;
        const LAZY_EAGER     = 5;
        let   stepFields     = [];
        let   lazyEnabled    = false;
        let   lazyCounter    = 0;

        // v2.53 — Apply per-form custom CSS. Scoped only to this form via
        // an id-prefixed selector pass so it never leaks into the host
        // theme. Light sanitization strips </style and javascript:.
        if (form.customCss && !document.getElementById("fcp-custom-css-" + form.id)) {
            const tag = document.createElement("style");
            tag.id = "fcp-custom-css-" + form.id;
            tag.textContent = String(form.customCss).replace(/<\/style[^>]*>/gi, "").replace(/javascript:/gi, "");
            document.head.appendChild(tag);
        }

        // Auto-currency: detection happens AFTER the first render so it
        // never blocks page load. We render with the configured currency
        // first, then if the visitor is in a different region, the JS
        // fetch below kicks in and re-renders the affected fields.
        //
        // Intentionally SKIPS UPI (Indian protocol, INR-only) and Bank
        // (account-specific currency) — overriding those would either
        // break the field or mislead the visitor.
        const autoCurrencyEnabled = !!(form.settings && form.settings.auto_currency
            && window.FCFormConfig && FCFormConfig.autoCurrencyEnabled);
        let autoCurrencyApplied = false;
        function maybeFetchAutoCurrency() {
            if (!autoCurrencyEnabled || autoCurrencyApplied) return;
            const rest = (window.FCFormConfig && FCFormConfig.rest) || "";
            if (!rest) return;
            // setTimeout: yield so the form paints before we hit the network.
            setTimeout(() => {
                fetch(rest.replace(/\/$/, "") + "/detect-currency", {
                    credentials: "same-origin",
                    headers: { "X-WP-Nonce": (FCFormConfig.nonce || "") }
                })
                .then(r => r.json())
                .then(d => {
                    if (!d || !d.currency) return;
                    autoCurrencyApplied = true;
                    let changed = false;
                    (form.steps || []).forEach(s => {
                        (s.fields || []).forEach(f => {
                            if (["payment","pricing","product"].includes(f.type) && f.currency !== d.currency) {
                                f.currency = d.currency;
                                changed = true;
                            }
                        });
                    });
                    if (changed) render(); // repaint with the right currency
                })
                .catch(() => {});
            }, 0);
        }

        let currentStep      = 0;
        const data           = {};
        // Bot-detection signals captured for the lifetime of this form.
        const startTime      = Date.now();
        let interactionCount = 0;   // any keystroke / change / focus on real fields
        let pointerCount     = 0;   // any mouse / touch event in the form area
        // Stable session id used by the step-event tracker so the server can
        // distinguish unique visitors from re-visits. Random per page load.
        const sessionId      = Math.random().toString(36).slice(2) + Date.now().toString(36);
        const reportedSteps  = new Set();
        function reportStepEvent(type, step) {
            const key = type + ":" + step;
            if (reportedSteps.has(key)) return;
            reportedSteps.add(key);
            const restBase  = (window.FCFormConfig && FCFormConfig.rest) || "";
            const restNonce = (window.FCFormConfig && FCFormConfig.nonce) || "";
            if (!restBase) return;
            fetch(restBase.replace(/\/$/, "") + "/forms/" + form.id + "/step-event", {
                method: "POST",
                credentials: "same-origin",
                headers: { "Content-Type": "application/json", "X-WP-Nonce": restNonce },
                body: JSON.stringify({ session_id: sessionId, step: step, type: type }),
                keepalive: true
            }).catch(() => {});
        }

        // -----------------------------------------------------------
        // Form Abandonment auto-save.
        //
        // When form.settings.abandonment.enabled is true, we capture
        // whatever the visitor has typed so far as they fill the form.
        // The server upserts these into fcp_submissions with is_abandoned=1.
        // On final submit, finalize_abandoned() promotes the row to a
        // real submission (no duplicates).
        //
        // Two save channels:
        //   1. Debounced auto-save every 8 seconds while typing.
        //   2. sendBeacon() on `beforeunload` / pagehide so we capture
        //      everything even if the tab closes mid-keystroke.
        // -----------------------------------------------------------
        const abandonEnabled = !!(form.settings && form.settings.abandonment && form.settings.abandonment.enabled);
        let abandonTimer     = null;
        let lastAbandonHash  = "";

        // Collect the values from every visible .fc-field WITHOUT requiring
        // a step to be active. Mirrors saveCurrentStepData's selectors but
        // walks the whole container so cross-step data is captured.
        function snapshotAllFields() {
            const data = {};
            (form.steps || []).forEach(step => {
                (step.fields || []).forEach(f => {
                    if (["section","divider","columns","html"].includes(f.type)) return;
                    const div = container.querySelector(`.fc-field[data-fid="${f.id}"]`);
                    if (!div) return;
                    // Prefer a specific hidden mirror input if the field uses one.
                    const specific = div.querySelector(
                        "[data-fcp-schedule-value]," +
                        "[data-fcp-toggle-value]," +
                        "[data-fcp-rating-value]," +
                        "[data-fcp-file-url]," +
                        "[data-fcp-hidden]," +
                        "[data-fcp-otp-value]," +
                        "[data-fcp-video-url]"
                    );
                    if (specific) {
                        if (specific.value) data[f.label || f.type] = specific.value;
                        return;
                    }
                    const checked = div.querySelectorAll("input[type='radio']:checked, input[type='checkbox']:checked");
                    if (checked.length) {
                        const vals = Array.from(checked).map(c => c.value);
                        if (vals.length) data[f.label || f.type] = vals.length === 1 ? vals[0] : vals;
                        return;
                    }
                    const inp = div.querySelector("input,select,textarea");
                    if (inp && inp.value) data[f.label || f.type] = inp.value;
                });
            });
            return data;
        }

        function saveAbandonNow(useBeacon) {
            if (!abandonEnabled) return;
            const restBase  = (window.FCFormConfig && FCFormConfig.rest)  || "";
            const restNonce = (window.FCFormConfig && FCFormConfig.nonce) || "";
            if (!restBase) return;

            const data = snapshotAllFields();
            // Skip if nothing has changed since the last save (saves bandwidth
            // and stops empty-payload requests after the form is cleared).
            const hash = JSON.stringify(data);
            if (hash === lastAbandonHash || hash === "{}") return;
            lastAbandonHash = hash;

            const payload = JSON.stringify({ session_id: sessionId, data: data });
            const url = restBase.replace(/\/$/, "") + "/forms/" + form.id + "/track-partial";

            if (useBeacon && navigator.sendBeacon) {
                try {
                    const blob = new Blob([payload], { type: "application/json" });
                    navigator.sendBeacon(url, blob);
                    return;
                } catch (e) { /* fall through to fetch */ }
            }
            fetch(url, {
                method: "POST",
                credentials: "same-origin",
                headers: { "Content-Type": "application/json", "X-WP-Nonce": restNonce },
                body: payload,
                keepalive: true
            }).catch(() => {});
        }

        function scheduleAbandonSave() {
            if (!abandonEnabled) return;
            if (abandonTimer) clearTimeout(abandonTimer);
            abandonTimer = setTimeout(() => saveAbandonNow(false), 8000);
        }

        if (abandonEnabled) {
            // Fire a final save when the tab closes / navigates away.
            // pagehide is fired BEFORE beforeunload on iOS/Safari, and
            // is the only reliable hook on mobile browsers.
            window.addEventListener("pagehide",     () => saveAbandonNow(true));
            window.addEventListener("beforeunload", () => saveAbandonNow(true));
            // Also save when the tab is hidden (Chrome tab switching) —
            // catches mobile users that lock their phone mid-form.
            document.addEventListener("visibilitychange", () => {
                if (document.visibilityState === "hidden") saveAbandonNow(true);
            });
        }

        // Optional privacy notice — visible at the bottom of the form when
        // form.settings.abandonment.show_notice is on. Helps with GDPR
        // disclosure for sites that auto-capture data before submit.
        const showAbandonNotice = !!(abandonEnabled
            && form.settings.abandonment
            && form.settings.abandonment.show_notice);
        function abandonNoticeHTML() {
            if (!showAbandonNotice) return "";
            return '<div class="fcp-abandon-notice" style="margin-top:14px;padding:8px 12px;font-size:12px;color:#64748b;text-align:center;background:rgba(99,102,241,0.06);border:1px solid rgba(99,102,241,0.18);border-radius:8px;">'
                 + '💾 Your progress is saved automatically — you can return to this form anytime if you don\'t finish now.'
                 + '</div>';
        }

        // Surface the schedule helper to the input handlers in attachHandlers().
        // (Hoisted via closure — referenced below.)

        // Conversational mode: flatten every field across every step into a
        // virtual "step per field" sequence. We don't mutate the form
        // definition — we just track which field index the visitor is on
        // and render only that one.
        const conversational = !!(form.settings && form.settings.conversational && form.settings.conversational.enabled);
        let convIdx = 0;
        const convFields = conversational
            ? form.steps.flatMap(s => s.fields).filter(f => !["html","section","divider","columns","hidden"].includes(f.type))
            : [];

        function render() {
            if (conversational) { renderConversational(); return; }
            const stepCount = form.steps.length;
            // Defensive per-field render: a single buggy field (e.g. a logic
            // rule + UPI combination that throws) MUST NOT blank the whole
            // form. We wrap each renderField call and show an inline error
            // placeholder for any field that explodes — the rest still render.
            // v2.60 — Lazy-render threshold. Forms with > LAZY_THRESHOLD
            // fields on the current step get rendered in two passes:
            //   1) First LAZY_EAGER fields render fully so the visitor sees
            //      content above the fold immediately.
            //   2) Remaining fields render as tiny placeholders. An
            //      IntersectionObserver swaps each placeholder for the
            //      real markup ~200px before it scrolls into view.
            // On step change / submit we force-flush remaining placeholders
            // so validation + payload collection work normally.
            // v2.63.2 — Reassign the outer-scope lazy vars on every render
            // so the sibling helpers (flushLazyFields / wireLazyObserver /
            // upgradeLazyField, defined alongside `render` not inside it)
            // can read them. Pre-2.63.2 these were declared with `const`
            // inside render(), so the helpers threw "lazyEnabled is not
            // defined" — which broke the entire preview page render.
            stepFields  = (form.steps[currentStep] || {}).fields || [];
            lazyEnabled = stepFields.length > LAZY_THRESHOLD;
            lazyCounter = 0;

            function safeRenderField(f) {
                try {
                    if (lazyEnabled && lazyCounter >= LAZY_EAGER) {
                        const idx = lazyCounter++;
                        // Lightweight placeholder — same height ballpark as a
                        // real field so the scroll position doesn't jump as
                        // we upgrade. Stores the field id so the swap-in
                        // pass can find the matching schema.
                        return '<div class="fc-field fcp-lazy-field" data-fid="' + (f && f.id ? f.id : "") + '" data-lazy-idx="' + idx + '" style="min-height:72px;background:var(--bg-soft);border-radius:8px;animation:fcp-lazy-pulse 1.5s ease-in-out infinite;"></div>';
                    }
                    lazyCounter++;
                    return FCFields.renderField(f, "live");
                } catch (err) {
                    if (window.console) console.error("FormCraft: field render failed", f && f.id, err);
                    var label = (f && f.label) ? f.label : (f && f.type) ? f.type : "field";
                    label = String(label).replace(/[<>&"]/g, "");
                    return '<div class="fc-field" data-fid="' + (f && f.id ? f.id : "") + '" data-type="error" style="padding:14px;border:1px dashed #fecaca;background:#fef2f2;color:#7f1d1d;border-radius:8px;">'
                         + '<strong>Field render error:</strong> ' + label
                         + '<div style="font-size:12px;margin-top:4px;color:#b91c1c;">Check this field\'s configuration in the form builder.</div>'
                         + '</div>';
                }
            }
            // v2.59 — Resolve language + direction. The dir attribute on the
            // form root is enough for browsers to mirror form controls; the
            // CSS layout flips via [dir="rtl"] selectors in style.css.
            const fcpLang = (form.settings && form.settings.language) || "en";
            const fcpDir  = global.FCP_I18N ? global.FCP_I18N.dir(form) : "ltr";
            const a11y    = (form.settings && form.settings.a11yLabel) || form.title || "Form";
            container.innerHTML = `
                <div class="fc-form-public" role="region" aria-label="${FCApp.escapeHtml(a11y)}" lang="${FCApp.escapeHtml(fcpLang)}" dir="${fcpDir}">
                    <!-- Screen-reader live region — JS pushes step-change
                         announcements + validation errors here so AT users
                         hear "Step 2 of 3" / "Please fix the highlighted
                         fields" without us hijacking focus. -->
                    <div class="fcp-sr-live" aria-live="polite" aria-atomic="true"
                         style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;"></div>

                    <div class="fcp-form-header" style="margin-bottom:24px;text-align:center;">
                        <h2 class="fcp-form-title" id="fcp-form-title-${form.id}" style="margin:0 0 6px;font-size:26px;font-weight:700;line-height:1.25;color:#0f172a;letter-spacing:-0.02em;">${FCApp.escapeHtml(form.title || "")}</h2>
                        ${form.description ? `<p class="fcp-form-description" style="margin:0;font-size:15px;line-height:1.5;color:#64748b;max-width:520px;margin-left:auto;margin-right:auto;">${FCApp.escapeHtml(form.description)}</p>` : ""}
                    </div>

                    ${stepCount > 1 ? progressMarkup() : ""}

                    <form id="fcForm" novalidate autocomplete="off" aria-labelledby="fcp-form-title-${form.id}">
                        ${form.steps.map((s, i) => `
                            <div class="fc-step-panel ${i === currentStep ? "active" : ""}" data-step="${i}">
                                ${stepCount > 1 ? `<h3 style="margin:0 0 14px;">${FCApp.escapeHtml(s.title)}</h3>` : ""}
                                ${(s.fields || []).map(safeRenderField).join("")}
                            </div>`).join("")}

                        ${(() => {
                            // v2.67.9 — Defence-in-depth captcha gate.
                            const globalEnabled = !window.FCP_BOOTSTRAP || (window.FCP_BOOTSTRAP.recaptcha && window.FCP_BOOTSTRAP.recaptcha.enabled);
                            if (!form.settings.recaptcha || !globalEnabled || currentStep !== stepCount - 1) return "";
                            // v2.67.10 — Suppress when an explicit captcha field is on the form.
                            const hasExplicitCaptcha = form.steps.some(st => (st.fields || []).some(fld => fld.type === "captcha"));
                            if (hasExplicitCaptcha) return "";
                            // v2.67.13 — Render the RIGHT widget div for the
                            // admin's picked provider. Pre-2.67.13 this was a
                            // hardcoded reCAPTCHA-branded mock that showed
                            // "I'm not a robot · reCAPTCHA · Privacy · Terms"
                            // regardless of provider — so hCaptcha and Turnstile
                            // sites saw Google's branding even though the JS
                            // library on the page was hCaptcha's. Now each
                            // provider gets its native widget div; their
                            // auto-renderer scripts (loaded in the shortcode)
                            // inject the real, branded widget.
                            const b        = window.FCP_BOOTSTRAP && window.FCP_BOOTSTRAP.recaptcha ? window.FCP_BOOTSTRAP.recaptcha : {};
                            const provider = b.provider || "recaptcha";
                            const siteKey  = b.site_key || "";
                            const version  = b.version  || "v3";
                            // v3 flavours are invisible — no widget div needed;
                            // grecaptcha.execute() runs on submit.
                            if (provider === "recaptcha" && version === "v3") return "";
                            const label = "Verify you're not a robot";
                            let widget = "";
                            if (provider === "hcaptcha") {
                                widget = `<div class="h-captcha" data-sitekey="${FCApp.escapeHtml(siteKey)}"></div>`;
                            } else if (provider === "turnstile") {
                                widget = `<div class="cf-turnstile" data-sitekey="${FCApp.escapeHtml(siteKey)}"></div>`;
                            } else {
                                widget = `<div class="g-recaptcha" data-sitekey="${FCApp.escapeHtml(siteKey)}"></div>`;
                            }
                            // No key configured yet → fall back to the mock so
                            // the admin sees SOMETHING in preview + gets the
                            // hint to configure the keys.
                            if (!siteKey) {
                                const brand = provider === "hcaptcha" ? "hCaptcha" : provider === "turnstile" ? "Cloudflare Turnstile" : "reCAPTCHA";
                                widget = `<div style="border:1px solid var(--border);background:var(--bg-soft);padding:14px;border-radius:10px;display:flex;align-items:center;gap:10px;max-width:320px;">
                                    <input type="checkbox" id="fcCaptcha" style="width:24px;height:24px;">
                                    <span style="font-weight:600;">I'm not a robot</span>
                                    <div style="margin-left:auto;font-size:11px;color:var(--text-soft);text-align:right;">${brand}<br>(no site key set)</div>
                                </div>`;
                            }
                            return `<div class="fc-field" id="recaptchaBox">
                                <label>${label}</label>
                                ${widget}
                            </div>`;
                        })()}

                        <div class="fc-nav">
                            ${currentStep > 0 ?
                                `<button type="button" class="btn btn-outline" id="prevBtn">${FCApp.ICONS.arrowLeft} ${FCApp.escapeHtml(global.FCP_I18N.t(form, "previous"))}</button>`
                                : "<span></span>"}
                            <div style="display:flex;gap:8px;">
                                ${form.settings.saveResume !== false ? `<button type="button" class="btn btn-ghost btn-sm" id="saveDraftBtn" title="Email yourself a link to resume later">${FCApp.ICONS.save || ""} Save & continue later</button>` : ""}
                                ${currentStep < stepCount - 1 ?
                                    `<button type="button" class="btn btn-primary" id="nextBtn">${FCApp.escapeHtml(global.FCP_I18N.t(form, "next"))} ${FCApp.ICONS.arrowRight}</button>` :
                                    `<button type="submit" class="btn btn-primary">${FCApp.escapeHtml(form.settings.submitText || global.FCP_I18N.t(form, "submit"))} ${FCApp.ICONS.arrowRight}</button>`}
                            </div>
                        </div>

                        <!--
                            Honeypot block. Hidden from real users via off-screen
                            CSS + aria-hidden, but field names / labels / types
                            are bot-attractive (Fake Filler and most spam bots
                            fill any input that looks like "website" / "phone").
                            All four are checked server-side and any one being
                            filled marks the submission as spam.
                        -->
                        <div class="fcp-hp-wrap" aria-hidden="true" tabindex="-1">
                            <label>Your website</label>
                            <input class="fcp-hp" type="url"   name="fcp_hp_website"  tabindex="-1" autocomplete="off">
                            <label>Confirm email</label>
                            <input class="fcp-hp" type="email" name="fcp_hp_email"    tabindex="-1" autocomplete="off">
                            <label>Phone</label>
                            <input class="fcp-hp" type="tel"   name="fcp_hp_phone"    tabindex="-1" autocomplete="off">
                            <label>Address</label>
                            <input class="fcp-hp" type="text"  name="fcp_hp_address"  tabindex="-1" autocomplete="off">
                        </div>
                    </form>
                    ${abandonNoticeHTML()}
                </div>`;

            FCFields.hydrate(container);
            attachHandlers();
            applyLogic();
            // Tracked once per (session, step, type) — server de-dupes too.
            reportStepEvent("view", currentStep);
            // Kick off auto-currency detection AFTER the form has painted.
            // No-op if disabled / already done. The fetch is async + cached,
            // so subsequent renders (step navigation) don't re-hit the API.
            maybeFetchAutoCurrency();
        }

        // --- Conversational render (Typeform-style one-at-a-time) ---
        function renderConversational() {
            if (convIdx >= convFields.length) {
                // Final "ready to submit" screen
                container.innerHTML = `
                    <div class="fc-form-public fcp-conv" style="text-align:center;padding:40px 20px;">
                        <h2 style="margin:0 0 16px;">${FCApp.escapeHtml(form.title)}</h2>
                        <p class="text-muted" style="max-width:480px;margin:0 auto 24px;">Ready to send? Review your answers below.</p>
                        <form id="fcForm" novalidate>
                            <div style="text-align:left;max-width:560px;margin:0 auto 24px;background:var(--bg-elev);border:1px solid var(--border);border-radius:10px;padding:18px;">
                                ${convFields.map(f => {
                                    let v = data[f.label];
                                    if (Array.isArray(v)) v = v.join(", ");
                                    return `<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border-soft);">
                                        <div class="text-muted" style="font-size:13px;">${FCApp.escapeHtml(f.label)}</div>
                                        <div class="fw-700" style="font-size:13px;text-align:right;max-width:60%;word-break:break-word;">${FCApp.escapeHtml((v == null ? "—" : String(v)).slice(0, 100))}</div>
                                    </div>`;
                                }).join("")}
                            </div>
                            <button type="submit" class="btn btn-primary" style="padding:12px 32px;font-size:16px;">${FCApp.escapeHtml(form.settings.submitText || global.FCP_I18N.t(form, "submit"))} →</button>
                            <div><button type="button" class="btn btn-ghost btn-sm" style="margin-top:14px;" id="convBack">← Back to edit</button></div>
                        </form>
                    </div>`;
                document.getElementById("convBack").addEventListener("click", () => { convIdx--; render(); });
                document.getElementById("fcForm").addEventListener("submit", e => {
                    e.preventDefault();
                    ensureRecaptchaToken().then(handleSubmit).catch(err => FCApp.toast(err.message || "Verification failed.", "error"));
                });
                return;
            }
            const f      = convFields[convIdx];
            const pct    = Math.round(((convIdx + 1) / (convFields.length + 1)) * 100);
            const isLast = convIdx === convFields.length - 1;
            container.innerHTML = `
                <div class="fc-form-public fcp-conv" style="min-height:420px;display:flex;flex-direction:column;">
                    <div style="height:4px;background:var(--bg-soft);border-radius:2px;margin-bottom:32px;">
                        <div style="height:100%;width:${pct}%;background:linear-gradient(90deg,var(--brand-500),var(--brand-600));border-radius:2px;transition:width .4s;"></div>
                    </div>
                    <form id="fcForm" novalidate style="flex:1;display:flex;flex-direction:column;justify-content:center;max-width:640px;margin:0 auto;width:100%;">
                        <div style="font-size:12px;color:var(--text-muted);font-weight:600;margin-bottom:8px;">${convIdx + 1} of ${convFields.length}</div>
                        <h2 style="margin:0 0 24px;font-size:26px;line-height:1.3;">${FCApp.escapeHtml(f.label || "")} ${f.required ? '<span style="color:var(--danger);">*</span>' : ""}</h2>
                        ${FCFields.renderField(f, "live")}
                        <div style="margin-top:32px;display:flex;gap:10px;align-items:center;">
                            ${convIdx > 0 ? `<button type="button" class="btn btn-outline" id="convPrev">← ${FCApp.escapeHtml(global.FCP_I18N.t(form, "previous"))}</button>` : ""}
                            <button type="button" class="btn btn-primary" id="convNext" style="padding:10px 28px;">${FCApp.escapeHtml(isLast ? global.FCP_I18N.t(form, "submit") : global.FCP_I18N.t(form, "next"))} →</button>
                            <span class="text-muted text-sm" style="margin-left:auto;">Press Enter ↵</span>
                        </div>
                    </form>
                </div>`;
            FCFields.hydrate(container);
            const next = document.getElementById("convNext");
            const prev = document.getElementById("convPrev");
            function advance() {
                // Save this single field
                const div = container.querySelector(".fc-field");
                if (div) {
                    const tempPanel = document.createElement("div");
                    tempPanel.className = "fc-step-panel";
                    tempPanel.dataset.step = "0";
                    tempPanel.appendChild(div.cloneNode(true));
                    // Replicate saveCurrentStepData by leveraging the same logic
                    // But simpler: just collect the field's value directly.
                }
                // Reuse the main collector by temporarily wrapping
                const realPanel = container.querySelector("form");
                if (realPanel) {
                    // synthesize step panel for saveCurrentStepData
                    const panel = document.createElement("div");
                    panel.className = "fc-step-panel active";
                    panel.dataset.step = "0";
                    container.querySelectorAll(".fc-field").forEach(d => panel.appendChild(d));
                    container.appendChild(panel);
                    // Hack: temporarily set currentStep / form.steps[0].fields
                    const origFields = form.steps[0].fields;
                    form.steps[0].fields = [ f ];
                    const origStep = currentStep;
                    currentStep = 0;
                    saveCurrentStepData();
                    form.steps[0].fields = origFields;
                    currentStep = origStep;
                }
                convIdx++;
                render();
            }
            next.addEventListener("click", advance);
            if (prev) prev.addEventListener("click", () => { convIdx--; render(); });
            // Auto-advance on radio / yesno pick
            const auto = form.settings.conversational.autoAdvance !== false;
            if (auto) {
                container.querySelectorAll('.fc-field input[type="radio"]').forEach(r =>
                    r.addEventListener("change", () => setTimeout(advance, 250))
                );
            }
            // Enter key advances
            container.addEventListener("keydown", e => {
                if (e.key === "Enter" && e.target.tagName !== "TEXTAREA") {
                    e.preventDefault();
                    advance();
                }
            });
        }

        function progressMarkup() {
            const pct = ((currentStep) / (form.steps.length - 1)) * 100;
            if ((form.settings.progressStyle || "bar") === "steps") {
                return `<div class="fc-progress">
                    <div class="fc-progress-steps">
                        ${form.steps.map((s, i) => `
                            <div class="fc-step ${i < currentStep ? "done" : (i === currentStep ? "active" : "")}">
                                <div class="num">${i < currentStep ? "✓" : (i + 1)}</div>
                                <div class="title">${FCApp.escapeHtml(s.title)}</div>
                            </div>`).join("")}
                    </div>
                </div>`;
            } else if (form.settings.progressStyle === "none") {
                return "";
            }
            return `<div class="fc-progress">
                <div class="fc-progress-bar"><div class="fc-progress-fill" style="width:${pct}%"></div></div>
                <div class="flex justify-between mt-2 text-sm text-muted">
                    <span>Step ${currentStep + 1} of ${form.steps.length}</span>
                    <span>${Math.round(pct)}% complete</span>
                </div>
            </div>`;
        }

        // ─── v2.60 — Lazy-field upgrade pass ───
        // Walk every .fcp-lazy-field placeholder + replace with the real
        // markup when it enters the viewport. Required-field placeholders
        // are upgraded immediately so validation can grab their values.
        // On step change / submit, flushLazyFields() forces all remaining
        // placeholders to upgrade synchronously so the payload is complete.
        function flushLazyFields() {
            const placeholders = container.querySelectorAll(".fcp-lazy-field");
            placeholders.forEach(ph => upgradeLazyField(ph));
        }
        function upgradeLazyField(ph) {
            const fid = ph.getAttribute("data-fid");
            if (!fid) return;
            const field = stepFields.find(f => f.id === fid);
            if (!field) return;
            try {
                const html = FCFields.renderField(field, "live");
                const wrap = document.createElement("div");
                wrap.innerHTML = html;
                const real = wrap.firstElementChild;
                if (real) ph.replaceWith(real);
                else      ph.classList.remove("fcp-lazy-field");
            } catch (e) {
                ph.classList.remove("fcp-lazy-field");
            }
        }
        function wireLazyObserver() {
            if (!lazyEnabled || !("IntersectionObserver" in window)) {
                flushLazyFields();
                return;
            }
            // Upgrade required fields eagerly so validation can read them
            // even if the visitor never scrolls down before submitting.
            container.querySelectorAll(".fcp-lazy-field").forEach(ph => {
                const fid = ph.getAttribute("data-fid");
                const field = stepFields.find(f => f.id === fid);
                if (field && field.required) upgradeLazyField(ph);
            });
            const io = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        upgradeLazyField(entry.target);
                        io.unobserve(entry.target);
                    }
                });
            }, { rootMargin: "200px 0px" });
            container.querySelectorAll(".fcp-lazy-field").forEach(ph => io.observe(ph));
        }

        /* v2.67 — Map / Location field bootstrap.
           Delegates to the IIFE-level FCMapHelpers (also exported as the
           global FCMap so the admin form-builder canvas can boot the
           same Leaflet maps in-place — without that, the builder canvas
           shows only the empty grey placeholder you saw before). */
        function wireMapFields() {
            FCMapHelpers.bootIn(container);
        }

        function attachHandlers() {
            wireLazyObserver();
            // v2.67 — Boot Leaflet for any map fields on the current step.
            // Lazy-loads the Leaflet runtime (CSS + JS) on first use so
            // forms without a map field never download it.
            wireMapFields();
            const next = container.querySelector("#nextBtn");
            const prev = container.querySelector("#prevBtn");
            const save = container.querySelector("#saveDraftBtn");
            const formEl = container.querySelector("#fcForm");
            if (next) next.addEventListener("click", () => {
                if (!validateCurrentStep()) return;
                saveCurrentStepData();
                reportStepEvent("complete", currentStep);
                currentStep++; render();
                container.scrollIntoView({ behavior: "smooth", block: "start" });
                // Screen-reader + keyboard focus: announce + focus the new step.
                announce("Step " + (currentStep + 1) + " of " + stepCount + ": " + (form.steps[currentStep] && form.steps[currentStep].name ? form.steps[currentStep].name : ""));
                focusFirstFieldOfCurrentStep();
            });
            if (prev) prev.addEventListener("click", () => {
                saveCurrentStepData();
                currentStep--; render();
                container.scrollIntoView({ behavior: "smooth", block: "start" });
                announce("Step " + (currentStep + 1) + " of " + stepCount);
                focusFirstFieldOfCurrentStep();
            });
            if (save) save.addEventListener("click", openSaveDraftModal);
            formEl.addEventListener("submit", e => {
                e.preventDefault();
                if (!validateCurrentStep()) return;
                if (form.settings.recaptcha) {
                    const c = container.querySelector("#fcCaptcha");
                    if (c && !c.checked) {
                        FCApp.toast("Please complete the CAPTCHA", "warning");
                        return;
                    }
                }
                // UPI / Bank transfer fields require BOTH a reference ID and
                // the "I have completed the payment" checkbox to be ticked
                // before we accept the submission. Skip cards whose parent
                // method is not the currently-selected one (the methods
                // radio collapses other cards via display:none).
                const payConfirms = container.querySelectorAll("[data-fcp-payconfirm]");
                for (let i = 0; i < payConfirms.length; i++) {
                    const wrap = payConfirms[i];
                    // If the card is hidden (visitor picked a different method)
                    // skip the check — getComputedStyle is the truth here
                    // because parents may collapse it via display:none.
                    if (wrap.offsetParent === null) continue;
                    const cb = wrap.querySelector("[data-fcp-payconfirm-cb]");
                    const ref= wrap.querySelector("[data-fcp-payref]");
                    if (!cb || !ref) continue;
                    if (!ref.value || ref.value.trim().length < parseInt(wrap.dataset.minRef || "6", 10)) {
                        FCApp.toast("Please enter your payment reference ID", "warning");
                        ref.focus();
                        ref.scrollIntoView({ behavior: "smooth", block: "center" });
                        return;
                    }
                    if (!cb.checked) {
                        FCApp.toast("Please tick the payment confirmation checkbox", "warning");
                        const callout = wrap.querySelector("[data-fcp-confirm-callout]");
                        if (callout) {
                            callout.scrollIntoView({ behavior: "smooth", block: "center" });
                            callout.style.transition = "box-shadow .3s";
                            callout.style.boxShadow = "0 0 0 4px rgba(239,68,68,0.45)";
                            setTimeout(() => { callout.style.boxShadow = ""; }, 1400);
                        }
                        return;
                    }
                }
                saveCurrentStepData();
                reportStepEvent("submit", currentStep);
                ensureRecaptchaToken().then(handleSubmit).catch(err => {
                    FCApp.toast(err.message || "reCAPTCHA verification failed.", "error");
                });
            });
            // Live logic re-eval on input
            formEl.addEventListener("input", applyLogic);
            formEl.addEventListener("change", applyLogic);

            // Track only real-field interactions (skip honeypot fields).
            const realInputs = container.querySelectorAll(".fc-field input, .fc-field select, .fc-field textarea");
            realInputs.forEach(el => {
                el.addEventListener("input",  () => { interactionCount++; scheduleAbandonSave(); });
                el.addEventListener("change", () => { interactionCount++; scheduleAbandonSave(); });
                el.addEventListener("keydown",() => { interactionCount++; });
            });
            // Pointer/mouse activity inside the form area — humans use a mouse;
            // most bots set values programmatically without any pointer events.
            ["mousemove","mousedown","touchstart"].forEach(evt => {
                container.addEventListener(evt, () => { pointerCount++; }, { passive: true });
            });
        }

        /**
         * Resolve with the v3 reCAPTCHA token (or accept the v2 widget's
         * response) and stuff it into the hidden token input. Server-side
         * verifies the token against Google's siteverify API before
         * accepting the submission. Resolves immediately when no captcha
         * field is present.
         */
        function ensureRecaptchaToken() {
            const hidden = container.querySelector('input[name="fcp_recaptcha_token"]');
            function setToken(t) { if (hidden) hidden.value = t || ""; }

            // hCaptcha widget — read token from the rendered widget. Tokens
            // also auto-populate hidden h-captcha-response on the host page,
            // but we standardise on fcp_recaptcha_token for the server.
            const hcap = container.querySelector("[data-fcp-hcaptcha]");
            if (hcap) {
                if (!window.hcaptcha || !hcaptcha.getResponse) {
                    return Promise.reject(new Error("hCaptcha didn't load."));
                }
                const t = hcaptcha.getResponse();
                if (!t) return Promise.reject(new Error("Please complete the hCaptcha challenge."));
                setToken(t);
                return Promise.resolve();
            }
            // Cloudflare Turnstile — same pattern.
            const turn = container.querySelector("[data-fcp-turnstile]");
            if (turn) {
                if (!window.turnstile || !turnstile.getResponse) {
                    return Promise.reject(new Error("Cloudflare Turnstile didn't load."));
                }
                const t = turnstile.getResponse(turn);
                if (!t) return Promise.reject(new Error("Please complete the verification challenge."));
                setToken(t);
                return Promise.resolve();
            }
            const v2 = container.querySelector("[data-fcp-captcha]");
            if (v2) {
                const token = (window.grecaptcha && grecaptcha.getResponse) ? grecaptcha.getResponse() : "";
                if (!token) {
                    return Promise.reject(new Error("Please complete the reCAPTCHA challenge."));
                }
                setToken(token);
                return Promise.resolve();
            }
            const v3 = container.querySelector("[data-fcp-captcha-v3]");
            if (v3) {
                const siteKey = v3.dataset.sitekey;
                if (!window.grecaptcha || !grecaptcha.execute) {
                    return Promise.reject(new Error("reCAPTCHA v3 script didn't load."));
                }
                return new Promise((resolve, reject) => {
                    try {
                        grecaptcha.ready(() => {
                            grecaptcha.execute(siteKey, { action: "submit" }).then(token => {
                                setToken(token);
                                resolve();
                            }).catch(err => reject(err));
                        });
                    } catch (e) { reject(e); }
                });
            }
            // v2.67.13 — Auto-inject widget path. When the admin turns on the
            // global "Enable reCAPTCHA protection" toggle without dragging an
            // explicit captcha field, we render one of these three standard
            // widget divs in the form-render step, and the picked provider's
            // JS (loaded via wp_enqueue_script in class-fcp-shortcode.php)
            // auto-injects the real widget. Token lookup mirrors the picked
            // provider so hCaptcha / Turnstile / reCAPTCHA all work.
            const hcapAuto = container.querySelector(".h-captcha");
            if (hcapAuto) {
                if (!window.hcaptcha || !hcaptcha.getResponse) {
                    return Promise.reject(new Error("hCaptcha didn't load."));
                }
                const t = hcaptcha.getResponse();
                if (!t) return Promise.reject(new Error("Please complete the hCaptcha challenge."));
                setToken(t);
                return Promise.resolve();
            }
            const turnAuto = container.querySelector(".cf-turnstile");
            if (turnAuto) {
                if (!window.turnstile || !turnstile.getResponse) {
                    return Promise.reject(new Error("Cloudflare Turnstile didn't load."));
                }
                const t = turnstile.getResponse(turnAuto);
                if (!t) return Promise.reject(new Error("Please complete the verification challenge."));
                setToken(t);
                return Promise.resolve();
            }
            const rcAuto = container.querySelector(".g-recaptcha");
            if (rcAuto) {
                const t = (window.grecaptcha && grecaptcha.getResponse) ? grecaptcha.getResponse() : "";
                if (!t) return Promise.reject(new Error("Please complete the reCAPTCHA challenge."));
                setToken(t);
                return Promise.resolve();
            }
            return Promise.resolve();
        }

        /**
         * Collect bot-detection signals. Server uses these to decide if
         * the submission should be classified as spam.
         */
        function collectSpamSignals() {
            const hps = container.querySelectorAll(".fcp-hp");
            let hpFilled = false;
            hps.forEach(el => {
                if (el.value && el.value.trim() !== "") hpFilled = true;
            });
            return {
                hp:           hpFilled ? 1 : 0,
                time:         Math.max(0, Math.floor((Date.now() - startTime) / 1000)),
                interactions: interactionCount,
                pointer:      pointerCount,
                fields:       Object.keys(data).length
            };
        }

        function validateCurrentStep() {
            // v2.60 — Flush any still-unrendered lazy placeholders BEFORE
            // running validation so we read real input values (not the
            // placeholder div).
            flushLazyFields();
            return _validateCurrentStep();
        }
        function _validateCurrentStep() {
            const panel = container.querySelector(`.fc-step-panel[data-step="${currentStep}"]`);
            let ok = true;
            // Layout / informational fields don't take user input — skip the
            // required-validation loop for them.
            const NON_INPUT_TYPES = ["section","divider","html","columns","hidden"];
            panel.querySelectorAll(".fc-field").forEach(div => {
                const fid = div.dataset.fid;
                const f = form.steps[currentStep].fields.find(x => x.id === fid);
                if (!f) return;
                if (NON_INPUT_TYPES.includes(f.type)) return;
                // skip hidden fields (conditional logic)
                if (div.style.display === "none") return;
                const errPrev = div.querySelector(".form-error");
                if (errPrev) errPrev.remove();

                if (f.required) {
                    // GDPR: must explicitly check the consent box.
                    if (f.type === "gdpr") {
                        const cb = div.querySelector("[data-fcp-gdpr]");
                        if (!cb || !cb.checked) {
                            ok = false;
                            const e = document.createElement("div");
                            e.className = "form-error";
                            e.textContent = f.errorMessage || "You must agree to continue";
                            div.appendChild(e);
                        }
                        return;
                    }
                    // Toggle: required means the user must actually flip it ON.
                    if (f.type === "toggle") {
                        const val = div.querySelector("[data-fcp-toggle-value]");
                        if (!val || val.value !== "Yes") {
                            ok = false;
                            const e = document.createElement("div");
                            e.className = "form-error";
                            e.textContent = f.errorMessage || "Please enable this option";
                            div.appendChild(e);
                        }
                        return;
                    }
                    const inputs = div.querySelectorAll("input,select,textarea");
                    let hasValue = false;
                    inputs.forEach(i => {
                        if (i.type === "checkbox" || i.type === "radio") { if (i.checked) hasValue = true; }
                        else if (i.value && i.value.trim() !== "") hasValue = true;
                    });
                    if (!hasValue && f.type !== "rating") {
                        ok = false;
                        const e = document.createElement("div");
                        e.className = "form-error";
                        e.textContent = f.errorMessage || "This field is required";
                        div.appendChild(e);
                    }
                    if (f.type === "rating") {
                        const rt = div.querySelector(".fc-rating");
                        if (!rt.dataset.value) {
                            ok = false;
                            const e = document.createElement("div");
                            e.className = "form-error";
                            e.textContent = f.errorMessage || "Please rate before continuing";
                            div.appendChild(e);
                        }
                    }
                }
                // Email pattern
                if (f.type === "email") {
                    const i = div.querySelector("input");
                    if (i && i.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(i.value)) {
                        ok = false;
                        const e = document.createElement("div");
                        e.className = "form-error";
                        e.textContent = "Please enter a valid email address";
                        div.appendChild(e);
                    }
                }

                // v2.53 — Visual validation rules (admin-defined per field)
                if (Array.isArray(f.validationRules) && f.validationRules.length) {
                    const inp = div.querySelector("input,textarea");
                    const val = inp ? (inp.value || "").trim() : "";
                    if (val) {
                        for (const rule of f.validationRules) {
                            const v = (rule.value  || "").toString();
                            const v2= (rule.value2 || "").toString();
                            const lv = val.toLowerCase();
                            const lr = v.toLowerCase();
                            let pass = true;
                            switch (rule.type) {
                                case "contains":      pass = lr === "" || lv.indexOf(lr) !== -1; break;
                                case "not_contains":  pass = lr === "" || lv.indexOf(lr) === -1; break;
                                case "starts_with":   pass = lr === "" || lv.indexOf(lr) === 0; break;
                                case "ends_with":     pass = lr === "" || lv.lastIndexOf(lr) === lv.length - lr.length; break;
                                case "equals":        pass = lv === lr; break;
                                case "min_words":     pass = val.split(/\s+/).filter(Boolean).length >= (parseInt(v, 10) || 0); break;
                                case "max_words":     pass = val.split(/\s+/).filter(Boolean).length <= (parseInt(v, 10) || Infinity); break;
                                case "between": {
                                    const n = parseFloat(val);
                                    pass = !isNaN(n) && n >= parseFloat(v) && n <= parseFloat(v2);
                                    break;
                                }
                                case "is_email":      pass = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val); break;
                                case "is_url":        pass = /^https?:\/\/\S+\.\S+/.test(val); break;
                                case "is_numeric":    pass = /^-?\d+(\.\d+)?$/.test(val); break;
                                case "blocked_words": {
                                    const words = v.split(/[,\n]/).map(s => s.trim().toLowerCase()).filter(Boolean);
                                    pass = !words.some(w => lv.indexOf(w) !== -1);
                                    break;
                                }
                            }
                            if (!pass) {
                                ok = false;
                                const e = document.createElement("div");
                                e.className = "form-error";
                                e.textContent = rule.message || ("This value doesn't match the rule (" + rule.type.replace(/_/g, " ") + ").");
                                div.appendChild(e);
                                break;     // one rule failure per field is enough
                            }
                        }
                    }
                }
            });
            if (!ok) {
                FCApp.toast("Please fix errors in this step", "error");
                // Move focus to the first invalid field and announce to
                // screen readers. WCAG 2.4.3 Focus Order + 3.3.1 Error
                // Identification expect this on failed validation.
                const firstErr = panel.querySelector(".form-error");
                if (firstErr) {
                    const errField = firstErr.closest(".fc-field");
                    const focusTarget = errField && errField.querySelector("input,select,textarea,button");
                    if (focusTarget) {
                        try { focusTarget.focus(); } catch (e) {}
                        focusTarget.setAttribute("aria-invalid", "true");
                    }
                    announce("Please correct the highlighted fields: " + firstErr.textContent);
                }
            } else {
                // Clear any stale aria-invalid from a previous attempt.
                panel.querySelectorAll('[aria-invalid="true"]').forEach(el => el.removeAttribute("aria-invalid"));
            }
            return ok;
        }

        /** Moves keyboard focus to the first focusable input on the current
         *  step. WCAG 2.4.3 — when content changes, focus should land on
         *  the new actionable element. */
        function focusFirstFieldOfCurrentStep() {
            const panel = container.querySelector(`.fc-step-panel[data-step="${currentStep}"]`);
            if (!panel) return;
            const target = panel.querySelector("input:not([type='hidden']):not([disabled]), select:not([disabled]), textarea:not([disabled])");
            if (target) { try { target.focus({ preventScroll: true }); } catch (e) {} }
        }

        /** Pushes a short string into the offscreen aria-live region so
         *  screen readers announce it. Safe to call with empty/null. */
        function announce(message) {
            if (!message) return;
            const live = container.querySelector(".fcp-sr-live");
            if (!live) return;
            // Reset → set, so identical consecutive messages still announce.
            live.textContent = "";
            setTimeout(() => { live.textContent = String(message); }, 50);
        }

        function saveCurrentStepData() {
            const panel = container.querySelector(`.fc-step-panel[data-step="${currentStep}"]`);
            // Layout fields don't have submitted values — skip them so they
            // don't end up as empty rows in the submission data.
            const SKIP_TYPES = ["section","divider","html","columns","captcha"];
            panel.querySelectorAll(".fc-field").forEach(div => {
                const fid = div.dataset.fid;
                const f = form.steps[currentStep].fields.find(x => x.id === fid);
                if (!f) return;
                if (SKIP_TYPES.includes(f.type)) return;
                if (f.type === "checkbox" || f.type === "multiselect") {
                    // Both render as a checkbox list — collect every checked value.
                    data[f.label] = Array.from(div.querySelectorAll("input[type='checkbox']:checked")).map(i => i.value);
                } else if (f.type === "rating") {
                    data[f.label] = div.querySelector(".fc-rating")?.dataset.value || "";
                } else if (f.type === "radio" || f.type === "yesno") {
                    // Picked-radio value (or empty when nothing chosen)
                    const checked = div.querySelector('input[type="radio"]:checked');
                    data[f.label] = checked ? checked.value : "";
                } else if (f.type === "toggle") {
                    // Hidden Yes/No mirror set by the toggle hydrate
                    const val = div.querySelector("[data-fcp-toggle-value]");
                    data[f.label] = val ? (val.value || "No") : "No";
                } else if (f.type === "likert") {
                    // Collect one answer per statement → { stmt: scale-label }
                    const out = {};
                    div.querySelectorAll("input[type='radio']:checked").forEach(r => {
                        const stmt = r.dataset.likertStmt;
                        const lab  = r.dataset.likertLabel;
                        if (stmt) out[stmt] = lab + " (" + r.value + ")";
                    });
                    data[f.label] = out;
                } else if (f.type === "nps") {
                    const checked = div.querySelector("input[type='radio']:checked");
                    data[f.label] = checked ? checked.value : "";
                } else if (f.type === "poll") {
                    const checked = div.querySelector("input[type='radio']:checked");
                    data[f.label] = checked ? checked.value : "";
                } else if (f.type === "video") {
                    // Pipe upload URL stashed in the hidden input by hydrate
                    const inp = div.querySelector("[data-fcp-video-url]");
                    data[f.label] = inp ? (inp.value || "") : "";
                } else if (f.type === "schedule") {
                    // Hidden input holds the ISO datetime like "2026-04-15T14:00"
                    const inp = div.querySelector("[data-fcp-schedule-value]");
                    data[f.label] = inp ? (inp.value || "") : "";
                } else if (f.type === "list") {
                    // Flat list of non-empty values
                    const vals = Array.from(div.querySelectorAll("[data-fcp-list-input]"))
                        .map(i => (i.value || "").trim())
                        .filter(v => v !== "");
                    data[f.label] = vals;
                } else if (f.type === "repeater") {
                    // Walk every row, pull each sub-field's value into an
                    // object keyed by the sub-field label. Skip rows that
                    // are entirely empty so partially-filled forms don't
                    // produce noisy blanks in submissions / emails.
                    const rows = div.querySelectorAll("[data-fcp-rep-row]");
                    const out  = [];
                    rows.forEach(row => {
                        const obj = {};
                        let hasValue = false;
                        row.querySelectorAll("[data-sub-label]").forEach(inp => {
                            const label = inp.dataset.subLabel || inp.dataset.subId || "field";
                            let val;
                            if (inp.type === "checkbox") {
                                val = inp.checked ? "Yes" : "";
                            } else {
                                val = (inp.value || "").trim();
                            }
                            if (val !== "") hasValue = true;
                            obj[label] = val;
                        });
                        if (hasValue) out.push(obj);
                    });
                    data[f.label] = out;
                } else if (f.type === "file" || f.type === "image") {
                    // The visible <input type=file> has a useless C:\fakepath\
                    // value. The hidden [data-fcp-file-url] input is the one
                    // populated by the upload handler with the public URL.
                    const urlInp = div.querySelector("[data-fcp-file-url]");
                    data[f.label] = urlInp ? (urlInp.value || "") : "";
                } else if (f.type === "signature") {
                    // Export the canvas as a PNG data URL so the actual
                    // signature image is stored with the submission and can
                    // be rendered later. Only export when the user has drawn
                    // something — otherwise save empty so required-validation
                    // and the detail view can show "—".
                    const canvas = div.querySelector(".signature-pad");
                    if (canvas && canvas.dataset.fcpHasDrawing === "1") {
                        try {
                            data[f.label] = canvas.toDataURL("image/png");
                        } catch (e) {
                            // toDataURL can throw if the canvas is tainted by
                            // a cross-origin draw, which never happens here —
                            // fall back to the legacy placeholder so submit
                            // still works.
                            data[f.label] = "(signature captured)";
                        }
                    } else {
                        data[f.label] = "";
                    }
                } else if (f.type === "payment") {
                    // Collect the chosen method + any reference / card details
                    // from the visible panel only (hidden panels are ignored).
                    const chosen = div.querySelector("input[type='radio']:checked");
                    const method = chosen ? chosen.value : "";
                    data[f.label] = method;
                    const activePanel = div.querySelector(`.fcp-method-panel[data-method="${method}"]`);
                    if (activePanel) {
                        activePanel.querySelectorAll("input").forEach(inp => {
                            if (!inp.name || !inp.value) return;
                            // Strip the field-name prefix so the label is human-readable.
                            // e.g. fld_abc123__upi_ref → "upi_ref"
                            const suffix = inp.name.replace(/^fld_[^_]+__/, "").replace(/_/g, " ");
                            const key = f.label + " · " + suffix;
                            data[key] = inp.value;
                        });
                    }
                } else if (f.type === "bank" || f.type === "upi") {
                    // Standalone Bank Transfer / UPI Payment fields — collect
                    // reference + confirmation alongside the field label.
                    const ref = div.querySelector(`input[name$="_txn"]`);
                    const ok  = div.querySelector(`input[name$="_confirmed"]:checked`);
                    data[f.label] = ok ? "Payment confirmed" : "Pending";
                    if (ref && ref.value) data[f.label + " · Reference"] = ref.value;
                } else if (f.type === "calculation") {
                    // Calculation: save the raw numeric value (not the formatted display).
                    const inp = div.querySelector("[data-fcp-calc] input");
                    data[f.label] = inp ? (inp.dataset.fcpRawValue || "0") : "0";
                } else if (f.type === "wc-products") {
                    // WooCommerce product field: save the picked product id,
                    // optional variation id, and quantity using the labels
                    // that FCP_WooCommerce::extract_line_items expects.
                    const checked = div.querySelector('input[type="radio"]:checked');
                    data[f.label] = checked ? checked.value : "";
                    const qty = div.querySelector("[data-fcp-wc-qty]");
                    if (qty) data[f.label + " Quantity"] = qty.value || "1";
                    const variation = div.querySelector("[data-fcp-wc-variation]");
                    if (variation && variation.value) data[f.label + " Variation"] = variation.value;
                } else {
                    const input = div.querySelector("input,select,textarea");
                    if (input) data[f.label] = input.value;
                }
            });
        }

        function applyLogic() {
            const all = container.querySelectorAll(".fc-field");
            // Snapshot once instead of per-field flatMap — applyLogic runs
            // on every keystroke so the O(n²) was wasteful.
            const allFields = form.steps.flatMap(s => s.fields);
            all.forEach(div => {
                try {
                const fid = div.dataset.fid;
                const f = allFields.find(x => x.id === fid);
                // Group model: f.logicGroups = [[rule,rule],[rule]] — each
                // inner array is a group (AND), outer array is OR across
                // groups. Backwards-compat with the old single-mode shape:
                //   - logicMatch "all" → one group containing all rules
                //   - logicMatch "any" → one rule per group
                let groups = Array.isArray(f && f.logicGroups) ? f.logicGroups
                    : (f && Array.isArray(f.logic) && f.logic.length
                        ? ( f.logicMatch === "any"
                              ? f.logic.map(r => [r])
                              : [ f.logic ] )
                        : null);
                if (!f || !groups || !groups.length) return;
                const action = f.logicAction === "hide" ? "hide" : "show";

                /**
                 * Read the current value of a source field. Several field
                 * types use a dedicated hidden input or data attribute
                 * because their first <input> isn't the "real" value:
                 *   - Schedule: timezone <select> comes first — slot value
                 *     lives in [data-fcp-schedule-value]
                 *   - Toggle: visible checkbox is "on"/empty — Yes/No
                 *     mirror lives in [data-fcp-toggle-value]
                 *   - Rating: stars carry data-value — mirror in
                 *     [data-fcp-rating-value]
                 *   - File / Image: visible file input is useless — URL
                 *     lives in [data-fcp-file-url]
                 *   - Calculation: raw number lives in dataset.fcpRawValue
                 *   - Hidden field: [data-fcp-hidden]
                 * The order below is "most-specific first" so we don't
                 * accidentally read the wrong input.
                 */
                function readSourceValue(src) {
                    const specific = src.querySelector(
                        "[data-fcp-schedule-value]," +
                        "[data-fcp-toggle-value]," +
                        "[data-fcp-rating-value]," +
                        "[data-fcp-file-url]," +
                        "[data-fcp-hidden]," +
                        "[data-fcp-otp-value]," +
                        "[data-fcp-video-url]"
                    );
                    if (specific) return specific.value || "";
                    const calc = src.querySelector("[data-fcp-calc] input");
                    if (calc) return calc.dataset.fcpRawValue || "0";
                    const checked = src.querySelectorAll("input[type='radio']:checked, input[type='checkbox']:checked");
                    if (checked.length) return Array.from(checked).map(c => c.value).join(",");
                    const inp = src.querySelector("input,select,textarea");
                    if (!inp) return "";
                    // Radio/checkbox groups with nothing checked must read as
                    // empty — falling back to inp.value would return the FIRST
                    // option's value attribute (e.g. "Basic") and make a
                    // Show-when rule incorrectly pass before the visitor picks.
                    if (inp.type === "radio" || inp.type === "checkbox") return "";
                    return inp.value || "";
                }

                function evalRule(rule) {
                    const src = container.querySelector(`.fc-field[data-fid="${rule.field}"]`);
                    if (!src) return true;
                    const v      = readSourceValue(src);
                    const target = (rule.value || "");
                    // Case-insensitive helpers so admins can type "Yes" or
                    // "yes" without breaking the rule.
                    const lv = String(v).toLowerCase();
                    const lt = String(target).toLowerCase();
                    switch (rule.op) {
                        case "equals":            return lv === lt;
                        case "not_equals":        return lv !== lt;
                        case "contains":          return lv.indexOf(lt) !== -1;
                        case "not_contains":      return lv.indexOf(lt) === -1;
                        case "starts_with":       return lv.indexOf(lt) === 0;
                        case "ends_with":         return lt.length === 0 || lv.lastIndexOf(lt) === lv.length - lt.length;
                        case "greater_than":      return parseFloat(v) > parseFloat(target);
                        case "less_than":         return parseFloat(v) < parseFloat(target);
                        case "greater_or_equal":  return parseFloat(v) >= parseFloat(target);
                        case "less_or_equal":     return parseFloat(v) <= parseFloat(target);
                        case "is_empty":          return v === "" || v === null;
                        case "is_not_empty":      return v !== "" && v !== null;
                        default: return true;
                    }
                }

                // Group semantics: every rule in a group must pass (AND);
                // at least one group must pass (OR). An empty group is
                // treated as "no rules to satisfy", which would always pass
                // — we skip empty groups instead so the field's logic stays
                // meaningful while the admin is mid-edit.
                const passes = groups.some(group =>
                    Array.isArray(group) && group.length > 0 && group.every(evalRule)
                );

                // Show-mode: visible when passes. Hide-mode: hidden when passes.
                const visible = action === "hide" ? !passes : passes;
                div.style.display = visible ? "" : "none";
                } catch (err) {
                    // Never let a malformed rule break the form. Worst case
                    // the field stays visible — that's far better than a
                    // page-wide blank from one bad logic entry.
                    if (window.console) console.warn("FormCraft: logic eval failed for", div.dataset.fid, err);
                    div.style.display = "";
                }
            });
        }

        /**
         * Two-phase pay-then-submit. Creates an order with the gateway,
         * opens its checkout, verifies the payment server-side, and only
         * then completes the form submission. If the visitor closes the
         * checkout or the gateway rejects the payment, the submission is
         * NOT saved (well, the pending row is left for the admin to clean
         * up — controlled by the server side).
         */
        function handlePaymentThenSubmit(paymentField, method, btn) {
            const restBase  = (window.FCFormConfig && FCFormConfig.rest)  ? FCFormConfig.rest  : "";
            const restNonce = (window.FCFormConfig && FCFormConfig.nonce) ? FCFormConfig.nonce : "";
            if (!restBase) {
                FCApp.toast("Payment gateways need WordPress (REST endpoint missing).", "error");
                btn.innerHTML = form.settings.submitText || global.FCP_I18N.t(form, "submit"); btn.disabled = false;
                return;
            }
            // Prefer the live computed amount from the DOM (dynamic pricing
            // may have updated it based on the visitor's plan selection).
            // If a coupon is active, dataset.fcpBase is the post-discount
            // total — we need the PRE-discount base, because the server
            // re-applies the coupon itself for tamper protection.
            const fieldEl   = container.querySelector(`.fc-field[data-fid="${paymentField.id}"]`);
            const priced    = fieldEl ? fieldEl.querySelector("[data-fcp-priced]") : null;
            let liveAmount  = 0;
            if (priced) {
                liveAmount = priced.dataset.fcpPreCouponBase
                    ? parseFloat(priced.dataset.fcpPreCouponBase)
                    : parseFloat(priced.dataset.fcpBase || 0);
            }
            const amount    = liveAmount > 0 ? liveAmount : parseFloat(paymentField.amount || 0);
            if (!amount || amount <= 0) {
                FCApp.toast("Payment amount not configured for this form.", "error");
                btn.innerHTML = form.settings.submitText || global.FCP_I18N.t(form, "submit"); btn.disabled = false;
                return;
            }

            const payload = Object.assign({}, data, { _fcp_signals: collectSpamSignals() });
            const formEl  = container.querySelector("#fcForm");
            const coupon  = (formEl && formEl.dataset.fcpCouponCode) ? formEl.dataset.fcpCouponCode : "";
            btn.innerHTML = '<span class="spinner"></span> Setting up payment…';

            fetch(restBase.replace(/\/$/, "") + "/payment/create-order", {
                method: "POST",
                credentials: "same-origin",
                headers: { "Content-Type": "application/json", "X-WP-Nonce": restNonce },
                body: JSON.stringify({
                    form_id:     form.wpId || form.id,
                    gateway:     method,
                    amount:      amount,
                    currency:    paymentField.currency || "INR",
                    data:        payload,
                    coupon_code: coupon,
                    return_url:  location.href.split("?")[0]
                })
            })
            .then(r => r.json())
            .then(res => {
                if (!res || !res.success || !res.order) {
                    throw new Error(res && res.message ? res.message : "Could not start payment");
                }
                btn.innerHTML = '<span class="spinner"></span> Waiting for payment…';
                return openGatewayCheckout(method, res, paymentField);
            })
            .then(({ submissionId, proof }) => {
                btn.innerHTML = '<span class="spinner"></span> Verifying payment…';
                return fetch(restBase.replace(/\/$/, "") + "/payment/verify", {
                    method: "POST",
                    credentials: "same-origin",
                    headers: { "Content-Type": "application/json", "X-WP-Nonce": restNonce },
                    body: JSON.stringify({ submission_id: submissionId, gateway: method, proof: proof })
                })
                .then(r => r.json())
                .then(verifyRes => {
                    if (!verifyRes || !verifyRes.success) {
                        throw new Error(verifyRes && verifyRes.message ? verifyRes.message : "Payment verification failed");
                    }
                    showSuccess({ message: "Payment received — your submission is confirmed.", mail: verifyRes.mail });
                });
            })
            .catch(err => {
                console.error("[FormCraft] Payment flow failed:", err);
                btn.innerHTML = form.settings.submitText || global.FCP_I18N.t(form, "submit"); btn.disabled = false;
                FCApp.toast(err.message || "Payment failed — please try again.", "error");
            });
        }

        function showSuccess(resp) {
            // v2.66.2 — removed dev console.log (was useful during payment
            // gateway integration but noisy in production)
            // Fire a synthetic event so any installed ad-platform pixel
            // (Meta / Google / TikTok / LinkedIn / Pinterest / Snap / Twitter
            // / Reddit / Microsoft / Quora) can track the conversion. The
            // pixel snippets emitted by FCP_Ad_Platforms listen for this.
            try { document.dispatchEvent(new CustomEvent("fcp:submitted", { detail: { id: resp && resp.id, message: resp && resp.message } })); } catch (e) {}
            const msg = (resp && resp.message) || form.settings.successMessage || global.FCP_I18N.t(form, "success");
            container.innerHTML = `
                <div class="fc-form-public" style="text-align:center;padding:60px 20px;">
                    <div style="width:80px;height:80px;border-radius:50%;background:rgba(16,185,129,0.12);color:var(--success);display:grid;place-items:center;margin:0 auto 18px;font-size:36px;">✓</div>
                    <h2 style="margin:0 0 8px;">Payment received!</h2>
                    <p class="text-muted" style="max-width:480px;margin:0 auto 18px;">${FCApp.escapeHtml(msg)}</p>
                    <button class="btn btn-outline" onclick="location.reload()">${FCApp.escapeHtml(global.FCP_I18N.t(form, "another"))}</button>
                </div>`;
            if (form.settings.redirect) setTimeout(() => location.href = form.settings.redirect, 1500);
        }

        /**
         * Open the right gateway's checkout. Resolves with the proof object
         * that the server-side /payment/verify needs.
         */
        function openGatewayCheckout(method, orderRes, paymentField) {
            const order        = orderRes.order;
            const submissionId = orderRes.submission_id;

            if (method === "razorpay") {
                return loadScript("https://checkout.razorpay.com/v1/checkout.js").then(() => new Promise((resolve, reject) => {
                    const cfg = order.checkout;
                    const rzp = new Razorpay({
                        key:         cfg.key,
                        amount:      cfg.amount,
                        currency:    cfg.currency,
                        order_id:    cfg.order_id,
                        name:        cfg.name,
                        description: cfg.description,
                        prefill:     cfg.prefill || {},
                        handler:     function (resp) {
                            resolve({ submissionId: submissionId, proof: {
                                razorpay_payment_id: resp.razorpay_payment_id,
                                razorpay_order_id:   resp.razorpay_order_id,
                                razorpay_signature:  resp.razorpay_signature
                            } });
                        },
                        modal: { ondismiss: () => reject(new Error("Payment cancelled.")) }
                    });
                    rzp.on("payment.failed", function (resp) {
                        reject(new Error(resp.error && resp.error.description || "Payment failed."));
                    });
                    rzp.open();
                }));
            }

            if (method === "stripe") {
                // Stripe Checkout is a redirect — store submission id for verify on return.
                try {
                    sessionStorage.setItem("fcp_pending_payment", JSON.stringify({
                        submissionId: submissionId, gateway: "stripe"
                    }));
                } catch (e) {}
                location.href = order.checkout.redirect_url;
                // The redirect interrupts the JS flow. The verify happens
                // when the user returns from Stripe — see resumePendingPayment().
                return new Promise(() => {});
            }

            if (method === "cashfree") {
                return loadScript("https://sdk.cashfree.com/js/v3/cashfree.js").then(() => new Promise((resolve, reject) => {
                    const cf = window.Cashfree({ mode: order.checkout.mode || "production" });
                    cf.checkout({
                        paymentSessionId: order.checkout.payment_session_id,
                        returnUrl:        location.href.split("?")[0] + "?fcp_cf_order=" + order.order_id
                    }).then(result => {
                        if (result.error) return reject(new Error(result.error.message || "Cashfree payment failed."));
                        resolve({ submissionId: submissionId, proof: { order_id: order.order_id } });
                    }).catch(reject);
                }));
            }

            if (method === "instamojo") {
                location.href = order.checkout.redirect_url;
                return new Promise(() => {});
            }

            if (method === "paypal") {
                return loadScript("https://www.paypal.com/sdk/js?client-id=" + encodeURIComponent(order.checkout.client_id) + "&currency=" + encodeURIComponent(order.checkout.currency || "USD"))
                    .then(() => new Promise((resolve, reject) => {
                        // Inject a small overlay to host the PayPal Smart Buttons.
                        const overlay = document.createElement("div");
                        overlay.className = "fcp-paypal-overlay";
                        overlay.innerHTML = `
                            <div class="fcp-paypal-modal">
                                <h3 style="margin:0 0 12px;">Complete payment with PayPal</h3>
                                <div id="fcp-paypal-buttons"></div>
                                <button type="button" class="btn btn-outline btn-sm mt-2" id="fcp-paypal-cancel">Cancel</button>
                            </div>`;
                        document.body.appendChild(overlay);

                        document.getElementById("fcp-paypal-cancel").addEventListener("click", () => {
                            overlay.remove();
                            reject(new Error("Payment cancelled."));
                        });
                        paypal.Buttons({
                            createOrder: () => order.checkout.order_id,
                            onApprove:   (data) => {
                                overlay.remove();
                                resolve({ submissionId: submissionId, proof: { paypal_order_id: data.orderID } });
                            },
                            onCancel: () => { overlay.remove(); reject(new Error("Payment cancelled.")); },
                            onError:  (err) => { overlay.remove(); reject(new Error(err && err.message || "PayPal error.")); }
                        }).render("#fcp-paypal-buttons");
                    }));
            }

            return Promise.reject(new Error("Unknown payment gateway: " + method));
        }

        function loadScript(src) {
            return new Promise((resolve, reject) => {
                if (document.querySelector(`script[src="${src}"]`)) return resolve();
                const s = document.createElement("script");
                s.src = src; s.async = true;
                s.onload = () => resolve();
                s.onerror = () => reject(new Error("Could not load: " + src));
                document.head.appendChild(s);
            });
        }

        // Resume after a redirect-style gateway (Stripe / Instamojo) bounces back.
        function resumePendingPayment() {
            const restBase  = (window.FCFormConfig && FCFormConfig.rest)  ? FCFormConfig.rest  : "";
            const restNonce = (window.FCFormConfig && FCFormConfig.nonce) ? FCFormConfig.nonce : "";
            if (!restBase) return;
            const params = new URLSearchParams(location.search);
            const pending = (() => { try { return JSON.parse(sessionStorage.getItem("fcp_pending_payment") || "null"); } catch (e) { return null; } })();
            if (!pending) return;

            let proof = null;
            if (pending.gateway === "stripe" && params.get("session_id")) proof = { session_id: params.get("session_id") };
            if (pending.gateway === "instamojo" && params.get("payment_request_id")) proof = { payment_request_id: params.get("payment_request_id"), payment_id: params.get("payment_id") || "" };
            if (!proof) return;

            sessionStorage.removeItem("fcp_pending_payment");
            container.innerHTML = `<div class="fc-form-public" style="text-align:center;padding:40px 20px;"><span class="spinner"></span><p class="text-muted mt-3">Verifying payment…</p></div>`;
            fetch(restBase.replace(/\/$/, "") + "/payment/verify", {
                method: "POST",
                credentials: "same-origin",
                headers: { "Content-Type": "application/json", "X-WP-Nonce": restNonce },
                body: JSON.stringify({ submission_id: pending.submissionId, gateway: pending.gateway, proof })
            })
            .then(r => r.json())
            .then(res => {
                if (res && res.success) showSuccess(res);
                else container.innerHTML = `<div class="fc-form-public" style="text-align:center;padding:40px;"><h3>Payment couldn't be verified</h3><p class="text-muted">${FCApp.escapeHtml(res && res.message || "")}</p></div>`;
            });
        }
        // Run the resume on initial mount so returning visitors see the
        // verification finish automatically.
        setTimeout(resumePendingPayment, 0);

        function handleSubmit() {
            const formEl = container.querySelector("#fcForm");
            const btn = formEl.querySelector("button[type=submit]");
            btn.innerHTML = '<span class="spinner"></span> Submitting…';
            btn.disabled = true;

            // Detect if the form has a Payment Method field with a real online
            // gateway selected — if so, route through the two-phase pay-then-
            // submit flow instead of the normal submission.
            const paymentField = form.steps.flatMap(s => s.fields).find(fx => fx.type === "payment");
            if (paymentField) {
                const radio = container.querySelector(`.fc-field[data-fid="${paymentField.id}"] input[type='radio']:checked`);
                const method = radio ? radio.value : "";
                const onlineGateways = ["razorpay", "stripe", "cashfree", "instamojo", "paypal", "mollie", "paystack", "mercadopago"];
                if (onlineGateways.indexOf(method) >= 0) {
                    return handlePaymentThenSubmit(paymentField, method, btn);
                }
            }

            // Attach bot-detection signals to the submission payload so the
            // server can classify it. Signals are stripped out by the REST
            // handler before the row is saved to the database. Also attach
            // the abandonment session id so the server can promote an
            // existing abandoned row instead of creating a duplicate, and
            // the user journey (pages visited before submitting) so the
            // admin can see the visitor's path.
            const journey = (window.FCJourney && typeof FCJourney.get === "function")
                ? FCJourney.get()
                : null;
            // v2.54 — capture form-fill duration in seconds.
            // signals.time is already collected for spam detection; we
            // duplicate it into _meta.duration so analytics has a stable
            // home for "how long did this take to fill out?" without
            // depending on the spam-signal layout.
            const fillDuration = Math.max(0, Math.floor((Date.now() - startTime) / 1000));

            // v2.54 — A/B variant assignment. Sticky per browser via
            // localStorage so the same visitor sees the same variant if
            // they reload. 50/50 random split, only when the form has
            // form.abTest.enabled.
            const abVariant = (function () {
                if (!form.abTest || !form.abTest.enabled) return null;
                const key = "fcp_ab_" + form.id;
                let v = localStorage.getItem(key);
                if (v !== "A" && v !== "B") {
                    v = Math.random() < 0.5 ? "A" : "B";
                    try { localStorage.setItem(key, v); } catch (e) {}
                }
                return v;
            })();

            // v2.51 — capture UTM params + referrer for source attribution.
            // Reads from current URL first, then sessionStorage so a 2nd-page
            // submission still attributes to the campaign that brought them.
            const utm = (function () {
                const qs = new URLSearchParams(location.search);
                const out = {};
                ["utm_source","utm_medium","utm_campaign","utm_content","utm_term","gclid","fbclid"].forEach(k => {
                    const v = qs.get(k) || sessionStorage.getItem("_fcp_" + k) || "";
                    if (v) {
                        out[k] = v;
                        try { sessionStorage.setItem("_fcp_" + k, v); } catch (e) {}
                    }
                });
                return out;
            })();
            const payload = Object.assign({}, data, {
                _fcp_signals:    collectSpamSignals(),
                _fcp_session_id: sessionId,
                _fcp_journey:    journey,
                _fcp_utm:        utm,
                _fcp_referrer:   document.referrer || "",
                _fcp_duration:   fillDuration,
                _fcp_ab_variant: abVariant,
                // Per-form CSRF token — bound to this form's id so a token
                // captured from form A can't be replayed against form B.
                _fcp_form_nonce: (window.FCFormConfig && FCFormConfig.formNonce) || ""
            });

            // Hook for WP shortcode (POSTs to REST). Falls back to local save.
            const submitFn = opts.onSubmit ? opts.onSubmit(payload) : Promise.resolve({ success: true, message: form.settings.successMessage });

            Promise.resolve(submitFn).then(resp => {
                resp = resp || {};

                // Log the response for diagnostics — visitors won't normally
                // see this, but admins testing the form can open DevTools and
                // immediately see whether the admin / user emails went out.
                try {
                    // v2.66.2 — removed dev console.log
                    if (resp.mail) {
                        if (resp.mail.admin) {
                            console[resp.mail.admin.sent ? "log" : "warn"](
                                "[FormCraft] Admin email " + (resp.mail.admin.sent ? "✓ sent" : "✗ FAILED"),
                                resp.mail.admin
                            );
                        }
                        if (resp.mail.user) {
                            console[resp.mail.user.sent ? "log" : "warn"](
                                "[FormCraft] User confirmation " + (resp.mail.user.sent ? "✓ sent" : "✗ FAILED"),
                                resp.mail.user
                            );
                        }
                    }
                } catch (e) {}
                if (!opts.previewMode && !opts.onSubmit) {
                    // Local (no WP) fallback - save to localStorage
                    if (typeof FCData !== "undefined") {
                        const s = FCData.load();
                        const sub = {
                            id: FCData.uid("sub"),
                            formId: form.id,
                            formTitle: form.title,
                            name: data["Full Name"] || data["Your Name"] || data["Name"] || "Anonymous",
                            email: data["Email"] || data["Email Address"] || data["Work Email"] || "",
                            phone: data["Phone"] || "",
                            ip: "0.0.0.0",
                            country: "Unknown",
                            browser: navigator.userAgent.includes("Firefox") ? "Firefox" : "Chrome",
                            device: window.innerWidth < 768 ? "Mobile" : "Desktop",
                            read: false,
                            spam: false,
                            createdAt: new Date().toISOString(),
                            data: data
                        };
                        s.submissions.unshift(sub);
                        const f = s.forms.find(x => x.id === form.id);
                        if (f) f.submissions = (f.submissions || 0) + 1;
                        FCData.save(s);
                    }
                }

                // Login response → skip the thank-you screen, show a brief
                // welcome toast, and redirect immediately. The auth cookie is
                // already set server-side by wp_signon.
                if (resp.login) {
                    FCApp.toast(resp.message || "Signed in", "success");
                    const target = resp.redirect || form.settings.redirect || location.href;
                    setTimeout(() => { location.href = target; }, 600);
                    return;
                }
                // Fire conversion event for any installed ad-platform pixel.
                try { document.dispatchEvent(new CustomEvent("fcp:submitted", { detail: { id: resp.id, message: resp.message } })); } catch (e) {}
                const msg = resp.message || form.settings.successMessage || "Thank you. We have received your submission.";
                // Detect whether the form had a poll field with "show live
                // results" enabled — if so we render bar chart of votes after
                // submit.
                const pollFields = form.steps.flatMap(s => s.fields).filter(f => f.type === "poll" && f.showResultsAfterSubmit);
                const showPollResults = pollFields.length > 0;
                // Detect a quiz form — sums per-option scores against the
                // chosen answers + renders the score / range result.
                const quizResult = computeQuizResult();
                container.innerHTML = `
                    <div class="fc-form-public" style="text-align:center;padding:60px 20px;">
                        <div style="width:80px;height:80px;border-radius:50%;background:rgba(16,185,129,0.12);color:var(--success);display:grid;place-items:center;margin:0 auto 18px;font-size:36px;">✓</div>
                        <h2 style="margin:0 0 8px;">${quizResult ? "Your result" : "Submission received!"}</h2>
                        <p class="text-muted" style="max-width:480px;margin:0 auto 18px;">${FCApp.escapeHtml(msg)}</p>
                        ${quizResult ? renderQuizResultBlock(quizResult) : ""}
                        ${showPollResults ? `<div id="fcpPollResults" style="text-align:left;max-width:560px;margin:18px auto 0;"></div>` : ""}
                        <button class="btn btn-outline" style="margin-top:18px;" onclick="location.reload()">Submit another response</button>
                    </div>`;
                if (showPollResults) loadPollResults(pollFields);
                const redirect = resp.redirect || form.settings.redirect;
                if (redirect) setTimeout(() => location.href = redirect, 1500);
            }).catch(err => {
                console.error(err);
                btn.innerHTML = form.settings.submitText || global.FCP_I18N.t(form, "submit");
                btn.disabled = false;
                // Login errors come back with code "fcp_login_failed" or
                // "fcp_login_locked" — render the WP message inline above the
                // submit button instead of the generic toast, so the visitor
                // can fix + retry without losing form state.
                const code = err && (err.code || err.error_code || "");
                if (code && code.indexOf("fcp_login") === 0) {
                    const formEl = container.querySelector("#fcForm");
                    if (formEl) {
                        formEl.querySelectorAll(".fcp-login-error").forEach(n => n.remove());
                        const e = document.createElement("div");
                        e.className = "fcp-login-error form-error";
                        e.style.cssText = "margin:10px 0;padding:10px 14px;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);border-radius:8px;color:var(--danger);";
                        e.textContent = (err && err.message) || "Login failed.";
                        formEl.querySelector(".fc-nav").before(e);
                    }
                    return;
                }
                FCApp.toast((err && err.message) || "Something went wrong. Please try again.", "error");
            });
        }

        // --- Save & Continue: email the visitor a link to resume later ---
        function openSaveDraftModal() {
            // Pull a sensible default email from the current step's data.
            saveCurrentStepData();
            const guess = data["Email"] || data["Email Address"] || data["Work Email"] || data["email"] || "";
            FCApp.modal({
                title: "Save your progress",
                body: `
                    <p style="margin:0 0 12px;color:var(--text-muted);font-size:14px;">We'll email you a link so you can pick up where you left off — valid for 7 days. We won't sign you up for anything.</p>
                    <input type="email" class="form-control" id="fcpDraftEmail" placeholder="your@email.com" value="${FCApp.escapeHtml(guess)}" autocomplete="email" style="font-size:15px;">
                    <div id="fcpDraftStatus" class="form-help" style="min-height:18px;margin-top:8px;"></div>
                `,
                footer: `
                    <button class="btn btn-outline" data-close>Cancel</button>
                    <button class="btn btn-primary" id="fcpDraftSubmit">${FCApp.ICONS.mail || ""} Email me the link</button>
                `
            });
            setTimeout(() => {
                const submit = document.getElementById("fcpDraftSubmit");
                if (!submit) return;
                submit.addEventListener("click", () => {
                    const emailEl = document.getElementById("fcpDraftEmail");
                    const status  = document.getElementById("fcpDraftStatus");
                    const email   = (emailEl.value || "").trim();
                    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                        status.textContent = "Please enter a valid email.";
                        status.style.color = "var(--danger)";
                        return;
                    }
                    submit.disabled = true;
                    const orig = submit.innerHTML;
                    submit.innerHTML = '<span class="spinner" style="width:14px;height:14px;border:2px solid var(--border);border-top-color:var(--brand-500);border-radius:50%;display:inline-block;animation:spin .6s linear infinite;"></span> Sending…';
                    status.textContent = "";

                    const restBase  = (window.FCFormConfig && FCFormConfig.rest)  || "";
                    const restNonce = (window.FCFormConfig && FCFormConfig.nonce) || "";
                    if (!restBase) {
                        status.textContent = "Save & continue only works on the live WordPress form.";
                        status.style.color = "var(--danger)";
                        submit.disabled = false;
                        submit.innerHTML = orig;
                        return;
                    }
                    saveCurrentStepData();
                    fetch(restBase.replace(/\/$/, "") + "/forms/" + form.id + "/save-draft", {
                        method:  "POST",
                        credentials: "same-origin",
                        headers: { "Content-Type": "application/json", "X-WP-Nonce": restNonce },
                        body:    JSON.stringify({
                            email: email,
                            data:  data,
                            step:  currentStep,
                            return_url: location.href.split("?")[0].split("#")[0]
                        })
                    }).then(r => r.json().then(j => ({ ok: r.ok, body: j })))
                      .then(({ ok, body }) => {
                        if (!ok || !body || body.code) {
                            const msg = (body && (body.message || body.code)) || "Could not save.";
                            status.textContent = msg;
                            status.style.color = "var(--danger)";
                            submit.disabled = false;
                            submit.innerHTML = orig;
                            return;
                        }
                        status.innerHTML = body.email_sent
                            ? `<span style="color:var(--success);">✓ Resume link sent to <strong>${FCApp.escapeHtml(email)}</strong>.</span>`
                            : `<span style="color:var(--warning,#f59e0b);">Saved, but email failed. Bookmark this link:<br><code style="font-size:11px;">${FCApp.escapeHtml(body.resume_url)}</code></span>`;
                        submit.style.display = "none";
                    }).catch(err => {
                        status.textContent = err.message || "Network error.";
                        status.style.color = "var(--danger)";
                        submit.disabled = false;
                        submit.innerHTML = orig;
                    });
                });
            }, 0);
        }

        // --- Live poll results after submit ---
        function loadPollResults(pollFields) {
            const wrap = container.querySelector("#fcpPollResults");
            if (!wrap) return;
            const restBase  = (window.FCFormConfig && FCFormConfig.rest) || "";
            const restNonce = (window.FCFormConfig && FCFormConfig.nonce) || "";
            if (!restBase) return;
            fetch(restBase.replace(/\/$/, "") + "/forms/" + form.id + "/poll-results", {
                credentials: "same-origin",
                headers: { "X-WP-Nonce": restNonce }
            }).then(r => r.json()).then(res => {
                if (!res || !res.polls) return;
                wrap.innerHTML = pollFields.map(f => {
                    const poll = res.polls[f.id];
                    if (!poll) return "";
                    return `<div style="background:#fff;border:1px solid var(--border);border-radius:10px;padding:16px;margin-bottom:10px;">
                        <div class="fw-700" style="margin-bottom:10px;">${FCApp.escapeHtml(poll.label)} <span class="text-muted text-sm" style="font-weight:400;">(${poll.total} votes)</span></div>
                        ${poll.options.map(o => `
                            <div style="margin-bottom:8px;">
                                <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;">
                                    <span>${FCApp.escapeHtml(o.label)}</span><strong>${o.pct}% (${o.votes})</strong>
                                </div>
                                <div style="height:8px;background:var(--bg-soft);border-radius:4px;overflow:hidden;">
                                    <div style="height:100%;width:${o.pct}%;background:linear-gradient(90deg,var(--brand-500),var(--brand-600));transition:width .5s;"></div>
                                </div>
                            </div>`).join("")}
                    </div>`;
                }).join("");
            }).catch(() => {});
        }

        // --- Quiz scoring ---
        // Computes total score for the form: each radio / checkbox option
        // optionally carries f.scores = { "Option A": 5, "Option B": 2 }.
        // Sums every selected option's score across the form. Result ranges
        // (form.settings.quiz.results = [ { min, max, message } ]) decide
        // the message + grade shown after submit.
        function computeQuizResult() {
            if (!form.settings.quiz || !form.settings.quiz.enabled) return null;
            let total = 0;
            let maxPossible = 0;
            form.steps.flatMap(s => s.fields).forEach(f => {
                if (!f.scores || typeof f.scores !== "object") return;
                const v = data[f.label];
                if (Array.isArray(v)) {
                    v.forEach(x => { if (typeof f.scores[x] === "number") total += f.scores[x]; });
                    Object.values(f.scores).forEach(n => { if (typeof n === "number" && n > 0) maxPossible += n; });
                } else if (typeof v === "string" && v !== "" && typeof f.scores[v] === "number") {
                    total += f.scores[v];
                    maxPossible += Math.max(...Object.values(f.scores).filter(n => typeof n === "number"));
                }
            });
            const ranges = (form.settings.quiz.results || []).slice().sort((a, b) => (a.min || 0) - (b.min || 0));
            let matched = null;
            for (const r of ranges) {
                const min = parseFloat(r.min);
                const max = parseFloat(r.max);
                if ((!isFinite(min) || total >= min) && (!isFinite(max) || total <= max)) { matched = r; break; }
            }
            return { score: total, max: maxPossible, label: matched ? matched.label : "", message: matched ? matched.message : "" };
        }
        function renderQuizResultBlock(r) {
            return `<div style="background:#fff;border:1px solid var(--border);border-radius:10px;padding:24px;margin:0 auto 18px;max-width:480px;text-align:center;">
                <div style="font-size:48px;font-weight:800;color:var(--brand-600);line-height:1;">${r.score}${r.max ? `<span style="font-size:24px;color:var(--text-muted);"> / ${r.max}</span>` : ""}</div>
                ${r.label ? `<div class="fw-700" style="font-size:18px;margin-top:8px;">${FCApp.escapeHtml(r.label)}</div>` : ""}
                ${r.message ? `<div class="text-muted" style="margin-top:8px;">${FCApp.escapeHtml(r.message)}</div>` : ""}
            </div>`;
        }

        // --- Resume a saved draft if ?fcp_draft=<token> is in the URL ---
        function tryResumeDraft() {
            const token = new URLSearchParams(location.search).get("fcp_draft");
            if (!token) return;
            const restBase  = (window.FCFormConfig && FCFormConfig.rest) || "";
            const restNonce = (window.FCFormConfig && FCFormConfig.nonce) || "";
            if (!restBase) return;
            fetch(restBase.replace(/\/$/, "") + "/forms/" + form.id + "/resume-draft?token=" + encodeURIComponent(token), {
                credentials: "same-origin",
                headers: { "X-WP-Nonce": restNonce }
            }).then(r => r.ok ? r.json() : Promise.reject(r))
              .then(res => {
                if (!res || !res.success) return;
                Object.assign(data, res.data || {});
                currentStep = Math.max(0, parseInt(res.step, 10) || 0);
                if (currentStep >= form.steps.length) currentStep = form.steps.length - 1;
                render();
                applyDraftValuesToInputs();
                FCApp.toast("Welcome back — your draft has been restored.", "success");
            }).catch(() => { /* expired / wrong form — silently continue */ });
        }

        // After re-render, push the saved values back into the rendered inputs
        // so the visitor sees their previous answers. Repeater rows are
        // rebuilt to match the saved count.
        function applyDraftValuesToInputs() {
            const fields = form.steps.flatMap(s => s.fields);
            container.querySelectorAll(".fc-field").forEach(div => {
                const fid = div.dataset.fid;
                const f = fields.find(x => x.id === fid);
                if (!f || !(f.label in data)) return;
                const v = data[f.label];
                if (f.type === "checkbox" || f.type === "multiselect") {
                    const want = Array.isArray(v) ? v : [v];
                    div.querySelectorAll("input[type='checkbox']").forEach(cb => { cb.checked = want.includes(cb.value); });
                } else if (f.type === "rating") {
                    const rt = div.querySelector(".fc-rating");
                    if (rt) {
                        rt.dataset.value = String(v || 0);
                        rt.querySelectorAll(".star").forEach((s, i) => s.classList.toggle("active", (i + 1) <= (parseInt(v, 10) || 0)));
                    }
                } else if (f.type === "repeater" && Array.isArray(v)) {
                    const rep = div.querySelector("[data-fcp-repeater]");
                    if (!rep) return;
                    const rowsWrap = rep.querySelector("[data-fcp-rep-rows]");
                    const tmpl     = rep.querySelector("[data-fcp-rep-template]");
                    if (!rowsWrap || !tmpl) return;
                    rowsWrap.innerHTML = "";
                    v.forEach(rowVal => {
                        const fresh = tmpl.content.firstElementChild.cloneNode(true);
                        Object.entries(rowVal || {}).forEach(([label, val]) => {
                            const inp = fresh.querySelector(`[data-sub-label="${label}"]`);
                            if (!inp) return;
                            if (inp.type === "checkbox") inp.checked = val === "Yes" || val === "1" || val === true;
                            else inp.value = String(val || "");
                        });
                        rowsWrap.appendChild(fresh);
                    });
                    // Re-hydrate to wire Add/Remove + reindex.
                    if (window.FCFields && FCFields.hydrate) FCFields.hydrate(div);
                } else {
                    const input = div.querySelector("input,select,textarea");
                    if (input) {
                        input.value = v == null ? "" : String(v);
                        // Fire input + change so downstream listeners (range
                        // live value, dynamic pricing, calculation, logic)
                        // recompute against the restored value.
                        input.dispatchEvent(new Event("input",  { bubbles: true }));
                        input.dispatchEvent(new Event("change", { bubbles: true }));
                    }
                }
            });
        }

        render();
        tryResumeDraft();
    }

    global.FCForm = { renderPublicForm };
})(window);
