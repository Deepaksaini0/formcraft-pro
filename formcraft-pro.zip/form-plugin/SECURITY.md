# Security Policy

FormCraft Pro is a self-hosted WordPress plugin. The plugin runs entirely
inside the customer's WordPress install — no FormCraft-operated servers,
no data leaves the site unless the admin explicitly configures an
outbound integration. This document explains how the plugin protects
submission data, how to report vulnerabilities, and what compliance
posture customers can rely on.

## Reporting a vulnerability

Please email `security@imarkinfotech.com` (PGP key on request) with:
- A description of the issue
- Steps to reproduce
- Affected version(s)
- Your disclosure timeline preferences

We respond within **3 business days**, agree on a fix window with you,
publish a patch + advisory, and credit you in the release notes unless
you ask us not to.

**Do not** open GitHub issues for security bugs.

## Supported versions

We ship security patches for the **current minor + the previous minor**.
Customers on older minors are encouraged to upgrade — every release is
backwards-compatible with at most a one-version deprecation window.

| Version | Supported |
| --- | --- |
| 2.43.x | ✅ |
| 2.42.x | ✅ (security only) |
| < 2.42 | ❌ |

## Threat model + mitigations

| Threat | Mitigation |
| --- | --- |
| **CSRF on form submit** | Every submission requires a WordPress REST nonce (`wp_rest`). Public forms additionally validate a per-form nonce (`fcp_form_<id>`) embedded in the rendered HTML, blocking replay across forms. |
| **Spam / bot floods** | Honeypot field on every form, IP rate limit (configurable, default 30/min), optional reCAPTCHA v2/v3, hCaptcha, Cloudflare Turnstile, and Akismet integration. |
| **PII exposure in transit** | All REST traffic runs over the host's TLS. Outbound ad-platform / CRM API calls use HTTPS only (`sslverify => true`). |
| **PII exposure in ad-platform pushes** | Email, phone, and name fields are SHA-256 hashed (lowercase + trimmed) before being sent to Meta CAPI / TikTok Events / LinkedIn / Pinterest / Snapchat / Reddit. Matches the platforms' required Advanced Matching format. |
| **SQL injection** | Every query uses `$wpdb->prepare()` with placeholders. No string concatenation of user input into SQL. CI lints for raw queries (`WordPress.DB.DirectDatabaseQuery`). |
| **XSS in admin** | All output runs through `esc_html`, `esc_attr`, `esc_url`, `esc_js`, or `FCApp.escapeHtml()` (JS). Inline scripts emitted by ad-platform pixels use only sanitized config values. |
| **File upload abuse** | Allowed MIME types are configurable (default: pdf, doc, docx, jpg, png). Size cap (default 10 MB). Files are stored outside the web root when WP's `wp_upload_dir()` is configured that way. |
| **Form Locker bypass** | Five independent gates run server-side in submit_form() — password, login required, geo, one-per-user, unique field. Client-side checks are best-effort UX only. |
| **Code execution via calculation formula** | Runtime evaluator uses `new Function()` with a strict character-allow-list regex + function-name allow-list (`round`, `floor`, `ceil`, `abs`, `min`, `max`, `pow`, `sqrt`, `sum`, `avg`, `gt`, `lt`, `gte`, `lte`, `eq`, `neq`, `cond`). Anything outside the allow-list rejects the formula and falls back to 0. |
| **Webhook replay** | Outbound webhooks include an HMAC-SHA256 signature in the `X-Formcraft-Signature` header. Receivers verify against the shared secret to detect tampering. |
| **Plugin update tampering** | Updates ship through wordpress.org (when applicable) or signed ZIP. Checksums published in each release advisory. |

## Data flow

```
┌─────────────┐      ┌────────────────┐      ┌──────────────────┐
│  Visitor    ├──────►  WordPress     ├──────►  WordPress DB    │
│  (browser)  │ HTTPS│  (your server) │      │  (wp_fcp_*)      │
└─────────────┘      └─┬──────────────┘      └──────────────────┘
                       │  Optional outbound
                       │  (admin-configured)
                       ▼
            ┌──────────────────────────┐
            │  Mailchimp / Slack /     │
            │  Meta CAPI / Telegram /  │  ← only fires if admin
            │  Stripe / Razorpay / ... │     enabled in Settings
            └──────────────────────────┘
```

## Compliance posture

### GDPR / UK GDPR
- Submission data export + erasure is wired into WP's
  `wp_privacy_personal_data_exporters` and `wp_privacy_personal_data_erasers`
  hooks. Site admins handle DSAR requests through
  **Tools → Export / Erase Personal Data** — no FormCraft-specific UI needed.
- Optional consent (GDPR checkbox) field type.
- Geo-blocking field (Form Locker) to honor regional data-residency rules.
- Submission retention is admin-controlled — no auto-deletion, no off-site
  copies.

### SOC 2 / ISO 27001
- FormCraft Pro is a **self-hosted plugin**, not a SaaS. The plugin
  itself does not store data on FormCraft-controlled infrastructure, so
  the SOC 2 / ISO scope falls on the customer's hosting provider
  (WP Engine, Kinsta, AWS, etc.).
- For enterprise customers, we maintain a **Sub-processor Inventory**
  describing what data each enabled integration sees (Mailchimp sees
  email + name; Meta CAPI sees hashed email + IP; etc.). Available on
  request.

### HIPAA
- Not certified. The plugin does not include BAA-grade encryption at
  rest, audit logging, or access controls. Do not collect PHI.

### CCPA / CPRA
- Same as GDPR — DSAR exports + erasure via WP's Privacy Framework.

## Known limitations

- **No retry queue for outbound integrations.** A failed Mailchimp push
  is logged but not retried automatically. The 2.43+ release adds a
  best-effort retry queue (3 attempts with exponential backoff) for
  webhooks; native CRM adapters still fire-and-forget.
- **No automated WCAG audit.** Forms render with semantic HTML, ARIA
  labels on required fields, and keyboard-navigable controls, but the
  plugin has not undergone an external WCAG 2.1 AA audit. EU public-sector
  customers should commission one before deployment.
- **No PHP CSRF token rotation.** Sessions inherit WP's nonce lifetime
  (12 / 24 hours). Per-form nonces are added in 2.43 to reduce reuse
  surface.

## Hardening checklist for admins

1. Run on PHP 8.0+ (8.2+ recommended).
2. Enable WP automatic core + plugin updates.
3. Use a managed host with WAF (WP Engine, Kinsta, Pressable).
4. Set `wp-config.php`: `define( 'DISALLOW_FILE_EDIT', true );`
5. Configure a CDN with HTTPS + HSTS in front of the site.
6. Enable reCAPTCHA / hCaptcha + Akismet for spam-prone forms.
7. Turn off the Custom Webhook field for non-admin user roles.
8. Audit the Form Locker settings on every new form (default-deny mindset).

## Disclosure history

| Date | Reporter | Issue | Severity | Patched in |
| --- | --- | --- | --- | --- |
| _(none reported yet — initial release)_ | | | | |

---
_Last updated: 2026-06-05 · v2.43.0_
