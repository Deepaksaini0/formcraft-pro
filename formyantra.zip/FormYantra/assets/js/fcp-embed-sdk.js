/*!
 * FormYantra Embed SDK (v2.72.67)
 *
 * A tiny standalone script that renders a FormYantra form inside any
 * hosting container — pure web, React Native (via WebView), Ionic /
 * Capacitor, Cordova, or a static site. Works entirely over the REST
 * API; requires only a base URL + form id + optional API key.
 *
 * Public API:
 *   FCP.embed({
 *     container:  '#my-form-container'   // CSS selector or element
 *     baseUrl:    'https://mysite.com',  // WP site root
 *     formId:     42,                    // wp_fcp_forms.id
 *     apiKey:     'sk_live_...',         // optional; boosts rate limits
 *     onSubmit:   (result) => {},        // fires on successful submit
 *     onError:    (err) => {},           // fires on network/validation error
 *     theme:      'auto'|'light'|'dark', // default 'auto'
 *   });
 *
 * The embedded form uses the site's existing REST endpoints (no CORS
 * config needed on same origin). For cross-origin (native app + remote
 * WP), the site must permit the caller's origin via wp_headers filter.
 *
 * Native app integration:
 *   • React Native — drop a <WebView source={{uri: sdkHtmlUrl}}/> and
 *     bridge onMessage/postMessage for onSubmit callbacks.
 *   • Ionic/Capacitor — same pattern via <ion-content> + iframe.
 *   • Cordova — use InAppBrowser to open a page hosting this SDK.
 *
 * A native Swift + Kotlin SDK (no WebView) is a separate roadmap item.
 */

(function (global) {
  'use strict';

  var VERSION = '2.72.67';

  function _q(sel) {
    if (typeof sel === 'string') return document.querySelector(sel);
    return sel;
  }

  function _post(url, body, headers) {
    return fetch(url, {
      method: 'POST',
      credentials: 'omit',
      headers: Object.assign({ 'Content-Type': 'application/json' }, headers || {}),
      body: JSON.stringify(body || {}),
    }).then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); });
  }

  function _get(url, headers) {
    return fetch(url, {
      credentials: 'omit',
      headers: Object.assign({}, headers || {}),
    }).then(function (r) { return r.json(); });
  }

  function _authHeaders(apiKey) {
    return apiKey ? { 'Authorization': 'Bearer ' + apiKey } : {};
  }

  function _renderField(f, container) {
    var wrap = document.createElement('div');
    wrap.className = 'fcp-sdk-field';
    wrap.style.cssText = 'margin-bottom:16px;';

    var label = document.createElement('label');
    label.style.cssText = 'display:block;font-weight:600;margin-bottom:6px;color:#0f172a;';
    label.textContent = (f.label || 'Untitled') + (f.required ? ' *' : '');
    wrap.appendChild(label);

    var input;
    var t = (f.type || 'text').toLowerCase();
    if (t === 'textarea') {
      input = document.createElement('textarea');
      input.rows = 4;
    } else if (t === 'select' || t === 'dropdown') {
      input = document.createElement('select');
      (f.options || []).forEach(function (opt) {
        var o = document.createElement('option');
        o.value = o.textContent = String(opt);
        input.appendChild(o);
      });
    } else if (t === 'radio' || t === 'checkbox') {
      input = document.createElement('div');
      (f.options || []).forEach(function (opt) {
        var row = document.createElement('label');
        row.style.cssText = 'display:block;margin:4px 0;font-weight:400;';
        var ctrl = document.createElement('input');
        ctrl.type = t === 'radio' ? 'radio' : 'checkbox';
        ctrl.name = f.label;
        ctrl.value = String(opt);
        row.appendChild(ctrl);
        row.appendChild(document.createTextNode(' ' + opt));
        input.appendChild(row);
      });
    } else if (t === 'number' || t === 'range') {
      input = document.createElement('input');
      input.type = 'number';
    } else if (t === 'email') {
      input = document.createElement('input');
      input.type = 'email';
    } else if (t === 'tel' || t === 'phone') {
      input = document.createElement('input');
      input.type = 'tel';
    } else if (t === 'date') {
      input = document.createElement('input');
      input.type = 'date';
    } else {
      input = document.createElement('input');
      input.type = 'text';
    }
    input.name = f.label || 'field';
    input.dataset.fcpLabel = f.label;
    if (input.tagName !== 'DIV') {
      input.style.cssText = 'width:100%;padding:10px 12px;border:1px solid #cbd5e1;border-radius:8px;font-size:14px;box-sizing:border-box;';
      if (f.placeholder) input.placeholder = f.placeholder;
      if (f.required)    input.required = true;
    }
    wrap.appendChild(input);
    if (f.help) {
      var h = document.createElement('div');
      h.style.cssText = 'font-size:12px;color:#64748b;margin-top:4px;';
      h.textContent = f.help;
      wrap.appendChild(h);
    }
    container.appendChild(wrap);
  }

  function _collect(container, fields) {
    var data = {};
    fields.forEach(function (f) {
      var name = f.label;
      if (!name) return;
      if (f.type === 'checkbox' && Array.isArray(f.options)) {
        var vals = Array.from(container.querySelectorAll('input[name="' + name + '"]:checked')).map(function (c) { return c.value; });
        data[name] = vals.join(', ');
        return;
      }
      var el = container.querySelector('[name="' + name + '"]');
      if (el) data[name] = el.value;
    });
    return data;
  }

  var API = {
    version: VERSION,

    /* Embed a form into a container. Returns a destroyer function. */
    embed: function (opts) {
      opts = opts || {};
      var container = _q(opts.container);
      if (!container) throw new Error('FCP.embed: container not found');
      var base = String(opts.baseUrl || '').replace(/\/$/, '');
      var restBase = base + '/wp-json/formyantra/v1';
      var formId = opts.formId;
      if (!base || !formId) throw new Error('FCP.embed: baseUrl + formId required');

      container.innerHTML = '<div style="text-align:center;padding:30px;color:#64748b;">Loading form…</div>';

      _get(restBase + '/forms/' + formId, _authHeaders(opts.apiKey))
        .then(function (form) {
          if (!form || form.code) throw new Error((form && form.message) || 'Form not found.');
          _render(container, form, opts, restBase);
        })
        .catch(function (err) {
          container.innerHTML = '<div style="color:#b91c1c;padding:20px;">Failed to load form: ' + (err.message || 'unknown') + '</div>';
          if (opts.onError) opts.onError(err);
        });

      return function destroy() { container.innerHTML = ''; };
    },
  };

  function _render(container, form, opts, restBase) {
    var theme = opts.theme || 'auto';
    var isDark = theme === 'dark' || (theme === 'auto' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
    var bg = isDark ? '#0f172a' : '#ffffff';
    var fg = isDark ? '#e2e8f0' : '#0f172a';
    container.innerHTML = '';
    container.style.cssText = 'font-family:-apple-system,BlinkMacSystemFont,"Inter",sans-serif;max-width:560px;margin:0 auto;padding:24px;background:' + bg + ';color:' + fg + ';border-radius:12px;';

    var title = document.createElement('h2');
    title.textContent = form.title || 'Form';
    title.style.cssText = 'margin:0 0 6px;font-size:22px;font-weight:700;';
    container.appendChild(title);
    if (form.description) {
      var d = document.createElement('p');
      d.textContent = form.description;
      d.style.cssText = 'margin:0 0 20px;color:#64748b;font-size:14px;';
      container.appendChild(d);
    }

    var formEl = document.createElement('form');
    formEl.style.cssText = 'display:block;';
    var flatFields = [];
    (form.steps || []).forEach(function (step) {
      (step.fields || []).forEach(function (f) {
        if (['section','divider','html'].indexOf(f.type) !== -1) return;
        _renderField(f, formEl);
        flatFields.push(f);
      });
    });

    var submitBtn = document.createElement('button');
    submitBtn.type = 'submit';
    submitBtn.textContent = (form.settings && form.settings.submitText) || 'Submit';
    submitBtn.style.cssText = 'width:100%;padding:12px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;border:none;border-radius:8px;font-weight:600;font-size:15px;cursor:pointer;margin-top:6px;';
    formEl.appendChild(submitBtn);

    var msg = document.createElement('div');
    msg.style.cssText = 'margin-top:12px;font-size:13px;';
    formEl.appendChild(msg);

    formEl.addEventListener('submit', function (e) {
      e.preventDefault();
      submitBtn.disabled = true;
      submitBtn.textContent = 'Submitting…';
      msg.textContent = '';
      var data = _collect(formEl, flatFields);
      _post(restBase + '/forms/' + form.id + '/submit', { data: data }, _authHeaders(opts.apiKey))
        .then(function (r) {
          if (!r.ok || (r.body && r.body.code)) throw new Error((r.body && (r.body.message || r.body.code)) || 'Submit failed.');
          msg.style.color = '#15803d';
          msg.textContent = (r.body && r.body.message) || 'Submitted successfully.';
          submitBtn.disabled = false;
          submitBtn.textContent = 'Submit';
          formEl.reset();
          if (opts.onSubmit) opts.onSubmit(r.body);
        }).catch(function (err) {
          msg.style.color = '#b91c1c';
          msg.textContent = err.message || 'Submit failed.';
          submitBtn.disabled = false;
          submitBtn.textContent = 'Submit';
          if (opts.onError) opts.onError(err);
        });
    });
    container.appendChild(formEl);
  }

  global.FCP = API;

  // Expose to CommonJS / ESM consumers as well.
  if (typeof module === 'object' && module.exports) module.exports = API;
})(typeof window !== 'undefined' ? window : this);
