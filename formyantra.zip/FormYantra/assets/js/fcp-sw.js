/* =========================================================================
   FormYantra — Service Worker
   Caches the public form shell so a returning visitor can keep filling a
   form even when offline. Submissions made offline are queued in
   IndexedDB and replayed when the connection comes back.
   ========================================================================= */

const SW_VERSION   = "fcp-sw-v1";
const SHELL_CACHE  = "fcp-shell-" + SW_VERSION;
const DB_NAME      = "fcp-offline";
const DB_STORE     = "queued";
const SHELL_ASSETS = [];   // populated at install() — see message handler

/* ----------------------- install / activate ----------------------- */
self.addEventListener("install", () => {
    // Skip waiting so the new SW activates immediately on first install.
    self.skipWaiting();
});

self.addEventListener("activate", (event) => {
    // Purge old caches so an updated plugin doesn't keep serving stale JS.
    event.waitUntil((async () => {
        const keys = await caches.keys();
        await Promise.all(keys.filter(k => k.startsWith("fcp-shell-") && k !== SHELL_CACHE).map(k => caches.delete(k)));
        await self.clients.claim();
    })());
});

/* ----------------------- fetch interception ----------------------- */
self.addEventListener("fetch", (event) => {
    const url = new URL(event.request.url);
    // Only intercept same-origin requests — third-party CDN assets fall
    // through to the browser normally.
    if (url.origin !== self.location.origin) return;

    // Submit POSTs to our REST endpoint get the offline-queue treatment.
    if (event.request.method === "POST" && url.pathname.indexOf("/wp-json/fcp/v1/submit") !== -1) {
        event.respondWith(submitOrQueue(event.request));
        return;
    }

    // Plugin assets get a stale-while-revalidate strategy.
    if (url.pathname.indexOf("/wp-content/plugins/form-plugin/") !== -1) {
        event.respondWith(staleWhileRevalidate(event.request));
        return;
    }
});

async function staleWhileRevalidate(request) {
    const cache    = await caches.open(SHELL_CACHE);
    const cached   = await cache.match(request);
    const fetchP   = fetch(request).then(res => {
        if (res && res.status === 200) cache.put(request, res.clone());
        return res;
    }).catch(() => cached);
    return cached || fetchP;
}

/* ----------------------- offline submit queue ----------------------- */
async function submitOrQueue(request) {
    try {
        const res = await fetch(request.clone());
        return res;
    } catch (e) {
        // Fully offline — read the body + stash it for replay.
        try {
            const body = await request.clone().text();
            const headers = {};
            request.headers.forEach((v, k) => { headers[k] = v; });
            await queueSubmission({
                url:     request.url,
                headers: headers,
                body:    body,
                at:      Date.now()
            });
            // Tell any open clients we queued it.
            await broadcast({ type: "fcp-queued", count: await queueLength() });
            return new Response(JSON.stringify({
                success:  true,
                queued:   true,
                offline:  true,
                message:  "You're offline — your submission is queued and will send automatically when you're back online."
            }), { status: 202, headers: { "content-type": "application/json" } });
        } catch (err) {
            return new Response(JSON.stringify({ success: false, message: "Offline submit failed: " + err.message }), { status: 503, headers: { "content-type": "application/json" } });
        }
    }
}

/* IndexedDB queue — minimal wrapper. One store, append-only.
   Each entry: { id auto, url, headers, body, at }. */
function openDb() {
    return new Promise((resolve, reject) => {
        const req = indexedDB.open(DB_NAME, 1);
        req.onupgradeneeded = () => {
            const db = req.result;
            if (!db.objectStoreNames.contains(DB_STORE)) {
                db.createObjectStore(DB_STORE, { keyPath: "id", autoIncrement: true });
            }
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror   = () => reject(req.error);
    });
}
async function queueSubmission(item) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
        const tx = db.transaction(DB_STORE, "readwrite");
        tx.objectStore(DB_STORE).add(item);
        tx.oncomplete = resolve;
        tx.onerror    = () => reject(tx.error);
    });
}
async function queueLength() {
    const db = await openDb();
    return new Promise((resolve) => {
        const tx = db.transaction(DB_STORE, "readonly");
        const req = tx.objectStore(DB_STORE).count();
        req.onsuccess = () => resolve(req.result || 0);
        req.onerror   = () => resolve(0);
    });
}
async function drainQueue() {
    const db = await openDb();
    const items = await new Promise((resolve, reject) => {
        const tx = db.transaction(DB_STORE, "readonly");
        const req = tx.objectStore(DB_STORE).getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror   = () => reject(req.error);
    });
    const sent = [];
    for (const item of items) {
        try {
            const res = await fetch(item.url, {
                method:  "POST",
                headers: item.headers,
                body:    item.body
            });
            if (res.ok) sent.push(item.id);
        } catch (e) {
            // Connection dropped again — stop, retry later.
            break;
        }
    }
    if (sent.length) {
        await new Promise((resolve, reject) => {
            const tx = db.transaction(DB_STORE, "readwrite");
            sent.forEach(id => tx.objectStore(DB_STORE).delete(id));
            tx.oncomplete = resolve;
            tx.onerror    = () => reject(tx.error);
        });
    }
    return sent.length;
}
async function broadcast(msg) {
    const clients = await self.clients.matchAll({ includeUncontrolled: true });
    clients.forEach(c => c.postMessage(msg));
}

/* ----------------------- client messages + sync ----------------------- */
self.addEventListener("message", (event) => {
    if (!event.data || !event.data.type) return;
    if (event.data.type === "fcp-replay-queue") {
        event.waitUntil(drainAndBroadcast());
    }
});

self.addEventListener("sync", (event) => {
    if (event.tag === "fcp-flush") event.waitUntil(drainAndBroadcast());
});

async function drainAndBroadcast() {
    const n = await drainQueue();
    if (n) await broadcast({ type: "fcp-sent", count: n });
}
