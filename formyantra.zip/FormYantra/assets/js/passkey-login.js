/**
 * FormYantra - Passkey login on wp-login.php (v2.71).
 *
 * Attaches to the "Sign in with passkey" button rendered by
 * FCP_Passkey::render_login_button(). Runs the WebAuthn assertion flow,
 * POSTs the result to /passkeys/login/verify, then navigates to the
 * redirect_to URL (or /wp-admin/).
 *
 * No external dependency, no jQuery.
 */
(function () {
    "use strict";
    if (!window.FCP_Passkey) return;

    var btn    = document.getElementById("fcp-passkey-btn");
    var status = document.getElementById("fcp-passkey-status");
    if (!btn) return;

    function say(msg, ok) {
        if (!status) return;
        status.textContent = msg || "";
        status.style.color = ok === false ? "#b91c1c" : "#64748b";
    }

    function b64urlToBuf(s) {
        var pad = "===".slice((s.length + 3) % 4);
        var b64 = s.replace(/-/g, "+").replace(/_/g, "/") + pad;
        var raw = atob(b64);
        var buf = new Uint8Array(raw.length);
        for (var i = 0; i < raw.length; i++) buf[i] = raw.charCodeAt(i);
        return buf;
    }
    function bufToB64url(buf) {
        var bytes = new Uint8Array(buf);
        var s = "";
        for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
        return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
    }

    btn.addEventListener("click", async function () {
        if (!window.PublicKeyCredential) {
            say("This browser doesn't support passkeys. Try Chrome / Safari / Firefox.", false);
            return;
        }
        btn.disabled = true;
        say("Requesting challenge…");
        try {
            var chResp = await fetch(FCP_Passkey.restUrl + "/login/challenge", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: "{}"
            });
            var opts = await chResp.json();
            if (!chResp.ok) throw new Error(opts.message || "Server refused to start the sign-in.");

            var publicKey = {
                challenge:        b64urlToBuf(opts.challenge),
                rpId:             opts.rpId,
                timeout:          opts.timeout,
                userVerification: opts.userVerification,
                allowCredentials: (opts.allowCredentials || []).map(function (c) {
                    return { type: "public-key", id: b64urlToBuf(c.id) };
                })
            };
            say("Waiting for your device…");
            var cred = await navigator.credentials.get({ publicKey: publicKey });
            if (!cred) throw new Error("No credential returned.");

            say("Verifying…");
            var vResp = await fetch(FCP_Passkey.restUrl + "/login/verify", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    credentialId:      bufToB64url(cred.rawId),
                    clientDataJSON:    bufToB64url(cred.response.clientDataJSON),
                    authenticatorData: bufToB64url(cred.response.authenticatorData),
                    signature:         bufToB64url(cred.response.signature),
                    userHandle:        cred.response.userHandle ? bufToB64url(cred.response.userHandle) : ""
                })
            });
            var vj = await vResp.json();
            if (!vResp.ok || !vj.ok) throw new Error(vj.message || "Sign-in rejected.");

            say("Signed in — redirecting…");
            window.location.href = (vj.redirect_to || FCP_Passkey.redirect || "/wp-admin/");
        } catch (err) {
            if (err && err.name === "NotAllowedError") {
                say("Cancelled or timed out.", false);
            } else {
                say("Sign-in failed: " + (err && err.message ? err.message : "unknown"), false);
            }
            btn.disabled = false;
        }
    });
})();
