/* =============================================================
 * FormYantra — User Journey Tracker
 *
 * Tracks the path a visitor took before submitting a form:
 * - Each page visit (URL + title + timestamp)
 * - Referrer (where they came from before this session)
 * - UTM parameters (campaign attribution)
 * - Site search queries (?s=)
 * - Time spent on each page
 *
 * All data lives in the visitor's own localStorage. Nothing is
 * sent to the server until they actually submit a FormYantra form,
 * at which point the form engine reads the journey and includes
 * it in the submission payload. No tracking endpoint, no cookies,
 * no third-party requests.
 *
 * Cap: 30 most-recent pages per session. Older entries are dropped
 * FIFO so localStorage doesn't bloat. Session resets after 30
 * minutes of inactivity (typical analytics-session definition).
 * ============================================================= */
(function () {
    "use strict";

    var STORAGE_KEY  = "fcp_journey";
    var MAX_PAGES    = 30;
    var SESSION_GAP  = 30 * 60 * 1000; // 30 minutes
    var STORAGE_TS   = "fcp_journey_lastseen";

    function safeStorage() {
        try {
            var t = "__fcp_t__";
            localStorage.setItem(t, "1");
            localStorage.removeItem(t);
            return localStorage;
        } catch (e) { return null; }
    }

    var store = safeStorage();
    if (!store) return; // privacy / private-browsing mode → no tracking, fail-quiet

    function loadJourney() {
        try {
            var raw = store.getItem(STORAGE_KEY);
            return raw ? JSON.parse(raw) : { entry: null, pages: [], utm: {} };
        } catch (e) {
            return { entry: null, pages: [], utm: {} };
        }
    }

    function saveJourney(j) {
        try { store.setItem(STORAGE_KEY, JSON.stringify(j)); } catch (e) { /* quota — ignore */ }
    }

    function maybeResetSession(j) {
        var now = Date.now();
        var last = parseInt(store.getItem(STORAGE_TS) || "0", 10);
        if (last && (now - last) > SESSION_GAP) {
            // Reset session — visitor was gone for >30 min
            return { entry: null, pages: [], utm: {} };
        }
        return j;
    }

    function parseUtm() {
        var params = new URLSearchParams(location.search);
        var keys = ["utm_source","utm_medium","utm_campaign","utm_term","utm_content","gclid","fbclid","msclkid"];
        var out = {};
        keys.forEach(function (k) {
            var v = params.get(k);
            if (v) out[k] = v;
        });
        return out;
    }

    function externalReferrer() {
        var r = document.referrer || "";
        if (!r) return ""; // direct
        try {
            var ru = new URL(r);
            if (ru.hostname === location.hostname) return ""; // internal navigation
            return r;
        } catch (e) { return r; }
    }

    function classifyReferrer(ref) {
        if (!ref) return "direct";
        var r = ref.toLowerCase();
        if (/google\./.test(r))    return "google";
        if (/bing\./.test(r))      return "bing";
        if (/duckduckgo\./.test(r))return "duckduckgo";
        if (/yahoo\./.test(r))     return "yahoo";
        if (/facebook\.|fb\.com/.test(r)) return "facebook";
        if (/twitter\.|t\.co|x\.com/.test(r)) return "twitter";
        if (/linkedin\./.test(r))  return "linkedin";
        if (/instagram\./.test(r)) return "instagram";
        if (/youtube\./.test(r))   return "youtube";
        if (/reddit\./.test(r))    return "reddit";
        if (/pinterest\./.test(r)) return "pinterest";
        if (/whatsapp\.|wa\.me/.test(r)) return "whatsapp";
        return "other";
    }

    function siteSearchQuery() {
        // WordPress site search uses ?s=<query>
        var s = new URLSearchParams(location.search).get("s");
        return s ? s.trim() : "";
    }

    function track() {
        var j = maybeResetSession(loadJourney());

        // First page in this session → record entry + UTM + classified referrer
        if (!j.entry) {
            var ref = externalReferrer();
            j.entry = {
                url:        location.href,
                referrer:   ref,
                ref_source: classifyReferrer(ref),
                ts:         Date.now()
            };
            var utm = parseUtm();
            if (Object.keys(utm).length) j.utm = utm;
        }

        // Same-URL deduplication: don't record the same page twice in a row
        var lastPage = j.pages[j.pages.length - 1];
        if (!lastPage || lastPage.url !== location.href) {
            // Stamp the previous page's duration BEFORE pushing the new one
            if (lastPage && !lastPage.duration) {
                lastPage.duration = Math.max(0, Math.round((Date.now() - lastPage.ts) / 1000));
            }
            var entry = {
                url:   location.href,
                title: (document.title || "").slice(0, 200),
                ts:    Date.now()
            };
            var q = siteSearchQuery();
            if (q) entry.search = q.slice(0, 200);
            j.pages.push(entry);
            if (j.pages.length > MAX_PAGES) j.pages = j.pages.slice(-MAX_PAGES);
        }

        store.setItem(STORAGE_TS, String(Date.now()));
        saveJourney(j);

        // Stamp last page's duration when the visitor leaves (best-effort,
        // sendBeacon-style — runs on tab-close / navigation).
        var stampOnLeave = function () {
            try {
                var jj = loadJourney();
                if (jj.pages && jj.pages.length) {
                    var last = jj.pages[jj.pages.length - 1];
                    if (last && last.url === location.href && !last.duration) {
                        last.duration = Math.max(0, Math.round((Date.now() - last.ts) / 1000));
                        saveJourney(jj);
                    }
                }
                store.setItem(STORAGE_TS, String(Date.now()));
            } catch (e) {}
        };
        window.addEventListener("pagehide",     stampOnLeave);
        window.addEventListener("beforeunload", stampOnLeave);
        document.addEventListener("visibilitychange", function () {
            if (document.visibilityState === "hidden") stampOnLeave();
        });
    }

    // Surface a small helper so the form engine can read the journey at
    // submit time and clear it after a successful submission.
    window.FCJourney = {
        get: function () {
            return maybeResetSession(loadJourney());
        },
        clear: function () {
            try { store.removeItem(STORAGE_KEY); } catch (e) {}
        }
    };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", track);
    } else {
        track();
    }
})();
