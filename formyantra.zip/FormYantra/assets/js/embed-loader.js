/**
 * FormYantra — Universal Embed Loader (v2.51)
 *
 * One tiny script that handles every non-inline embed mode:
 *   - popup     : modal centered on screen, triggered by button/time/scroll/exit
 *   - floating  : fixed-position chat-style button that opens a popup on click
 *   - slidein   : bottom-right card that slides in on scroll
 *   - bar       : sticky top/bottom announcement bar with the form inline
 *
 * Usage:
 *   <script src="…/embed-loader.js"
 *           data-form-id="42"
 *           data-mode="popup"
 *           data-trigger="button"
 *           data-delay="3000"
 *           data-button-label="Get a Quote"
 *           data-position="bottom-right"
 *           data-form-url="https://site.com/formyantra/contact/"></script>
 *
 * The form-url MUST be set — that's the standalone landing-page URL of
 * the form (WordPress generates one automatically via the pretty
 * /formyantra/<slug>/ rewrite rule, or directly from public/form.html).
 *
 * Why iframe and not inline JS render: iframe is sandboxed, doesn't
 * leak the host site's CSS into the form, doesn't leak the form's JS
 * into the host's globals, and works across origins. Trade-off: a tiny
 * extra HTTP request — worth it for safety.
 */
(function () {
    "use strict";

    // The script's own <script> tag — find by data-form-id presence.
    const script = document.currentScript || (function () {
        const s = document.querySelectorAll("script[data-form-id]");
        return s[s.length - 1];
    })();
    if (!script) return;

    const cfg = {
        formId:      script.getAttribute("data-form-id"),
        formUrl:     script.getAttribute("data-form-url"),
        mode:        (script.getAttribute("data-mode") || "popup").toLowerCase(),
        trigger:     (script.getAttribute("data-trigger") || "button").toLowerCase(),  // button|time|scroll|exit
        delay:       parseInt(script.getAttribute("data-delay") || "3000", 10),
        scrollPct:   parseInt(script.getAttribute("data-scroll-pct") || "60", 10),
        buttonLabel: script.getAttribute("data-button-label") || "Open Form",
        buttonColor: script.getAttribute("data-button-color") || "#6366f1",
        position:    (script.getAttribute("data-position") || "bottom-right").toLowerCase(),
        width:       parseInt(script.getAttribute("data-width") || "640", 10),
        height:      parseInt(script.getAttribute("data-height") || "720", 10),
    };

    if (!cfg.formUrl || !cfg.formId) {
        console.warn("[FormYantra embed] Missing data-form-id or data-form-url on script tag.");
        return;
    }

    // Once-per-visitor dismissal — visitor closes the popup, we don't
    // nag them again for 7 days. Stored in localStorage keyed by form id.
    const DISMISS_KEY = "fcp_embed_dismissed_" + cfg.formId;
    const dismissedAt = parseInt(localStorage.getItem(DISMISS_KEY) || "0", 10);
    if (dismissedAt && Date.now() - dismissedAt < 7 * 24 * 60 * 60 * 1000) {
        // Still respect manual trigger (button click) — only auto-triggers honour dismissal.
        if (cfg.trigger !== "button" && cfg.mode !== "floating" && cfg.mode !== "bar") return;
    }

    // ─── Build the popup container once ───
    function makePopup() {
        const wrap = document.createElement("div");
        wrap.className = "fcp-embed-popup";
        wrap.setAttribute("role", "dialog");
        wrap.setAttribute("aria-label", "Form");
        wrap.innerHTML =
            '<div class="fcp-embed-backdrop"></div>' +
            '<div class="fcp-embed-box" style="width:' + cfg.width + 'px;height:' + cfg.height + 'px;">' +
                '<button class="fcp-embed-close" aria-label="Close">&times;</button>' +
                '<iframe src="' + cfg.formUrl + '" frameborder="0" loading="lazy" title="Form"></iframe>' +
            '</div>';
        document.body.appendChild(wrap);
        const close = () => {
            wrap.classList.remove("is-open");
            localStorage.setItem(DISMISS_KEY, String(Date.now()));
            setTimeout(() => wrap.remove(), 200);
        };
        wrap.querySelector(".fcp-embed-close").addEventListener("click", close);
        wrap.querySelector(".fcp-embed-backdrop").addEventListener("click", close);
        document.addEventListener("keydown", function onEsc(e) {
            if (e.key === "Escape" && wrap.classList.contains("is-open")) {
                close();
                document.removeEventListener("keydown", onEsc);
            }
        });
        requestAnimationFrame(() => wrap.classList.add("is-open"));
        return wrap;
    }

    // ─── Mode: popup ───
    // Decoupled from how it's triggered — same renderer for click/time/scroll/exit.
    function openPopup() {
        if (document.querySelector(".fcp-embed-popup")) return;
        makePopup();
    }

    // ─── Mode: floating chat button ───
    // Always-visible fixed-position button. Click → opens the popup.
    function mountFloatingButton() {
        const btn = document.createElement("button");
        btn.className = "fcp-embed-fab fcp-embed-fab-" + cfg.position;
        btn.style.background = cfg.buttonColor;
        btn.textContent = cfg.buttonLabel;
        btn.addEventListener("click", openPopup);
        document.body.appendChild(btn);
    }

    // ─── Mode: slide-in ───
    // Compact card that slides up from bottom-right on scroll. Same close
    // behavior as popup. Smaller iframe so it doesn't dominate the page.
    function mountSlideIn() {
        const card = document.createElement("div");
        card.className = "fcp-embed-slide fcp-embed-slide-" + cfg.position;
        card.style.width = Math.min(cfg.width, 420) + "px";
        card.innerHTML =
            '<button class="fcp-embed-close" aria-label="Close">&times;</button>' +
            '<iframe src="' + cfg.formUrl + '" frameborder="0" loading="lazy" title="Form" style="height:' + Math.min(cfg.height, 540) + 'px;"></iframe>';
        document.body.appendChild(card);
        card.querySelector(".fcp-embed-close").addEventListener("click", () => {
            card.classList.remove("is-open");
            localStorage.setItem(DISMISS_KEY, String(Date.now()));
            setTimeout(() => card.remove(), 200);
        });
        const trigger = () => requestAnimationFrame(() => card.classList.add("is-open"));
        if (cfg.trigger === "time")   setTimeout(trigger, cfg.delay);
        else if (cfg.trigger === "scroll") onScrollPct(cfg.scrollPct, trigger);
        else                                trigger();   // default: show immediately
    }

    // ─── Mode: bar ───
    // Sticky top OR bottom announcement bar. Form renders inline inside it
    // (visitor doesn't get an extra modal step). Best for newsletter signup.
    function mountBar() {
        const bar = document.createElement("div");
        bar.className = "fcp-embed-bar fcp-embed-bar-" + (cfg.position.indexOf("top") === 0 ? "top" : "bottom");
        bar.innerHTML =
            '<iframe src="' + cfg.formUrl + '?compact=1" frameborder="0" loading="lazy" title="Form"></iframe>' +
            '<button class="fcp-embed-close" aria-label="Close">&times;</button>';
        document.body.appendChild(bar);
        bar.querySelector(".fcp-embed-close").addEventListener("click", () => {
            bar.remove();
            localStorage.setItem(DISMISS_KEY, String(Date.now()));
        });
    }

    // ─── Trigger plumbing for popup mode ───
    // Buttons inline on the page can opt in by adding data-fcp-popup="<form-id>".
    function wireButtons() {
        const buttons = document.querySelectorAll('[data-fcp-popup="' + cfg.formId + '"]');
        buttons.forEach(b => b.addEventListener("click", function (e) {
            e.preventDefault();
            openPopup();
        }));
    }
    function onScrollPct(pct, fn) {
        let fired = false;
        const handler = () => {
            const max  = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight) - window.innerHeight;
            const done = max > 0 ? (window.scrollY / max) * 100 : 0;
            if (done >= pct && !fired) { fired = true; fn(); window.removeEventListener("scroll", handler); }
        };
        window.addEventListener("scroll", handler, { passive: true });
        handler();
    }
    function onExitIntent(fn) {
        let fired = false;
        document.addEventListener("mouseleave", function (e) {
            // Only top-edge exits count — leaving via the URL/tab bar.
            if (!fired && e.clientY <= 0) { fired = true; fn(); }
        });
    }

    // ─── Boot ───
    function boot() {
        // Inject style block once.
        if (!document.getElementById("fcp-embed-style")) {
            const s = document.createElement("style");
            s.id = "fcp-embed-style";
            s.textContent =
                ".fcp-embed-popup{position:fixed;inset:0;z-index:2147483600;display:flex;align-items:center;justify-content:center;opacity:0;pointer-events:none;transition:opacity .2s}" +
                ".fcp-embed-popup.is-open{opacity:1;pointer-events:auto}" +
                ".fcp-embed-backdrop{position:absolute;inset:0;background:rgba(15,23,42,.55);backdrop-filter:blur(2px)}" +
                ".fcp-embed-box{position:relative;background:#fff;border-radius:14px;box-shadow:0 24px 64px rgba(15,23,42,.4);max-width:92vw;max-height:90vh;overflow:hidden;transform:translateY(8px);transition:transform .2s}" +
                ".fcp-embed-popup.is-open .fcp-embed-box{transform:translateY(0)}" +
                ".fcp-embed-box iframe{width:100%;height:100%;border:0;display:block;background:transparent}" +
                ".fcp-embed-close{position:absolute;top:10px;right:10px;width:32px;height:32px;border-radius:50%;background:rgba(15,23,42,.85);color:#fff;border:0;font-size:20px;font-weight:300;cursor:pointer;z-index:1;line-height:1;display:grid;place-items:center}" +
                ".fcp-embed-close:hover{background:#0f172a;transform:scale(1.05)}" +
                ".fcp-embed-fab{position:fixed;z-index:2147483500;color:#fff;border:0;border-radius:999px;padding:14px 24px;font:600 14px system-ui,-apple-system,sans-serif;cursor:pointer;box-shadow:0 8px 24px rgba(15,23,42,.25);transition:transform .15s, box-shadow .15s}" +
                ".fcp-embed-fab:hover{transform:translateY(-2px);box-shadow:0 12px 30px rgba(15,23,42,.3)}" +
                ".fcp-embed-fab-bottom-right{bottom:24px;right:24px}" +
                ".fcp-embed-fab-bottom-left{bottom:24px;left:24px}" +
                ".fcp-embed-fab-top-right{top:24px;right:24px}" +
                ".fcp-embed-fab-top-left{top:24px;left:24px}" +
                ".fcp-embed-slide{position:fixed;z-index:2147483500;background:#fff;border-radius:14px 14px 0 0;box-shadow:0 12px 32px rgba(15,23,42,.25);overflow:hidden;transform:translateY(120%);transition:transform .25s ease-out}" +
                ".fcp-embed-slide.is-open{transform:translateY(0)}" +
                ".fcp-embed-slide-bottom-right{bottom:0;right:24px}" +
                ".fcp-embed-slide-bottom-left{bottom:0;left:24px}" +
                ".fcp-embed-slide iframe{width:100%;border:0;display:block}" +
                ".fcp-embed-bar{position:fixed;left:0;right:0;z-index:2147483500;background:#fff;box-shadow:0 -4px 16px rgba(15,23,42,.1);display:flex;align-items:stretch}" +
                ".fcp-embed-bar-top{top:0;box-shadow:0 4px 16px rgba(15,23,42,.1)}" +
                ".fcp-embed-bar-bottom{bottom:0}" +
                ".fcp-embed-bar iframe{flex:1;border:0;height:84px}" +
                ".fcp-embed-bar .fcp-embed-close{position:relative;width:40px;height:auto;border-radius:0;top:auto;right:auto;background:#0f172a}" +
                "@media(prefers-reduced-motion:reduce){.fcp-embed-popup,.fcp-embed-box,.fcp-embed-slide,.fcp-embed-fab{transition:none !important}}";
            document.head.appendChild(s);
        }

        if (cfg.mode === "floating") {
            mountFloatingButton();
            return;
        }
        if (cfg.mode === "slidein") {
            mountSlideIn();
            return;
        }
        if (cfg.mode === "bar") {
            mountBar();
            return;
        }
        // popup mode
        wireButtons();
        if (cfg.trigger === "time")   setTimeout(openPopup, cfg.delay);
        if (cfg.trigger === "scroll") onScrollPct(cfg.scrollPct, openPopup);
        if (cfg.trigger === "exit")   onExitIntent(openPopup);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
})();
