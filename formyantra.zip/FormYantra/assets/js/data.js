/* ============================================================
   FormYantra - Data Layer (LocalStorage backed)
   ============================================================ */
(function (global) {
    "use strict";

    const STORAGE_KEY = "fcp_state_v1";

    // ---------- Seed / defaults ----------
    const today = new Date();
    function daysAgo(n) {
        const d = new Date(today);
        d.setDate(d.getDate() - n);
        return d.toISOString();
    }
    function uid(prefix) {
        return (prefix || "id") + "_" + Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-3);
    }

    const seedForms = [
        {
            id: "form_contact",
            title: "Contact Us",
            description: "Reach out and we'll get back to you within 24 hours.",
            status: "active",
            tag: "contact",
            steps: [
                {
                    id: "step_1",
                    title: "Your Details",
                    fields: [
                        { id: uid("f"), type: "name", label: "Full Name", required: true, placeholder: "John Doe" },
                        { id: uid("f"), type: "email", label: "Email Address", required: true, placeholder: "you@company.com" },
                        { id: uid("f"), type: "tel", label: "Phone", required: false, placeholder: "+1 555 0100" }
                    ]
                },
                {
                    id: "step_2",
                    title: "Your Message",
                    fields: [
                        { id: uid("f"), type: "select", label: "Subject", required: true, options: ["General inquiry", "Sales question", "Support request", "Partnership"] },
                        { id: uid("f"), type: "textarea", label: "Tell us more", required: true, placeholder: "How can we help?" }
                    ]
                }
            ],
            settings: { submitText: "Send Message", successMessage: "Thanks! We received your message.", recaptcha: true },
            views: 4823, submissions: 421, spam: 19,
            createdAt: daysAgo(45), updatedAt: daysAgo(2)
        },
        {
            id: "form_lead",
            title: "Multi-Step Lead Capture",
            description: "Qualify leads with a friendly 3-step flow.",
            status: "active", tag: "marketing",
            steps: [
                { id: "step_a", title: "About You",
                  fields: [
                    { id: uid("f"), type: "name", label: "Your Name", required: true },
                    { id: uid("f"), type: "email", label: "Work Email", required: true },
                    { id: uid("f"), type: "text", label: "Company", required: true }
                  ]
                },
                { id: "step_b", title: "Your Needs",
                  fields: [
                    { id: uid("f"), type: "radio", label: "Team Size", required: true, options: ["1-10", "11-50", "51-200", "200+"] },
                    { id: uid("f"), type: "checkbox", label: "What are you interested in?", options: ["Forms", "Surveys", "Payments", "Analytics"] },
                    { id: uid("f"), type: "range", label: "Monthly budget (USD)", min: 0, max: 5000, step: 100 }
                  ]
                },
                { id: "step_c", title: "Schedule",
                  fields: [
                    { id: uid("f"), type: "date", label: "Best date to talk", required: true },
                    { id: uid("f"), type: "time", label: "Time", required: false },
                    { id: uid("f"), type: "textarea", label: "Anything else?", required: false }
                  ]
                }
            ],
            settings: { submitText: "Get Demo", successMessage: "Thanks — a rep will be in touch shortly!", recaptcha: true },
            views: 12340, submissions: 1842, spam: 64,
            createdAt: daysAgo(60), updatedAt: daysAgo(1)
        },
        {
            id: "form_event",
            title: "Event Registration",
            description: "Register attendees for an upcoming event.",
            status: "active", tag: "events",
            steps: [
                { id: "s1", title: "Attendee",
                  fields: [
                    { id: uid("f"), type: "name", label: "Attendee Name", required: true },
                    { id: uid("f"), type: "email", label: "Email", required: true },
                    { id: uid("f"), type: "select", label: "Ticket Type", required: true, options: ["General", "VIP", "Speaker"] }
                  ]
                },
                { id: "s2", title: "Confirm",
                  fields: [
                    { id: uid("f"), type: "checkbox", label: "Dietary preferences", options: ["Vegetarian", "Vegan", "Gluten-free", "None"] },
                    { id: uid("f"), type: "gdpr", label: "I agree to the privacy policy", required: true }
                  ]
                }
            ],
            settings: { submitText: "Register", successMessage: "You're in! See you at the event.", recaptcha: false },
            views: 2150, submissions: 318, spam: 7,
            createdAt: daysAgo(20), updatedAt: daysAgo(3)
        },
        {
            id: "form_job",
            title: "Job Application",
            description: "Single-step application with resume upload.",
            status: "draft", tag: "hr",
            steps: [
                { id: "j1", title: "Application",
                  fields: [
                    { id: uid("f"), type: "name", label: "Full Name", required: true },
                    { id: uid("f"), type: "email", label: "Email", required: true },
                    { id: uid("f"), type: "tel", label: "Phone", required: true },
                    { id: uid("f"), type: "url", label: "LinkedIn", required: false },
                    { id: uid("f"), type: "file", label: "Resume (PDF)", required: true },
                    { id: uid("f"), type: "textarea", label: "Cover letter", required: false }
                  ]
                }
            ],
            settings: { submitText: "Apply", successMessage: "Thanks! We'll review your application." },
            views: 612, submissions: 41, spam: 2,
            createdAt: daysAgo(5), updatedAt: daysAgo(1)
        },
        {
            id: "form_feedback",
            title: "Customer Feedback",
            description: "Net Promoter Score + open feedback.",
            status: "active", tag: "support",
            steps: [
                { id: "fb1", title: "Rate Us",
                  fields: [
                    { id: uid("f"), type: "rating", label: "How likely are you to recommend us?", required: true },
                    { id: uid("f"), type: "textarea", label: "Tell us why", required: false }
                  ]
                }
            ],
            settings: { submitText: "Submit Feedback", successMessage: "Thanks for your feedback!" },
            views: 1875, submissions: 542, spam: 11,
            createdAt: daysAgo(30), updatedAt: daysAgo(7)
        }
    ];

    const seedSubmissions = (function () {
        const rows = [];
        const names = ["Ava Martinez","Liam Patel","Noah Kim","Emma Johnson","Sofia Garcia","Mason Wright","Olivia Brown","Lucas Davis","Isabella Lee","Ethan Wilson","Mia Anderson","Aiden Taylor","Zara Khan","Ravi Sharma","Yuki Tanaka","Anna Müller","Diego Lopez","Chloe Smith","Henrik Olsen","Priya Iyer"];
        const browsers = ["Chrome","Firefox","Safari","Edge","Opera"];
        const devices = ["Desktop","Mobile","Tablet"];
        const countries = ["United States","India","Germany","United Kingdom","Brazil","Japan","Canada","Australia","France","Spain"];
        for (let i = 0; i < 48; i++) {
            const form = seedForms[i % seedForms.length];
            const isSpam = i % 13 === 0;
            const isRead = i % 3 !== 0;
            rows.push({
                id: uid("sub"),
                formId: form.id,
                formTitle: form.title,
                name: names[i % names.length],
                email: names[i % names.length].toLowerCase().replace(/\s+/g, ".") + "@example.com",
                phone: "+1 555 " + String(1000 + i).padStart(4, "0"),
                ip: "192.168." + (i % 99) + "." + ((i * 7) % 250),
                country: countries[i % countries.length],
                browser: browsers[i % browsers.length],
                device: devices[i % devices.length],
                read: isRead,
                spam: isSpam,
                createdAt: daysAgo(i % 35),
                data: {
                    "Full Name": names[i % names.length],
                    "Email Address": names[i % names.length].toLowerCase().replace(/\s+/g, ".") + "@example.com",
                    "Subject": ["General inquiry","Sales question","Support request"][i % 3],
                    "Message": "Hi team, I'd like to know more about your product offering and pricing.",
                    "Company": ["Acme Inc","Globex","Initech","Soylent","Umbrella"][i % 5]
                }
            });
        }
        return rows;
    })();

    const seedSettings = {
        general: {
            siteName: "FormYantra",
            adminEmail: "admin@formcraft.local",
            timezone: "America/New_York",
            dateFormat: "MM/DD/YYYY",
            language: "en",
            currency: "USD",
            theme: "light"
        },
        recaptcha: {
            enabled: true,
            version: "v3",
            siteKey: "",
            secretKey: "",
            autoInject: true,
            scoreThreshold: 0.5
        },
        email: {
            smtpHost: "smtp.gmail.com",
            smtpPort: 587,
            smtpUser: "noreply@example.com",
            smtpPass: "",
            encryption: "tls",
            fromName: "FormYantra",
            fromEmail: "noreply@example.com",
            adminRecipients: "admin@example.com",
            sendUserConfirmation: true,
            sendAdminNotification: true,
            confirmationSubject: "Thanks for contacting us!",
            confirmationBody: "<h2>Hi {{name}},</h2><p>We received your submission and will reply soon.</p>"
        },
        styling: {
            primaryColor: "#6366f1",
            accentColor: "#06b6d4",
            buttonRadius: 10,
            font: "Inter",
            buttonStyle: "filled"
        },
        security: {
            csrf: true,
            honeypot: true,
            rateLimit: 30,
            maxUpload: 10,
            allowedFiles: "pdf,doc,docx,jpg,png",
            gdpr: true,
            ipBlocklist: ""
        }
    };

    const seedIntegrations = [
        { id: "zapier",    name: "Zapier",         category: "zapier",   status: "disconnected", description: "Connect to 5000+ apps via Zapier automations.",  icon: "zap" },
        { id: "slack",     name: "Slack",          category: "crm",      status: "disconnected", description: "Send submission alerts to a Slack channel.",      icon: "message" },
        { id: "mailchimp", name: "Mailchimp",      category: "crm",      status: "disconnected", description: "Sync contacts into your Mailchimp lists.",        icon: "mail" },
        { id: "hubspot",   name: "HubSpot CRM",    category: "crm",      status: "disconnected", description: "Push leads into HubSpot deals & contacts.",       icon: "trending" },
        { id: "stripe",    name: "Stripe",         category: "payment",  status: "disconnected", description: "Accept cards globally via Stripe Checkout.",      icon: "credit" },
        { id: "razorpay",  name: "Razorpay",       category: "payment",  status: "disconnected", description: "Accept UPI / cards / netbanking in India.",       icon: "credit" },
        { id: "cashfree",  name: "Cashfree",       category: "payment",  status: "disconnected", description: "Indian gateway with lower fees than Razorpay.",   icon: "credit" },
        { id: "instamojo", name: "Instamojo",      category: "payment",  status: "disconnected", description: "Simple Indian gateway for solo founders.",        icon: "credit" },
        { id: "paypal",    name: "PayPal",         category: "payment",  status: "disconnected", description: "Accept PayPal payments worldwide.",               icon: "credit" },
        { id: "sheets",    name: "Google Sheets",  category: "webhooks", status: "disconnected", description: "Stream submissions into a Google Sheet.",         icon: "grid" },
        { id: "webhook",   name: "Custom Webhook", category: "webhooks", status: "disconnected", description: "Send a POST request on every submission.",        icon: "code" },
        { id: "drive",     name: "Google Drive",   category: "webhooks", status: "disconnected", description: "Upload form attachments to Google Drive.",        icon: "folder" }
    ];

    const seedUsers = [
        { id: "u1", name: "Alex Morgan",    email: "alex@example.com",         role: "Admin",   status: "active",  avatar: "AM", lastLogin: daysAgo(0) },
        { id: "u2", name: "Jordan Lee",     email: "jordan@example.com",       role: "Admin",   status: "active",  avatar: "JL", lastLogin: daysAgo(1) },
        { id: "u3", name: "Sara Williams",  email: "sara@example.com",         role: "Editor",  status: "active",  avatar: "SW", lastLogin: daysAgo(3) },
        { id: "u4", name: "Marcus Chen",    email: "marcus@example.com",       role: "Manager", status: "active",  avatar: "MC", lastLogin: daysAgo(7) },
        { id: "u5", name: "Elena Rossi",    email: "elena@example.com",        role: "Editor",  status: "inactive",avatar: "ER", lastLogin: daysAgo(28) }
    ];

    const seedTemplates = [
        { id: "tpl_contact",   name: "Contact Form",        desc: "Simple contact form with name, email and message.",        category: "General",   color: "#6366f1", icon: "📧" },
        { id: "tpl_quote",     name: "Get a Quote",         desc: "Multi-step quote request for sales teams.",                 category: "Business",  color: "#06b6d4", icon: "💼" },
        { id: "tpl_survey",    name: "Customer Survey",     desc: "Collect NPS-style feedback with ratings.",                  category: "Surveys",   color: "#10b981", icon: "📊" },
        { id: "tpl_event",     name: "Event Registration",  desc: "Register attendees and capture preferences.",               category: "Events",    color: "#f59e0b", icon: "🎉" },
        { id: "tpl_job",       name: "Job Application",     desc: "Recruit talent with resume upload.",                        category: "HR",        color: "#ef4444", icon: "💼" },
        { id: "tpl_donation",  name: "Donation Form",       desc: "Accept donations with preset amounts.",                     category: "Payments",  color: "#8b5cf6", icon: "💝" },
        { id: "tpl_rsvp",      name: "RSVP",                desc: "Quick yes/no RSVP with guest count.",                       category: "Events",    color: "#ec4899", icon: "🎫" },
        { id: "tpl_newsletter",name: "Newsletter Signup",   desc: "Single-field newsletter capture.",                          category: "Marketing", color: "#3b82f6", icon: "✉️" },

        // Business category — full multi-step forms with proper field configs
        { id: "tpl_job_upload",   name: "Job Application Upload Form", desc: "Multi-step recruitment form with resume upload and cover letter.", category: "Business", color: "#ef4444", icon: "📄" },
        { id: "tpl_accident",     name: "Accident Report Form",        desc: "Workplace incident reporting with witnesses, photos, signature.",  category: "Business", color: "#dc2626", icon: "⚠️" },
        { id: "tpl_address_book", name: "Address Book Form",           desc: "Contact directory entry with full address and details.",          category: "Business", color: "#0ea5e9", icon: "📇" },
        { id: "tpl_auto_info",    name: "Automobile Information Form", desc: "Vehicle ownership, insurance, and service record capture.",       category: "Business", color: "#475569", icon: "🚗" },
        { id: "tpl_blog_pitch",   name: "Blog Post Pitch Form",        desc: "Writer pitches with topic, audience, and sample work.",           category: "Business", color: "#8b5cf6", icon: "✍️" },
        { id: "tpl_billing",      name: "Billing / Order Form",        desc: "Order capture with line items, totals, and payment method.",      category: "Business", color: "#16a34a", icon: "🧾" },
        { id: "tpl_lead_gen",     name: "Lead Generation Form",        desc: "B2B qualification form with industry, budget, and timeline.",     category: "Business", color: "#06b6d4", icon: "🎯" },
        { id: "tpl_appointment",  name: "Appointment Booking Form",    desc: "Calendly-style booking with service, date, and time slot.",       category: "Business", color: "#f59e0b", icon: "📅" },
        { id: "tpl_meeting_room", name: "Meeting Room Registration Form", desc: "Internal room booking with equipment and catering options.",   category: "Business", color: "#6366f1", icon: "🪑" },
        { id: "tpl_partnership",  name: "Partnership Agreement Form",  desc: "Partnership proposal with terms, goals, and digital signature.",  category: "Business", color: "#0f172a", icon: "🤝" },

        /* ─── v2.62 — Industry-specific template packs ───
           Each template carries:
             - industry: pack name (used for grouping in the UI)
             - version:  semver, bumped when fields/structure change so
                         installed forms know whether an upgrade exists
             - tags:     keyword list for the search box
             - source:   "builtin" (vs "community" for user-published)
           Pack expansions live in the marketplace.html "Industry Packs"
           rail — each pack groups all templates with the same industry. */

        // ─── Healthcare (8) ───
        { id: "tpl_hc_intake",       name: "Patient Intake Form",         desc: "New patient details, insurance card, allergies, current meds.",        category: "Healthcare", industry: "Healthcare", version: "1.0.0", source: "builtin", color: "#0ea5e9", icon: "🏥", tags: ["clinic","patient","intake","medical"] },
        { id: "tpl_hc_appt",         name: "Doctor Appointment Booking",  desc: "Pick a doctor, choose a time slot, describe symptoms.",                 category: "Healthcare", industry: "Healthcare", version: "1.0.0", source: "builtin", color: "#0ea5e9", icon: "📅", tags: ["doctor","appointment","booking"] },
        { id: "tpl_hc_insurance",    name: "Insurance Claim Form",        desc: "Pre-auth + reimbursement request with policy upload.",                  category: "Healthcare", industry: "Healthcare", version: "1.0.0", source: "builtin", color: "#0ea5e9", icon: "🛡", tags: ["insurance","claim","reimbursement"] },
        { id: "tpl_hc_refill",       name: "Prescription Refill Request", desc: "Existing prescription number + pharmacy of choice.",                    category: "Healthcare", industry: "Healthcare", version: "1.0.0", source: "builtin", color: "#0ea5e9", icon: "💊", tags: ["prescription","refill","pharmacy"] },
        { id: "tpl_hc_screening",    name: "COVID-19 Screening",          desc: "Symptom checklist + travel history + vaccination status.",              category: "Healthcare", industry: "Healthcare", version: "1.0.0", source: "builtin", color: "#0ea5e9", icon: "🦠", tags: ["covid","screening","health"] },
        { id: "tpl_hc_vaccine",      name: "Vaccination Consent",         desc: "Patient signature, prior reactions, contraindications.",                category: "Healthcare", industry: "Healthcare", version: "1.0.0", source: "builtin", color: "#0ea5e9", icon: "💉", tags: ["vaccine","consent","immunization"] },
        { id: "tpl_hc_history",      name: "Medical History Questionnaire",desc: "Family history, surgeries, chronic conditions, current medications.",  category: "Healthcare", industry: "Healthcare", version: "1.0.0", source: "builtin", color: "#0ea5e9", icon: "📋", tags: ["history","medical","questionnaire"] },
        { id: "tpl_hc_telehealth",   name: "Telehealth Waiver",           desc: "Consent for virtual consultation + tech requirements check.",          category: "Healthcare", industry: "Healthcare", version: "1.0.0", source: "builtin", color: "#0ea5e9", icon: "💻", tags: ["telehealth","virtual","waiver"] },

        // ─── Real Estate (6) ───
        { id: "tpl_re_inquiry",      name: "Property Inquiry Form",       desc: "Visitor asks about a listing — captures bedrooms, budget, timeline.",  category: "Real Estate", industry: "Real Estate", version: "1.0.0", source: "builtin", color: "#16a34a", icon: "🏡", tags: ["property","inquiry","real-estate"] },
        { id: "tpl_re_mortgage",     name: "Mortgage Pre-Approval",       desc: "Income + assets + employment for loan pre-qualification.",              category: "Real Estate", industry: "Real Estate", version: "1.0.0", source: "builtin", color: "#16a34a", icon: "💰", tags: ["mortgage","loan","financing"] },
        { id: "tpl_re_viewing",      name: "Property Viewing Request",    desc: "Pick a time + party size for an in-person showing.",                    category: "Real Estate", industry: "Real Estate", version: "1.0.0", source: "builtin", color: "#16a34a", icon: "🔑", tags: ["viewing","showing","tour"] },
        { id: "tpl_re_tenant",       name: "Tenant Application",          desc: "Income proof, references, prior addresses, employment.",                category: "Real Estate", industry: "Real Estate", version: "1.0.0", source: "builtin", color: "#16a34a", icon: "🏘", tags: ["tenant","rental","lease"] },
        { id: "tpl_re_listing",      name: "Sell Your Property",          desc: "Seller submits listing details, photos, asking price.",                 category: "Real Estate", industry: "Real Estate", version: "1.0.0", source: "builtin", color: "#16a34a", icon: "🏷", tags: ["listing","sell","fsbo"] },
        { id: "tpl_re_agent",        name: "Find an Agent",               desc: "Match a buyer/seller to an agent based on location + price range.",     category: "Real Estate", industry: "Real Estate", version: "1.0.0", source: "builtin", color: "#16a34a", icon: "🤝", tags: ["agent","realtor","match"] },

        // ─── Education (7) ───
        { id: "tpl_edu_enroll",      name: "Student Enrollment Form",     desc: "Grade level, parent details, prior school, transport needs.",          category: "Education", industry: "Education", version: "1.0.0", source: "builtin", color: "#a855f7", icon: "🎓", tags: ["student","enrollment","admission"] },
        { id: "tpl_edu_pt_conf",     name: "Parent-Teacher Conference",   desc: "Book a slot, list discussion topics, request translator.",              category: "Education", industry: "Education", version: "1.0.0", source: "builtin", color: "#a855f7", icon: "📚", tags: ["parent-teacher","conference","meeting"] },
        { id: "tpl_edu_scholar",     name: "Scholarship Application",     desc: "Essay upload, GPA, references, financial need declaration.",            category: "Education", industry: "Education", version: "1.0.0", source: "builtin", color: "#a855f7", icon: "🏆", tags: ["scholarship","grant","aid"] },
        { id: "tpl_edu_course",      name: "Online Course Signup",        desc: "Course selection, payment, prereq verification, completion goals.",     category: "Education", industry: "Education", version: "1.0.0", source: "builtin", color: "#a855f7", icon: "📖", tags: ["course","online","mooc"] },
        { id: "tpl_edu_tutoring",    name: "Tutoring Request",            desc: "Subject + grade level + availability, learning goals.",                category: "Education", industry: "Education", version: "1.0.0", source: "builtin", color: "#a855f7", icon: "✏", tags: ["tutoring","lesson","private"] },
        { id: "tpl_edu_alumni",      name: "Alumni Network Update",       desc: "Year, current employer, achievements, willingness to mentor.",          category: "Education", industry: "Education", version: "1.0.0", source: "builtin", color: "#a855f7", icon: "🎓", tags: ["alumni","network","mentor"] },
        { id: "tpl_edu_transcript",  name: "Transcript Request",          desc: "Student ID, delivery method, recipient, payment.",                      category: "Education", industry: "Education", version: "1.0.0", source: "builtin", color: "#a855f7", icon: "📜", tags: ["transcript","records","request"] },

        // ─── Restaurants & Hospitality (6) ───
        { id: "tpl_rh_reservation",  name: "Table Reservation",           desc: "Date, time, party size, dietary restrictions, special occasion.",      category: "Restaurants", industry: "Restaurants & Hospitality", version: "1.0.0", source: "builtin", color: "#ea580c", icon: "🍽", tags: ["reservation","dining","table"] },
        { id: "tpl_rh_catering",     name: "Catering Inquiry",            desc: "Event date, guest count, menu preferences, budget.",                    category: "Restaurants", industry: "Restaurants & Hospitality", version: "1.0.0", source: "builtin", color: "#ea580c", icon: "🍱", tags: ["catering","event","food"] },
        { id: "tpl_rh_feedback",     name: "Restaurant Feedback",         desc: "Food, service, ambiance ratings + open feedback.",                      category: "Restaurants", industry: "Restaurants & Hospitality", version: "1.0.0", source: "builtin", color: "#ea580c", icon: "⭐", tags: ["feedback","review","experience"] },
        { id: "tpl_rh_giftcard",     name: "Gift Card Purchase",          desc: "Amount, recipient details, personal message, delivery method.",         category: "Restaurants", industry: "Restaurants & Hospitality", version: "1.0.0", source: "builtin", color: "#ea580c", icon: "🎁", tags: ["gift","voucher","present"] },
        { id: "tpl_rh_private",      name: "Private Event Booking",       desc: "Private room reservation with menu + AV requirements.",                  category: "Restaurants", industry: "Restaurants & Hospitality", version: "1.0.0", source: "builtin", color: "#ea580c", icon: "🥂", tags: ["private","event","function"] },
        { id: "tpl_rh_hotel",        name: "Hotel Booking Inquiry",       desc: "Check-in/out, room type, special requests, loyalty number.",            category: "Restaurants", industry: "Restaurants & Hospitality", version: "1.0.0", source: "builtin", color: "#ea580c", icon: "🏨", tags: ["hotel","booking","stay"] },

        // ─── Fitness & Wellness (5) ───
        { id: "tpl_fit_gym",         name: "Gym Membership Application",  desc: "Plan selection, health questionnaire, payment, terms.",                category: "Fitness", industry: "Fitness & Wellness", version: "1.0.0", source: "builtin", color: "#dc2626", icon: "💪", tags: ["gym","membership","fitness"] },
        { id: "tpl_fit_pt",          name: "Personal Training Inquiry",   desc: "Goals, fitness level, schedule preference, injury history.",            category: "Fitness", industry: "Fitness & Wellness", version: "1.0.0", source: "builtin", color: "#dc2626", icon: "🏋", tags: ["personal-training","coach","fitness"] },
        { id: "tpl_fit_assess",      name: "Fitness Assessment Booking",  desc: "Body comp + capacity test booking with prep checklist.",                category: "Fitness", industry: "Fitness & Wellness", version: "1.0.0", source: "builtin", color: "#dc2626", icon: "📈", tags: ["assessment","testing","fitness"] },
        { id: "tpl_fit_yoga",        name: "Yoga Class Signup",           desc: "Class selection, level, mat rental, intro pack pricing.",               category: "Fitness", industry: "Fitness & Wellness", version: "1.0.0", source: "builtin", color: "#dc2626", icon: "🧘", tags: ["yoga","class","wellness"] },
        { id: "tpl_fit_wellness",    name: "Wellness Consultation",       desc: "Stress + sleep + nutrition baseline + goals.",                          category: "Fitness", industry: "Fitness & Wellness", version: "1.0.0", source: "builtin", color: "#dc2626", icon: "🌿", tags: ["wellness","holistic","consultation"] },

        // ─── Non-profit (4) ───
        { id: "tpl_np_donate",       name: "Donation Form",               desc: "Preset amounts, dedication option, recurring choice, receipt.",         category: "Non-profit", industry: "Non-profit", version: "1.0.0", source: "builtin", color: "#16a34a", icon: "💝", tags: ["donation","charity","nonprofit"] },
        { id: "tpl_np_volunteer",    name: "Volunteer Signup",            desc: "Skills, availability, role preferences, background check consent.",    category: "Non-profit", industry: "Non-profit", version: "1.0.0", source: "builtin", color: "#16a34a", icon: "🙌", tags: ["volunteer","help","community"] },
        { id: "tpl_np_partner",      name: "Partnership Request",         desc: "Org details, partnership type, expected outcomes, budget.",             category: "Non-profit", industry: "Non-profit", version: "1.0.0", source: "builtin", color: "#16a34a", icon: "🤝", tags: ["partner","collaboration","grant"] },
        { id: "tpl_np_sponsor",      name: "Sponsorship Inquiry",         desc: "Sponsor tier selection, brand assets, event matching.",                 category: "Non-profit", industry: "Non-profit", version: "1.0.0", source: "builtin", color: "#16a34a", icon: "🌟", tags: ["sponsor","corporate","funding"] },

        // ─── Legal (5) ───
        { id: "tpl_lg_intake",       name: "Legal Case Intake",           desc: "Case type, opposing party, timeline, prior counsel.",                   category: "Legal", industry: "Legal", version: "1.0.0", source: "builtin", color: "#1e293b", icon: "⚖", tags: ["legal","intake","case"] },
        { id: "tpl_lg_consult",      name: "Free Consultation Request",   desc: "Brief description + preferred contact method + urgency.",               category: "Legal", industry: "Legal", version: "1.0.0", source: "builtin", color: "#1e293b", icon: "💼", tags: ["consultation","attorney","advice"] },
        { id: "tpl_lg_review",       name: "Document Review Request",     desc: "Document upload + review scope + deadline.",                            category: "Legal", industry: "Legal", version: "1.0.0", source: "builtin", color: "#1e293b", icon: "📄", tags: ["document","review","contract"] },
        { id: "tpl_lg_retainer",     name: "Retainer Agreement",          desc: "Scope of services, fee structure, signature, payment.",                 category: "Legal", industry: "Legal", version: "1.0.0", source: "builtin", color: "#1e293b", icon: "✍", tags: ["retainer","agreement","fees"] },
        { id: "tpl_lg_will",         name: "Will Planning Questionnaire", desc: "Assets, beneficiaries, executor, guardian preferences.",                category: "Legal", industry: "Legal", version: "1.0.0", source: "builtin", color: "#1e293b", icon: "📜", tags: ["will","estate","planning"] },

        // ─── Beauty & Wellness (5) ───
        { id: "tpl_bw_appt",         name: "Salon Appointment Booking",   desc: "Service, stylist, date/time + arrival prep.",                          category: "Beauty", industry: "Beauty & Wellness", version: "1.0.0", source: "builtin", color: "#ec4899", icon: "💇", tags: ["salon","appointment","beauty"] },
        { id: "tpl_bw_consult",      name: "Skincare Consultation",       desc: "Skin type, current routine, concerns, goals.",                          category: "Beauty", industry: "Beauty & Wellness", version: "1.0.0", source: "builtin", color: "#ec4899", icon: "✨", tags: ["skincare","consultation","beauty"] },
        { id: "tpl_bw_voucher",      name: "Spa Gift Voucher",            desc: "Treatment + amount + recipient + delivery.",                            category: "Beauty", industry: "Beauty & Wellness", version: "1.0.0", source: "builtin", color: "#ec4899", icon: "💆", tags: ["spa","voucher","gift"] },
        { id: "tpl_bw_intake",       name: "Treatment Intake Form",       desc: "Health background, allergies, prior reactions, consent.",               category: "Beauty", industry: "Beauty & Wellness", version: "1.0.0", source: "builtin", color: "#ec4899", icon: "🧖", tags: ["treatment","intake","spa"] },
        { id: "tpl_bw_allergy",      name: "Allergy Disclosure",          desc: "Known allergies + reactions + emergency contact.",                      category: "Beauty", industry: "Beauty & Wellness", version: "1.0.0", source: "builtin", color: "#ec4899", icon: "🌸", tags: ["allergy","disclosure","safety"] },

        // ─── Photography (4) ───
        { id: "tpl_ph_wedding",      name: "Wedding Photography Inquiry", desc: "Date, venue, package, special requests, gallery preferences.",         category: "Photography", industry: "Photography", version: "1.0.0", source: "builtin", color: "#7c3aed", icon: "📸", tags: ["wedding","photography","booking"] },
        { id: "tpl_ph_portrait",     name: "Portrait Session Booking",    desc: "Session type, location, group size, styling preferences.",              category: "Photography", industry: "Photography", version: "1.0.0", source: "builtin", color: "#7c3aed", icon: "🎨", tags: ["portrait","session","photography"] },
        { id: "tpl_ph_commercial",   name: "Commercial Shoot Inquiry",    desc: "Brand, deliverables, usage rights, budget, deadline.",                  category: "Photography", industry: "Photography", version: "1.0.0", source: "builtin", color: "#7c3aed", icon: "🏢", tags: ["commercial","brand","photography"] },
        { id: "tpl_ph_selection",    name: "Photo Selection Form",        desc: "Client picks final photos from a gallery with album choices.",          category: "Photography", industry: "Photography", version: "1.0.0", source: "builtin", color: "#7c3aed", icon: "🖼", tags: ["selection","gallery","photography"] },

        // ─── Construction & Trades (5) ───
        { id: "tpl_ct_quote",        name: "Construction Project Quote",  desc: "Project type, scope, square footage, materials, timeline.",            category: "Construction", industry: "Construction & Trades", version: "1.0.0", source: "builtin", color: "#f97316", icon: "🏗", tags: ["construction","quote","project"] },
        { id: "tpl_ct_estimate",     name: "Free Estimate Request",       desc: "Job type, urgency, photos of the issue, preferred site visit.",        category: "Construction", industry: "Construction & Trades", version: "1.0.0", source: "builtin", color: "#f97316", icon: "📐", tags: ["estimate","quote","repair"] },
        { id: "tpl_ct_permit",       name: "Permit Application",          desc: "Property info, project description, contractor license, fees.",         category: "Construction", industry: "Construction & Trades", version: "1.0.0", source: "builtin", color: "#f97316", icon: "📋", tags: ["permit","application","compliance"] },
        { id: "tpl_ct_subcontract",  name: "Subcontractor Application",   desc: "Trade, license, insurance, references, capacity.",                      category: "Construction", industry: "Construction & Trades", version: "1.0.0", source: "builtin", color: "#f97316", icon: "🔨", tags: ["subcontractor","application","trade"] },
        { id: "tpl_ct_warranty",     name: "Warranty Registration",       desc: "Product details, install date, contractor, photo of receipt.",          category: "Construction", industry: "Construction & Trades", version: "1.0.0", source: "builtin", color: "#f97316", icon: "🛡", tags: ["warranty","registration","product"] },

        /* ─── v2.72.25 — Modern 2026 template pack ───
           Trendy use cases for AI startups, creators, remote teams, and
           modern e-commerce. Gradient-friendly palette + emoji icons that
           read well against dark and light themes. */

        // ─── AI & SaaS (6) ───
        { id: "tpl_ai_waitlist",     name: "AI Product Waitlist",         desc: "Early-access signup with role, use case, and referral source.",           category: "AI & SaaS", industry: "AI & SaaS", version: "1.0.0", source: "builtin", color: "#8b5cf6", icon: "🤖", tags: ["ai","waitlist","early-access","launch"] },
        { id: "tpl_ai_beta",         name: "Beta Tester Application",     desc: "Recruit beta users with device info, feedback style, and NDA consent.",   category: "AI & SaaS", industry: "AI & SaaS", version: "1.0.0", source: "builtin", color: "#8b5cf6", icon: "🧪", tags: ["beta","testing","product"] },
        { id: "tpl_ai_feature_req",  name: "Feature Request",             desc: "Users propose features with problem, solution, and priority vote.",       category: "AI & SaaS", industry: "AI & SaaS", version: "1.0.0", source: "builtin", color: "#8b5cf6", icon: "💡", tags: ["feature","product","roadmap"] },
        { id: "tpl_ai_bug_report",   name: "Bug Report",                  desc: "Reproducer steps, browser, screenshot, severity, expected vs actual.",    category: "AI & SaaS", industry: "AI & SaaS", version: "1.0.0", source: "builtin", color: "#8b5cf6", icon: "🐛", tags: ["bug","issue","qa","product"] },
        { id: "tpl_ai_saas_demo",    name: "SaaS Demo Request",           desc: "Team size, current tools, budget range, preferred demo date.",            category: "AI & SaaS", industry: "AI & SaaS", version: "1.0.0", source: "builtin", color: "#8b5cf6", icon: "🎯", tags: ["demo","sales","saas","b2b"] },
        { id: "tpl_ai_pmf_survey",   name: "Product-Market Fit Survey",   desc: "How disappointed users would be without your product — Sean Ellis style.", category: "AI & SaaS", industry: "AI & SaaS", version: "1.0.0", source: "builtin", color: "#8b5cf6", icon: "📊", tags: ["pmf","survey","product","startup"] },

        // ─── Creator Economy (5) ───
        { id: "tpl_cr_podcast",      name: "Podcast Guest Pitch",         desc: "Guest bio, expertise, past appearances, sample topics, availability.",    category: "Creator", industry: "Creator Economy", version: "1.0.0", source: "builtin", color: "#f43f5e", icon: "🎙", tags: ["podcast","guest","pitch","creator"] },
        { id: "tpl_cr_collab",       name: "Brand Collaboration",         desc: "Follower stats, niche, past partnerships, rate card, deliverables.",      category: "Creator", industry: "Creator Economy", version: "1.0.0", source: "builtin", color: "#f43f5e", icon: "🤝", tags: ["influencer","collab","brand","sponsorship"] },
        { id: "tpl_cr_membership",   name: "Membership / Patreon Signup", desc: "Tier selection, billing, expectations, community rules.",                 category: "Creator", industry: "Creator Economy", version: "1.0.0", source: "builtin", color: "#f43f5e", icon: "⭐", tags: ["membership","patreon","subscription"] },
        { id: "tpl_cr_press_kit",    name: "Press Kit Request",           desc: "Media outlet, coverage angle, deadline, requested assets.",               category: "Creator", industry: "Creator Economy", version: "1.0.0", source: "builtin", color: "#f43f5e", icon: "📰", tags: ["press","media","pr","kit"] },
        { id: "tpl_cr_content_brief",name: "Content Creator Brief",       desc: "Video style, deliverables, hooks, CTA, deadline, usage rights.",          category: "Creator", industry: "Creator Economy", version: "1.0.0", source: "builtin", color: "#f43f5e", icon: "🎬", tags: ["content","ugc","brief","video"] },

        // ─── Modern Agency (5) ───
        { id: "tpl_ag_brief",        name: "Project Brief Intake",        desc: "Client goals, target audience, deliverables, timeline, budget range.",    category: "Agency", industry: "Modern Agency", version: "1.0.0", source: "builtin", color: "#0ea5e9", icon: "📝", tags: ["brief","agency","project","scope"] },
        { id: "tpl_ag_proposal",     name: "Proposal Request",            desc: "Company, problem statement, expected outcomes, decision timeline.",       category: "Agency", industry: "Modern Agency", version: "1.0.0", source: "builtin", color: "#0ea5e9", icon: "📄", tags: ["proposal","rfp","agency","sales"] },
        { id: "tpl_ag_web_design",   name: "Website Design Inquiry",      desc: "Pages needed, design references, CMS, launch date, budget.",              category: "Agency", industry: "Modern Agency", version: "1.0.0", source: "builtin", color: "#0ea5e9", icon: "🎨", tags: ["web","design","agency","site"] },
        { id: "tpl_ag_seo",          name: "SEO Audit Request",           desc: "Domain, target keywords, competitors, current rankings, goals.",          category: "Agency", industry: "Modern Agency", version: "1.0.0", source: "builtin", color: "#0ea5e9", icon: "🔍", tags: ["seo","audit","marketing","agency"] },
        { id: "tpl_ag_retainer",     name: "Monthly Retainer Signup",     desc: "Service tier, scope, KPIs, communication cadence, payment.",              category: "Agency", industry: "Modern Agency", version: "1.0.0", source: "builtin", color: "#0ea5e9", icon: "🔁", tags: ["retainer","subscription","agency"] },

        // ─── Modern E-commerce (5) ───
        { id: "tpl_ec_return",       name: "Return / Refund Request",     desc: "Order ID, reason, photos, preferred resolution, restocking consent.",     category: "E-commerce", industry: "Modern E-commerce", version: "1.0.0", source: "builtin", color: "#14b8a6", icon: "↩", tags: ["return","refund","ecommerce","support"] },
        { id: "tpl_ec_exchange",     name: "Size Exchange",               desc: "Order lookup, current size, requested size, condition confirmation.",     category: "E-commerce", industry: "Modern E-commerce", version: "1.0.0", source: "builtin", color: "#14b8a6", icon: "🔄", tags: ["exchange","size","ecommerce"] },
        { id: "tpl_ec_review",       name: "Product Review Submission",   desc: "Rating, photos, would-recommend, fit/quality/value scores.",              category: "E-commerce", industry: "Modern E-commerce", version: "1.0.0", source: "builtin", color: "#14b8a6", icon: "⭐", tags: ["review","rating","ecommerce","ugc"] },
        { id: "tpl_ec_preorder",     name: "Pre-order Reservation",       desc: "Product variant, quantity, shipping address, deposit consent.",           category: "E-commerce", industry: "Modern E-commerce", version: "1.0.0", source: "builtin", color: "#14b8a6", icon: "📦", tags: ["preorder","launch","ecommerce"] },
        { id: "tpl_ec_wholesale",    name: "Wholesale Application",       desc: "Business type, tax ID, expected volume, distribution channels.",          category: "E-commerce", industry: "Modern E-commerce", version: "1.0.0", source: "builtin", color: "#14b8a6", icon: "🏪", tags: ["wholesale","b2b","ecommerce"] },

        // ─── Remote Work & HR (5) ───
        { id: "tpl_rw_retro",        name: "Team Retrospective",          desc: "Went well / didn't / ideas / action items — sprint retro anonymously.",   category: "Remote Work", industry: "Remote Work & HR", version: "1.0.0", source: "builtin", color: "#059669", icon: "🔄", tags: ["retro","sprint","team","agile"] },
        { id: "tpl_rw_standup",      name: "Async Standup",               desc: "Yesterday, today, blockers — for distributed teams that skip meetings.",  category: "Remote Work", industry: "Remote Work & HR", version: "1.0.0", source: "builtin", color: "#059669", icon: "☕", tags: ["standup","async","remote","scrum"] },
        { id: "tpl_rw_pto",          name: "PTO / Time-off Request",      desc: "Dates, type (vacation/sick/personal), coverage, manager approval.",       category: "Remote Work", industry: "Remote Work & HR", version: "1.0.0", source: "builtin", color: "#059669", icon: "🏖", tags: ["pto","vacation","hr","time-off"] },
        { id: "tpl_rw_referral",     name: "Employee Referral",           desc: "Candidate details, role fit, referrer relationship, resume upload.",      category: "Remote Work", industry: "Remote Work & HR", version: "1.0.0", source: "builtin", color: "#059669", icon: "👥", tags: ["referral","hiring","hr"] },
        { id: "tpl_rw_expense",      name: "Expense Reimbursement",       desc: "Amount, category, receipt upload, project code, approver.",               category: "Remote Work", industry: "Remote Work & HR", version: "1.0.0", source: "builtin", color: "#059669", icon: "🧾", tags: ["expense","reimbursement","finance"] },

        // ─── Community & Events (5) ───
        { id: "tpl_co_discord",      name: "Discord Server Join Request", desc: "Interests, why join, how they found us, code of conduct agreement.",      category: "Community", industry: "Community & Events", version: "1.0.0", source: "builtin", color: "#6366f1", icon: "💬", tags: ["discord","community","join"] },
        { id: "tpl_co_livestream",   name: "Livestream Signup",           desc: "Timezone, calendar reminder, question submission, notification prefs.",   category: "Community", industry: "Community & Events", version: "1.0.0", source: "builtin", color: "#6366f1", icon: "🔴", tags: ["livestream","webinar","event"] },
        { id: "tpl_co_meetup",       name: "Virtual Meetup RSVP",         desc: "Attendance, topics of interest, intro pitch, networking prefs.",          category: "Community", industry: "Community & Events", version: "1.0.0", source: "builtin", color: "#6366f1", icon: "🎪", tags: ["meetup","rsvp","virtual","event"] },
        { id: "tpl_co_speaker_cfp",  name: "Speaker CFP (Call for Papers)",desc: "Talk title, abstract, bio, past talks, technical requirements.",         category: "Community", industry: "Community & Events", version: "1.0.0", source: "builtin", color: "#6366f1", icon: "🎤", tags: ["cfp","speaker","conference","talk"] },
        { id: "tpl_co_hackathon",    name: "Hackathon Team Signup",       desc: "Team name, roles filled, tech stack, project idea, seeking teammates.",   category: "Community", industry: "Community & Events", version: "1.0.0", source: "builtin", color: "#6366f1", icon: "💻", tags: ["hackathon","team","event"] },

        // ─── Digital Products (4) ───
        { id: "tpl_dp_launch_email", name: "Launch-day Email Capture",    desc: "Single-field email + optional interest tag, GDPR consent, referrer.",     category: "Digital Products", industry: "Digital Products", version: "1.0.0", source: "builtin", color: "#ec4899", icon: "🚀", tags: ["launch","email","waitlist"] },
        { id: "tpl_dp_freebie",      name: "Free Download / Lead Magnet", desc: "Email-gated PDF/ebook delivery with tag-based segmentation.",             category: "Digital Products", industry: "Digital Products", version: "1.0.0", source: "builtin", color: "#ec4899", icon: "🎁", tags: ["lead-magnet","freebie","download","email"] },
        { id: "tpl_dp_course_wait",  name: "Course Waitlist",             desc: "Interest level, current skill, cohort preference, price sensitivity.",    category: "Digital Products", industry: "Digital Products", version: "1.0.0", source: "builtin", color: "#ec4899", icon: "📚", tags: ["course","waitlist","cohort"] },
        { id: "tpl_dp_affiliate",    name: "Affiliate Program Application",desc: "Audience, channels, promo strategy, ID for payouts, tax info.",         category: "Digital Products", industry: "Digital Products", version: "1.0.0", source: "builtin", color: "#ec4899", icon: "💸", tags: ["affiliate","partner","payout"] },

        // ─── Startups & Fundraising (4) ───
        { id: "tpl_st_pitch",        name: "Startup Pitch Submission",    desc: "One-liner, market, traction, team, ask amount, deck upload.",             category: "Startups", industry: "Startups & Fundraising", version: "1.0.0", source: "builtin", color: "#0f172a", icon: "🚀", tags: ["pitch","startup","vc","fundraising"] },
        { id: "tpl_st_investor",     name: "Investor Update Signup",      desc: "Quarterly investor update opt-in with segmentation by check size.",       category: "Startups", industry: "Startups & Fundraising", version: "1.0.0", source: "builtin", color: "#0f172a", icon: "📈", tags: ["investor","update","startup"] },
        { id: "tpl_st_advisor",      name: "Advisory Board Nomination",   desc: "Nominee bio, expertise, LinkedIn, equity expectations.",                  category: "Startups", industry: "Startups & Fundraising", version: "1.0.0", source: "builtin", color: "#0f172a", icon: "🧭", tags: ["advisor","board","startup"] },
        { id: "tpl_st_userinterview",name: "User Interview Booking",      desc: "30-min chat scheduler with role, incentive, calendar link, NDA.",         category: "Startups", industry: "Startups & Fundraising", version: "1.0.0", source: "builtin", color: "#0f172a", icon: "🎤", tags: ["user-research","interview","product"] }
    ];

    function defaultState() {
        return {
            forms: seedForms,
            submissions: seedSubmissions,
            settings: seedSettings,
            integrations: seedIntegrations,
            users: seedUsers,
            templates: seedTemplates,
            user: { name: "Alex Morgan", email: "alex@example.com", role: "Admin", avatar: "AM" },
            ui: { theme: "light", sidebarCollapsed: false, onboarded: false }
        };
    }

    function migrate(state) {
        if (!Array.isArray(state.integrations)) {
            state.integrations = seedIntegrations.map(s => ({ ...s }));
            return true;
        }
        let changed = false;
        const byId = {};
        state.integrations.forEach(i => { byId[i.id] = i; });
        seedIntegrations.forEach(seed => {
            const existing = byId[seed.id];
            if (!existing) {
                state.integrations.push({ ...seed });
                changed = true;
            } else if (!existing.category) {
                existing.category = seed.category;
                changed = true;
            }
        });
        // Templates migration: append any new seedTemplates entries that
        // aren't already in the user's cached list. Lets users get new
        // templates (Business pack, etc.) after a plugin upgrade without
        // wiping their existing template state.
        if (!Array.isArray(state.templates)) {
            state.templates = seedTemplates.map(t => ({ ...t }));
            changed = true;
        } else {
            const tplIds = new Set(state.templates.map(t => t.id));
            seedTemplates.forEach(seed => {
                if (!tplIds.has(seed.id)) {
                    state.templates.push({ ...seed });
                    changed = true;
                }
            });
        }
        return changed;
    }

    function load() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (!raw) {
                const s = defaultState();
                localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
                return s;
            }
            const state = JSON.parse(raw);
            if (migrate(state)) {
                localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
            }
            return state;
        } catch (e) {
            console.warn("State load failed, resetting", e);
            const s = defaultState();
            localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
            return s;
        }
    }

    function save(state) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    }

    function reset() {
        localStorage.removeItem(STORAGE_KEY);
        return load();
    }

    // expose
    global.FCData = {
        STORAGE_KEY,
        load,
        save,
        reset,
        uid,
        daysAgo
    };
})(window);
