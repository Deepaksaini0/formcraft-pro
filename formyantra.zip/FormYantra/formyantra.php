<?php
/**
 * Plugin Name:       FormYantra
 * Plugin URI:        https://formyantra.local/
 * Description:       Smart forms, better results. Modern multi-step form builder with drag-and-drop, conditional logic, reCAPTCHA, analytics, submission management and integrations.
 * Version:           2.72.79
 * Requires at least: 5.5
 * Requires PHP:      7.4
 * Author:            FormYantra Team
 * Author URI:        https://formyantra.local/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       formcraft-pro
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // No direct access
}

/* ---------------------------------------------------------------
 * Constants
 * ------------------------------------------------------------ */
define( 'FCP_VERSION',     '2.72.79' );
define( 'FCP_FILE',        __FILE__ );
define( 'FCP_PATH',        plugin_dir_path( __FILE__ ) );
define( 'FCP_URL',         plugin_dir_url( __FILE__ ) );
define( 'FCP_BASENAME',    plugin_basename( __FILE__ ) );
define( 'FCP_TABLE_FORMS',    'fcp_forms' );
define( 'FCP_TABLE_SUBS',     'fcp_submissions' );
define( 'FCP_TABLE_MAIL_LOG', 'fcp_mail_log' );
define( 'FCP_TABLE_COUPONS',  'fcp_coupons' );
define( 'FCP_TABLE_WEBHOOKS', 'fcp_webhooks' );
define( 'FCP_TABLE_REVISIONS', 'fcp_form_revisions' );
define( 'FCP_TABLE_STEP_EVENTS', 'fcp_step_events' );
define( 'FCP_TABLE_USERS',       'fcp_users' );

/* ---------------------------------------------------------------
 * Autoload includes
 * ------------------------------------------------------------ */
require_once FCP_PATH . 'includes/class-fcp-db.php';
require_once FCP_PATH . 'includes/class-fcp-admin.php';
require_once FCP_PATH . 'includes/class-fcp-rest.php';
require_once FCP_PATH . 'includes/class-fcp-shortcode.php';
require_once FCP_PATH . 'includes/class-fcp-mailer.php';
require_once FCP_PATH . 'includes/class-fcp-payment.php';
require_once FCP_PATH . 'includes/class-fcp-integrations.php';
require_once FCP_PATH . 'includes/class-fcp-ai.php';
require_once FCP_PATH . 'includes/class-fcp-i18n.php';
require_once FCP_PATH . 'includes/class-fcp-tokens.php';
require_once FCP_PATH . 'includes/class-fcp-graphql.php';
require_once FCP_PATH . 'includes/class-fcp-2fa.php';
require_once FCP_PATH . 'includes/class-fcp-audit.php';
require_once FCP_PATH . 'includes/class-fcp-crypto.php';
require_once FCP_PATH . 'includes/class-fcp-saas.php';
require_once FCP_PATH . 'includes/class-fcp-help.php';
require_once FCP_PATH . 'includes/class-fcp-ghl.php';
// v2.64.2 — Hardening backstop. Some hosts' WP class loaders re-cache
// the bootstrap chain in a way that drops the SaaS REST hook, leaving
// /saas/* endpoints unregistered. Hooking rest_api_init directly at
// file-load time is bulletproof — it runs even if the plugins_loaded
// callback below somehow doesn't reach FCP_SaaS::bootstrap().
if ( class_exists( 'FCP_SaaS' ) ) {
    add_action( 'rest_api_init', [ 'FCP_SaaS', 'register_rest' ], 5 );
}
if ( class_exists( 'FCP_Help' ) ) {
    add_action( 'rest_api_init', [ 'FCP_Help', 'register_rest' ], 5 );
}
// v2.66.2 — Same hardening for the rest of the classes that register
// REST routes via bootstrap. Audit caught that 2FA / Tokens / GraphQL
// could hit the same "bootstrap chain broke, routes never registered"
// failure mode on hosts that triggered it for SaaS. The named static
// `register_routes` methods are already in place; we just need to wire
// them via add_action at file-load time too.
if ( class_exists( 'FCP_Tokens' ) && method_exists( 'FCP_Tokens', 'register_routes' ) ) {
    add_action( 'rest_api_init', [ 'FCP_Tokens', 'register_routes' ], 5 );
}
if ( class_exists( 'FCP_GraphQL' ) && method_exists( 'FCP_GraphQL', 'register_route' ) ) {
    add_action( 'rest_api_init', [ 'FCP_GraphQL', 'register_route' ], 5 );
}
if ( class_exists( 'FCP_2FA' ) && method_exists( 'FCP_2FA', 'register_routes' ) ) {
    add_action( 'rest_api_init', [ 'FCP_2FA', 'register_routes' ], 5 );
}
require_once FCP_PATH . 'includes/class-fcp-woocommerce.php';
require_once FCP_PATH . 'includes/class-fcp-otp.php';
require_once FCP_PATH . 'includes/class-fcp-users.php';
require_once FCP_PATH . 'includes/class-fcp-privacy.php';
require_once FCP_PATH . 'includes/class-fcp-migrator.php';
require_once FCP_PATH . 'includes/class-fcp-ad-platforms.php';
require_once FCP_PATH . 'includes/class-fcp-retry-queue.php';
require_once FCP_PATH . 'includes/class-fcp-digest.php';
require_once FCP_PATH . 'includes/class-fcp-backup.php';
require_once FCP_PATH . 'includes/class-fcp-india.php';
require_once FCP_PATH . 'includes/class-fcp-payments-pro.php';
require_once FCP_PATH . 'includes/class-fcp-analytics-pro.php';
require_once FCP_PATH . 'includes/class-fcp-builder-pro.php';
require_once FCP_PATH . 'includes/class-fcp-security-pro.php';
require_once FCP_PATH . 'includes/class-fcp-passkey.php';

// WP-CLI commands — only loaded under the CLI runtime so they cost nothing
// on web requests. Provides `wp fcp ...` and `wp formcraft ...` aliases.
if ( defined( 'WP_CLI' ) && WP_CLI ) {
    require_once FCP_PATH . 'includes/class-fcp-cli.php';
}

/* ---------------------------------------------------------------
 * Activation / Deactivation
 * ------------------------------------------------------------ */
register_activation_hook( __FILE__, function () {
    FCP_DB::activate();
    if ( class_exists( 'FCP_Tokens' ) ) FCP_Tokens::install_table();
    if ( class_exists( 'FCP_2FA' ) )    FCP_2FA::install_table();
    if ( class_exists( 'FCP_Audit' ) )  FCP_Audit::install_table();
    if ( class_exists( 'FCP_Migrator' ) ) FCP_Migrator::ensure_log_table();
    if ( class_exists( 'FCP_Retry_Queue' ) ) {
        FCP_Retry_Queue::ensure_table();
        FCP_Retry_Queue::schedule_cron();
    }
    if ( class_exists( 'FCP_Passkey' ) ) FCP_Passkey::install_table();
    if ( class_exists( 'FCP_Digest' ) ) {
        FCP_Digest::schedule_all();
    }
    if ( class_exists( 'FCP_Backup' ) ) {
        FCP_Backup::bootstrap();
    }
    if ( class_exists( 'FCP_Shortcode' ) ) {
        // The User Dashboard page is always created — its shortcode
        // gracefully handles the "no member" case so there's no downside.
        FCP_Shortcode::ensure_user_dashboard_page();
        // Login + Registration auto-creation is now controlled by the
        // admin toggle on the Forms page (fcp_membership_enabled). On
        // first activation we leave it OFF — admin opts in explicitly.
        if ( get_option( 'fcp_membership_enabled' ) ) {
            FCP_Shortcode::ensure_auth_pages();
        }
        // Register the pretty URL rewrite then flush so the new
        // /formcraft-pro/{slug}/ route resolves without an admin
        // having to manually visit Permalinks → Save.
        ( new FCP_Shortcode() )->register_pretty_url_route();
    }
    flush_rewrite_rules();
} );
register_deactivation_hook( __FILE__, function () {
    // Keep data; only flush rewrite rules + unschedule our cron events.
    if ( class_exists( 'FCP_Retry_Queue' ) ) FCP_Retry_Queue::unschedule_cron();
    if ( class_exists( 'FCP_Digest' ) )      FCP_Digest::unschedule_all();
    if ( class_exists( 'FCP_Backup' ) )      FCP_Backup::unschedule();
    flush_rewrite_rules();
} );

// Custom cron interval + tick handler for the integration retry queue.
add_filter( 'cron_schedules', [ 'FCP_Retry_Queue', 'filter_cron_schedules' ] );
add_action( FCP_Retry_Queue::HOOK_TICK, [ 'FCP_Retry_Queue', 'tick' ] );

// v2.54 — Scheduled digest cron handlers
add_action( FCP_Digest::HOOK_DAILY,   [ 'FCP_Digest', 'tick_daily'   ] );
add_action( FCP_Digest::HOOK_WEEKLY,  [ 'FCP_Digest', 'tick_weekly'  ] );
add_action( FCP_Digest::HOOK_MONTHLY, [ 'FCP_Digest', 'tick_monthly' ] );

/* ---------------------------------------------------------------
 * Bootstrap
 * ------------------------------------------------------------ */
add_action( 'plugins_loaded', function () {
    load_plugin_textdomain( 'formcraft-pro', false, dirname( FCP_BASENAME ) . '/languages' );

    // Auto-migrate the database schema whenever the plugin version
    // changes. dbDelta safely adds missing columns to existing tables,
    // so upgrades don't require a deactivate/reactivate cycle.
    if ( get_option( 'fcp_db_version' ) !== FCP_VERSION ) {
        FCP_DB::activate();
        if ( class_exists( 'FCP_Migrator' ) ) FCP_Migrator::ensure_log_table();
        update_option( 'fcp_db_version', FCP_VERSION );
        // Always re-ensure the User Dashboard page on upgrade. Login +
        // Registration are only re-created if the admin previously
        // enabled the membership toggle.
        if ( class_exists( 'FCP_Shortcode' ) ) {
            FCP_Shortcode::ensure_user_dashboard_page();
            if ( get_option( 'fcp_membership_enabled' ) ) {
                FCP_Shortcode::ensure_auth_pages();
            }
        }
        // One-time slug migration: every existing form with the legacy
        // auto-generated slug (form_AbCdEf) gets re-keyed to a title-based
        // slug so old /formcraft-pro/form_xxx/ links become readable.
        fcp_migrate_legacy_slugs();
        // One-time cleanup of useless abandoned rows captured by earlier
        // versions before the "require name + email" gate was added.
        fcp_purge_useless_abandoned();
        // Schedule a rewrite-rule flush for the NEXT request. Flushing
        // here is too early — the pretty-URL rule is added on the `init`
        // hook (which fires after plugins_loaded), so flushing now would
        // wipe the rules table without the new rule being repopulated.
        update_option( 'fcp_needs_rewrite_flush', 1 );
    }

    // Deferred rewrite flush: runs late on `init` (after the rule itself
    // has been registered) and self-clears the flag. This is the standard
    // WP pattern for "flush rewrite rules from a plugin upgrade."
    add_action( 'init', function () {
        if ( get_option( 'fcp_needs_rewrite_flush' ) ) {
            flush_rewrite_rules( false );
            delete_option( 'fcp_needs_rewrite_flush' );
        }
    }, 99 );

    if ( is_admin() ) {
        new FCP_Admin();
    }
    new FCP_REST();
    new FCP_Shortcode();
    new FCP_Mailer();   // hooks phpmailer_init to route mail through saved SMTP creds
    new FCP_Privacy();  // GDPR / CCPA — wires into WP Tools → Export/Erase Personal Data
    // v2.60 — Personal Access Tokens (Bearer auth + scopes) + GraphQL
    FCP_Tokens::bootstrap();
    FCP_GraphQL::bootstrap();
    // v2.61 — 2FA + audit log routes
    FCP_2FA::bootstrap();
    // v2.64 — Monetization / SaaS layer (white-label, license, usage, multisite)
    FCP_SaaS::bootstrap();
    // v2.68 — Backup & Restore (daily auto-snapshot to wp-content/uploads)
    if ( class_exists( 'FCP_Backup' ) ) FCP_Backup::bootstrap();
    // v2.70 — India Integrations Suite (IFSC, GST invoice, WhatsApp, SMS, VAHAN)
    if ( class_exists( 'FCP_India' ) ) FCP_India::bootstrap();
    // v2.70.15 — Passkey (FIDO2) enrolment routes
    if ( class_exists( 'FCP_Passkey' ) ) FCP_Passkey::bootstrap();
} );

/* ---------------------------------------------------------------
 * Cron: meeting reminder
 *
 * Schedule-field bookings register a one-shot wp_cron event 30 min
 * before the slot via wp_schedule_single_event('fcp_meeting_reminder',
 * [ $sub_id, $field_label ]). When the event fires, FCP_REST sends
 * the reminder email + clears the entry.
 * ------------------------------------------------------------ */
/**
 * One-time migration: walk every form and replace any legacy auto-generated
 * slug (matches `form_AbCdEf` / `form-AbCdEf` — six random alphanumeric
 * chars after the prefix) with a unique title-based slug. Idempotent; safe
 * to call on every upgrade.
 */
/**
 * One-time cleanup: delete abandoned submissions that lack EITHER a
 * captured name OR a captured email. They're not useful for recovery
 * (no email = no way to nudge the visitor) and only clutter the admin UI.
 * Idempotent — safe to call on every upgrade.
 */
function fcp_purge_useless_abandoned() {
    global $wpdb;
    if ( ! class_exists( 'FCP_DB' ) ) return;
    $table  = FCP_DB::subs_table();
    $exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
    if ( ! $exists ) return;
    $wpdb->query(
        "DELETE FROM $table
          WHERE is_abandoned = 1
            AND (
                submitter_email IS NULL OR submitter_email = ''
                OR submitter_name  IS NULL OR submitter_name  = ''
            )"
    );
}

function fcp_migrate_legacy_slugs() {
    global $wpdb;
    if ( ! class_exists( 'FCP_DB' ) ) return;
    $table = FCP_DB::forms_table();
    $exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
    if ( ! $exists ) return;
    $rows = $wpdb->get_results( "SELECT id, title, slug FROM $table", ARRAY_A );
    foreach ( (array) $rows as $r ) {
        $slug          = $r['slug'] ?? '';
        $title         = $r['title'] ?? '';
        $is_legacy     = preg_match( '/^form[_-][A-Za-z0-9]{6}$/', $slug );
        // v2.69.7 — Also catch placeholder slugs from forms that were
        // saved once with the default "Untitled Form" title and then
        // renamed, but whose slug never got regenerated.
        $is_placeholder = preg_match( '/^untitled(-form)?(-\d+)?$/', $slug );
        $title_is_real  = $title && strcasecmp( $title, 'Untitled' ) !== 0
                                 && strcasecmp( $title, 'Untitled Form' ) !== 0;
        if ( empty( $slug ) || $is_legacy || ( $is_placeholder && $title_is_real ) ) {
            $new = FCP_DB::build_unique_slug( $title ?: 'form', (int) $r['id'] );
            if ( $new && $new !== $slug ) {
                $wpdb->update( $table, [ 'slug' => $new ], [ 'id' => (int) $r['id'] ] );
            }
        }
    }
}

add_action( 'fcp_meeting_reminder', function ( $sub_id, $field_label ) {
    if ( ! class_exists( 'FCP_REST' ) ) return;
    FCP_REST::send_meeting_reminder( (int) $sub_id, (string) $field_label );
}, 10, 2 );

/* ---------------------------------------------------------------
 * Cron: Form Abandonment recovery
 *
 * Runs hourly. For every abandoned row where the recovery delay has
 * elapsed and an email was captured, send the recovery email. Also
 * hard-deletes abandoned rows older than 30 days so the table doesn't
 * grow unbounded.
 * ------------------------------------------------------------ */
add_action( 'init', function () {
    if ( ! wp_next_scheduled( 'fcp_abandon_recovery' ) ) {
        wp_schedule_event( time() + 600, 'hourly', 'fcp_abandon_recovery' );
    }
} );
register_deactivation_hook( __FILE__, function () {
    $ts = wp_next_scheduled( 'fcp_abandon_recovery' );
    if ( $ts ) wp_unschedule_event( $ts, 'fcp_abandon_recovery' );
} );

add_action( 'fcp_abandon_recovery', function () {
    if ( ! class_exists( 'FCP_DB' ) || ! class_exists( 'FCP_REST' ) ) return;
    global $wpdb;
    $table = FCP_DB::subs_table();

    // Iterate per-form so each form's own recovery_delay + recovery_enabled
    // are respected. Skip forms where the feature is off.
    $form_ids = $wpdb->get_col( "SELECT DISTINCT form_id FROM $table WHERE is_abandoned = 1 AND submitter_email <> '' AND submitter_email IS NOT NULL AND recovery_sent_at IS NULL" );
    foreach ( (array) $form_ids as $fid ) {
        $form = FCP_DB::get_form( (int) $fid );
        if ( ! $form ) continue;
        $cfg = $form['settings']['abandonment'] ?? [];
        if ( empty( $cfg['enabled'] ) || empty( $cfg['recovery_enabled'] ) ) continue;
        $delay = max( 5, (int) ( $cfg['recovery_delay'] ?? 60 ) );

        $cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $delay * 60 ) - ( (int) get_option( 'gmt_offset', 0 ) * 3600 ) );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id FROM $table
              WHERE is_abandoned = 1
                AND form_id = %d
                AND submitter_email <> ''
                AND submitter_email IS NOT NULL
                AND recovery_sent_at IS NULL
                AND last_touched_at <= %s
              ORDER BY last_touched_at ASC
              LIMIT 25",
            (int) $fid, $cutoff
        ), ARRAY_A );
        foreach ( (array) $rows as $r ) {
            FCP_REST::dispatch_recovery_email( (int) $r['id'] );
        }
    }

    // Purge stale abandoned rows older than 30 days so the table stays lean.
    FCP_DB::purge_stale_abandoned( 30 );
} );

/* ---------------------------------------------------------------
 * Settings / Plugins page action link
 * ------------------------------------------------------------ */
add_filter( 'plugin_action_links_' . FCP_BASENAME, function ( $links ) {
    $url      = admin_url( 'admin.php?page=formcraft-pro' );
    $docs_url = admin_url( 'admin.php?page=formcraft-pro-docs' );
    array_unshift( $links,
        '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Dashboard', 'formcraft-pro' ) . '</a>',
        '<a href="' . esc_url( $docs_url ) . '">' . esc_html__( 'Docs', 'formcraft-pro' ) . '</a>'
    );
    return $links;
} );
