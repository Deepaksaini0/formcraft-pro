<?php
/**
 * FormYantra - Database installer & accessor.
 *
 * Creates two custom tables on activation and provides helpers used by
 * the REST layer and admin pages. Forms and submissions are stored as
 * structured JSON so the schema stays simple while the field model
 * evolves on the front end.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_DB {

    public static function forms_table() {
        global $wpdb;
        return $wpdb->prefix . FCP_TABLE_FORMS;
    }

    public static function subs_table() {
        global $wpdb;
        return $wpdb->prefix . FCP_TABLE_SUBS;
    }

    public static function mail_log_table() {
        global $wpdb;
        return $wpdb->prefix . FCP_TABLE_MAIL_LOG;
    }

    public static function coupons_table() {
        global $wpdb;
        return $wpdb->prefix . FCP_TABLE_COUPONS;
    }

    public static function webhooks_table() {
        global $wpdb;
        return $wpdb->prefix . FCP_TABLE_WEBHOOKS;
    }

    public static function revisions_table() {
        global $wpdb;
        return $wpdb->prefix . FCP_TABLE_REVISIONS;
    }

    public static function step_events_table() {
        global $wpdb;
        return $wpdb->prefix . FCP_TABLE_STEP_EVENTS;
    }

    public static function users_table() {
        global $wpdb;
        return $wpdb->prefix . FCP_TABLE_USERS;
    }

    public static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();

        $forms = self::forms_table();
        $subs  = self::subs_table();

        $sql_forms = "CREATE TABLE $forms (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            slug VARCHAR(64) NOT NULL,
            title VARCHAR(255) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'draft',
            data LONGTEXT NOT NULL,
            views BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            submissions BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY slug (slug),
            KEY status (status)
        ) $charset;";

        $sql_subs = "CREATE TABLE $subs (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            form_id BIGINT(20) UNSIGNED NOT NULL,
            data LONGTEXT NOT NULL,
            notes TEXT NULL,
            submitter_name VARCHAR(255) NULL,
            submitter_email VARCHAR(255) NULL,
            ip_address VARCHAR(64) NULL,
            user_agent VARCHAR(255) NULL,
            country VARCHAR(64) NULL,
            device VARCHAR(32) NULL,
            browser VARCHAR(64) NULL,
            is_spam TINYINT(1) NOT NULL DEFAULT 0,
            is_read TINYINT(1) NOT NULL DEFAULT 0,
            payment_status VARCHAR(20) NOT NULL DEFAULT 'none',
            payment_provider VARCHAR(32) NULL,
            payment_id VARCHAR(128) NULL,
            payment_order_id VARCHAR(128) NULL,
            payment_amount DECIMAL(12,2) NULL,
            payment_currency VARCHAR(8) NULL,
            paid_at DATETIME NULL,
            coupon_code VARCHAR(64) NULL,
            coupon_discount DECIMAL(12,2) NULL,
            coupon_original_amount DECIMAL(12,2) NULL,
            wc_order_id BIGINT(20) UNSIGNED NULL,
            wc_order_status VARCHAR(32) NULL,
            wc_order_total DECIMAL(12,2) NULL,
            approval_status VARCHAR(20) NOT NULL DEFAULT 'none',
            approval_note TEXT NULL,
            approved_by BIGINT(20) UNSIGNED NULL,
            approved_at DATETIME NULL,
            is_abandoned TINYINT(1) NOT NULL DEFAULT 0,
            session_id VARCHAR(64) NULL,
            last_touched_at DATETIME NULL,
            recovery_sent_at DATETIME NULL,
            journey LONGTEXT NULL,
            ghl_contact_id VARCHAR(64) NULL,
            ghl_last_sync DATETIME NULL,
            ghl_status VARCHAR(32) NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY ghl_contact_id (ghl_contact_id),
            KEY form_id (form_id),
            KEY is_spam (is_spam),
            KEY is_read (is_read),
            KEY payment_status (payment_status),
            KEY payment_order_id (payment_order_id),
            KEY wc_order_id (wc_order_id),
            KEY approval_status (approval_status),
            KEY is_abandoned (is_abandoned),
            KEY session_id (session_id),
            KEY last_touched_at (last_touched_at),
            KEY created_at (created_at)
        ) $charset;";

        $sql_mail_log = "CREATE TABLE " . self::mail_log_table() . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            recipient VARCHAR(255) NOT NULL,
            subject VARCHAR(255) NOT NULL,
            form_id BIGINT(20) UNSIGNED NULL,
            submission_id BIGINT(20) UNSIGNED NULL,
            purpose VARCHAR(32) NOT NULL DEFAULT 'notify',
            status VARCHAR(16) NOT NULL DEFAULT 'delivered',
            error_message TEXT NULL,
            sent_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY sent_at (sent_at),
            KEY status (status),
            KEY form_id (form_id)
        ) $charset;";

        $sql_coupons = "CREATE TABLE " . self::coupons_table() . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            code VARCHAR(64) NOT NULL,
            discount_type VARCHAR(16) NOT NULL DEFAULT 'percent',
            discount_value DECIMAL(12,2) NOT NULL DEFAULT 0,
            currency VARCHAR(8) NULL,
            status VARCHAR(16) NOT NULL DEFAULT 'active',
            applies_to LONGTEXT NULL,
            min_amount DECIMAL(12,2) NULL,
            max_uses INT UNSIGNED NOT NULL DEFAULT 0,
            used_count INT UNSIGNED NOT NULL DEFAULT 0,
            expires_at DATETIME NULL,
            note VARCHAR(255) NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY code (code),
            KEY status (status)
        ) $charset;";

        $sql_webhooks = "CREATE TABLE " . self::webhooks_table() . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            label VARCHAR(120) NULL,
            target VARCHAR(32) NOT NULL DEFAULT 'webhook',
            url TEXT NOT NULL,
            form_id BIGINT(20) UNSIGNED NULL,
            event VARCHAR(32) NOT NULL DEFAULT 'submission',
            status VARCHAR(16) NOT NULL DEFAULT 'active',
            headers TEXT NULL,
            secret VARCHAR(64) NULL,
            last_status INT NULL,
            last_error TEXT NULL,
            last_fired_at DATETIME NULL,
            fire_count INT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY form_id (form_id),
            KEY status (status),
            KEY target (target)
        ) $charset;";

        $sql_users = "CREATE TABLE " . self::users_table() . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            email VARCHAR(190) NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            display_name VARCHAR(190) NULL,
            phone VARCHAR(40) NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            registered_form_id BIGINT(20) UNSIGNED NULL,
            meta LONGTEXT NULL,
            login_count INT UNSIGNED NOT NULL DEFAULT 0,
            last_login_at DATETIME NULL,
            last_login_ip VARCHAR(64) NULL,
            reset_code VARCHAR(64) NULL,
            reset_expires_at DATETIME NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY email (email),
            KEY status (status),
            KEY registered_form_id (registered_form_id)
        ) $charset;";

        $sql_step_events = "CREATE TABLE " . self::step_events_table() . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            form_id BIGINT(20) UNSIGNED NOT NULL,
            session_id VARCHAR(64) NOT NULL,
            step_index TINYINT UNSIGNED NOT NULL,
            event_type VARCHAR(16) NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY form_id (form_id),
            KEY session_id (session_id),
            KEY event_type (event_type),
            KEY created_at (created_at)
        ) $charset;";

        $sql_revisions = "CREATE TABLE " . self::revisions_table() . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            form_id BIGINT(20) UNSIGNED NOT NULL,
            snapshot LONGTEXT NOT NULL,
            note VARCHAR(255) NULL,
            created_by BIGINT(20) UNSIGNED NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY form_id (form_id),
            KEY created_at (created_at)
        ) $charset;";

        dbDelta( $sql_forms );
        dbDelta( $sql_subs );
        dbDelta( $sql_mail_log );
        dbDelta( $sql_coupons );
        dbDelta( $sql_webhooks );
        dbDelta( $sql_revisions );
        dbDelta( $sql_step_events );
        dbDelta( $sql_users );

        // Default settings only — no demo data is ever inserted when
        // installed as a WordPress plugin. Users start with a clean slate.
        if ( ! get_option( 'fcp_settings' ) ) {
            update_option( 'fcp_settings', self::default_settings() );
        }
    }

    public static function default_settings() {
        // Auto-detect site-level defaults from WordPress so the General
        // Settings tab is pre-filled without admin intervention.
        $wp_tz  = function_exists( 'wp_timezone_string' ) ? wp_timezone_string() : get_option( 'timezone_string', 'UTC' );
        if ( ! $wp_tz ) $wp_tz = 'UTC';
        // Currency: WooCommerce if active, else infer from locale, else USD.
        $wp_currency = 'USD';
        if ( function_exists( 'get_woocommerce_currency' ) ) {
            $wp_currency = get_woocommerce_currency();
        } else {
            $locale_map = [ 'en_IN' => 'INR', 'hi_IN' => 'INR', 'en_GB' => 'GBP', 'de_DE' => 'EUR', 'fr_FR' => 'EUR', 'es_ES' => 'EUR', 'ja' => 'JPY', 'ja_JP' => 'JPY', 'en_AU' => 'AUD', 'en_CA' => 'CAD', 'pt_BR' => 'BRL', 'zh_CN' => 'CNY' ];
            $loc = get_locale();
            if ( isset( $locale_map[ $loc ] ) ) $wp_currency = $locale_map[ $loc ];
        }
        // Language: WP locale → first 2 chars (ISO 639-1) as a sensible default.
        $wp_lang_full = get_locale() ?: 'en_US';
        $wp_lang = substr( $wp_lang_full, 0, 2 );

        return [
            'general' => [
                'site_name'    => get_bloginfo( 'name' ),
                'admin_email'  => get_option( 'admin_email' ),
                'date_format'  => get_option( 'date_format', 'M j, Y' ),
                'timezone'     => $wp_tz,
                'currency'     => $wp_currency,
                'language'     => $wp_lang,
            ],
            'recaptcha' => [
                'enabled'         => false,
                'provider'        => 'recaptcha', // recaptcha | hcaptcha | turnstile
                'version'         => 'v3',
                'site_key'        => '',
                'secret_key'      => '',
                'auto_inject'     => true,
                'score_threshold' => 0.5,
                'hcaptcha'        => [ 'site_key' => '', 'secret_key' => '' ],
                'turnstile'       => [ 'site_key' => '', 'secret_key' => '' ],
            ],
            'maps' => [
                'google_api_key'  => '',
            ],
            'email' => [
                'use_wp_mail'           => true,
                'smtp_host'             => '',
                'smtp_port'             => 587,
                'smtp_user'             => '',
                'smtp_pass'             => '',
                'encryption'            => 'tls',
                'from_name'             => get_bloginfo( 'name' ),
                'from_email'            => get_option( 'admin_email' ),
                'admin_recipients'      => get_option( 'admin_email' ),
                'send_admin'            => true,
                'send_user'             => true,
                'confirmation_subject'  => __( 'Thanks for contacting us!', 'formcraft-pro' ),
                'confirmation_body'     => '<h2>Hi {{name}},</h2><p>We received your submission and will reply soon.</p>',
            ],
            'styling' => [
                'primary_color' => '#6366f1',
                'accent_color'  => '#06b6d4',
                'button_radius' => 10,
                'font'          => 'Inter',
                'button_style'  => 'filled',
            ],
            'security' => [
                'csrf'         => true,
                'honeypot'     => true,
                'rate_limit'   => 30,
                'max_upload'   => 10,
                'allowed_ext'  => 'pdf,doc,docx,jpg,png',
                'gdpr'         => true,
                'ip_blocklist' => '',
            ],
            // v2.54 — Scheduled email digest. When enabled, a WP-cron job
            // fires at the configured cadence + sends a summary of
            // submissions, top forms, and top sources to the recipient.
            'scheduled_reports' => [
                'enabled'   => false,
                'frequency' => 'weekly',                  // daily | weekly | monthly
                'recipient' => get_option( 'admin_email' ),
                'last_sent' => '',
            ],
            // Role permissions matrix — editable from Users & Permissions.
            // Admin always has every permission regardless of these flags
            // (enforced both in the UI and in any future server-side check).
            'role_permissions' => [
                'admin'   => [
                    'create_forms' => true, 'delete_forms' => true,  'view_submissions' => true, 'delete_submissions' => true,
                    'export_data'  => true, 'manage_users' => true,  'configure_integrations' => true, 'edit_settings' => true, 'access_billing' => true,
                ],
                'manager' => [
                    'create_forms' => true, 'delete_forms' => true,  'view_submissions' => true, 'delete_submissions' => true,
                    'export_data'  => true, 'manage_users' => false, 'configure_integrations' => false, 'edit_settings' => false, 'access_billing' => false,
                ],
                'editor'  => [
                    'create_forms' => true, 'delete_forms' => false, 'view_submissions' => true, 'delete_submissions' => false,
                    'export_data'  => false,'manage_users' => false, 'configure_integrations' => false, 'edit_settings' => false, 'access_billing' => false,
                ],
            ],
            // Ad platforms / social posting / messaging — see
            // FCP_Ad_Platforms::registry() for the full list of supported
            // keys. Each entry is { enabled: bool, <platform-specific fields> }.
            'ad_platforms' => [
                'meta'          => [ 'enabled' => false ],
                'google_ads'    => [ 'enabled' => false ],
                'tiktok'        => [ 'enabled' => false ],
                'linkedin_ads'  => [ 'enabled' => false ],
                'pinterest_ads' => [ 'enabled' => false ],
                'snapchat'      => [ 'enabled' => false ],
                'twitter_ads'   => [ 'enabled' => false ],
                'reddit'        => [ 'enabled' => false ],
                'bing_ads'      => [ 'enabled' => false ],
                'quora_ads'     => [ 'enabled' => false ],
                'fb_page'       => [ 'enabled' => false ],
                'ig_business'   => [ 'enabled' => false ],
                'li_page'       => [ 'enabled' => false ],
                'telegram'      => [ 'enabled' => false ],
                'whatsapp'      => [ 'enabled' => false ],
                'teams'         => [ 'enabled' => false ],
                'discord'       => [ 'enabled' => false ],
            ],
            'integrations' => [
                'mailchimp'      => [ 'enabled' => false, 'api_key' => '', 'audience_id' => '', 'datacenter' => '' ],
                'hubspot'        => [ 'enabled' => false, 'api_token' => '' ],
                'slack'          => [ 'enabled' => false, 'webhook_url' => '' ],
                'activecampaign' => [ 'enabled' => false, 'api_url'  => '', 'api_key' => '', 'list_id' => '' ],
                'convertkit'     => [ 'enabled' => false, 'api_key'  => '', 'api_secret' => '', 'form_id' => '' ],
                'salesforce'     => [ 'enabled' => false, 'client_id' => '', 'client_secret' => '', 'refresh_token' => '', 'instance_url' => '' ],
                'zoho_crm'       => [ 'enabled' => false, 'client_id' => '', 'client_secret' => '', 'refresh_token' => '', 'region' => 'com', 'module' => 'Leads' ],
                'dropbox'        => [ 'enabled' => false, 'access_token' => '', 'folder_path' => '/FormCraft' ],
                'google_drive'   => [ 'enabled' => false, 'client_id' => '', 'client_secret' => '', 'refresh_token' => '', 'folder_id' => '' ],
                'zapier'         => [ 'enabled' => false ], // Zapier is just a webhook target — no extra config needed
                'brevo'           => [ 'enabled' => false, 'api_key' => '', 'list_id' => '' ],
                'aweber'          => [ 'enabled' => false, 'access_token' => '', 'account_id' => '', 'list_id' => '' ],
                'campaign_monitor'=> [ 'enabled' => false, 'api_key' => '', 'list_id' => '' ],
                'breeze'          => [ 'enabled' => false, 'webhook_url' => '', 'api_key' => '' ],
                'agile_crm'       => [ 'enabled' => false, 'domain' => '', 'email' => '', 'api_key' => '' ],
                'mailgun'         => [ 'enabled' => false, 'api_key' => '', 'domain' => '', 'region' => 'us', 'from_email' => '', 'from_name' => '', 'to_email' => '{admin}', 'subject' => '', 'body' => '' ],
                'postmark'        => [ 'enabled' => false, 'server_token' => '', 'message_stream' => 'outbound', 'from_email' => '', 'from_name' => '', 'to_email' => '{admin}', 'subject' => '', 'body' => '' ],
                'sendgrid'        => [ 'enabled' => false, 'api_key' => '', 'from_email' => '', 'from_name' => '', 'to_email' => '{admin}', 'subject' => '', 'body' => '' ],
                'airtable'        => [ 'enabled' => false, 'pat' => '' ],
            ],
            'ai' => [
                'enabled' => false,
                'api_key' => '',
                'model'   => 'claude-haiku-4-5-20251001',
            ],
            'otp' => [
                'default_cc' => '+91',
                'default_channel' => 'email',
                'twilio' => [
                    'enabled'     => false,
                    'account_sid' => '',
                    'auth_token'  => '',
                    'from_number' => '',
                ],
                'msg91' => [
                    'enabled'     => false,
                    'auth_key'    => '',
                    'template_id' => '',
                    'sender_id'   => '',
                ],
            ],
            'payment' => [
                'test_mode'   => true,
                'razorpay'    => [ 'enabled' => false, 'key_id' => '', 'key_secret' => '', 'webhook_secret' => '' ],
                'stripe'      => [ 'enabled' => false, 'publishable_key' => '', 'secret_key' => '', 'webhook_secret' => '' ],
                'cashfree'    => [ 'enabled' => false, 'app_id' => '', 'secret_key' => '', 'webhook_secret' => '' ],
                'instamojo'   => [ 'enabled' => false, 'api_key' => '', 'auth_token' => '', 'salt' => '' ],
                'paypal'      => [ 'enabled' => false, 'client_id' => '', 'client_secret' => '', 'webhook_id' => '' ],
                'authorize'   => [ 'enabled' => false, 'login_id' => '', 'transaction_key' => '' ],
                'square'      => [ 'enabled' => false, 'access_token' => '', 'location_id' => '' ],
                'mollie'      => [ 'enabled' => false, 'api_key' => '' ],
                'paystack'    => [ 'enabled' => false, 'secret_key' => '', 'public_key' => '' ],
                'mercadopago' => [ 'enabled' => false, 'access_token' => '', 'public_key' => '' ],
            ],
        ];
    }

    public static function seed_sample_form() {
        $sample = [
            'title'       => __( 'Contact Us', 'formcraft-pro' ),
            'description' => __( 'Reach out and we\'ll get back to you within 24 hours.', 'formcraft-pro' ),
            'status'      => 'active',
            'steps' => [[
                'id'     => 'step_1',
                'title'  => __( 'Your Details', 'formcraft-pro' ),
                'fields' => [
                    [ 'id' => 'f1', 'type' => 'name',     'label' => 'Full Name',     'required' => true ],
                    [ 'id' => 'f2', 'type' => 'email',    'label' => 'Email Address', 'required' => true ],
                    [ 'id' => 'f3', 'type' => 'tel',      'label' => 'Phone',         'required' => false ],
                    [ 'id' => 'f4', 'type' => 'textarea', 'label' => 'Message',       'required' => true ],
                ],
            ]],
            'settings' => [
                'submitText'     => __( 'Send Message', 'formcraft-pro' ),
                'successMessage' => __( 'Thanks! We received your message.', 'formcraft-pro' ),
                'recaptcha'      => false,
            ],
        ];
        self::insert_form( $sample );
    }

    /* -----------------------------------------------------------
     * Forms CRUD
     * -------------------------------------------------------- */
    public static function get_forms( $args = [] ) {
        global $wpdb;
        $table = self::forms_table();
        $where = '1=1';
        if ( ! empty( $args['status'] ) ) {
            $where .= $wpdb->prepare( ' AND status = %s', $args['status'] );
        }
        $sql = "SELECT * FROM $table WHERE $where ORDER BY updated_at DESC";
        $rows = $wpdb->get_results( $sql, ARRAY_A );
        return array_map( [ __CLASS__, 'hydrate_form' ], $rows ?: [] );
    }

    /**
     * v2.60 — Object-cache layer.
     *
     * The form schema is the single hottest read in the plugin — every
     * page render that contains a form calls get_form() at least once.
     * On a busy site (hundreds of pages, dozens of forms) this hits MySQL
     * thousands of times per minute even though the schema barely changes.
     *
     * wp_cache_get/set/delete are no-ops without a persistent cache, but
     * Redis Object Cache, Memcached, W3 Total Cache, LiteSpeed, etc. all
     * implement them — so this single change makes the plugin instantly
     * compatible with every host's caching layer.
     *
     * Group: 'formcraft-pro'. TTL: 5 min — short enough that a manual
     * direct DB edit becomes visible within a few minutes; long enough
     * to absorb most page-load hits. Explicit invalidation happens in
     * insert_form / update_form / delete_form below.
     */
    const CACHE_GROUP = 'formcraft-pro';
    const CACHE_TTL   = 300; // 5 min

    public static function get_form( $id ) {
        // Cache key splits numeric vs slug — slugs can resolve to a different
        // form if it gets renamed, so we don't want a slug entry to mask a
        // newer numeric one. Numeric ids are immutable.
        $cache_key = is_numeric( $id ) ? 'form_id_' . (int) $id : 'form_slug_' . md5( (string) $id );
        $cached = wp_cache_get( $cache_key, self::CACHE_GROUP );
        if ( false !== $cached ) return $cached === '__null__' ? null : $cached;

        global $wpdb;
        $table = self::forms_table();
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d OR slug = %s LIMIT 1", $id, $id ), ARRAY_A );
        $out = $row ? self::hydrate_form( $row ) : null;
        // Store null hits under a sentinel so we don't re-query missing forms.
        wp_cache_set( $cache_key, $out === null ? '__null__' : $out, self::CACHE_GROUP, self::CACHE_TTL );
        // Mirror the numeric lookup under the slug key so subsequent
        // slug-based fetches don't fall through to MySQL.
        if ( $out && ! empty( $out['slug'] ) ) {
            wp_cache_set( 'form_slug_' . md5( $out['slug'] ), $out, self::CACHE_GROUP, self::CACHE_TTL );
            wp_cache_set( 'form_id_'   . (int) $out['id'],   $out, self::CACHE_GROUP, self::CACHE_TTL );
        }
        return $out;
    }

    /**
     * Invalidate every cache key tied to a form. Called from insert /
     * update / delete after the DB write completes.
     */
    private static function bust_form_cache( $form ) {
        if ( ! is_array( $form ) ) return;
        if ( ! empty( $form['id'] ) )   wp_cache_delete( 'form_id_'   . (int) $form['id'], self::CACHE_GROUP );
        if ( ! empty( $form['slug'] ) ) wp_cache_delete( 'form_slug_' . md5( $form['slug'] ), self::CACHE_GROUP );
    }

    /**
     * Build a URL-friendly slug from a form title, ensuring it doesn't
     * collide with another form. Falls back to a random suffix when the
     * title is empty or sanitises down to nothing.
     */
    public static function build_unique_slug( $title, $exclude_id = 0 ) {
        global $wpdb;
        $base = sanitize_title( (string) $title );
        if ( $base === '' ) {
            return 'form-' . wp_generate_password( 6, false, false );
        }
        $table = self::forms_table();
        $slug  = $base;
        $i     = 2;
        while ( true ) {
            $existing = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM $table WHERE slug = %s AND id <> %d LIMIT 1",
                $slug, (int) $exclude_id
            ) );
            if ( ! $existing ) return $slug;
            $slug = $base . '-' . $i++;
            if ( $i > 200 ) return $base . '-' . wp_generate_password( 6, false, false ); // safety
        }
    }

    public static function insert_form( $form ) {
        global $wpdb;
        $table = self::forms_table();
        // Always derive the slug from the title so URLs read as
        // /formcraft-pro/payment-form/ instead of /form_dZT0Vv/.
        $slug = ! empty( $form['slug'] )
            ? self::build_unique_slug( $form['slug'] )
            : self::build_unique_slug( isset( $form['title'] ) ? $form['title'] : '' );
        $wpdb->insert( $table, [
            'slug'       => $slug,
            'title'      => isset( $form['title'] ) ? sanitize_text_field( $form['title'] ) : 'Untitled',
            'status'     => isset( $form['status'] ) ? sanitize_text_field( $form['status'] ) : 'draft',
            'data'       => wp_json_encode( $form ),
            'created_at' => current_time( 'mysql' ),
            'updated_at' => current_time( 'mysql' ),
        ] );
        $new_id = $wpdb->insert_id;
        // v2.60 — Bust any null-result cache that an earlier get_form()
        // populated for this slug/id.
        self::bust_form_cache( [ 'id' => $new_id, 'slug' => $slug ] );
        return $new_id;
    }

    public static function update_form( $id, $form ) {
        global $wpdb;
        $table = self::forms_table();
        // Snapshot the PRE-update form first so the revision history captures
        // the state before this change. Skip when the snapshot would be
        // identical (e.g. status-only flip) so we don't pile up dupes.
        $prev = self::get_form( $id );
        if ( $prev ) {
            $prev_clean = $prev;
            unset( $prev_clean['id'], $prev_clean['slug'], $prev_clean['views'], $prev_clean['submissions'], $prev_clean['created_at'], $prev_clean['updated_at'] );
            self::insert_revision( $id, $prev_clean, '' );
        }
        $update = [
            'title'      => isset( $form['title'] ) ? sanitize_text_field( $form['title'] ) : 'Untitled',
            'status'     => isset( $form['status'] ) ? sanitize_text_field( $form['status'] ) : 'draft',
            'data'       => wp_json_encode( $form ),
            'updated_at' => current_time( 'mysql' ),
        ];
        // Upgrade legacy auto-generated slugs (form_AbCdEf / form-AbCdEf) to
        // a title-based one on the first save, and honour explicit slug
        // changes sent from the client.
        //
        // v2.69.7 — Also regenerate when the current slug is a placeholder
        // derived from the default "Untitled Form" title (e.g. "untitled",
        // "untitled-form", "untitled-form-2"). Otherwise, a form the user
        // created with the default title, then meaningfully renamed later,
        // keeps a stale slug forever — which shows up in the Embed modal's
        // Direct Link, iframe, and Popup Button URLs.
        $current_slug   = isset( $prev['slug'] ) ? $prev['slug'] : '';
        $wants_slug     = isset( $form['slug'] ) ? sanitize_title( $form['slug'] ) : '';
        $new_title      = isset( $form['title'] ) ? sanitize_text_field( $form['title'] ) : '';
        $is_legacy      = (bool) preg_match( '/^form[_-][A-Za-z0-9]{6}$/', $current_slug );
        $is_placeholder = (bool) preg_match( '/^untitled(-form)?(-\d+)?$/', $current_slug );
        $title_is_real  = $new_title && strcasecmp( $new_title, 'Untitled' ) !== 0
                                     && strcasecmp( $new_title, 'Untitled Form' ) !== 0;
        if ( $wants_slug && $wants_slug !== $current_slug ) {
            $update['slug'] = self::build_unique_slug( $wants_slug, $id );
        } elseif ( ( $is_legacy || $is_placeholder ) && $title_is_real ) {
            $update['slug'] = self::build_unique_slug( $new_title, $id );
        }
        $result = $wpdb->update( $table, $update, [ 'id' => (int) $id ] );
        // v2.60 — Invalidate cache under both the old + new slug so a
        // visitor hitting either URL gets the fresh schema.
        self::bust_form_cache( [ 'id' => $id, 'slug' => $current_slug ] );
        if ( isset( $update['slug'] ) ) self::bust_form_cache( [ 'id' => $id, 'slug' => $update['slug'] ] );
        return $result;
    }

    /* -----------------------------------------------------------
     * Form revisions
     * -------------------------------------------------------- */
    public static function insert_revision( $form_id, $snapshot, $note = '' ) {
        global $wpdb;
        $wpdb->insert( self::revisions_table(), [
            'form_id'    => (int) $form_id,
            'snapshot'   => wp_json_encode( $snapshot ),
            'note'       => sanitize_text_field( substr( (string) $note, 0, 255 ) ),
            'created_by' => get_current_user_id() ?: null,
            'created_at' => current_time( 'mysql' ),
        ] );
        // Prune to the last 20 per form so the table doesn't grow unbounded.
        $table = self::revisions_table();
        $keep_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT id FROM $table WHERE form_id = %d ORDER BY created_at DESC LIMIT 20",
            (int) $form_id
        ) );
        if ( count( $keep_ids ) >= 20 ) {
            $ids = implode( ',', array_map( 'intval', $keep_ids ) );
            $wpdb->query( $wpdb->prepare(
                "DELETE FROM $table WHERE form_id = %d AND id NOT IN ($ids)",
                (int) $form_id
            ) );
        }
        return $wpdb->insert_id;
    }

    public static function get_revisions( $form_id ) {
        global $wpdb;
        $table = self::revisions_table();
        $rows  = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, form_id, note, created_by, created_at FROM $table WHERE form_id = %d ORDER BY created_at DESC LIMIT 50",
            (int) $form_id
        ), ARRAY_A );
        if ( ! $rows ) return [];
        foreach ( $rows as &$r ) {
            $r['id']         = (int) $r['id'];
            $r['form_id']    = (int) $r['form_id'];
            $r['created_by'] = $r['created_by'] ? (int) $r['created_by'] : null;
            if ( $r['created_by'] ) {
                $u = get_user_by( 'id', $r['created_by'] );
                $r['created_by_name'] = $u ? $u->display_name : 'User #' . $r['created_by'];
            } else {
                $r['created_by_name'] = '—';
            }
        }
        return $rows;
    }

    public static function get_revision( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . self::revisions_table() . " WHERE id = %d", (int) $id
        ), ARRAY_A );
    }

    public static function delete_form( $id ) {
        global $wpdb;
        // v2.60 — Resolve slug before delete so we can invalidate that key too.
        $existing = self::get_form( (int) $id );
        $wpdb->delete( self::forms_table(), [ 'id' => (int) $id ] );
        $wpdb->delete( self::subs_table(), [ 'form_id' => (int) $id ] );
        if ( $existing ) self::bust_form_cache( $existing );
    }

    public static function hydrate_form( $row ) {
        if ( ! $row ) {
            return null;
        }
        $payload = json_decode( $row['data'], true );
        $payload = is_array( $payload ) ? $payload : [];
        $payload['id']          = (int) $row['id'];
        $payload['slug']        = $row['slug'];
        $payload['title']       = $row['title'];
        $payload['status']      = $row['status'];
        $payload['views']       = (int) $row['views'];
        $payload['submissions'] = (int) $row['submissions'];
        $payload['created_at']  = $row['created_at'];
        $payload['updated_at']  = $row['updated_at'];
        return $payload;
    }

    /* -----------------------------------------------------------
     * Submissions
     * -------------------------------------------------------- */
    public static function insert_submission( $form_id, $data, $extra = [] ) {
        global $wpdb;
        $name = $data['name'] ?? $data['Full Name'] ?? $data['email'] ?? '';
        $email = $data['email'] ?? $data['Email Address'] ?? '';
        $wpdb->insert( self::subs_table(), [
            'form_id'         => (int) $form_id,
            'data'            => wp_json_encode( $data ),
            'submitter_name'  => sanitize_text_field( $name ),
            'submitter_email' => sanitize_email( $email ),
            'ip_address'      => $extra['ip']  ?? self::get_ip(),
            'user_agent'      => substr( $_SERVER['HTTP_USER_AGENT'] ?? '', 0, 250 ),
            'country'         => $extra['country'] ?? '',
            'device'          => $extra['device']  ?? '',
            'browser'         => $extra['browser'] ?? '',
            'is_spam'         => ! empty( $extra['spam'] ) ? 1 : 0,
            'is_read'         => 0,
            'created_at'      => current_time( 'mysql' ),
        ] );
        $sid = $wpdb->insert_id;
        // bump form submissions counter
        $wpdb->query( $wpdb->prepare( "UPDATE " . self::forms_table() . " SET submissions = submissions + 1 WHERE id = %d", $form_id ) );
        return $sid;
    }

    public static function get_submissions( $args = [] ) {
        global $wpdb;
        $table = self::subs_table();
        $where = '1=1';
        if ( isset( $args['form_id'] ) )  $where .= $wpdb->prepare( ' AND form_id = %d', $args['form_id'] );
        if ( isset( $args['is_spam'] ) )  $where .= $wpdb->prepare( ' AND is_spam = %d', $args['is_spam'] );
        if ( isset( $args['is_read'] ) )  $where .= $wpdb->prepare( ' AND is_read = %d', $args['is_read'] );
        // Default: hide abandoned rows so the regular Submissions UI stays
        // focused on completed entries. Pass is_abandoned=1 to fetch them.
        if ( isset( $args['is_abandoned'] ) ) {
            $where .= $wpdb->prepare( ' AND is_abandoned = %d', $args['is_abandoned'] );
        } else {
            $where .= ' AND is_abandoned = 0';
        }
        return $wpdb->get_results( "SELECT * FROM $table WHERE $where ORDER BY created_at DESC", ARRAY_A );
    }

    /* -----------------------------------------------------------
     * Abandoned submissions (Form Abandonment feature)
     * -------------------------------------------------------- */

    /**
     * Insert OR update an abandoned submission row keyed by
     * (form_id, session_id). Called from the auto-save endpoint as the
     * visitor types. When the user finally submits, finalize_abandoned()
     * flips is_abandoned to 0 so the row becomes a real submission.
     */
    public static function upsert_abandoned( $form_id, $session_id, $data, $extra = [] ) {
        global $wpdb;
        $table = self::subs_table();
        // Fuzzy detection: walk every label and pick the first one that
        // contains "name" / looks like an email. Lets the admin label the
        // field anything ("Your Name", "Customer Name", "Full Name").
        $name = '';
        $email = '';
        foreach ( (array) $data as $k => $v ) {
            if ( ! is_string( $v ) || $v === '' ) continue;
            $lk = strtolower( (string) $k );
            if ( ! $email && is_email( trim( $v ) ) ) { $email = trim( $v ); continue; }
            if ( ! $name && ( strpos( $lk, 'name' ) !== false ) ) { $name = trim( $v ); }
        }

        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM $table WHERE form_id = %d AND session_id = %s AND is_abandoned = 1 LIMIT 1",
            (int) $form_id, $session_id
        ) );

        $row = [
            'data'            => wp_json_encode( $data ),
            'submitter_name'  => sanitize_text_field( (string) $name ),
            'submitter_email' => sanitize_email( (string) $email ),
            'last_touched_at' => current_time( 'mysql' ),
        ];

        if ( $existing ) {
            $wpdb->update( $table, $row, [ 'id' => (int) $existing ] );
            return (int) $existing;
        }

        $row['form_id']      = (int) $form_id;
        $row['session_id']   = substr( (string) $session_id, 0, 64 );
        $row['ip_address']   = $extra['ip']  ?? self::get_ip();
        $row['user_agent']   = substr( $_SERVER['HTTP_USER_AGENT'] ?? '', 0, 250 );
        $row['country']      = $extra['country'] ?? '';
        $row['device']       = $extra['device']  ?? '';
        $row['browser']      = $extra['browser'] ?? '';
        $row['is_abandoned'] = 1;
        $row['is_spam']      = 0;
        $row['is_read']      = 0;
        $row['created_at']   = current_time( 'mysql' );
        $wpdb->insert( $table, $row );
        return (int) $wpdb->insert_id;
    }

    /**
     * Promote an abandoned row to a real submission. Called from the
     * regular submit endpoint when a session_id matches an existing
     * abandoned row — so we don't end up with duplicate entries.
     */
    public static function finalize_abandoned( $form_id, $session_id, $data, $extra = [] ) {
        global $wpdb;
        if ( ! $session_id ) return 0;
        $table = self::subs_table();
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM $table WHERE form_id = %d AND session_id = %s AND is_abandoned = 1 LIMIT 1",
            (int) $form_id, $session_id
        ) );
        if ( ! $existing ) return 0;

        $name  = $data['name'] ?? $data['Full Name'] ?? $data['Name'] ?? '';
        $email = $data['email'] ?? $data['Email Address'] ?? $data['Email'] ?? '';
        $wpdb->update( $table, [
            'data'            => wp_json_encode( $data ),
            'submitter_name'  => sanitize_text_field( (string) $name ),
            'submitter_email' => sanitize_email( (string) $email ),
            'is_abandoned'    => 0,
            'is_spam'         => ! empty( $extra['spam'] ) ? 1 : 0,
            'country'         => $extra['country'] ?? '',
            'device'          => $extra['device']  ?? '',
            'browser'         => $extra['browser'] ?? '',
            'created_at'      => current_time( 'mysql' ), // re-stamp so it appears as a fresh submission
        ], [ 'id' => (int) $existing ] );

        // Bump form submissions counter (was not bumped during partial saves)
        $wpdb->query( $wpdb->prepare( "UPDATE " . self::forms_table() . " SET submissions = submissions + 1 WHERE id = %d", $form_id ) );
        return (int) $existing;
    }

    /**
     * Fetch abandoned rows ready for a recovery email. Excludes ones we
     * already nudged ($recovery_sent_at not null) and ones without an
     * email captured.
     */
    public static function pending_recovery_rows( $delay_minutes = 60 ) {
        global $wpdb;
        $table = self::subs_table();
        $cutoff = gmdate( 'Y-m-d H:i:s', time() - ( max( 5, (int) $delay_minutes ) * 60 ) - ( get_option( 'gmt_offset', 0 ) * 3600 ) );
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM $table
              WHERE is_abandoned = 1
                AND submitter_email <> ''
                AND submitter_email IS NOT NULL
                AND recovery_sent_at IS NULL
                AND last_touched_at <= %s
              ORDER BY last_touched_at ASC
              LIMIT 50",
            $cutoff
        ), ARRAY_A );
    }

    /**
     * Remove all abandoned rows for the same (form_id, email) — typically
     * called right after a real submission lands so the visitor's earlier
     * partial attempts disappear from the Abandoned Entries page. Skips
     * the optional $keep_id so finalize_abandoned()'s own row isn't deleted.
     */
    public static function purge_abandoned_for_email( $form_id, $email, $keep_id = 0 ) {
        global $wpdb;
        if ( ! $email || ! is_email( $email ) ) return 0;
        $table = self::subs_table();
        $sql   = "DELETE FROM $table WHERE form_id = %d AND is_abandoned = 1 AND submitter_email = %s";
        $args  = [ (int) $form_id, $email ];
        if ( $keep_id ) {
            $sql   .= ' AND id <> %d';
            $args[] = (int) $keep_id;
        }
        return (int) $wpdb->query( $wpdb->prepare( $sql, ...$args ) );
    }

    /**
     * Hard-delete abandoned rows older than N days to keep the table
     * lean. Runs from the same cron as recovery sending.
     */
    public static function purge_stale_abandoned( $days = 30 ) {
        global $wpdb;
        $table  = self::subs_table();
        $cutoff = gmdate( 'Y-m-d H:i:s', time() - ( max( 1, (int) $days ) * 86400 ) - ( get_option( 'gmt_offset', 0 ) * 3600 ) );
        return (int) $wpdb->query( $wpdb->prepare(
            "DELETE FROM $table WHERE is_abandoned = 1 AND last_touched_at <= %s",
            $cutoff
        ) );
    }

    public static function get_submission( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . self::subs_table() . " WHERE id = %d", $id ), ARRAY_A );
    }

    public static function update_submission( $id, $changes ) {
        global $wpdb;
        return $wpdb->update( self::subs_table(), $changes, [ 'id' => (int) $id ] );
    }

    public static function delete_submission( $id ) {
        global $wpdb;
        // v2.69.10 — Grab the form_id BEFORE deletion so we can rebase the
        // form's cached submissions counter to match reality afterwards.
        // The old code just DELETEd and left the counter drifting upward.
        $form_id = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT form_id FROM " . self::subs_table() . " WHERE id = %d", (int) $id
        ) );
        $result = $wpdb->delete( self::subs_table(), [ 'id' => (int) $id ] );
        if ( $form_id ) self::recount_form_submissions( $form_id );
        // v2.69.11 — Persistent global "Deleted" counter so the Submissions
        // overview can show admins how many entries have been removed over
        // the site's lifetime. Only counts actual DB deletions (not spam
        // moves or archive flags).
        if ( $result ) self::bump_deleted_counter( 1 );
        return $result;
    }

    /**
     * v2.69.11 — Increment the global submissions-deleted counter by $n.
     * Stored in an option so it survives restore/backup cycles and doesn't
     * need a new DB column. Callers: single-row delete, GDPR bulk erase.
     */
    public static function bump_deleted_counter( $n = 1 ) {
        $n = max( 0, (int) $n );
        if ( ! $n ) return;
        $curr = (int) get_option( 'fcp_deleted_submissions_count', 0 );
        update_option( 'fcp_deleted_submissions_count', $curr + $n );
    }

    /** v2.69.11 — Read the global deletions counter. */
    public static function get_deleted_counter() {
        return (int) get_option( 'fcp_deleted_submissions_count', 0 );
    }

    /**
     * v2.69.10 — Rebase a form's cached `submissions` counter to the real
     * row count (excluding spam + abandoned, matching the "All Entries"
     * view's default filter). Called on any single-submission mutation and
     * from the FormCraft admin-page auto-heal.
     */
    public static function recount_form_submissions( $form_id ) {
        global $wpdb;
        $form_id = (int) $form_id;
        if ( $form_id <= 0 ) return;
        $wpdb->query( $wpdb->prepare(
            "UPDATE " . self::forms_table() . " f
             SET f.submissions = (
                SELECT COUNT(*) FROM " . self::subs_table() . " s
                WHERE s.form_id = %d AND s.is_spam = 0 AND s.is_abandoned = 0
             )
             WHERE f.id = %d",
            $form_id, $form_id
        ) );
    }

    /**
     * v2.69.10 — Rebase every form's counter in one query. Cheap on real
     * installs (a single grouped-select-update), so it's safe to call from
     * an admin-page hook to auto-heal drift accumulated by older versions.
     */
    public static function recount_all_form_submissions() {
        global $wpdb;
        $forms = self::forms_table();
        $subs  = self::subs_table();
        $wpdb->query(
            "UPDATE $forms f
             LEFT JOIN (
                SELECT form_id, COUNT(*) AS cnt
                FROM $subs
                WHERE is_spam = 0 AND is_abandoned = 0
                GROUP BY form_id
             ) c ON c.form_id = f.id
             SET f.submissions = COALESCE(c.cnt, 0)"
        );
    }

    public static function bump_views( $form_id ) {
        global $wpdb;
        $wpdb->query( $wpdb->prepare( "UPDATE " . self::forms_table() . " SET views = views + 1 WHERE id = %d", $form_id ) );
    }

    /* -----------------------------------------------------------
     * Mail log
     * -------------------------------------------------------- */
    public static function log_mail( $args ) {
        global $wpdb;
        $row = [
            'recipient'     => sanitize_text_field( substr( $args['recipient']     ?? '', 0, 255 ) ),
            'subject'       => sanitize_text_field( substr( $args['subject']       ?? '', 0, 255 ) ),
            'form_id'       => isset( $args['form_id'] )       ? (int) $args['form_id']       : null,
            'submission_id' => isset( $args['submission_id'] ) ? (int) $args['submission_id'] : null,
            'purpose'       => sanitize_key( $args['purpose'] ?? 'notify' ),
            'status'        => sanitize_key( $args['status']  ?? 'delivered' ),
            'error_message' => isset( $args['error_message'] ) ? substr( (string) $args['error_message'], 0, 2000 ) : null,
            'sent_at'       => current_time( 'mysql' ),
        ];
        return $wpdb->insert( self::mail_log_table(), $row );
    }

    public static function get_mail_log( $limit = 50 ) {
        global $wpdb;
        $log_t   = self::mail_log_table();
        $forms_t = self::forms_table();
        $limit   = max( 1, min( 500, (int) $limit ) );
        $rows = $wpdb->get_results(
            "SELECT l.*, f.title AS form_title
             FROM $log_t l
             LEFT JOIN $forms_t f ON l.form_id = f.id
             ORDER BY l.sent_at DESC
             LIMIT $limit",
            ARRAY_A
        );
        if ( ! $rows ) return [];
        foreach ( $rows as &$r ) {
            $r['id']            = (int) $r['id'];
            $r['form_id']       = isset( $r['form_id'] )       ? (int) $r['form_id']       : null;
            $r['submission_id'] = isset( $r['submission_id'] ) ? (int) $r['submission_id'] : null;
        }
        return $rows;
    }

    public static function last_mail_sent_at() {
        global $wpdb;
        $val = $wpdb->get_var( "SELECT sent_at FROM " . self::mail_log_table() . " WHERE status='delivered' ORDER BY sent_at DESC LIMIT 1" );
        return $val ?: null;
    }

    /* -----------------------------------------------------------
     * Coupons
     * -------------------------------------------------------- */
    public static function get_coupons() {
        global $wpdb;
        $rows = $wpdb->get_results( "SELECT * FROM " . self::coupons_table() . " ORDER BY created_at DESC", ARRAY_A );
        return array_map( [ __CLASS__, 'hydrate_coupon' ], $rows ?: [] );
    }

    public static function get_coupon( $id ) {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . self::coupons_table() . " WHERE id = %d", $id ), ARRAY_A );
        return $row ? self::hydrate_coupon( $row ) : null;
    }

    public static function get_coupon_by_code( $code ) {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . self::coupons_table() . " WHERE code = %s LIMIT 1", strtoupper( trim( $code ) ) ), ARRAY_A );
        return $row ? self::hydrate_coupon( $row ) : null;
    }

    public static function insert_coupon( $data ) {
        global $wpdb;
        $row = self::sanitize_coupon( $data );
        $row['created_at'] = current_time( 'mysql' );
        $row['updated_at'] = current_time( 'mysql' );
        $ok = $wpdb->insert( self::coupons_table(), $row );
        if ( ! $ok ) return new WP_Error( 'db', 'Could not save coupon. Code may already exist.' );
        return $wpdb->insert_id;
    }

    public static function update_coupon( $id, $data ) {
        global $wpdb;
        $row = self::sanitize_coupon( $data, true );
        $row['updated_at'] = current_time( 'mysql' );
        return $wpdb->update( self::coupons_table(), $row, [ 'id' => (int) $id ] );
    }

    public static function delete_coupon( $id ) {
        global $wpdb;
        return $wpdb->delete( self::coupons_table(), [ 'id' => (int) $id ] );
    }

    public static function bump_coupon_use( $code ) {
        global $wpdb;
        $code = strtoupper( trim( $code ) );
        $wpdb->query( $wpdb->prepare( "UPDATE " . self::coupons_table() . " SET used_count = used_count + 1, updated_at = %s WHERE code = %s", current_time( 'mysql' ), $code ) );
    }

    /**
     * Evaluate a coupon against an amount + form id. Returns:
     *   [ 'ok' => true,  'discount' => float, 'final' => float, 'coupon' => array ]
     *   [ 'ok' => false, 'message' => string ]
     */
    public static function evaluate_coupon( $code, $amount, $form_id = 0 ) {
        $coupon = self::get_coupon_by_code( $code );
        if ( ! $coupon ) {
            return [ 'ok' => false, 'message' => 'Coupon code not found.' ];
        }
        if ( $coupon['status'] !== 'active' ) {
            return [ 'ok' => false, 'message' => 'This coupon is inactive.' ];
        }
        if ( $coupon['expires_at'] && strtotime( $coupon['expires_at'] ) < current_time( 'timestamp' ) ) {
            return [ 'ok' => false, 'message' => 'This coupon has expired.' ];
        }
        if ( $coupon['max_uses'] > 0 && $coupon['used_count'] >= $coupon['max_uses'] ) {
            return [ 'ok' => false, 'message' => 'This coupon has reached its usage limit.' ];
        }
        if ( $coupon['min_amount'] !== null && (float) $amount < (float) $coupon['min_amount'] ) {
            return [ 'ok' => false, 'message' => 'Minimum order amount is ' . number_format( (float) $coupon['min_amount'], 2 ) . '.' ];
        }
        if ( ! empty( $coupon['applies_to'] ) && is_array( $coupon['applies_to'] ) && (int) $form_id > 0 ) {
            $applies = array_map( 'intval', $coupon['applies_to'] );
            if ( ! in_array( (int) $form_id, $applies, true ) ) {
                return [ 'ok' => false, 'message' => 'This coupon is not valid for this form.' ];
            }
        }
        $amount   = (float) $amount;
        $discount = 0;
        if ( $coupon['discount_type'] === 'percent' ) {
            $discount = round( $amount * ( (float) $coupon['discount_value'] / 100 ), 2 );
        } else {
            $discount = (float) $coupon['discount_value'];
        }
        if ( $discount > $amount ) $discount = $amount;
        if ( $discount < 0 )       $discount = 0;
        $final = max( 0, round( $amount - $discount, 2 ) );
        return [
            'ok'       => true,
            'discount' => $discount,
            'final'    => $final,
            'coupon'   => $coupon,
        ];
    }

    private static function sanitize_coupon( $d, $partial = false ) {
        $out = [];
        if ( isset( $d['code'] ) )           $out['code']           = strtoupper( preg_replace( '/[^A-Z0-9_\-]/i', '', $d['code'] ) );
        if ( isset( $d['discount_type'] ) )  $out['discount_type']  = in_array( $d['discount_type'], [ 'percent', 'flat' ], true ) ? $d['discount_type'] : 'percent';
        if ( isset( $d['discount_value'] ) ) $out['discount_value'] = max( 0, (float) $d['discount_value'] );
        if ( isset( $d['currency'] ) )       $out['currency']       = strtoupper( substr( sanitize_text_field( $d['currency'] ), 0, 8 ) );
        if ( isset( $d['status'] ) )         $out['status']         = in_array( $d['status'], [ 'active', 'inactive' ], true ) ? $d['status'] : 'active';
        if ( array_key_exists( 'applies_to', $d ) )  $out['applies_to'] = is_array( $d['applies_to'] ) ? wp_json_encode( array_map( 'intval', $d['applies_to'] ) ) : '';
        if ( array_key_exists( 'min_amount', $d ) )  $out['min_amount'] = $d['min_amount'] === '' || $d['min_amount'] === null ? null : (float) $d['min_amount'];
        if ( isset( $d['max_uses'] ) )       $out['max_uses']       = max( 0, (int) $d['max_uses'] );
        if ( isset( $d['used_count'] ) && ! $partial ) $out['used_count'] = max( 0, (int) $d['used_count'] );
        if ( array_key_exists( 'expires_at', $d ) ) {
            $exp = $d['expires_at'];
            if ( $exp === '' || $exp === null ) {
                $out['expires_at'] = null;
            } else {
                $ts = strtotime( $exp );
                $out['expires_at'] = $ts ? date( 'Y-m-d H:i:s', $ts ) : null;
            }
        }
        if ( isset( $d['note'] ) )           $out['note']           = sanitize_text_field( substr( (string) $d['note'], 0, 255 ) );
        return $out;
    }

    public static function hydrate_coupon( $row ) {
        if ( ! $row ) return null;
        $row['id']             = (int) $row['id'];
        $row['discount_value'] = (float) $row['discount_value'];
        $row['min_amount']     = $row['min_amount'] === null ? null : (float) $row['min_amount'];
        $row['max_uses']       = (int) $row['max_uses'];
        $row['used_count']     = (int) $row['used_count'];
        $applies = $row['applies_to'] ?? '';
        if ( $applies && is_string( $applies ) ) {
            $decoded = json_decode( $applies, true );
            $row['applies_to'] = is_array( $decoded ) ? $decoded : [];
        } else {
            $row['applies_to'] = [];
        }
        return $row;
    }

    /* -----------------------------------------------------------
     * Webhooks
     * -------------------------------------------------------- */
    public static function get_webhooks( $args = [] ) {
        global $wpdb;
        $table = self::webhooks_table();
        $where = '1=1';
        if ( ! empty( $args['form_id'] ) ) $where .= $wpdb->prepare( ' AND (form_id IS NULL OR form_id = %d)', (int) $args['form_id'] );
        if ( ! empty( $args['event'] ) )   $where .= $wpdb->prepare( ' AND event = %s', $args['event'] );
        if ( ! empty( $args['status'] ) )  $where .= $wpdb->prepare( ' AND status = %s', $args['status'] );
        $rows = $wpdb->get_results( "SELECT * FROM $table WHERE $where ORDER BY created_at DESC", ARRAY_A );
        return array_map( [ __CLASS__, 'hydrate_webhook' ], $rows ?: [] );
    }

    public static function get_webhook( $id ) {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . self::webhooks_table() . " WHERE id = %d", $id ), ARRAY_A );
        return $row ? self::hydrate_webhook( $row ) : null;
    }

    public static function insert_webhook( $data ) {
        global $wpdb;
        $row = self::sanitize_webhook( $data );
        $row['secret']     = $row['secret']     ?? wp_generate_password( 32, false );
        $row['created_at'] = current_time( 'mysql' );
        $row['updated_at'] = current_time( 'mysql' );
        $ok = $wpdb->insert( self::webhooks_table(), $row );
        return $ok ? $wpdb->insert_id : new WP_Error( 'db', 'Could not save webhook.' );
    }

    public static function update_webhook( $id, $data ) {
        global $wpdb;
        $row = self::sanitize_webhook( $data, true );
        $row['updated_at'] = current_time( 'mysql' );
        return $wpdb->update( self::webhooks_table(), $row, [ 'id' => (int) $id ] );
    }

    public static function delete_webhook( $id ) {
        global $wpdb;
        return $wpdb->delete( self::webhooks_table(), [ 'id' => (int) $id ] );
    }

    public static function record_webhook_fire( $id, $http_status, $error = '' ) {
        global $wpdb;
        $wpdb->query( $wpdb->prepare(
            "UPDATE " . self::webhooks_table() . "
             SET fire_count = fire_count + 1,
                 last_fired_at = %s,
                 last_status = %d,
                 last_error = %s,
                 updated_at = %s
             WHERE id = %d",
            current_time( 'mysql' ),
            (int) $http_status,
            substr( (string) $error, 0, 2000 ),
            current_time( 'mysql' ),
            (int) $id
        ) );
    }

    private static function sanitize_webhook( $d, $partial = false ) {
        $out = [];
        if ( isset( $d['label'] ) )   $out['label']  = sanitize_text_field( substr( (string) $d['label'], 0, 120 ) );
        if ( isset( $d['target'] ) )  $out['target'] = sanitize_key( $d['target'] ) ?: 'webhook';
        if ( isset( $d['url'] ) )     $out['url']    = esc_url_raw( $d['url'] );
        if ( array_key_exists( 'form_id', $d ) ) {
            $out['form_id'] = ( $d['form_id'] === null || $d['form_id'] === '' || $d['form_id'] === 'all' )
                ? null : (int) $d['form_id'];
        }
        if ( isset( $d['event'] ) )   $out['event']  = in_array( $d['event'], [ 'submission', 'payment', 'spam' ], true ) ? $d['event'] : 'submission';
        if ( isset( $d['status'] ) )  $out['status'] = in_array( $d['status'], [ 'active', 'paused' ], true ) ? $d['status'] : 'active';
        if ( array_key_exists( 'headers', $d ) ) {
            $out['headers'] = is_string( $d['headers'] ) ? substr( $d['headers'], 0, 4000 ) : '';
        }
        if ( isset( $d['secret'] ) )  $out['secret'] = substr( preg_replace( '/[^A-Za-z0-9]/', '', (string) $d['secret'] ), 0, 64 );
        return $out;
    }

    public static function hydrate_webhook( $row ) {
        if ( ! $row ) return null;
        $row['id']          = (int) $row['id'];
        $row['form_id']     = $row['form_id'] === null ? null : (int) $row['form_id'];
        $row['last_status'] = $row['last_status'] === null ? null : (int) $row['last_status'];
        $row['fire_count']  = (int) $row['fire_count'];
        return $row;
    }

    /* -----------------------------------------------------------
     * Helpers
     * -------------------------------------------------------- */
    public static function get_ip() {
        foreach ( [ 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_CLIENT_IP', 'REMOTE_ADDR' ] as $k ) {
            if ( ! empty( $_SERVER[ $k ] ) ) {
                $ip = explode( ',', $_SERVER[ $k ] )[0];
                return filter_var( trim( $ip ), FILTER_VALIDATE_IP ) ?: '';
            }
        }
        return '';
    }
}
