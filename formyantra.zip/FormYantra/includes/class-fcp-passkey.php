<?php
/**
 * FormYantra - Passkey (FIDO2 / WebAuthn) enrolment (v2.70.15).
 *
 * Stores WebAuthn public-key credentials for admin users. This first
 * release ships full REGISTRATION + management (list, name, delete) and
 * the *client-side* login flow. The server-side login VERIFICATION step
 * (parsing authenticator data, checking the signature against the stored
 * public key) is deliberately gated behind a "requires-crypto-review"
 * flag — passkey verification is security-critical and needs a proper
 * CBOR decoder + COSE key extraction, which we'll add in v2.71.
 *
 * Until that lands, this class is safe to enable — admins can enrol
 * devices (their credentials are captured + stored) and manage them,
 * but the "sign in with passkey" action just says "verification arriving
 * in v2.71" and hands off to the regular password login. No lockout risk.
 *
 * Table:
 *   fcp_passkeys(id, user_id, credential_id, public_key, sign_count,
 *                device_name, transports, created_at, last_used_at)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_Passkey {

    const TABLE_KEY = 'fcp_passkeys';

    public static function bootstrap() {
        add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ], 5 );
        // v2.71 — Full sign-in flow. Adds a "Sign in with passkey" button
        // to wp-login.php and enqueues the client-side WebAuthn JS.
        add_action( 'login_form',              [ __CLASS__, 'render_login_button' ] );
        add_action( 'login_enqueue_scripts',   [ __CLASS__, 'enqueue_login_assets' ] );
    }

    public static function table() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE_KEY;
    }

    public static function install_table() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::table();
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL,
            credential_id VARCHAR(512) NOT NULL,
            public_key TEXT NOT NULL,
            sign_count BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            device_name VARCHAR(128) NULL,
            transports VARCHAR(255) NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_used_at DATETIME NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY credential_id (credential_id(255)),
            KEY user_id (user_id)
        ) $charset;";
        dbDelta( $sql );
    }

    /* ---------- REST routes ---------- */

    public static function register_routes() {
        $ns = 'formcraft/v1';

        register_rest_route( $ns, '/passkeys', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [ __CLASS__, 'list_passkeys' ],
                'permission_callback' => [ __CLASS__, 'can_manage_self' ],
            ],
        ] );
        register_rest_route( $ns, '/passkeys/(?P<id>\d+)', [
            [
                'methods'             => WP_REST_Server::DELETABLE,
                'callback'            => [ __CLASS__, 'delete_passkey' ],
                'permission_callback' => [ __CLASS__, 'can_manage_self' ],
            ],
            [
                'methods'             => WP_REST_Server::EDITABLE,
                'callback'            => [ __CLASS__, 'rename_passkey' ],
                'permission_callback' => [ __CLASS__, 'can_manage_self' ],
            ],
        ] );
        register_rest_route( $ns, '/passkeys/register/challenge', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ __CLASS__, 'register_challenge' ],
            'permission_callback' => [ __CLASS__, 'can_manage_self' ],
        ] );
        register_rest_route( $ns, '/passkeys/register/verify', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ __CLASS__, 'register_verify' ],
            'permission_callback' => [ __CLASS__, 'can_manage_self' ],
        ] );

        // v2.71 — Public login endpoints. NO auth needed — this IS how
        // the user authenticates. Rate-limited inside the handlers.
        register_rest_route( $ns, '/passkeys/login/challenge', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ __CLASS__, 'login_challenge' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( $ns, '/passkeys/login/verify', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ __CLASS__, 'login_verify' ],
            'permission_callback' => '__return_true',
        ] );
    }

    public static function can_manage_self() {
        return is_user_logged_in();
    }

    /* ---------- Handlers ---------- */

    /**
     * Return the current user's registered passkeys (metadata only —
     * never expose the credential id or public key beyond needed).
     */
    public static function list_passkeys() {
        global $wpdb;
        $uid  = get_current_user_id();
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, device_name, transports, created_at, last_used_at
             FROM " . self::table() . " WHERE user_id = %d ORDER BY created_at DESC",
            $uid
        ), ARRAY_A );
        return rest_ensure_response( [ 'passkeys' => array_map( function ( $r ) {
            return [
                'id'          => (int) $r['id'],
                'name'        => (string) ( $r['device_name'] ?: 'Unnamed device' ),
                'transports'  => (string) $r['transports'],
                'created_at'  => (string) $r['created_at'],
                'last_used_at'=> (string) ( $r['last_used_at'] ?: '' ),
            ];
        }, (array) $rows ) ] );
    }

    public static function delete_passkey( $req ) {
        global $wpdb;
        $uid = get_current_user_id();
        $ok = $wpdb->delete( self::table(), [ 'id' => (int) $req['id'], 'user_id' => $uid ] );
        return rest_ensure_response( [ 'ok' => (bool) $ok ] );
    }

    public static function rename_passkey( $req ) {
        global $wpdb;
        $body = $req->get_json_params();
        $name = isset( $body['name'] ) ? sanitize_text_field( (string) $body['name'] ) : '';
        $uid  = get_current_user_id();
        $wpdb->update( self::table(),
            [ 'device_name' => $name ],
            [ 'id' => (int) $req['id'], 'user_id' => $uid ]
        );
        return rest_ensure_response( [ 'ok' => true ] );
    }

    /**
     * Step 1 of registration: mint a challenge, store it in a transient
     * keyed to the user, return the options object the browser needs to
     * call navigator.credentials.create().
     */
    public static function register_challenge() {
        $uid   = get_current_user_id();
        $user  = wp_get_current_user();
        $chall = self::random_bytes_base64url( 32 );
        set_transient( 'fcp_pk_reg_' . $uid, $chall, 5 * MINUTE_IN_SECONDS );

        // Collect existing credential IDs so the browser refuses to
        // re-enrol the same authenticator twice.
        global $wpdb;
        $excludes = $wpdb->get_col( $wpdb->prepare(
            "SELECT credential_id FROM " . self::table() . " WHERE user_id = %d", $uid
        ) );

        return rest_ensure_response( [
            'challenge' => $chall,
            'rp' => [
                'name' => get_bloginfo( 'name' ),
                'id'   => wp_parse_url( home_url(), PHP_URL_HOST ),
            ],
            'user' => [
                'id'          => self::b64url( (string) $uid ),
                'name'        => $user->user_login,
                'displayName' => $user->display_name ?: $user->user_login,
            ],
            'pubKeyCredParams' => [
                [ 'type' => 'public-key', 'alg' => -7   ], // ES256
                [ 'type' => 'public-key', 'alg' => -257 ], // RS256
            ],
            'authenticatorSelection' => [
                'residentKey'      => 'preferred',
                'userVerification' => 'preferred',
            ],
            'timeout' => 60000,
            'attestation' => 'none',
            'excludeCredentials' => array_map( function ( $cid ) {
                return [ 'type' => 'public-key', 'id' => $cid ];
            }, (array) $excludes ),
        ] );
    }

    /**
     * Step 2 of registration: browser sends back the AttestationResponse.
     * We store the credential id + public key. Attestation verification
     * is skipped here because we set attestation:"none" — the browser
     * won't send any attestation payload, so there's nothing to verify.
     * The stored credential's public key is what we'll later use to
     * verify login assertions.
     */
    public static function register_verify( $req ) {
        $body = $req->get_json_params();
        if ( ! is_array( $body ) ) return new WP_Error( 'bad_body', 'Invalid body', [ 'status' => 400 ] );
        $uid   = get_current_user_id();
        $chall = get_transient( 'fcp_pk_reg_' . $uid );
        if ( ! $chall ) return new WP_Error( 'no_challenge', 'Registration challenge expired. Try again.', [ 'status' => 400 ] );
        delete_transient( 'fcp_pk_reg_' . $uid );

        // Basic sanity — the browser must have echoed back our challenge
        // inside clientDataJSON.
        $client_data_b64 = (string) ( $body['clientDataJSON'] ?? '' );
        $client_data = json_decode( self::b64url_decode( $client_data_b64 ), true );
        if ( ! is_array( $client_data ) ) return new WP_Error( 'bad_client_data', 'Malformed clientDataJSON', [ 'status' => 400 ] );
        if ( ( $client_data['type'] ?? '' ) !== 'webauthn.create' ) return new WP_Error( 'bad_type', 'Wrong ceremony type', [ 'status' => 400 ] );
        if ( ( $client_data['challenge'] ?? '' ) !== $chall )       return new WP_Error( 'bad_challenge', 'Challenge mismatch', [ 'status' => 400 ] );

        $expected_origin = home_url();
        $got_origin = (string) ( $client_data['origin'] ?? '' );
        if ( rtrim( $got_origin, '/' ) !== rtrim( $expected_origin, '/' )
             && ! ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ) {
            return new WP_Error( 'bad_origin', 'Origin mismatch: ' . $got_origin . ' vs ' . $expected_origin, [ 'status' => 400 ] );
        }

        // Store the credential id + raw attestationObject. Full COSE key
        // extraction happens on first successful login (or, in a future
        // release, right here with a CBOR decoder). Storing the raw
        // attestationObject means no data is lost.
        $credential_id     = (string) ( $body['credentialId'] ?? '' );
        $attestation_b64   = (string) ( $body['attestationObject'] ?? '' );
        if ( ! $credential_id || ! $attestation_b64 ) return new WP_Error( 'incomplete', 'Missing credential fields', [ 'status' => 400 ] );

        global $wpdb;
        $device_name = isset( $body['deviceName'] ) ? sanitize_text_field( (string) $body['deviceName'] ) : self::guess_device_name();
        $transports  = isset( $body['transports'] ) && is_array( $body['transports'] )
            ? implode( ',', array_map( 'sanitize_key', $body['transports'] ) )
            : '';

        $wpdb->insert( self::table(), [
            'user_id'       => $uid,
            'credential_id' => $credential_id,
            'public_key'    => $attestation_b64,
            'sign_count'    => 0,
            'device_name'   => $device_name,
            'transports'    => $transports,
            'created_at'    => current_time( 'mysql' ),
        ] );

        return rest_ensure_response( [ 'ok' => true, 'id' => (int) $wpdb->insert_id, 'name' => $device_name ] );
    }

    /* ---------- Helpers ---------- */

    private static function random_bytes_base64url( $n ) {
        try { $bytes = random_bytes( $n ); }
        catch ( \Throwable $e ) { $bytes = openssl_random_pseudo_bytes( $n ); }
        return self::b64url( $bytes );
    }
    public static function b64url( $s ) {
        return rtrim( strtr( base64_encode( $s ), '+/', '-_' ), '=' );
    }
    public static function b64url_decode( $s ) {
        $r = strlen( $s ) % 4;
        if ( $r ) $s .= str_repeat( '=', 4 - $r );
        return base64_decode( strtr( $s, '-_', '+/' ) );
    }
    private static function guess_device_name() {
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if ( stripos( $ua, 'Windows' ) !== false ) return 'Windows device';
        if ( stripos( $ua, 'Mac' ) !== false )     return 'Mac device';
        if ( stripos( $ua, 'iPhone' ) !== false )  return 'iPhone';
        if ( stripos( $ua, 'iPad' ) !== false )    return 'iPad';
        if ( stripos( $ua, 'Android' ) !== false ) return 'Android device';
        if ( stripos( $ua, 'Linux' ) !== false )   return 'Linux device';
        return 'Passkey';
    }

    /* ================================================================
     * v2.71 — LOGIN FLOW
     *   1. login_challenge()  mints a random challenge, keys it to the IP
     *      (short-lived — 5 min).
     *   2. Client calls navigator.credentials.get({challenge}) — user taps
     *      Touch ID / Face ID / hardware key / phone.
     *   3. login_verify() receives {credentialId, authenticatorData,
     *      clientDataJSON, signature, userHandle}, looks up the stored
     *      attestationObject, extracts the public key (CBOR + COSE parse),
     *      verifies the signature with openssl, then wp_set_auth_cookie().
     * ================================================================ */

    /** Rate-limit: max 20 challenge / verify attempts per IP per 10 min. */
    private static function login_rate_limited() {
        $ip  = $_SERVER['REMOTE_ADDR'] ?? '';
        $key = 'fcp_pk_login_' . md5( $ip );
        $hits = (int) get_transient( $key );
        if ( $hits >= 20 ) return true;
        set_transient( $key, $hits + 1, 10 * MINUTE_IN_SECONDS );
        return false;
    }

    public static function login_challenge() {
        if ( self::login_rate_limited() ) {
            return new WP_Error( 'rate_limited', 'Too many attempts. Try again in a few minutes.', [ 'status' => 429 ] );
        }
        $chall = self::random_bytes_base64url( 32 );
        $ip    = $_SERVER['REMOTE_ADDR'] ?? '0';
        set_transient( 'fcp_pk_login_chall_' . md5( $ip ), $chall, 5 * MINUTE_IN_SECONDS );
        return rest_ensure_response( [
            'challenge'        => $chall,
            'rpId'             => wp_parse_url( home_url(), PHP_URL_HOST ),
            'timeout'          => 60000,
            'userVerification' => 'preferred',
            // Empty allowCredentials → "discoverable credential" flow.
            // The browser shows the user's stored passkeys for this site;
            // the picked one comes back with its userHandle so we can
            // identify the WP user without asking for a username.
            'allowCredentials' => [],
        ] );
    }

    public static function login_verify( $req ) {
        if ( self::login_rate_limited() ) {
            return new WP_Error( 'rate_limited', 'Too many attempts. Try again in a few minutes.', [ 'status' => 429 ] );
        }
        $body = $req->get_json_params();
        if ( ! is_array( $body ) ) return new WP_Error( 'bad_body', 'Invalid body', [ 'status' => 400 ] );

        $ip    = $_SERVER['REMOTE_ADDR'] ?? '0';
        $chall = get_transient( 'fcp_pk_login_chall_' . md5( $ip ) );
        if ( ! $chall ) return new WP_Error( 'no_challenge', 'Challenge expired. Try again.', [ 'status' => 400 ] );
        delete_transient( 'fcp_pk_login_chall_' . md5( $ip ) );

        $credential_id  = (string) ( $body['credentialId'] ?? '' );
        $client_data_b  = (string) ( $body['clientDataJSON'] ?? '' );
        $auth_data_b    = (string) ( $body['authenticatorData'] ?? '' );
        $signature_b    = (string) ( $body['signature'] ?? '' );
        $user_handle_b  = (string) ( $body['userHandle'] ?? '' );
        if ( ! $credential_id || ! $client_data_b || ! $auth_data_b || ! $signature_b ) {
            return new WP_Error( 'incomplete', 'Missing assertion fields', [ 'status' => 400 ] );
        }

        // Look up the stored credential
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, user_id, public_key, sign_count FROM " . self::table() . " WHERE credential_id = %s",
            $credential_id
        ), ARRAY_A );
        if ( ! $row ) return new WP_Error( 'unknown_credential', 'Unknown passkey.', [ 'status' => 401 ] );

        $user_id = (int) $row['user_id'];
        $user    = get_userdata( $user_id );
        if ( ! $user ) return new WP_Error( 'no_user', 'User not found.', [ 'status' => 401 ] );

        // Bonus check: userHandle in the assertion should match user_id
        // (we set it during registration). Skip on empty (older clients).
        if ( $user_handle_b !== '' ) {
            $handle = self::b64url_decode( $user_handle_b );
            if ( (string) $handle !== (string) $user_id ) {
                return new WP_Error( 'bad_user_handle', 'User handle mismatch.', [ 'status' => 401 ] );
            }
        }

        // Verify clientDataJSON
        $client_data_bytes = self::b64url_decode( $client_data_b );
        $client_data       = json_decode( $client_data_bytes, true );
        if ( ! is_array( $client_data ) ) return new WP_Error( 'bad_client_data', 'Malformed clientDataJSON', [ 'status' => 400 ] );
        if ( ( $client_data['type'] ?? '' ) !== 'webauthn.get' )     return new WP_Error( 'bad_type',     'Wrong ceremony type', [ 'status' => 400 ] );
        if ( ( $client_data['challenge'] ?? '' ) !== $chall )        return new WP_Error( 'bad_chall',    'Challenge mismatch', [ 'status' => 400 ] );
        $expected_origin = home_url();
        $got_origin      = (string) ( $client_data['origin'] ?? '' );
        if ( rtrim( $got_origin, '/' ) !== rtrim( $expected_origin, '/' ) ) {
            return new WP_Error( 'bad_origin', 'Origin mismatch.', [ 'status' => 400 ] );
        }

        // Verify authenticator data: RP ID hash + userPresent flag + counter
        $auth_data = self::b64url_decode( $auth_data_b );
        if ( strlen( $auth_data ) < 37 ) return new WP_Error( 'short_auth_data', 'Authenticator data too short', [ 'status' => 400 ] );
        $rp_id_hash  = substr( $auth_data, 0, 32 );
        $flags       = ord( $auth_data[32] );
        $sign_count  = self::read_u32be( substr( $auth_data, 33, 4 ) );
        $expected_rp = wp_parse_url( home_url(), PHP_URL_HOST );
        if ( hash( 'sha256', $expected_rp, true ) !== $rp_id_hash ) {
            return new WP_Error( 'bad_rp_id', 'RP ID hash mismatch.', [ 'status' => 400 ] );
        }
        if ( ( $flags & 0x01 ) === 0 ) return new WP_Error( 'no_user_present', 'User presence flag not set.', [ 'status' => 400 ] );

        // Extract the public key we stored at registration time.
        $public_key_pem = self::extract_public_key_pem_from_stored( $row['public_key'] );
        if ( is_wp_error( $public_key_pem ) ) return $public_key_pem;

        // Compose the message: authenticatorData || SHA-256(clientDataJSON)
        $client_data_hash = hash( 'sha256', $client_data_bytes, true );
        $signed_data      = $auth_data . $client_data_hash;
        $signature        = self::b64url_decode( $signature_b );

        // Verify. Both ES256 (DER-encoded ECDSA) and RS256 (raw PKCS1v1.5)
        // work with openssl_verify + OPENSSL_ALGO_SHA256 as long as the
        // key is in the right PEM form.
        $ok = @openssl_verify( $signed_data, $signature, $public_key_pem, OPENSSL_ALGO_SHA256 );
        if ( $ok !== 1 ) {
            return new WP_Error( 'bad_signature', 'Signature verification failed.', [ 'status' => 401 ] );
        }

        // Counter monotonicity check — soft-fail if counter is stuck at 0
        // (many platform authenticators legitimately never increment).
        if ( $sign_count > 0 && $sign_count <= (int) $row['sign_count'] ) {
            return new WP_Error( 'counter_replay', 'Possible cloned authenticator (counter did not advance).', [ 'status' => 401 ] );
        }

        // Update sign_count + last_used_at
        $wpdb->update( self::table(),
            [ 'sign_count' => $sign_count, 'last_used_at' => current_time( 'mysql' ) ],
            [ 'id' => (int) $row['id'] ]
        );

        // Log the user in.
        wp_set_current_user( $user_id );
        wp_set_auth_cookie( $user_id, true );
        do_action( 'wp_login', $user->user_login, $user );

        return rest_ensure_response( [
            'ok'          => true,
            'redirect_to' => admin_url(),
        ] );
    }

    /**
     * Extract a PEM-encoded public key from what we stored at registration.
     * At registration we saved the raw attestationObject (CBOR). Here we
     * parse it to find the credential's COSE public key, then convert to
     * PEM so openssl_verify can consume it.
     *
     * The result is cached on the row for future logins (saves reparsing
     * on every sign-in).
     */
    private static function extract_public_key_pem_from_stored( $stored ) {
        // If we already cached a PEM (starts with "-----BEGIN"), return it
        if ( strncmp( $stored, '-----BEGIN', 10 ) === 0 ) return $stored;

        $attestation_bytes = self::b64url_decode( $stored );
        try {
            $offset = 0;
            $obj    = self::cbor_decode( $attestation_bytes, $offset );
        } catch ( \Throwable $e ) {
            return new WP_Error( 'cbor_fail', 'Could not decode attestationObject: ' . $e->getMessage(), [ 'status' => 500 ] );
        }
        if ( ! is_array( $obj ) || ! isset( $obj['authData'] ) ) {
            return new WP_Error( 'no_authdata', 'attestationObject missing authData.', [ 'status' => 500 ] );
        }
        $auth_data = $obj['authData']; // raw bytes
        if ( strlen( $auth_data ) < 55 ) return new WP_Error( 'short_authdata', 'authData too short.', [ 'status' => 500 ] );

        $flags = ord( $auth_data[32] );
        $has_attested = ( $flags & 0x40 ) !== 0;
        if ( ! $has_attested ) return new WP_Error( 'no_attested', 'attestedCredentialData missing.', [ 'status' => 500 ] );

        // Skip: rpIdHash(32) + flags(1) + signCount(4) + AAGUID(16)
        $p = 32 + 1 + 4 + 16;
        // credentialIdLength (2 bytes big-endian) + credentialId
        $cid_len = self::read_u16be( substr( $auth_data, $p, 2 ) );
        $p += 2;
        $p += $cid_len;
        // COSE key starts here — parse it as CBOR
        $cbor_tail = substr( $auth_data, $p );
        $offset    = 0;
        try {
            $cose = self::cbor_decode( $cbor_tail, $offset );
        } catch ( \Throwable $e ) {
            return new WP_Error( 'cose_parse', 'COSE key parse failed: ' . $e->getMessage(), [ 'status' => 500 ] );
        }
        if ( ! is_array( $cose ) ) return new WP_Error( 'cose_shape', 'COSE key not a map.', [ 'status' => 500 ] );

        $pem = self::cose_to_pem( $cose );
        if ( is_wp_error( $pem ) ) return $pem;

        // Cache the PEM back to the DB — future logins skip the CBOR dance.
        global $wpdb;
        // We identify the row by matching stored value; safer than doing it here
        // via a query since we don't have the row id. Skip on cache write fail.
        try {
            $wpdb->query( $wpdb->prepare(
                "UPDATE " . self::table() . " SET public_key = %s WHERE public_key = %s",
                $pem, $stored
            ) );
        } catch ( \Throwable $e ) { /* best effort */ }

        return $pem;
    }

    /**
     * Convert a COSE key map to a PEM-encoded public key.
     * Supports ES256 (alg=-7, P-256) and RS256 (alg=-257).
     */
    private static function cose_to_pem( $cose ) {
        $kty = $cose[1] ?? null;   // 1 = key type
        $alg = $cose[3] ?? null;   // 3 = algorithm

        if ( $kty === 2 && $alg === -7 ) {
            // EC2 / ES256 / P-256
            $x = $cose[-2] ?? '';
            $y = $cose[-3] ?? '';
            if ( strlen( $x ) !== 32 || strlen( $y ) !== 32 ) {
                return new WP_Error( 'bad_ec_key', 'ES256 key must have 32-byte X and Y.' );
            }
            // Uncompressed EC point: 0x04 || X || Y
            $point = "\x04" . $x . $y;
            // DER: SEQUENCE { SEQUENCE { OID(id-ecPubKey), OID(P-256) }, BIT STRING (point) }
            $oid_ec_pk  = "\x06\x07\x2A\x86\x48\xCE\x3D\x02\x01";              // 1.2.840.10045.2.1
            $oid_p256   = "\x06\x08\x2A\x86\x48\xCE\x3D\x03\x01\x07";          // 1.2.840.10045.3.1.7
            $algo_seq   = self::der_sequence( $oid_ec_pk . $oid_p256 );
            $bit_string = self::der_bit_string( $point );
            $der        = self::der_sequence( $algo_seq . $bit_string );
            return self::pem_wrap( $der, 'PUBLIC KEY' );
        }

        if ( $kty === 3 && $alg === -257 ) {
            // RSA / RS256
            $n = $cose[-1] ?? '';
            $e = $cose[-2] ?? '';
            if ( ! $n || ! $e ) return new WP_Error( 'bad_rsa_key', 'RS256 key missing modulus or exponent.' );
            // Build RSAPublicKey: SEQUENCE { INTEGER n, INTEGER e }
            $rsa_pub_key = self::der_sequence( self::der_integer( $n ) . self::der_integer( $e ) );
            $oid_rsa     = "\x06\x09\x2A\x86\x48\x86\xF7\x0D\x01\x01\x01";     // 1.2.840.113549.1.1.1
            $null        = "\x05\x00";
            $algo_seq    = self::der_sequence( $oid_rsa . $null );
            $bit_string  = self::der_bit_string( $rsa_pub_key );
            $der         = self::der_sequence( $algo_seq . $bit_string );
            return self::pem_wrap( $der, 'PUBLIC KEY' );
        }

        return new WP_Error( 'unsupported_alg', 'Unsupported key type/algorithm (kty=' . var_export( $kty, true ) . ', alg=' . var_export( $alg, true ) . '). Supported: ES256, RS256.' );
    }

    /* ---------- DER helpers ---------- */

    private static function der_length( $len ) {
        if ( $len < 0x80 ) return chr( $len );
        $bytes = '';
        while ( $len > 0 ) {
            $bytes = chr( $len & 0xFF ) . $bytes;
            $len >>= 8;
        }
        return chr( 0x80 | strlen( $bytes ) ) . $bytes;
    }
    private static function der_sequence( $content ) {
        return "\x30" . self::der_length( strlen( $content ) ) . $content;
    }
    private static function der_bit_string( $content ) {
        // 0x00 unused-bits byte prefix
        return "\x03" . self::der_length( strlen( $content ) + 1 ) . "\x00" . $content;
    }
    private static function der_integer( $bytes ) {
        // Prepend 0x00 if high bit set (otherwise INTEGER would be negative)
        if ( strlen( $bytes ) > 0 && ( ord( $bytes[0] ) & 0x80 ) ) $bytes = "\x00" . $bytes;
        return "\x02" . self::der_length( strlen( $bytes ) ) . $bytes;
    }
    private static function pem_wrap( $der, $label ) {
        return "-----BEGIN $label-----\n" . chunk_split( base64_encode( $der ), 64, "\n" ) . "-----END $label-----\n";
    }

    /* ---------- Minimal CBOR decoder ----------
     * Only the WebAuthn-relevant subset: uints, ints, byte-strings,
     * text-strings, arrays, maps. Skips tags (major=6). Simple values
     * (major=7) return null except true/false. This is NOT a general
     * CBOR decoder — it's just enough for authenticator payloads.
     */
    public static function cbor_decode( $bytes, &$offset ) {
        if ( ! isset( $bytes[ $offset ] ) ) throw new \RuntimeException( 'CBOR: unexpected EOF' );
        $b     = ord( $bytes[ $offset++ ] );
        $major = $b >> 5;
        $add   = $b & 0x1F;
        $len   = self::cbor_read_len( $bytes, $offset, $add );

        switch ( $major ) {
            case 0: return $len;              // unsigned int
            case 1: return -1 - $len;         // negative int
            case 2:                           // byte string
                $out = substr( $bytes, $offset, $len );
                $offset += $len;
                return $out;
            case 3:                           // text string
                $out = substr( $bytes, $offset, $len );
                $offset += $len;
                return $out;
            case 4:                           // array
                $arr = [];
                for ( $i = 0; $i < $len; $i++ ) $arr[] = self::cbor_decode( $bytes, $offset );
                return $arr;
            case 5:                           // map
                $map = [];
                for ( $i = 0; $i < $len; $i++ ) {
                    $k = self::cbor_decode( $bytes, $offset );
                    $v = self::cbor_decode( $bytes, $offset );
                    $map[ $k ] = $v;
                }
                return $map;
            case 6:                           // semantic tag — skip, return inner
                return self::cbor_decode( $bytes, $offset );
            case 7:
                if ( $add === 20 ) return false;
                if ( $add === 21 ) return true;
                if ( $add === 22 ) return null;
                if ( $add === 23 ) return null;
                // Floats — we don't need them for WebAuthn
                return null;
        }
        return null;
    }

    private static function cbor_read_len( $bytes, &$offset, $add ) {
        if ( $add < 24 ) return $add;
        if ( $add === 24 ) { $v = ord( $bytes[ $offset ] );          $offset += 1; return $v; }
        if ( $add === 25 ) { $v = self::read_u16be( substr( $bytes, $offset, 2 ) ); $offset += 2; return $v; }
        if ( $add === 26 ) { $v = self::read_u32be( substr( $bytes, $offset, 4 ) ); $offset += 4; return $v; }
        if ( $add === 27 ) {
            $hi = self::read_u32be( substr( $bytes, $offset, 4 ) );
            $lo = self::read_u32be( substr( $bytes, $offset + 4, 4 ) );
            $offset += 8;
            return ( $hi << 32 ) | $lo;
        }
        throw new \RuntimeException( 'CBOR: unsupported length additional=' . $add );
    }

    private static function read_u16be( $b ) { return ( ord( $b[0] ) << 8 ) | ord( $b[1] ); }
    private static function read_u32be( $b ) {
        return ( ord( $b[0] ) << 24 ) | ( ord( $b[1] ) << 16 ) | ( ord( $b[2] ) << 8 ) | ord( $b[3] );
    }

    /* ---------- wp-login.php integration ---------- */

    public static function enqueue_login_assets() {
        wp_enqueue_script(
            'fcp-passkey-login',
            FCP_URL . 'assets/js/passkey-login.js',
            [],
            defined( 'FCP_VERSION' ) ? FCP_VERSION : '2.71',
            true
        );
        wp_localize_script( 'fcp-passkey-login', 'FCP_Passkey', [
            'restUrl'   => esc_url_raw( rest_url( 'formcraft/v1/passkeys' ) ),
            'redirect'  => isset( $_GET['redirect_to'] ) ? esc_url_raw( wp_unslash( $_GET['redirect_to'] ) ) : admin_url(),
        ] );
    }

    public static function render_login_button() {
        // Injected inside <form id="loginform"> above the "Log In" button.
        ?>
        <p style="text-align:center;margin:0 0 12px;">
            <button type="button" id="fcp-passkey-btn" class="button button-large" style="width:100%;padding:8px;background:#0f172a;color:#fff;border:0;border-radius:6px;cursor:pointer;font-weight:600;">
                🪪 Sign in with passkey
            </button>
            <span id="fcp-passkey-status" style="display:block;margin-top:6px;font-size:12px;color:#64748b;"></span>
        </p>
        <?php
    }
}
