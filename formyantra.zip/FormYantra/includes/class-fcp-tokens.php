<?php
/**
 * FormYantra — Personal Access Tokens.
 *
 * Admins generate scoped Bearer tokens for headless integrations
 * (Zapier-without-cookies, mobile apps, custom dashboards). Each token:
 *   - Belongs to a specific WP user (capability inherited from them)
 *   - Has a fixed scope list:
 *       forms:read         GET /forms, GET /forms/:id
 *       forms:write        POST/PUT/DELETE /forms*
 *       submissions:read   GET /submissions, GET /submissions/:id
 *       submissions:write  PUT/DELETE /submissions*, status changes
 *       analytics:read     GET /analytics/*
 *       graphql            POST /graphql (any query)
 *   - Has an optional expiry timestamp
 *   - Records last_used_at for audit
 *
 * Storage: a dedicated table fcp_api_tokens. Token bodies are NEVER
 * stored in clear text — we keep a SHA-256 hash. The token shown to
 * the admin on creation is the only time the full value exists; if
 * lost, they must mint a new one.
 *
 * Auth flow:
 *   GET /wp-json/fcp/v1/forms
 *   Authorization: Bearer fcp_pat_abcd1234…
 * The rest_authentication_errors filter sees the header, hashes it,
 * looks up the token, sets the current user to the token's owner, and
 * stashes the scope list on the request for downstream permission checks.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_Tokens {

    const TABLE         = 'fcp_api_tokens';
    const TOKEN_PREFIX  = 'fcp_pat_';
    const HASH_ALGO     = 'sha256';

    const SCOPES = [
        'forms:read'        => 'Read forms (list + single)',
        'forms:write'       => 'Create / update / delete forms',
        'submissions:read'  => 'Read submissions',
        'submissions:write' => 'Update / delete submissions',
        'analytics:read'    => 'Read analytics endpoints',
        'graphql'           => 'Query the /graphql endpoint',
    ];

    /* -------------------------------------------------------------------
     * Bootstrap (called from main plugin file on plugins_loaded).
     * Hooks the auth filter + REST routes.
     * ----------------------------------------------------------------- */
    public static function bootstrap() {
        add_filter( 'rest_authentication_errors', [ __CLASS__, 'authenticate' ], 20 );
        add_action( 'rest_api_init',              [ __CLASS__, 'register_routes' ] );
    }

    public static function table() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE;
    }

    /**
     * Create the tokens table on first activation. Called from
     * FCP_DB::install() / on the same upgrade hook.
     */
    public static function install_table() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $table   = self::table();
        $sql     = "CREATE TABLE $table (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            name VARCHAR(120) NOT NULL,
            token_hash CHAR(64) NOT NULL,
            scopes TEXT NOT NULL,
            expires_at DATETIME DEFAULT NULL,
            last_used_at DATETIME DEFAULT NULL,
            last_used_ip VARCHAR(45) DEFAULT NULL,
            created_at DATETIME NOT NULL,
            UNIQUE KEY token_hash (token_hash),
            KEY user_id (user_id)
        ) $charset;";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    /* -------------------------------------------------------------------
     * Auth — runs on every REST request. Returns NULL when we have no
     * opinion (let the existing cookie / nonce / app-password auth run);
     * sets the user + returns true when we matched a token.
     * ----------------------------------------------------------------- */
    public static function authenticate( $result ) {
        // Don't override a result an earlier filter already produced
        // (e.g. cookie auth). Only chime in when nothing else has.
        if ( ! empty( $result ) ) return $result;
        if ( ! function_exists( 'getallheaders' ) && empty( $_SERVER['HTTP_AUTHORIZATION'] ) ) return $result;
        $auth = '';
        if ( ! empty( $_SERVER['HTTP_AUTHORIZATION'] ) )           $auth = $_SERVER['HTTP_AUTHORIZATION'];
        elseif ( function_exists( 'getallheaders' ) )              {
            $headers = getallheaders();
            foreach ( $headers as $k => $v ) if ( strcasecmp( $k, 'Authorization' ) === 0 ) { $auth = $v; break; }
        }
        if ( ! $auth || stripos( $auth, 'Bearer ' ) !== 0 ) return $result;
        $token = trim( substr( $auth, 7 ) );
        if ( strpos( $token, self::TOKEN_PREFIX ) !== 0 ) return $result;

        global $wpdb;
        $hash = hash( self::HASH_ALGO, $token );
        $row  = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . self::table() . " WHERE token_hash = %s LIMIT 1", $hash
        ), ARRAY_A );
        if ( ! $row ) {
            return new WP_Error( 'fcp_bad_token', 'Invalid API token', [ 'status' => 401 ] );
        }
        if ( ! empty( $row['expires_at'] ) && strtotime( $row['expires_at'] ) < time() ) {
            return new WP_Error( 'fcp_expired_token', 'API token expired', [ 'status' => 401 ] );
        }
        // Update last_used_at + IP for audit.
        $wpdb->update( self::table(), [
            'last_used_at' => current_time( 'mysql' ),
            'last_used_ip' => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
        ], [ 'id' => (int) $row['id'] ] );

        wp_set_current_user( (int) $row['user_id'] );
        // Stash scopes on a global so REST handlers can call
        // FCP_Tokens::current_scopes() to enforce them.
        $GLOBALS['fcp_current_token_scopes'] = array_filter( array_map( 'trim', explode( ',', (string) $row['scopes'] ) ) );
        $GLOBALS['fcp_current_token_id']     = (int) $row['id'];
        return true;
    }

    /**
     * Returns the scope list of the token used on the current request,
     * or null when the request was authenticated by something else
     * (cookie, basic auth, app password) — in which case standard
     * capability checks apply and scope is irrelevant.
     */
    public static function current_scopes() {
        return isset( $GLOBALS['fcp_current_token_scopes'] ) ? $GLOBALS['fcp_current_token_scopes'] : null;
    }

    public static function require_scope( $scope ) {
        $scopes = self::current_scopes();
        if ( $scopes === null ) return true; // not token-auth; fall back to caps
        return in_array( $scope, $scopes, true )
            ? true
            : new WP_Error( 'fcp_scope_missing', 'Token missing scope: ' . $scope, [ 'status' => 403 ] );
    }

    /* -------------------------------------------------------------------
     * Token CRUD — admin REST endpoints.
     * Only manage_options users can hit these.
     * ----------------------------------------------------------------- */
    public static function register_routes() {
        register_rest_route( 'fcp/v1', '/tokens', [
            [
                'methods'  => WP_REST_Server::READABLE,
                'callback' => [ __CLASS__, 'rest_list' ],
                'permission_callback' => function () { return current_user_can( 'manage_options' ); },
            ],
            [
                'methods'  => WP_REST_Server::CREATABLE,
                'callback' => [ __CLASS__, 'rest_create' ],
                'permission_callback' => function () { return current_user_can( 'manage_options' ); },
            ],
        ] );
        register_rest_route( 'fcp/v1', '/tokens/(?P<id>\d+)', [
            'methods'  => WP_REST_Server::DELETABLE,
            'callback' => [ __CLASS__, 'rest_delete' ],
            'permission_callback' => function () { return current_user_can( 'manage_options' ); },
        ] );
        register_rest_route( 'fcp/v1', '/tokens/scopes', [
            'methods'  => WP_REST_Server::READABLE,
            'callback' => function () { return self::SCOPES; },
            'permission_callback' => function () { return current_user_can( 'manage_options' ); },
        ] );
    }

    public static function rest_list() {
        global $wpdb;
        $rows = $wpdb->get_results( "SELECT id, user_id, name, scopes, expires_at, last_used_at, last_used_ip, created_at FROM " . self::table() . " ORDER BY id DESC", ARRAY_A );
        return rest_ensure_response( $rows ?: [] );
    }

    public static function rest_create( $req ) {
        $body  = $req->get_json_params();
        $name  = isset( $body['name'] )  ? sanitize_text_field( (string) $body['name'] ) : '';
        $scopes= isset( $body['scopes'] ) && is_array( $body['scopes'] ) ? $body['scopes'] : [];
        $ttl   = isset( $body['ttl_days'] ) ? max( 0, (int) $body['ttl_days'] ) : 0;
        if ( $name === '' ) return new WP_Error( 'bad_input', 'name required', [ 'status' => 400 ] );
        $scopes = array_values( array_intersect( $scopes, array_keys( self::SCOPES ) ) );
        if ( ! $scopes ) return new WP_Error( 'bad_input', 'At least one scope required', [ 'status' => 400 ] );
        $token = self::TOKEN_PREFIX . wp_generate_password( 40, false, false );
        $hash  = hash( self::HASH_ALGO, $token );
        global $wpdb;
        $wpdb->insert( self::table(), [
            'user_id'    => get_current_user_id(),
            'name'       => $name,
            'token_hash' => $hash,
            'scopes'     => implode( ',', $scopes ),
            'expires_at' => $ttl ? gmdate( 'Y-m-d H:i:s', time() + $ttl * 86400 ) : null,
            'created_at' => current_time( 'mysql' ),
        ] );
        return rest_ensure_response( [
            'id'    => $wpdb->insert_id,
            'name'  => $name,
            'token' => $token,                              // <-- only time we ever return the plaintext
            'warning' => 'Copy this token now. It will not be shown again.',
            'scopes'=> $scopes,
        ] );
    }

    public static function rest_delete( $req ) {
        global $wpdb;
        $wpdb->delete( self::table(), [ 'id' => (int) $req['id'] ] );
        return rest_ensure_response( [ 'deleted' => true ] );
    }
}
