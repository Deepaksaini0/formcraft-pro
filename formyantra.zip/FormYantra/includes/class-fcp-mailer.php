<?php
/**
 * FormYantra - Built-in SMTP mailer.
 *
 * Hooks WordPress's PHPMailer instance (`phpmailer_init`) and routes
 * wp_mail() through whatever SMTP credentials the user has saved in
 * Email Settings — so the site can send mail directly to Gmail / SendGrid /
 * Mailgun / Brevo / Amazon SES / any custom SMTP without needing a
 * separate plugin like WP Mail SMTP.
 *
 * Runs at priority 99 so it overrides any SMTP plugin only when the
 * user has explicitly filled in FormYantra's SMTP fields; otherwise it
 * stays out of the way.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_Mailer {

    public function __construct() {
        add_action( 'phpmailer_init', [ $this, 'configure_smtp' ], 99 );
    }

    /**
     * Returns true when the user has filled in enough fields for us to
     * route mail directly through SMTP.
     */
    public static function is_configured() {
        $settings = get_option( 'fcp_settings', [] );
        $email    = isset( $settings['email'] ) ? $settings['email'] : [];
        return ! empty( $email['smtp_host'] ) && ! empty( $email['smtp_user'] );
    }

    /**
     * Configure the PHPMailer instance to use our saved SMTP credentials.
     *
     * @param PHPMailer|\PHPMailer\PHPMailer\PHPMailer $phpmailer
     */
    public function configure_smtp( $phpmailer ) {
        $settings = get_option( 'fcp_settings', [] );
        $email    = isset( $settings['email'] ) ? $settings['email'] : [];

        // Bail early if SMTP isn't configured — let WP defaults or a
        // separate SMTP plugin handle the send.
        if ( empty( $email['smtp_host'] ) || empty( $email['smtp_user'] ) ) {
            return;
        }

        $phpmailer->isSMTP();
        $phpmailer->Host       = trim( (string) $email['smtp_host'] );
        $phpmailer->Port       = ! empty( $email['smtp_port'] ) ? (int) $email['smtp_port'] : 587;
        $phpmailer->SMTPAuth   = true;
        $phpmailer->Username   = trim( (string) $email['smtp_user'] );
        $phpmailer->Password   = isset( $email['smtp_pass'] ) ? (string) $email['smtp_pass'] : '';

        $enc = isset( $email['encryption'] ) ? strtolower( $email['encryption'] ) : 'tls';
        if ( $enc === 'tls' || $enc === 'ssl' ) {
            $phpmailer->SMTPSecure = $enc;
        } else {
            $phpmailer->SMTPSecure = '';
            $phpmailer->SMTPAutoTLS = false;
        }

        // Apply From if configured (uses setFrom which also sets Sender,
        // improving deliverability for SPF-checked mailboxes like Gmail).
        if ( ! empty( $email['from_email'] ) && is_email( $email['from_email'] ) ) {
            try {
                $phpmailer->setFrom(
                    $email['from_email'],
                    ! empty( $email['from_name'] ) ? wp_strip_all_tags( $email['from_name'] ) : '',
                    false // don't auto-override later setFrom calls
                );
            } catch ( Exception $e ) {
                // Some PHPMailer versions throw on setFrom validation failures
                // — ignore silently, wp_mail will still surface the error.
            }
        }

        // Reasonable timeout so a misconfigured SMTP host doesn't hang
        // form submissions forever.
        $phpmailer->Timeout = 15;

        // Useful debug header for the email log when something goes wrong.
        if ( property_exists( $phpmailer, 'addCustomHeader' ) ) {
            // intentionally left blank — keep send anonymous
        }
    }
}
