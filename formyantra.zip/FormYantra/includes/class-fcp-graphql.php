<?php
/**
 * FormYantra — minimal GraphQL endpoint.
 *
 * Exposes a small schema covering the queries 95% of integrations need
 * without pulling in the full graphql-php library (which would balloon
 * the plugin by 1MB+). For richer needs the host can install WPGraphQL —
 * we register a bridge that re-exposes FormYantra data through that
 * plugin when it's active.
 *
 * Endpoint: POST /wp-json/fcp/v1/graphql
 * Auth:     Bearer fcp_pat_… token with the `graphql` scope, OR
 *           a logged-in admin (cookie / app password)
 *
 * Supported queries:
 *   query {
 *     forms(status: "active", limit: 20) {
 *       id title slug status submissions views createdAt
 *     }
 *     form(id: 42) {
 *       id title fieldCount
 *       steps { id title fields { id type label required } }
 *     }
 *     submissions(formId: 42, limit: 10, status: "new") {
 *       id formId data createdAt status
 *     }
 *     submission(id: 99) {
 *       id data createdAt name email
 *     }
 *     analytics(formId: 42) { views submissions conversionRate }
 *     me { id name capabilities }
 *   }
 *
 * Errors return { errors: [{ message, path }] } per GraphQL spec.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_GraphQL {

    public static function bootstrap() {
        add_action( 'rest_api_init', [ __CLASS__, 'register_route' ] );
    }

    public static function register_route() {
        register_rest_route( 'fcp/v1', '/graphql', [
            'methods'  => WP_REST_Server::CREATABLE,
            'callback' => [ __CLASS__, 'handle' ],
            'permission_callback' => [ __CLASS__, 'can_query' ],
        ] );
    }

    public static function can_query() {
        // Admin (manage_options) can always query — useful for the in-builder
        // explorer. PAT tokens need the `graphql` scope.
        if ( current_user_can( 'manage_options' ) ) return true;
        $scopes = class_exists( 'FCP_Tokens' ) ? FCP_Tokens::current_scopes() : null;
        return $scopes !== null && in_array( 'graphql', $scopes, true );
    }

    public static function handle( $req ) {
        $body  = $req->get_json_params();
        $query = isset( $body['query'] ) ? (string) $body['query'] : '';
        $vars  = isset( $body['variables'] ) && is_array( $body['variables'] ) ? $body['variables'] : [];
        if ( ! $query ) return self::error( 'Empty query' );

        try {
            $ast = self::parse( $query );
        } catch ( Exception $e ) {
            return self::error( 'Parse error: ' . $e->getMessage() );
        }
        $data   = [];
        $errors = [];
        foreach ( $ast as $field ) {
            try {
                $data[ $field['alias'] ] = self::resolve( $field, $vars );
            } catch ( Exception $e ) {
                $errors[] = [ 'message' => $e->getMessage(), 'path' => [ $field['alias'] ] ];
            }
        }
        $out = [ 'data' => $data ];
        if ( $errors ) $out['errors'] = $errors;
        return rest_ensure_response( $out );
    }

    /* ===================================================================
     * Tiny GraphQL parser.
     * Handles only the subset we expose: top-level query block + named
     * fields with key: value arguments + nested selection sets. Variables
     * are passed through as a separate map and substituted in argument
     * resolution.
     * =================================================================== */
    private static function parse( $query ) {
        // Strip the leading "query { … }" wrapper if present.
        $query = trim( $query );
        if ( preg_match( '/^(?:query|mutation|subscription)\b[^{]*\{(.*)\}\s*$/s', $query, $m ) ) {
            $body = $m[1];
        } elseif ( preg_match( '/^\{(.*)\}\s*$/s', $query, $m ) ) {
            $body = $m[1];
        } else {
            throw new Exception( 'expected { … }' );
        }
        return self::parse_selection_set( $body );
    }

    /**
     * Recursive descent over a selection set body. Returns an array of
     *   [ 'name' => …, 'alias' => …, 'args' => […], 'children' => […] ]
     */
    private static function parse_selection_set( $body ) {
        $tokens = self::tokenize( $body );
        $out    = [];
        $i      = 0;
        $n      = count( $tokens );
        while ( $i < $n ) {
            // Field name (possibly alias: name)
            $name  = $tokens[ $i++ ];
            $alias = $name;
            if ( $i < $n && $tokens[ $i ] === ':' ) {
                $i++; $name = $tokens[ $i++ ];
            }
            // Arguments?
            $args = [];
            if ( $i < $n && $tokens[ $i ] === '(' ) {
                $i++;
                while ( $i < $n && $tokens[ $i ] !== ')' ) {
                    $key = $tokens[ $i++ ];
                    if ( $tokens[ $i ] !== ':' ) throw new Exception( "missing ':' after $key" );
                    $i++;
                    $val = self::parse_value( $tokens[ $i++ ] );
                    $args[ $key ] = $val;
                    if ( $i < $n && $tokens[ $i ] === ',' ) $i++;
                }
                if ( $i < $n ) $i++; // skip ')'
            }
            // Selection set?
            $children = null;
            if ( $i < $n && $tokens[ $i ] === '{' ) {
                $i++;
                $depth = 1; $sub = '';
                while ( $i < $n && $depth > 0 ) {
                    if ( $tokens[ $i ] === '{' ) $depth++;
                    elseif ( $tokens[ $i ] === '}' ) { $depth--; if ( $depth === 0 ) { $i++; break; } }
                    $sub .= ( $sub === '' ? '' : ' ' ) . $tokens[ $i++ ];
                }
                $children = self::parse_selection_set( $sub );
            }
            $out[] = [ 'name' => $name, 'alias' => $alias, 'args' => $args, 'children' => $children ];
        }
        return $out;
    }

    private static function tokenize( $src ) {
        $tokens = [];
        $n = strlen( $src );
        $i = 0;
        while ( $i < $n ) {
            $c = $src[ $i ];
            if ( ctype_space( $c ) ) { $i++; continue; }
            if ( $c === ',' || $c === ':' || $c === '(' || $c === ')' || $c === '{' || $c === '}' ) {
                $tokens[] = $c; $i++; continue;
            }
            if ( $c === '"' ) {
                $j = $i + 1;
                while ( $j < $n && $src[ $j ] !== '"' ) $j++;
                $tokens[] = '"' . substr( $src, $i + 1, $j - $i - 1 ) . '"';
                $i = $j + 1; continue;
            }
            // Number or identifier
            $j = $i;
            while ( $j < $n && ! ctype_space( $src[ $j ] ) && strpos( ',:(){}', $src[ $j ] ) === false ) $j++;
            $tokens[] = substr( $src, $i, $j - $i );
            $i = $j;
        }
        return $tokens;
    }

    private static function parse_value( $tok ) {
        if ( $tok === 'true'  ) return true;
        if ( $tok === 'false' ) return false;
        if ( $tok === 'null'  ) return null;
        if ( $tok !== '' && $tok[0] === '"' ) return substr( $tok, 1, -1 );
        if ( is_numeric( $tok ) ) return strpos( $tok, '.' ) !== false ? (float) $tok : (int) $tok;
        return $tok; // identifier / enum
    }

    /* ===================================================================
     * Resolvers — one per top-level field name.
     * =================================================================== */
    private static function resolve( $node, $vars ) {
        $args = $node['args'];
        switch ( $node['name'] ) {
            case 'forms':       return self::resolve_forms( $args, $node['children'] );
            case 'form':        return self::resolve_form( $args, $node['children'] );
            case 'submissions': return self::resolve_submissions( $args, $node['children'] );
            case 'submission':  return self::resolve_submission( $args, $node['children'] );
            case 'analytics':   return self::resolve_analytics( $args );
            case 'me':          return self::resolve_me();
        }
        throw new Exception( 'Unknown field: ' . $node['name'] );
    }

    private static function resolve_forms( $args, $children ) {
        self::require_scope( 'forms:read', 'manage_options' );
        $limit  = isset( $args['limit'] )  ? min( 100, max( 1, (int) $args['limit'] ) ) : 20;
        $status = isset( $args['status'] ) ? sanitize_text_field( (string) $args['status'] ) : '';
        global $wpdb;
        $where  = $status ? $wpdb->prepare( 'WHERE status = %s', $status ) : '';
        $rows   = $wpdb->get_results( "SELECT * FROM " . FCP_DB::forms_table() . " $where ORDER BY id DESC LIMIT $limit", ARRAY_A );
        return array_map( function ( $r ) use ( $children ) { return self::shape_form( FCP_DB::hydrate_form( $r ), $children ); }, $rows ?: [] );
    }

    private static function resolve_form( $args, $children ) {
        self::require_scope( 'forms:read', 'manage_options' );
        $id = isset( $args['id'] ) ? (int) $args['id'] : 0;
        if ( ! $id ) throw new Exception( 'id required' );
        $form = FCP_DB::get_form( $id );
        if ( ! $form ) throw new Exception( 'Form not found' );
        return self::shape_form( $form, $children );
    }

    private static function shape_form( $form, $children ) {
        if ( ! $form ) return null;
        $field_count = 0;
        foreach ( ( $form['steps'] ?? [] ) as $s ) $field_count += count( $s['fields'] ?? [] );
        $shape = [
            'id'          => (int) ( $form['id'] ?? 0 ),
            'title'       => (string) ( $form['title'] ?? '' ),
            'slug'        => (string) ( $form['slug'] ?? '' ),
            'status'      => (string) ( $form['status'] ?? '' ),
            'submissions' => (int) ( $form['submissions'] ?? 0 ),
            'views'       => (int) ( $form['views'] ?? 0 ),
            'fieldCount'  => $field_count,
            'createdAt'   => (string) ( $form['createdAt'] ?? $form['created_at'] ?? '' ),
            'updatedAt'   => (string) ( $form['updatedAt'] ?? $form['updated_at'] ?? '' ),
            'steps'       => array_map( function ( $s ) {
                return [
                    'id'     => (string) ( $s['id'] ?? '' ),
                    'title'  => (string) ( $s['title'] ?? '' ),
                    'fields' => array_map( function ( $f ) {
                        return [
                            'id'       => (string) ( $f['id'] ?? '' ),
                            'type'     => (string) ( $f['type'] ?? '' ),
                            'label'    => (string) ( $f['label'] ?? '' ),
                            'required' => (bool) ( $f['required'] ?? false ),
                        ];
                    }, $s['fields'] ?? [] ),
                ];
            }, $form['steps'] ?? [] ),
        ];
        return self::project( $shape, $children );
    }

    private static function resolve_submissions( $args, $children ) {
        self::require_scope( 'submissions:read', 'edit_posts' );
        $form_id = isset( $args['formId'] ) ? (int) $args['formId'] : 0;
        $limit   = isset( $args['limit'] )  ? min( 100, max( 1, (int) $args['limit'] ) ) : 20;
        $status  = isset( $args['status'] ) ? sanitize_text_field( (string) $args['status'] ) : '';
        global $wpdb;
        $clauses = [];
        if ( $form_id ) $clauses[] = $wpdb->prepare( 'form_id = %d', $form_id );
        if ( $status )  $clauses[] = $wpdb->prepare( 'status = %s', $status );
        $where = $clauses ? 'WHERE ' . implode( ' AND ', $clauses ) : '';
        $rows  = $wpdb->get_results( "SELECT * FROM " . FCP_DB::subs_table() . " $where ORDER BY id DESC LIMIT $limit", ARRAY_A );
        return array_map( function ( $r ) use ( $children ) { return self::shape_submission( $r, $children ); }, $rows ?: [] );
    }

    private static function resolve_submission( $args, $children ) {
        self::require_scope( 'submissions:read', 'edit_posts' );
        $id = isset( $args['id'] ) ? (int) $args['id'] : 0;
        if ( ! $id ) throw new Exception( 'id required' );
        $row = FCP_DB::get_submission( $id );
        if ( ! $row ) throw new Exception( 'Submission not found' );
        return self::shape_submission( $row, $children );
    }

    private static function shape_submission( $row, $children ) {
        $data = is_string( $row['data'] ?? '' ) ? json_decode( $row['data'], true ) : ( $row['data'] ?? [] );
        if ( ! is_array( $data ) ) $data = [];
        $shape = [
            'id'        => (int) ( $row['id'] ?? 0 ),
            'formId'    => (int) ( $row['form_id'] ?? 0 ),
            'data'      => $data,
            'name'      => (string) ( $row['submitter_name']  ?? '' ),
            'email'     => (string) ( $row['submitter_email'] ?? '' ),
            'status'    => (string) ( $row['status']  ?? '' ),
            'createdAt' => (string) ( $row['created_at'] ?? '' ),
        ];
        return self::project( $shape, $children );
    }

    private static function resolve_analytics( $args ) {
        self::require_scope( 'analytics:read', 'edit_posts' );
        $form_id = isset( $args['formId'] ) ? (int) $args['formId'] : 0;
        if ( ! $form_id ) throw new Exception( 'formId required' );
        $form = FCP_DB::get_form( $form_id );
        if ( ! $form ) throw new Exception( 'Form not found' );
        $views = (int) ( $form['views'] ?? 0 );
        $subs  = (int) ( $form['submissions'] ?? 0 );
        return [
            'views'           => $views,
            'submissions'     => $subs,
            'conversionRate'  => $views > 0 ? round( ( $subs / $views ) * 100, 2 ) : 0.0,
        ];
    }

    private static function resolve_me() {
        $u = wp_get_current_user();
        return [
            'id'           => (int) $u->ID,
            'name'         => (string) $u->display_name,
            'capabilities' => array_keys( array_filter( (array) $u->allcaps ) ),
        ];
    }

    /**
     * Project a fully-shaped object down to just the requested fields.
     * When children is null (no selection set), returns the full shape.
     */
    private static function project( $shape, $children ) {
        if ( ! $children ) return $shape;
        $out = [];
        foreach ( $children as $c ) {
            $name = $c['name'];
            if ( ! array_key_exists( $name, $shape ) ) continue;
            $val = $shape[ $name ];
            if ( $c['children'] && is_array( $val ) ) {
                if ( self::is_assoc( $val ) ) {
                    $out[ $c['alias'] ] = self::project( $val, $c['children'] );
                } else {
                    $out[ $c['alias'] ] = array_map( function ( $item ) use ( $c ) {
                        return is_array( $item ) ? self::project( $item, $c['children'] ) : $item;
                    }, $val );
                }
            } else {
                $out[ $c['alias'] ] = $val;
            }
        }
        return $out;
    }

    private static function is_assoc( $arr ) {
        return is_array( $arr ) && ( array_keys( $arr ) !== range( 0, count( $arr ) - 1 ) );
    }

    private static function require_scope( $scope, $fallback_cap ) {
        $scopes = class_exists( 'FCP_Tokens' ) ? FCP_Tokens::current_scopes() : null;
        if ( $scopes === null ) {
            // Not token-auth — fall back to standard cap check.
            if ( ! current_user_can( $fallback_cap ) ) throw new Exception( 'Forbidden' );
            return;
        }
        if ( ! in_array( $scope, $scopes, true ) ) throw new Exception( 'Token missing scope: ' . $scope );
    }

    private static function error( $msg ) {
        return rest_ensure_response( [ 'errors' => [ [ 'message' => $msg ] ] ] );
    }
}
