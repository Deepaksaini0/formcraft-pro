<?php
/**
 * FormYantra - Admin menu + page renderer.
 *
 * Each menu entry maps to one of the prebuilt HTML "views" shipped in
 * /admin/views. The view is loaded inside an iframe-like wrapper so the
 * existing standalone UI (sidebar + topbar + theme) keeps working while
 * the plugin lives inside wp-admin.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_Admin {

    /** @var string Required capability for the menu. */
    private $cap = 'manage_options';

    public function __construct() {
        add_action( 'admin_menu',           [ $this, 'register_menu' ] );
        add_action( 'admin_enqueue_scripts',[ $this, 'enqueue_admin_assets' ] );
        add_filter( 'admin_body_class',     [ $this, 'admin_body_class' ] );
        add_action( 'admin_init',           [ $this, 'maybe_serve_view' ] );
        // v2.69.8 — Heal stale slugs + refresh rewrite rules the moment the
        // admin lands on any FormCraft page, so the Embed modal URLs never
        // point to the old auto-slug after a rename.
        add_action( 'admin_init',           [ $this, 'maybe_heal_slugs' ] );
    }

    /**
     * v2.69.8 — Placeholder-slug healer. Runs at most once per hour per admin
     * user via a transient. Walks the forms table, regenerates any slug that
     * still looks like the default "Untitled Form" auto-slug ("untitled",
     * "untitled-form", "untitled-form-2") for a form whose title is now
     * meaningful. Any rewrite of a slug also queues a rewrite-rule flush so
     * the pretty URL updates without the admin visiting Permalinks manually.
     */
    public function maybe_heal_slugs() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        if ( ! isset( $_GET['page'] ) || strpos( sanitize_key( $_GET['page'] ), 'formcraft-pro' ) !== 0 ) return;
        if ( ! class_exists( 'FCP_DB' ) ) return;

        global $wpdb;
        $table = FCP_DB::forms_table();
        // Only pull rows whose slug LOOKS suspect — placeholder / legacy /
        // empty. Real slugs skip the write path entirely, so this stays
        // cheap even on installs with hundreds of forms.
        $rows  = $wpdb->get_results(
            "SELECT id, title, slug FROM $table
             WHERE slug IS NULL OR slug = ''
                OR slug = 'untitled' OR slug LIKE 'untitled-%'
                OR slug REGEXP '^form[_-][A-Za-z0-9]{6}$'",
            ARRAY_A
        );
        $changed = false;
        foreach ( (array) $rows as $r ) {
            $slug           = (string) ( $r['slug'] ?? '' );
            $title          = (string) ( $r['title'] ?? '' );
            $is_legacy      = (bool) preg_match( '/^form[_-][A-Za-z0-9]{6}$/', $slug );
            $is_placeholder = (bool) preg_match( '/^untitled(-form)?(-\d+)?$/', $slug );
            $title_is_real  = $title && strcasecmp( $title, 'Untitled' ) !== 0
                                     && strcasecmp( $title, 'Untitled Form' ) !== 0;
            if ( empty( $slug ) || $is_legacy || ( $is_placeholder && $title_is_real ) ) {
                $new = FCP_DB::build_unique_slug( $title ?: 'form', (int) $r['id'] );
                if ( $new && $new !== $slug ) {
                    $wpdb->update( $table, [ 'slug' => $new ], [ 'id' => (int) $r['id'] ] );
                    FCP_DB::bust_form_cache( [ 'id' => $r['id'], 'slug' => $slug ] );
                    FCP_DB::bust_form_cache( [ 'id' => $r['id'], 'slug' => $new ] );
                    $changed = true;
                }
            }
        }
        if ( $changed ) {
            update_option( 'fcp_needs_rewrite_flush', 1 );
        }

        // v2.69.10 — While we're here, also reconcile the per-form
        // submissions counter. Older versions never decremented on delete,
        // so admins saw "Forms: 7 subs" but "Submissions: 1 entry" once
        // they'd cleaned up test data. Rebased against the real row count
        // (excluding spam + abandoned, matching the All Entries view).
        // Throttled to once per hour per admin user so the extra JOIN
        // doesn't run on every wp-admin page hit.
        $recount_key = 'fcp_recount_' . get_current_user_id();
        if ( ! get_transient( $recount_key ) ) {
            set_transient( $recount_key, 1, HOUR_IN_SECONDS );
            FCP_DB::recount_all_form_submissions();
        }

        // v2.70.9 — Back-fill payment_amount for paid submissions that were
        // manually verified before v2.70.9 (never captured the price). Walks
        // each such row, looks up the picked Product / Pricing option in the
        // form config, and writes the computed amount back. Throttled — runs
        // once per day per admin.
        $backfill_key = 'fcp_amount_backfill_' . get_current_user_id();
        if ( ! get_transient( $backfill_key ) ) {
            set_transient( $backfill_key, 1, DAY_IN_SECONDS );
            self::backfill_payment_amounts();
        }
    }

    /**
     * v2.70.9 — Compute + save payment_amount for any 'paid' submission
     * that currently has 0 / NULL. Uses the form's field configs to look
     * up prices — same logic as verify_payment + GST invoice.
     */
    public static function backfill_payment_amounts() {
        global $wpdb;
        if ( ! class_exists( 'FCP_DB' ) || ! class_exists( 'FCP_REST' ) ) return;
        $subs_t  = FCP_DB::subs_table();
        $rows = $wpdb->get_results(
            "SELECT id, form_id, data, payment_currency
             FROM $subs_t
             WHERE payment_status = 'paid'
               AND ( payment_amount IS NULL OR payment_amount = 0 )
             LIMIT 500",
            ARRAY_A
        );
        if ( ! $rows ) return;

        $form_cache = [];
        foreach ( $rows as $r ) {
            $fid = (int) $r['form_id'];
            if ( ! isset( $form_cache[ $fid ] ) ) $form_cache[ $fid ] = FCP_DB::get_form( $fid );
            $form = $form_cache[ $fid ];
            if ( ! $form ) continue;
            $data = json_decode( $r['data'] ?? '', true );
            if ( ! is_array( $data ) ) continue;
            $amt = FCP_REST::compute_amount_from_form_data( $form, $data );
            if ( $amt <= 0 ) continue;
            $wpdb->update(
                $subs_t,
                [
                    'payment_amount'   => $amt,
                    'payment_currency' => $r['payment_currency'] ?: ( $form['settings']['currency'] ?? 'INR' ),
                ],
                [ 'id' => (int) $r['id'] ]
            );
        }
    }

    public function register_menu() {
        // Unread submissions become a count bubble on both the top-level
        // menu and the Submissions submenu — matches WP core's "Comments
        // pending moderation" pattern (.awaiting-mod). It's recomputed on
        // every admin page render, so when the admin opens a submission
        // and the row flips to is_read=1, the badge drops on next nav.
        $unread = $this->unread_submissions_count();
        $bubble = $unread > 0
            ? ' <span class="awaiting-mod count-' . esc_attr( (string) $unread ) . '"><span class="pending-count" aria-hidden="true">' . esc_html( number_format_i18n( $unread ) ) . '</span><span class="screen-reader-text">' . esc_html( sprintf( _n( '%s unread submission', '%s unread submissions', $unread, 'formcraft-pro' ), number_format_i18n( $unread ) ) ) . '</span></span>'
            : '';

        // v2.72.13 — Stylised FormYantra brand mark for the wp-admin sidebar.
        // Silhouette of the wordmark's logo glyph: rounded "F" bracket on the
        // left with three checklist rows inside, a diagonal accent on the
        // right, and two small floating squares — all in a single monochrome
        // path so WP's admin colour scheme can recolour it cleanly.
        $icon_svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="black">'
                  . '<path d="M3 3.5A1.5 1.5 0 0 1 4.5 2H11v2H5v12H3V3.5z"/>'
                  . '<rect x="6.5" y="6"  width="6" height="1.6" rx="0.6"/>'
                  . '<rect x="6.5" y="9"  width="6" height="1.6" rx="0.6"/>'
                  . '<rect x="6.5" y="12" width="4" height="1.6" rx="0.6"/>'
                  . '<path d="M14.3 5.2l2.2-0.7-6 11.5-2.2 0.7z"/>'
                  . '<rect x="15" y="2"   width="2" height="2" rx="0.3"/>'
                  . '<rect x="17" y="4.5" width="1.5" height="1.5" rx="0.3"/>'
                  . '</svg>';
        $icon_uri = 'data:image/svg+xml;base64,' . base64_encode( $icon_svg );

        add_menu_page(
            __( 'FormYantra', 'formcraft-pro' ),
            __( 'FormYantra', 'formcraft-pro' ) . $bubble,
            $this->cap,
            'formcraft-pro',
            [ $this, 'render_page' ],
            $icon_uri,
            26
        );

        $pages = [
            'formcraft-pro'             => __( 'Dashboard',         'formcraft-pro' ),
            'formcraft-pro-forms'       => __( 'Forms',             'formcraft-pro' ),
            'formcraft-pro-new-form'    => __( 'New Form',          'formcraft-pro' ),
            'formcraft-pro-templates'   => __( 'Templates',         'formcraft-pro' ),
            'formcraft-pro-migrate'     => __( 'Import & Migration','formcraft-pro' ),
            'formcraft-pro-submissions' => __( 'Submissions',       'formcraft-pro' ) . $bubble,
            'formcraft-pro-abandoned'   => __( 'Abandoned Entries', 'formcraft-pro' ),
            'formcraft-pro-form-users'  => __( 'Form Users',        'formcraft-pro' ),
            'formcraft-pro-analytics'   => __( 'Analytics',         'formcraft-pro' ),
            'formcraft-pro-recaptcha'   => __( 'reCAPTCHA',         'formcraft-pro' ),
            'formcraft-pro-email'       => __( 'Email Settings',    'formcraft-pro' ),
            'formcraft-pro-payments'    => __( 'Payment Gateways',  'formcraft-pro' ),
            'formcraft-pro-pay-analytics'=> __( 'Payment Analytics', 'formcraft-pro' ),
            'formcraft-pro-coupons'     => __( 'Coupons',           'formcraft-pro' ),
            'formcraft-pro-integrations'=> __( 'Integrations',      'formcraft-pro' ),
            // Ad Platforms — only registered when at least one ad-platform /
            // social-posting / messaging integration is enabled. The page
            // self-handles the empty state, so even if WP caches the menu
            // briefly after admin disables everything, nothing breaks.
            ] + ( self::any_ad_platform_enabled() ? [ 'formcraft-pro-ad-platforms' => __( 'Ad Platforms', 'formcraft-pro' ) ] : [] ) + [
            'formcraft-pro-settings'    => __( 'Settings',          'formcraft-pro' ),
            'formcraft-pro-users'       => __( 'Team & Roles',      'formcraft-pro' ),
            'formcraft-pro-backup'      => __( 'Backup & Restore', 'formcraft-pro' ),
            'formcraft-pro-security'    => __( 'Security &amp; Privacy', 'formcraft-pro' ),
            'formcraft-pro-saas'        => __( 'SaaS &amp; White-label', 'formcraft-pro' ),
            'formcraft-pro-help'        => __( 'Help &amp; Diagnostics', 'formcraft-pro' ),
            'formcraft-pro-docs'        => __( 'Documentation',     'formcraft-pro' ),
        ];

        foreach ( $pages as $slug => $label ) {
            add_submenu_page(
                'formcraft-pro',
                // Page <title> — strip the bubble HTML so it doesn't
                // render literally in the browser tab.
                wp_strip_all_tags( $label ),
                $label,
                $this->cap,
                $slug,
                [ $this, 'render_page' ]
            );
        }
    }

    /**
     * Returns true when at least one Ad / Social / Messaging integration
     * has its `enabled` flag on in fcp_settings.ad_platforms. Used to
     * auto-show the dedicated "Ad Platforms" menu entry only when the
     * admin has actually wired one up — keeps the sidebar lean otherwise.
     */
    private static function any_ad_platform_enabled() {
        $settings = get_option( 'fcp_settings', [] );
        $ad       = isset( $settings['ad_platforms'] ) && is_array( $settings['ad_platforms'] )
            ? $settings['ad_platforms'] : [];
        foreach ( $ad as $cfg ) {
            if ( is_array( $cfg ) && ! empty( $cfg['enabled'] ) ) return true;
        }
        return false;
    }

    /**
     * Count submissions that are neither spam nor read yet.
     * Returns 0 quickly when the table doesn't exist (fresh activation race).
     */
    private function unread_submissions_count() {
        global $wpdb;
        if ( ! class_exists( 'FCP_DB' ) ) return 0;
        $table = FCP_DB::subs_table();
        $exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
        if ( ! $exists ) return 0;
        // Exclude abandoned partial submissions — those have their own
        // dedicated admin page and shouldn't inflate the "unread" badge
        // on the main Submissions menu entry.
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE is_read = 0 AND is_spam = 0 AND is_abandoned = 0" );
    }

    /**
     * Map admin page slug -> HTML view file in /admin/views.
     */
    private function slug_to_view( $slug ) {
        $map = [
            'formcraft-pro'              => 'dashboard.html',
            'formcraft-pro-forms'        => 'forms.html',
            'formcraft-pro-new-form'     => 'form-builder.html?new=1',
            'formcraft-pro-templates'    => 'templates.html',
            'formcraft-pro-migrate'      => 'migrate.html',
            'formcraft-pro-submissions'  => 'submissions.html',
            'formcraft-pro-abandoned'    => 'abandoned.html',
            'formcraft-pro-form-users'   => 'form-users.html',
            'formcraft-pro-analytics'    => 'analytics.html',
            'formcraft-pro-recaptcha'    => 'recaptcha.html',
            'formcraft-pro-email'        => 'email-settings.html',
            'formcraft-pro-payments'     => 'payment-gateways.html',
            'formcraft-pro-pay-analytics'=> 'payment-analytics.html',
            'formcraft-pro-coupons'      => 'coupons.html',
            'formcraft-pro-integrations' => 'integrations.html',
            'formcraft-pro-ad-platforms' => 'ad-platforms.html',
            'formcraft-pro-settings'     => 'settings.html',
            'formcraft-pro-users'        => 'users.html',
            'formcraft-pro-backup'       => 'backup.html',
            'formcraft-pro-security'     => 'security.html',
            'formcraft-pro-saas'         => 'saas.html',
            'formcraft-pro-help'         => 'help.html',
            'formcraft-pro-docs'         => 'docs.html',
        ];
        return $map[ $slug ] ?? 'dashboard.html';
    }

    /**
     * Render the wp-admin page (an iframe to the bundled HTML view).
     */
    public function render_page() {
        $slug = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : 'formcraft-pro';
        $view = $this->slug_to_view( $slug );

        // Forward arbitrary query args (e.g. ?id=42) into the iframe URL.
        $extra = $_GET;
        unset( $extra['page'] );
        $passthrough = $extra ? '&' . http_build_query( $extra ) : '';

        // Build the iframe src: serve our static HTML through admin-ajax (so it
        // inherits the WP environment) rather than directly hitting the file URL,
        // which avoids any auth / wp-content URL quirks on some hosts.
        $src_url = add_query_arg(
            [
                'action'  => 'fcp_view',
                'view'    => $view,
                '_wpnonce'=> wp_create_nonce( 'fcp_view' ),
            ],
            admin_url( 'admin-ajax.php' )
        );
        ?>
        <div class="wrap fcp-iframe-wrap">
            <iframe id="fcp-frame"
                    src="<?php echo esc_url( $src_url . '&p=' . rawurlencode( $passthrough ) ); ?>"
                    style="width:100%;border:0;background:transparent;display:block;"
                    title="<?php esc_attr_e( 'FormYantra', 'formcraft-pro' ); ?>"></iframe>
        </div>
        <style>
            #wpcontent { padding-left: 0 !important; }
            #wpbody-content { padding-bottom: 0 !important; }
            .fcp-iframe-wrap { margin: 0; padding: 0; }
            .auto-fold #wpcontent, .folded #wpcontent { padding-left: 0 !important; }
            @media (max-width: 782px) {
                #wpbody-content { padding-bottom: 0 !important; }
            }
        </style>
        <script>
        // v2.69.3 — Auto-size the iframe to its ACTUAL content height, always.
        // Never cap at viewport — that produced two scrollbars (iframe + wp-admin).
        // Only wp-admin scrolls. The internal sticky sidebar effectively becomes
        // static (no scroll context inside the iframe), which is the trade-off
        // the user asked for.
        (function () {
            var f = document.getElementById('fcp-frame');
            if (!f) return;
            var last = 0;
            function fit() {
                var h = Math.max(400, window.innerHeight - 32); // fallback
                try {
                    var doc = f.contentWindow.document;
                    if (doc && doc.body) {
                        h = Math.max(400,
                            doc.documentElement.scrollHeight,
                            doc.body.scrollHeight,
                            doc.documentElement.offsetHeight,
                            doc.body.offsetHeight
                        );
                    }
                } catch (e) { /* cross-origin or too early — keep fallback */ }
                if (h !== last) { f.style.height = h + 'px'; last = h; }
            }
            f.addEventListener('load', function () {
                fit();
                try {
                    var doc = f.contentWindow.document;
                    if (window.MutationObserver) {
                        new MutationObserver(fit).observe(doc.body, {
                            childList: true, subtree: true, attributes: true, characterData: false
                        });
                    }
                    if (window.ResizeObserver) {
                        new ResizeObserver(fit).observe(doc.body);
                    }
                } catch (e) {}
                setTimeout(fit, 100);
                setTimeout(fit, 500);
                setTimeout(fit, 1500);
            });
            window.addEventListener('resize', fit);
            fit();
        })();
        </script>
        <?php
    }

    /**
     * Stream the requested view file through admin-ajax so wp-admin can
     * sandbox it within an iframe without exposing direct file URLs.
     */
    public function maybe_serve_view() {
        if ( ! isset( $_GET['action'] ) || $_GET['action'] !== 'fcp_view' ) {
            return;
        }
        if ( ! current_user_can( $this->cap ) ) {
            wp_die( 'Forbidden', 'Forbidden', [ 'response' => 403 ] );
        }
        check_admin_referer( 'fcp_view' );

        $view = isset( $_GET['view'] ) ? sanitize_text_field( wp_unslash( $_GET['view'] ) ) : 'dashboard.html';
        // Allow a `?id=...` style passthrough after the file name (templates.html?cat=X).
        if ( strpos( $view, '?' ) !== false ) {
            list( $view, $qs ) = explode( '?', $view, 2 );
        } else {
            $qs = '';
        }
        $view = basename( $view );
        $allowed = [
            'dashboard.html','forms.html','form-builder.html','preview.html',
            'submissions.html','submission-detail.html','analytics.html',
            'settings.html','email-settings.html','recaptcha.html',
            'integrations.html','users.html','templates.html','docs.html',
            'payment-gateways.html','coupons.html','form-users.html',
            'abandoned.html','migrate.html','ad-platforms.html',
            'security.html',
            'saas.html',
            'help.html',
            'backup.html',
            'payment-analytics.html',
        ];
        if ( ! in_array( $view, $allowed, true ) ) {
            wp_die( 'Unknown view', 'Not found', [ 'response' => 404 ] );
        }

        // Build full URL the iframe will load. We just redirect to the
        // bundled HTML — the file lives on the same origin so cookies and
        // localStorage continue to work.
        $url = FCP_URL . $view;
        if ( ! empty( $_GET['p'] ) ) {
            $pass = trim( wp_unslash( $_GET['p'] ), '&?' );
            if ( $pass !== '' ) {
                $url .= ( strpos( $view, '?' ) === false ? '?' : '&' ) . $pass;
            }
        }
        if ( $qs ) {
            $url .= ( strpos( $url, '?' ) === false ? '?' : '&' ) . $qs;
        }

        // Inject the REST API base + nonce + current user info so the
        // iframe can swap from localStorage to live WP storage, clear
        // any demo seed data, and identify the currently-logged-in user
        // (no separate FormCraft login required — WordPress is the auth).
        $current   = wp_get_current_user();
        $user_name = $current && $current->exists()
            ? ( $current->display_name ?: $current->user_login )
            : 'Administrator';
        $user_role = ( $current && $current->exists() && ! empty( $current->roles ) )
            ? ucwords( str_replace( '_', ' ', $current->roles[0] ) )
            : 'Administrator';

        $url = add_query_arg( [
            'wp_rest'       => rawurlencode( esc_url_raw( rest_url( 'formcraft/v1/' ) ) ),
            'wp_nonce'      => wp_create_nonce( 'wp_rest' ),
            'wp_user'       => '1',
            'wp_user_id'    => $current ? (int) $current->ID : 0,
            'wp_user_name'  => rawurlencode( $user_name ),
            'wp_user_email' => rawurlencode( $current ? $current->user_email : '' ),
            'wp_user_role'  => rawurlencode( $user_role ),
            // v2.72.11 — Plugin base URL, needed by the iframe UI to load
            // brand assets (FormYantra logo, favicons) since the iframe
            // lives at the plugin path but referenced files are relative.
            'wp_plugin_url' => rawurlencode( FCP_URL ),
            // Cache-bust by version. Browsers cache HTML aggressively; the
            // version+timestamp combo forces a fresh disk-cache lookup on
            // every plugin update AND every page load, eliminating the
            // "I upgraded but still see old UI" class of bug.
            'fcpv'          => FCP_VERSION,
            'fcpt'          => time(),
        ], $url );

        wp_redirect( $url );
        exit;
    }

    public function enqueue_admin_assets( $hook ) {
        // Only on our pages
        if ( strpos( $hook, 'formcraft-pro' ) === false ) {
            return;
        }
        // Tiny CSS to keep the admin chrome out of the way.
        wp_add_inline_style( 'wp-admin', '#wpcontent{padding-left:0!important;}#wpfooter{display:none!important;}' );
    }

    public function admin_body_class( $classes ) {
        if ( isset( $_GET['page'] ) && strpos( $_GET['page'], 'formcraft-pro' ) === 0 ) {
            $classes .= ' fcp-admin ';
        }
        return $classes;
    }
}
