<?php
/**
 * FormYantra — Form Users.
 *
 * Self-contained user store independent of WordPress's wp_users table.
 * Used when a form is configured with the "Form User" After-Submit actions:
 * Register, Login, Request password reset (via OTP), Reset password.
 *
 * Passwords are hashed with PHP's password_hash() (bcrypt). Reset codes
 * are short-lived numeric OTPs sent over email + stored hashed in the
 * reset_code column. The session cookie is HttpOnly + Secure where TLS
 * is available; it's a signed payload (sha1_hmac) verified against the
 * user's password hash, so password changes invalidate every active
 * session automatically.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FCP_Users {

    const COOKIE       = 'fcp_user_session';
    const COOKIE_TTL   = 30 * DAY_IN_SECONDS;
    const RESET_TTL    = 15 * MINUTE_IN_SECONDS;
    const MAX_FAILS    = 5;
    const LOCK_TTL     = 15 * MINUTE_IN_SECONDS;

    /* -----------------------------------------------------------
     * Create
     * -------------------------------------------------------- */
    public static function create( $args ) {
        global $wpdb;
        $email = isset( $args['email'] ) ? sanitize_email( $args['email'] ) : '';
        $pass  = isset( $args['password'] ) ? (string) $args['password'] : '';
        if ( ! is_email( $email ) ) {
            return new WP_Error( 'fcp_users_bad_email', 'Please enter a valid email address.' );
        }
        if ( strlen( $pass ) < 8 ) {
            return new WP_Error( 'fcp_users_weak_pass', 'Password must be at least 8 characters.' );
        }
        $existing = self::find_by_email( $email );
        if ( $existing ) {
            return new WP_Error( 'fcp_users_exists', 'An account already exists with that email.' );
        }
        $row = [
            'email'              => $email,
            'password_hash'      => password_hash( $pass, PASSWORD_DEFAULT ),
            'display_name'       => sanitize_text_field( $args['display_name'] ?? '' ),
            'phone'              => sanitize_text_field( $args['phone'] ?? '' ),
            'status'             => 'active',
            'registered_form_id' => isset( $args['form_id'] ) ? (int) $args['form_id'] : null,
            'meta'               => wp_json_encode( is_array( $args['meta'] ?? null ) ? $args['meta'] : [] ),
            'created_at'         => current_time( 'mysql' ),
            'updated_at'         => current_time( 'mysql' ),
        ];
        $ok = $wpdb->insert( FCP_DB::users_table(), $row );
        if ( ! $ok ) {
            return new WP_Error( 'fcp_users_db', 'Could not create account: ' . $wpdb->last_error );
        }
        return (int) $wpdb->insert_id;
    }

    /* -----------------------------------------------------------
     * Authenticate
     * -------------------------------------------------------- */
    public static function authenticate( $email, $password, $ip = '' ) {
        $email = sanitize_email( $email );
        if ( ! is_email( $email ) || $password === '' ) {
            return new WP_Error( 'fcp_users_missing', 'Email and password are both required.' );
        }
        // Brute-force gate per (email, ip)
        $lock_key = 'fcp_user_fails_' . md5( strtolower( $email ) . '|' . $ip );
        $fails = (int) get_transient( $lock_key );
        if ( $fails >= self::MAX_FAILS ) {
            return new WP_Error( 'fcp_users_locked', 'Too many failed attempts. Try again in 15 minutes.' );
        }
        $user = self::find_by_email( $email );
        if ( ! $user || ! password_verify( $password, $user['password_hash'] ) ) {
            set_transient( $lock_key, $fails + 1, self::LOCK_TTL );
            return new WP_Error( 'fcp_users_bad_creds', 'Incorrect email or password.' );
        }
        if ( $user['status'] !== 'active' ) {
            return new WP_Error( 'fcp_users_inactive', 'This account is not active. Contact support.' );
        }
        // Successful login — clear lockout + bump counters.
        delete_transient( $lock_key );
        global $wpdb;
        $wpdb->update( FCP_DB::users_table(), [
            'login_count'   => ( (int) $user['login_count'] ) + 1,
            'last_login_at' => current_time( 'mysql' ),
            'last_login_ip' => substr( $ip, 0, 64 ),
            'updated_at'    => current_time( 'mysql' ),
        ], [ 'id' => (int) $user['id'] ] );
        return $user;
    }

    /* -----------------------------------------------------------
     * Find
     * -------------------------------------------------------- */
    public static function find_by_email( $email ) {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . FCP_DB::users_table() . " WHERE email = %s LIMIT 1",
            sanitize_email( $email )
        ), ARRAY_A );
        return $row ?: null;
    }
    public static function find_by_id( $id ) {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . FCP_DB::users_table() . " WHERE id = %d LIMIT 1",
            (int) $id
        ), ARRAY_A );
        return $row ?: null;
    }

    /* -----------------------------------------------------------
     * Password reset (OTP via email)
     * -------------------------------------------------------- */
    public static function request_password_reset( $email, $form_title = '' ) {
        $user = self::find_by_email( $email );
        if ( ! $user ) {
            // Generic message so attackers can't probe for valid emails.
            return [ 'sent' => true, 'message' => 'If that email is registered, a reset code is on its way.' ];
        }
        // 6-digit numeric code, stored hashed so a DB leak doesn't reveal it.
        $code      = str_pad( (string) wp_rand( 0, 999999 ), 6, '0', STR_PAD_LEFT );
        $code_hash = wp_hash( $code );
        $expires   = gmdate( 'Y-m-d H:i:s', time() + self::RESET_TTL );
        global $wpdb;
        $wpdb->update( FCP_DB::users_table(), [
            'reset_code'       => $code_hash,
            'reset_expires_at' => $expires,
            'updated_at'       => current_time( 'mysql' ),
        ], [ 'id' => (int) $user['id'] ] );

        // Email the plaintext code
        $title   = $form_title ?: get_bloginfo( 'name' );
        $subject = sprintf( '%s — Password reset code: %s', wp_strip_all_tags( $title ), $code );
        $html    = '<div style="font-family:Inter,Arial,sans-serif;color:#0f172a;max-width:560px;margin:0 auto;">'
                 . '<div style="background:#fff;padding:28px;border:1px solid #e5e7eb;border-radius:10px;border-top:4px solid #6366f1;">'
                 . '<h2 style="margin:0 0 8px;font-size:22px;">Reset your password</h2>'
                 . '<p style="margin:0 0 18px;color:#475569;">Use this one-time code to reset your password. It expires in ' . (int) ( self::RESET_TTL / 60 ) . ' minutes.</p>'
                 . '<div style="font-size:28px;font-weight:700;letter-spacing:6px;background:#f1f5f9;padding:14px 20px;border-radius:8px;display:inline-block;color:#0f172a;">' . esc_html( $code ) . '</div>'
                 . '<p style="margin-top:24px;color:#64748b;font-size:13px;">If you didn\'t request this, you can safely ignore the email.</p>'
                 . '</div></div>';
        $headers = [ 'Content-Type: text/html; charset=UTF-8' ];
        $ok = wp_mail( $email, $subject, $html, $headers );
        if ( class_exists( 'FCP_DB' ) && method_exists( 'FCP_DB', 'log_mail' ) ) {
            FCP_DB::log_mail( [
                'recipient' => $email,
                'subject'   => $subject,
                'purpose'   => 'user_password_reset',
                'status'    => $ok ? 'delivered' : 'failed',
            ] );
        }
        return [ 'sent' => (bool) $ok, 'message' => 'If that email is registered, a reset code is on its way.' ];
    }

    public static function reset_password( $email, $code, $new_password ) {
        $user = self::find_by_email( $email );
        if ( ! $user ) {
            return new WP_Error( 'fcp_users_bad_reset', 'Invalid reset code.' );
        }
        if ( empty( $user['reset_code'] ) || empty( $user['reset_expires_at'] ) ) {
            return new WP_Error( 'fcp_users_no_reset', 'No active reset request — start over.' );
        }
        if ( strtotime( $user['reset_expires_at'] ) < time() ) {
            return new WP_Error( 'fcp_users_expired', 'Reset code has expired — start over.' );
        }
        $code = preg_replace( '/\D/', '', (string) $code );
        if ( ! hash_equals( $user['reset_code'], wp_hash( $code ) ) ) {
            return new WP_Error( 'fcp_users_bad_reset', 'Invalid reset code.' );
        }
        if ( strlen( $new_password ) < 8 ) {
            return new WP_Error( 'fcp_users_weak_pass', 'New password must be at least 8 characters.' );
        }
        global $wpdb;
        $wpdb->update( FCP_DB::users_table(), [
            'password_hash'    => password_hash( $new_password, PASSWORD_DEFAULT ),
            'reset_code'       => null,
            'reset_expires_at' => null,
            'updated_at'       => current_time( 'mysql' ),
        ], [ 'id' => (int) $user['id'] ] );
        return true;
    }

    /* -----------------------------------------------------------
     * Sessions (cookie-based)
     * -------------------------------------------------------- */
    public static function start_session( $user ) {
        $secret = self::secret();
        $payload = [
            'uid' => (int) $user['id'],
            'exp' => time() + self::COOKIE_TTL,
        ];
        $token   = self::encode_token( $payload, $user['password_hash'], $secret );
        setcookie(
            self::COOKIE, $token,
            [
                'expires'  => $payload['exp'],
                'path'     => '/',
                'secure'   => is_ssl(),
                'httponly' => true,
                'samesite' => 'Lax',
            ]
        );
        $_COOKIE[ self::COOKIE ] = $token;
    }
    public static function current_user() {
        if ( empty( $_COOKIE[ self::COOKIE ] ) ) return null;
        $payload = self::decode_token( $_COOKIE[ self::COOKIE ] );
        if ( ! $payload || empty( $payload['uid'] ) || empty( $payload['exp'] ) ) return null;
        if ( $payload['exp'] < time() ) return null;
        $user = self::find_by_id( $payload['uid'] );
        if ( ! $user ) return null;
        $secret  = self::secret();
        $expected = self::encode_token( [ 'uid' => $payload['uid'], 'exp' => $payload['exp'] ], $user['password_hash'], $secret );
        if ( ! hash_equals( $expected, $_COOKIE[ self::COOKIE ] ) ) return null;
        return $user;
    }
    public static function end_session() {
        if ( isset( $_COOKIE[ self::COOKIE ] ) ) {
            setcookie( self::COOKIE, '', [ 'expires' => time() - 3600, 'path' => '/', 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax' ] );
            unset( $_COOKIE[ self::COOKIE ] );
        }
    }
    private static function encode_token( $payload, $pw_hash, $secret ) {
        $body = base64_encode( wp_json_encode( $payload ) );
        $sig  = hash_hmac( 'sha256', $body . '|' . $pw_hash, $secret );
        return $body . '.' . $sig;
    }
    private static function decode_token( $token ) {
        if ( strpos( $token, '.' ) === false ) return null;
        list( $body, ) = explode( '.', $token, 2 );
        $json = base64_decode( $body );
        if ( ! $json ) return null;
        $data = json_decode( $json, true );
        return is_array( $data ) ? $data : null;
    }
    private static function secret() {
        $key = get_option( 'fcp_users_secret' );
        if ( ! $key ) {
            $key = wp_generate_password( 48, true, true );
            update_option( 'fcp_users_secret', $key, false );
        }
        return $key;
    }

    /* -----------------------------------------------------------
     * Admin listing
     * -------------------------------------------------------- */
    public static function list_users( $args = [] ) {
        global $wpdb;
        $where = '1=1';
        if ( ! empty( $args['search'] ) ) {
            $like = '%' . $wpdb->esc_like( $args['search'] ) . '%';
            $where .= $wpdb->prepare( ' AND (email LIKE %s OR display_name LIKE %s OR phone LIKE %s)', $like, $like, $like );
        }
        if ( ! empty( $args['status'] ) ) {
            $where .= $wpdb->prepare( ' AND status = %s', $args['status'] );
        }
        $rows = $wpdb->get_results( "SELECT id, email, display_name, phone, status, registered_form_id, login_count, last_login_at, last_login_ip, meta, created_at, updated_at FROM " . FCP_DB::users_table() . " WHERE $where ORDER BY created_at DESC LIMIT 500", ARRAY_A );
        return $rows ?: [];
    }
    public static function delete_user( $id ) {
        global $wpdb;
        return $wpdb->delete( FCP_DB::users_table(), [ 'id' => (int) $id ] );
    }
    public static function update_user( $id, $changes ) {
        global $wpdb;
        $row = [];
        if ( isset( $changes['display_name'] ) ) $row['display_name'] = sanitize_text_field( $changes['display_name'] );
        if ( isset( $changes['phone'] ) )        $row['phone']        = sanitize_text_field( $changes['phone'] );
        if ( isset( $changes['status'] ) && in_array( $changes['status'], [ 'active', 'disabled' ], true ) ) {
            $row['status'] = $changes['status'];
        }
        if ( ! empty( $changes['password'] ) && strlen( $changes['password'] ) >= 8 ) {
            $row['password_hash'] = password_hash( $changes['password'], PASSWORD_DEFAULT );
        }
        if ( empty( $row ) ) return false;
        $row['updated_at'] = current_time( 'mysql' );
        return $wpdb->update( FCP_DB::users_table(), $row, [ 'id' => (int) $id ] );
    }

    /* -----------------------------------------------------------
     * Helper: build register/update args from a form submission
     * -------------------------------------------------------- */
    public static function args_from_form_data( $form_action, $data ) {
        $email_lbl = $form_action['emailField']    ?? '';
        $pass_lbl  = $form_action['passwordField'] ?? '';
        $name_lbl  = $form_action['nameField']     ?? '';
        $phone_lbl = $form_action['phoneField']    ?? '';
        $meta_lbls = $form_action['extraFields']   ?? []; // array of labels to capture as meta
        $meta      = [];
        foreach ( (array) $meta_lbls as $lbl ) {
            if ( ! $lbl ) continue;
            $v = $data[ $lbl ] ?? '';
            if ( is_array( $v ) ) $v = implode( ', ', $v );
            $meta[ $lbl ] = (string) $v;
        }
        return [
            'email'        => $email_lbl ? (string) ( $data[ $email_lbl ] ?? '' ) : '',
            'password'     => $pass_lbl  ? (string) ( $data[ $pass_lbl ]  ?? '' ) : '',
            'display_name' => $name_lbl  ? (string) ( $data[ $name_lbl ]  ?? '' ) : '',
            'phone'        => $phone_lbl ? (string) ( $data[ $phone_lbl ] ?? '' ) : '',
            'meta'         => $meta,
        ];
    }
}
