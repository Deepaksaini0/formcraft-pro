<?php
/**
 * FormYantra — Advanced Payment Features (v2.72.62).
 *
 * Ships five previously-missing capabilities:
 *   1. Recurring subscriptions (Stripe MVP; Razorpay/PayPal hooks reserved)
 *   2. Global tax engine       (flat OR per-country rules OR Stripe Tax)
 *   3. Generic invoice / receipt PDF (gateway-agnostic HTML template)
 *   4. Product upsells          (post-purchase bump on confirmation page)
 *   5. Saved payment methods    (Stripe Customer + auto-save; visible only
 *                                to logged-in WP users)
 *
 * Data model:
 *   • Subscriptions live in a new table `wp_fcp_subscriptions`.
 *   • Upsell purchases append to `submission.data._meta.upsells[]`.
 *   • Tax settings live under `form.settings.tax`.
 *   • Saved-card mapping stored in WP user meta `_fcp_stripe_customer_id`.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FCP_Payments_Pro {

    const SUBS_TABLE = 'fcp_subscriptions';
    const SCHEMA_OPT = 'fcp_payments_pro_schema';
    const SCHEMA_VER = 1;

    /* ─────────────────────────────────────────────────────────────
     * 0. Schema — created lazily so no plugin-activation hook change
     *    is required. Called on first admin/REST request.
     * ───────────────────────────────────────────────────────────── */
    public static function ensure_schema() {
        if ( (int) get_option( self::SCHEMA_OPT, 0 ) === self::SCHEMA_VER ) return;
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $table   = $wpdb->prefix . self::SUBS_TABLE;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( "CREATE TABLE $table (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            form_id BIGINT UNSIGNED NOT NULL,
            submission_id BIGINT UNSIGNED NOT NULL,
            wp_user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            gateway VARCHAR(32) NOT NULL,
            gateway_sub_id VARCHAR(128) NOT NULL,
            gateway_customer_id VARCHAR(128) NOT NULL DEFAULT '',
            status VARCHAR(32) NOT NULL DEFAULT 'incomplete',
            amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            currency VARCHAR(8) NOT NULL DEFAULT 'USD',
            plan_name VARCHAR(120) NOT NULL DEFAULT '',
            interval_unit VARCHAR(16) NOT NULL DEFAULT 'month',
            interval_count TINYINT UNSIGNED NOT NULL DEFAULT 1,
            current_period_end BIGINT UNSIGNED NOT NULL DEFAULT 0,
            cancel_at_period_end TINYINT UNSIGNED NOT NULL DEFAULT 0,
            submitter_email VARCHAR(190) NOT NULL DEFAULT '',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY gw_sub (gateway, gateway_sub_id),
            KEY form_id (form_id),
            KEY status (status),
            KEY wp_user_id (wp_user_id)
        ) $charset;" );
        update_option( self::SCHEMA_OPT, self::SCHEMA_VER, false );
    }

    /* ─────────────────────────────────────────────────────────────
     * 1. Subscriptions — CRUD helpers.
     * ───────────────────────────────────────────────────────────── */
    public static function record_subscription( $row ) {
        self::ensure_schema();
        global $wpdb;
        $table = $wpdb->prefix . self::SUBS_TABLE;
        $defaults = [
            'form_id' => 0, 'submission_id' => 0, 'wp_user_id' => 0,
            'gateway' => 'stripe', 'gateway_sub_id' => '', 'gateway_customer_id' => '',
            'status' => 'active', 'amount' => 0, 'currency' => 'USD',
            'plan_name' => '', 'interval_unit' => 'month', 'interval_count' => 1,
            'current_period_end' => 0, 'cancel_at_period_end' => 0,
            'submitter_email' => '',
            'created_at' => current_time( 'mysql' ),
            'updated_at' => current_time( 'mysql' ),
        ];
        $row = array_merge( $defaults, $row );
        // Upsert on gateway+gateway_sub_id.
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM $table WHERE gateway=%s AND gateway_sub_id=%s",
            $row['gateway'], $row['gateway_sub_id']
        ) );
        if ( $existing ) {
            $row['updated_at'] = current_time( 'mysql' );
            unset( $row['created_at'] );
            $wpdb->update( $table, $row, [ 'id' => (int) $existing ] );
            return (int) $existing;
        }
        $wpdb->insert( $table, $row );
        return (int) $wpdb->insert_id;
    }

    public static function list_subscriptions( $args = [] ) {
        self::ensure_schema();
        global $wpdb;
        $table = $wpdb->prefix . self::SUBS_TABLE;
        $where  = '1=1';
        $params = [];
        if ( ! empty( $args['form_id'] ) )   { $where .= ' AND form_id=%d';    $params[] = (int) $args['form_id']; }
        if ( ! empty( $args['status'] ) )    { $where .= ' AND status=%s';     $params[] = (string) $args['status']; }
        if ( ! empty( $args['wp_user_id'] ) ){ $where .= ' AND wp_user_id=%d'; $params[] = (int) $args['wp_user_id']; }
        $limit  = min( 200, max( 1, (int) ( $args['limit']  ?? 50 ) ) );
        $offset = max( 0, (int) ( $args['offset'] ?? 0 ) );
        $sql = "SELECT * FROM $table WHERE $where ORDER BY id DESC LIMIT $limit OFFSET $offset";
        return $params ? $wpdb->get_results( $wpdb->prepare( $sql, ...$params ), ARRAY_A )
                       : $wpdb->get_results( $sql, ARRAY_A );
    }

    public static function get_subscription( $id ) {
        self::ensure_schema();
        global $wpdb;
        $table = $wpdb->prefix . self::SUBS_TABLE;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id=%d", (int) $id ), ARRAY_A );
    }

    public static function update_subscription_by_gateway_id( $gateway, $gateway_sub_id, $data ) {
        self::ensure_schema();
        global $wpdb;
        $table = $wpdb->prefix . self::SUBS_TABLE;
        $data['updated_at'] = current_time( 'mysql' );
        return $wpdb->update( $table, $data, [ 'gateway' => $gateway, 'gateway_sub_id' => $gateway_sub_id ] );
    }

    /* ─────────────────────────────────────────────────────────────
     * 2. Global tax engine.
     * Modes:
     *   'off'       — no tax
     *   'flat'      — single flat rate on the whole amount
     *   'byCountry' — per-country map (or 'ALL' fallback)
     *   'stripeTax' — Stripe computes automatically at checkout
     *                 (this method returns 0; caller passes stripe_tax=true)
     * Returns [ 'rate' => 0.20, 'tax_amount' => 5.00, 'total_with_tax' => 30.00, 'label' => 'VAT 20%' ]
     * ───────────────────────────────────────────────────────────── */
    public static function calculate_tax( $tax_settings, $subtotal, $submission_country = '' ) {
        $mode = $tax_settings['mode'] ?? 'off';
        $subtotal = (float) $subtotal;
        if ( $subtotal <= 0 || $mode === 'off' || $mode === 'stripeTax' ) {
            return [ 'rate' => 0, 'tax_amount' => 0, 'total_with_tax' => $subtotal, 'label' => '' ];
        }
        $rate = 0;
        $label = 'Tax';
        if ( $mode === 'flat' ) {
            $rate = (float) ( $tax_settings['flatRate'] ?? 0 );
            $label = $tax_settings['flatLabel'] ?? 'Tax';
        } elseif ( $mode === 'byCountry' ) {
            $rules = is_array( $tax_settings['rules'] ?? null ) ? $tax_settings['rules'] : [];
            $cc = strtoupper( trim( (string) $submission_country ) );
            foreach ( $rules as $r ) {
                if ( ! is_array( $r ) ) continue;
                $rc = strtoupper( trim( (string) ( $r['country'] ?? '' ) ) );
                if ( $rc === $cc ) { $rate = (float) ( $r['rate'] ?? 0 ); $label = $r['label'] ?? ( 'Tax ' . $cc ); break; }
            }
            if ( $rate === 0 ) {
                // Fallback rule with country='ALL'
                foreach ( $rules as $r ) {
                    if ( ! is_array( $r ) ) continue;
                    if ( strtoupper( trim( (string) ( $r['country'] ?? '' ) ) ) === 'ALL' ) {
                        $rate = (float) ( $r['rate'] ?? 0 );
                        $label = $r['label'] ?? 'Tax';
                        break;
                    }
                }
            }
        }
        if ( $rate <= 0 ) return [ 'rate' => 0, 'tax_amount' => 0, 'total_with_tax' => $subtotal, 'label' => '' ];
        // Rate can be entered as 20 (20%) or 0.20 — normalize.
        if ( $rate > 1 ) $rate = $rate / 100;
        $tax_amount = round( $subtotal * $rate, 2 );
        return [
            'rate' => $rate,
            'tax_amount' => $tax_amount,
            'total_with_tax' => round( $subtotal + $tax_amount, 2 ),
            'label' => $label,
        ];
    }

    /* ─────────────────────────────────────────────────────────────
     * 3. Generic invoice / receipt renderer (gateway-agnostic HTML).
     * Reads the submission row + form + payment meta and returns a
     * print-optimized HTML page. Browser's Save-as-PDF handles export.
     * ───────────────────────────────────────────────────────────── */
    public static function render_receipt_html( $sub, $form = null ) {
        if ( ! is_array( $sub ) ) return '';
        $data = json_decode( (string) ( $sub['data'] ?? '{}' ), true );
        if ( ! is_array( $data ) ) $data = [];
        $meta = $data['_meta'] ?? [];
        $paid_amount = (float) ( $sub['payment_amount'] ?? ( $meta['payment']['amount'] ?? 0 ) );
        $currency    = (string) ( $sub['payment_currency'] ?? ( $meta['payment']['currency'] ?? 'USD' ) );
        $gateway     = (string) ( $sub['payment_gateway'] ?? ( $meta['payment']['gateway'] ?? '' ) );
        $payment_id  = (string) ( $sub['payment_id']      ?? ( $meta['payment']['payment_id'] ?? $sub['payment_ref'] ?? '' ) );
        $created     = (string) ( $sub['created_at'] ?? current_time( 'mysql' ) );
        $status      = (string) ( $sub['payment_status'] ?? ( $meta['payment']['status'] ?? 'paid' ) );

        $seller_name = get_bloginfo( 'name' );
        $seller_url  = home_url( '/' );
        $seller_email= get_option( 'admin_email' );
        // Optional overrides via a plugin-level setting.
        $settings    = get_option( 'fcp_settings', [] );
        if ( ! empty( $settings['receipt']['seller_name'] ) )  $seller_name  = $settings['receipt']['seller_name'];
        if ( ! empty( $settings['receipt']['seller_email'] ) ) $seller_email = $settings['receipt']['seller_email'];

        $receipt_no = 'RCPT-' . str_pad( (string) ( $sub['id'] ?? 0 ), 6, '0', STR_PAD_LEFT );
        $buyer_name = (string) ( $sub['submitter_name']  ?? '' );
        $buyer_mail = (string) ( $sub['submitter_email'] ?? '' );
        // Try to pull a phone from the submission data.
        $buyer_phone = '';
        foreach ( $data as $k => $v ) {
            if ( is_string( $v ) && preg_match( '/phone|mobile|tel/i', (string) $k ) ) { $buyer_phone = (string) $v; break; }
        }
        // Line item — always one, since a submission is a single transaction.
        // If tax was applied at checkout, split subtotal + tax + total.
        $tax_meta   = $meta['tax'] ?? [];
        $tax_amount = (float) ( $tax_meta['tax_amount'] ?? 0 );
        $tax_label  = (string) ( $tax_meta['label']      ?? '' );
        // Coupon breakdown lives on dedicated columns (populated by both
        // /submit for offline methods and /payment/create-order for online).
        $coupon_code            = (string) ( $sub['coupon_code']            ?? '' );
        $coupon_discount        = (float)  ( $sub['coupon_discount']        ?? 0 );
        $coupon_original_amount = (float)  ( $sub['coupon_original_amount'] ?? 0 );
        // Subtotal (before tax) — build from the post-coupon paid_amount.
        $subtotal   = $paid_amount - $tax_amount;
        // Upsells appended to _meta.upsells[] (feature #4).
        $upsells = is_array( $meta['upsells'] ?? null ) ? $meta['upsells'] : [];
        $upsell_total = 0;
        foreach ( $upsells as $u ) { $upsell_total += (float) ( $u['amount'] ?? 0 ); }
        $grand_total  = $paid_amount + $upsell_total;

        $form_title = $form ? (string) ( $form['title'] ?? '' ) : '';

        /* v2.72.99 — Line-item enrichment. Instead of a single opaque
         * "Form submission" row, walk the form definition and surface the
         * visitor's picks for product / pricing / plan / payment fields as
         * a labeled sub-item. Falls back to the form title alone if no
         * such field is present. */
        $line_items = [];
        if ( is_array( $form ) && isset( $form['steps'] ) && is_array( $form['steps'] ) ) {
            foreach ( $form['steps'] as $step ) {
                if ( ! isset( $step['fields'] ) || ! is_array( $step['fields'] ) ) continue;
                foreach ( $step['fields'] as $fld ) {
                    $type = (string) ( $fld['type']  ?? '' );
                    $lbl  = (string) ( $fld['label'] ?? '' );
                    if ( ! $lbl ) continue;
                    if ( ! in_array( $type, [ 'product','pricing','payment','wc-products' ], true ) ) continue;
                    $pick = isset( $data[ $lbl ] ) ? (string) $data[ $lbl ] : '';
                    if ( $pick === '' ) continue;
                    // Skip the Payment Method field's own row — it just holds
                    // the method slug (upi/bank/card…) which is already shown
                    // in the Payment column.
                    if ( $type === 'payment' ) continue;
                    $line_items[] = [
                        'label'  => $lbl,
                        'pick'   => $pick,
                        'type'   => $type,
                    ];
                }
            }
        }

        $esc = 'esc_html';
        ob_start(); ?>
        <!DOCTYPE html>
        <html lang="en"><head>
        <meta charset="utf-8">
        <title>Receipt <?php echo $esc( $receipt_no ); ?></title>
        <style>
            :root { --brand:#6366f1; --ink:#0f172a; --muted:#64748b; --line:#e2e8f0; }
            * { box-sizing: border-box; }
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, Roboto, sans-serif; color: var(--ink); margin: 0; padding: 32px; background:#f8fafc; }
            .page { max-width: 780px; margin: 0 auto; background:#fff; border-radius: 12px; padding: 40px; box-shadow: 0 10px 30px rgba(15,23,42,0.06); }
            .head { display:flex; justify-content: space-between; align-items:flex-start; gap:20px; margin-bottom: 28px; padding-bottom: 20px; border-bottom: 2px solid var(--line); }
            .brand { font-size: 22px; font-weight: 800; color: var(--brand); letter-spacing: -0.02em; }
            .brand-sub { font-size: 13px; color: var(--muted); margin-top: 4px; }
            .stamp { text-align:right; }
            .stamp .no { font-size: 12px; color: var(--muted); text-transform: uppercase; letter-spacing: 0.08em; }
            .stamp .val { font-size: 20px; font-weight: 700; color: var(--ink); }
            .stamp .date { font-size: 12px; color: var(--muted); margin-top: 2px; }
            .parties { display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:24px; }
            .party h4 { margin:0 0 4px; font-size:11px; font-weight:800; color:var(--muted); text-transform:uppercase; letter-spacing:0.08em; }
            .party .nm { font-size:15px; font-weight:700; margin-bottom:2px; }
            .party .li { font-size:13px; color:var(--muted); }
            table.items { width:100%; border-collapse:collapse; margin-bottom:20px; }
            table.items th { text-align:left; padding:10px 12px; background:#f1f5f9; font-size:11px; font-weight:800; color:var(--muted); text-transform:uppercase; letter-spacing:0.05em; }
            table.items th.r, table.items td.r { text-align:right; }
            table.items td { padding:12px; border-bottom:1px solid var(--line); font-size:14px; }
            table.totals { width:100%; max-width:340px; margin-left:auto; }
            table.totals td { padding:6px 12px; font-size:13px; }
            table.totals td.r { text-align:right; font-variant-numeric: tabular-nums; }
            table.totals tr.total td { font-size:16px; font-weight:800; border-top:2px solid var(--ink); padding-top:10px; }
            .status { display:inline-block; padding:3px 10px; border-radius:999px; font-size:11px; font-weight:800; letter-spacing:0.05em; background:#dcfce7; color:#15803d; text-transform:uppercase; }
            .foot { margin-top: 28px; padding-top:16px; border-top:1px solid var(--line); font-size:11px; color:var(--muted); text-align:center; }
            .printbar { max-width:780px; margin:0 auto 12px; text-align:right; }
            .printbtn { padding:8px 16px; background:var(--brand); color:#fff; border:none; border-radius:6px; font-weight:600; cursor:pointer; font-size:13px; }
            @media print { body { background:#fff; padding:0; } .page { box-shadow:none; border-radius:0; padding:24px; } .printbar { display:none; } }
        </style></head>
        <body>
            <div class="printbar"><button class="printbtn" onclick="window.print()">🖨 Print / Save as PDF</button></div>
            <div class="page">
                <div class="head">
                    <div>
                        <div class="brand"><?php echo $esc( $seller_name ); ?></div>
                        <div class="brand-sub"><?php echo $esc( $seller_url ); ?></div>
                    </div>
                    <div class="stamp">
                        <div class="no">Receipt</div>
                        <div class="val"><?php echo $esc( $receipt_no ); ?></div>
                        <div class="date"><?php echo $esc( date_i18n( 'd M Y', strtotime( $created ) ) ); ?></div>
                        <div style="margin-top:6px;"><span class="status">✓ <?php echo $esc( strtoupper( $status ) ); ?></span></div>
                    </div>
                </div>

                <div class="parties">
                    <div class="party">
                        <h4>Billed To</h4>
                        <div class="nm"><?php echo $esc( $buyer_name ?: 'Customer' ); ?></div>
                        <?php if ( $buyer_mail ) : ?><div class="li"><?php echo $esc( $buyer_mail ); ?></div><?php endif; ?>
                        <?php if ( $buyer_phone ) : ?><div class="li"><?php echo $esc( $buyer_phone ); ?></div><?php endif; ?>
                    </div>
                    <div class="party" style="text-align:right;">
                        <h4>Payment</h4>
                        <div class="nm"><?php echo $esc( ucfirst( $gateway ?: 'card' ) ); ?></div>
                        <?php if ( $payment_id ) : ?><div class="li" style="font-family: monospace; font-size:11px; word-break: break-all;"><?php echo $esc( $payment_id ); ?></div><?php endif; ?>
                    </div>
                </div>

                <table class="items">
                    <thead><tr><th>Description</th><th class="r">Amount</th></tr></thead>
                    <tbody>
                        <tr>
                            <td>
                                <strong><?php echo $esc( $form_title ?: 'Form submission' ); ?></strong>
                                <?php if ( $line_items ) : ?>
                                    <?php foreach ( $line_items as $li ) : ?>
                                        <br><span style="font-size:12px;color:var(--muted);"><?php echo $esc( $li['label'] ); ?>: <strong style="color:var(--ink);"><?php echo $esc( $li['pick'] ); ?></strong></span>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                                <?php if ( $subtotal !== $paid_amount ) : ?><br><span style="font-size:12px;color:var(--muted);">(before tax)</span><?php endif; ?>
                            </td>
                            <td class="r">
                                <?php if ( $coupon_discount > 0 && $coupon_original_amount > 0 ) : ?>
                                    <span style="text-decoration:line-through;color:var(--muted);font-size:12px;"><?php echo $esc( self::money( $coupon_original_amount, $currency ) ); ?></span><br>
                                <?php endif; ?>
                                <?php echo $esc( self::money( $subtotal, $currency ) ); ?>
                            </td>
                        </tr>
                        <?php foreach ( $upsells as $u ) : ?>
                            <tr>
                                <td><?php echo $esc( $u['title'] ?? 'Add-on' ); ?><br><span style="font-size:12px;color:var(--muted);">Add-on purchase</span></td>
                                <td class="r"><?php echo $esc( self::money( (float) ( $u['amount'] ?? 0 ), $currency ) ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <table class="totals">
                    <?php if ( $coupon_discount > 0 && $coupon_original_amount > 0 ) : ?>
                        <tr><td>Subtotal</td><td class="r"><?php echo $esc( self::money( $coupon_original_amount, $currency ) ); ?></td></tr>
                        <tr>
                            <td style="color:#16a34a;">Coupon <strong><?php echo $esc( $coupon_code ?: 'DISCOUNT' ); ?></strong></td>
                            <td class="r" style="color:#16a34a;">−<?php echo $esc( self::money( $coupon_discount, $currency ) ); ?></td>
                        </tr>
                    <?php else : ?>
                        <tr><td>Subtotal</td><td class="r"><?php echo $esc( self::money( $subtotal + $upsell_total, $currency ) ); ?></td></tr>
                    <?php endif; ?>
                    <?php if ( $tax_amount > 0 ) : ?>
                        <tr><td><?php echo $esc( $tax_label ?: 'Tax' ); ?></td><td class="r"><?php echo $esc( self::money( $tax_amount, $currency ) ); ?></td></tr>
                    <?php endif; ?>
                    <tr class="total"><td>Total paid</td><td class="r"><?php echo $esc( self::money( $grand_total, $currency ) ); ?></td></tr>
                </table>

                <div class="foot">
                    Thank you for your business.<br>
                    Questions? Contact <?php echo $esc( $seller_email ); ?>
                </div>
            </div>
        </body></html>
        <?php return ob_get_clean();
    }

    private static function money( $amt, $ccy ) {
        $amt = (float) $amt;
        $ccy = strtoupper( (string) $ccy );
        $sym = [ 'USD'=>'$', 'EUR'=>'€', 'GBP'=>'£', 'JPY'=>'¥', 'INR'=>'₹', 'CAD'=>'CA$', 'AUD'=>'A$' ];
        $s = $sym[ $ccy ] ?? ( $ccy . ' ' );
        return $s . number_format( $amt, 2 );
    }

    /* ─────────────────────────────────────────────────────────────
     * 4. Upsells — persist a completed upsell to submission._meta.upsells[].
     * ───────────────────────────────────────────────────────────── */
    public static function record_upsell( $submission_id, $upsell ) {
        if ( ! class_exists( 'FCP_DB' ) ) return false;
        $sub = FCP_DB::get_submission( (int) $submission_id );
        if ( ! $sub ) return false;
        $data = json_decode( (string) ( $sub['data'] ?? '{}' ), true );
        if ( ! is_array( $data ) ) $data = [];
        $meta = $data['_meta'] ?? [];
        if ( ! is_array( $meta ) ) $meta = [];
        $meta['upsells'] = is_array( $meta['upsells'] ?? null ) ? $meta['upsells'] : [];
        $meta['upsells'][] = array_merge( [
            'title' => 'Add-on', 'amount' => 0, 'currency' => 'USD',
            'gateway' => 'stripe', 'payment_id' => '', 'created_at' => current_time( 'mysql' ),
        ], (array) $upsell );
        $data['_meta'] = $meta;
        FCP_DB::update_submission( (int) $submission_id, [ 'data' => wp_json_encode( $data ) ] );
        return true;
    }
}
