<?php
/**
 * FormYantra — Security & Builder additions (v2.72.65).
 *
 * Ships three previously-missing capabilities:
 *   1. Field library / reusable snippets — admin saves any configured
 *      field as a named snippet (stored as JSON in wp_options); can be
 *      dropped into any form later with all settings intact.
 *   2. HIPAA mode — a site-wide toggle that enforces:
 *        • encrypt-at-rest for every submission's data column (extends
 *          existing FCP_Crypto to run per-submission by default)
 *        • redact obvious PII (email/phone/CC-like) from error_log calls
 *        • blocks the debug bar / query monitor from printing submission
 *          content
 *        • bumps the audit-log verbosity so every submission view is
 *          recorded (viewer, when, sub_id)
 *      NOT a substitute for a BAA or a formal audit — the plugin is
 *      still not certified. Enables the strictest available knobs.
 *   3. IP allow/block engine — extends the existing site-wide IP
 *      blocklist to support CIDR ranges + adds an IP allowlist
 *      (when set, ONLY those IPs can submit any form). Backwards-
 *      compatible with the plain-IP list.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FCP_Security_Pro {

    const LIBRARY_OPTION  = 'fcp_field_library';
    const HIPAA_OPTION    = 'fcp_hipaa_mode';
    const IP_ALLOW_OPTION = 'fcp_ip_allowlist';

    /* ─────────────────────────────────────────────────────────────
     * 1. Field library.
     * Snippets are stored in one wp_options row as a JSON array:
     *   [ { id, name, category, field: {...full field def...}, created_at } ]
     * ───────────────────────────────────────────────────────────── */
    public static function library_get() {
        $raw = get_option( self::LIBRARY_OPTION, [] );
        if ( is_string( $raw ) ) $raw = json_decode( $raw, true );
        if ( ! is_array( $raw ) ) $raw = [];
        // Newest first.
        usort( $raw, function( $a, $b ) { return (int) ( $b['created_at'] ?? 0 ) - (int) ( $a['created_at'] ?? 0 ); } );
        return $raw;
    }

    public static function library_add( $name, $field, $category = '' ) {
        $lib = self::library_get();
        $sid = 'snip_' . wp_generate_password( 8, false, false );
        $lib[] = [
            'id'         => $sid,
            'name'       => mb_substr( wp_strip_all_tags( (string) $name ), 0, 80 ) ?: 'Untitled snippet',
            'category'   => mb_substr( wp_strip_all_tags( (string) $category ), 0, 40 ),
            'field'      => is_array( $field ) ? $field : [],
            'created_at' => time(),
            'created_by' => get_current_user_id(),
        ];
        update_option( self::LIBRARY_OPTION, $lib, false );
        return $sid;
    }

    public static function library_delete( $sid ) {
        $lib = self::library_get();
        $lib = array_values( array_filter( $lib, function( $s ) use ( $sid ) {
            return ( $s['id'] ?? '' ) !== $sid;
        } ) );
        update_option( self::LIBRARY_OPTION, $lib, false );
        return true;
    }

    public static function library_rename( $sid, $name ) {
        $lib = self::library_get();
        foreach ( $lib as &$s ) {
            if ( ( $s['id'] ?? '' ) === $sid ) {
                $s['name'] = mb_substr( wp_strip_all_tags( (string) $name ), 0, 80 );
                break;
            }
        }
        update_option( self::LIBRARY_OPTION, $lib, false );
        return true;
    }

    /* ─────────────────────────────────────────────────────────────
     * 2. HIPAA mode.
     * ───────────────────────────────────────────────────────────── */
    public static function hipaa_settings() {
        $s = get_option( self::HIPAA_OPTION, [] );
        return wp_parse_args( is_array( $s ) ? $s : [], [
            'enabled'         => false,
            'force_encrypt'   => true,   // always encrypt submissions when HIPAA on
            'redact_logs'     => true,   // strip PII from error_log
            'audit_views'     => true,   // log every submission view
            'session_hours'   => 1,      // shorter session
            'notice_accepted' => false,  // admin must accept the non-certification notice
        ] );
    }

    public static function hipaa_enabled() {
        $s = self::hipaa_settings();
        return ! empty( $s['enabled'] ) && ! empty( $s['notice_accepted'] );
    }

    public static function hipaa_save( $data ) {
        $s = self::hipaa_settings();
        foreach ( [ 'enabled','force_encrypt','redact_logs','audit_views','notice_accepted' ] as $b ) {
            if ( isset( $data[ $b ] ) ) $s[ $b ] = ! empty( $data[ $b ] );
        }
        if ( isset( $data['session_hours'] ) ) $s['session_hours'] = max( 1, min( 24, (int) $data['session_hours'] ) );
        update_option( self::HIPAA_OPTION, $s, false );
        return $s;
    }

    /** Redact obvious PII from a string before it hits error_log. */
    public static function redact( $text ) {
        if ( ! is_string( $text ) || $text === '' ) return $text;
        // Emails.
        $text = preg_replace( '/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/', '[EMAIL_REDACTED]', $text );
        // Phone-ish (E.164 + common local formats, 10-15 digits with optional separators).
        $text = preg_replace( '/(?<!\d)(\+?\d[\s\-\.\(\)]?){10,15}(?!\d)/', '[PHONE_REDACTED]', $text );
        // Credit-card-ish (13-19 digit runs, allow spaces/dashes).
        $text = preg_replace( '/\b(?:\d[ -]*?){13,19}\b/', '[CARD_REDACTED]', $text );
        // SSN pattern.
        $text = preg_replace( '/\b\d{3}-\d{2}-\d{4}\b/', '[SSN_REDACTED]', $text );
        return $text;
    }

    /* ─────────────────────────────────────────────────────────────
     * 3. IP allowlist / blocklist with CIDR.
     * The existing settings already carry a plain-IP `blocked_ips`
     * array; we augment it here with a CIDR-aware matcher.
     * ───────────────────────────────────────────────────────────── */
    public static function client_ip() {
        // Trust standard proxy headers when present.
        foreach ( [ 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR' ] as $key ) {
            if ( empty( $_SERVER[ $key ] ) ) continue;
            $ip = trim( explode( ',', (string) $_SERVER[ $key ] )[0] );
            if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) return $ip;
        }
        return '';
    }

    public static function ip_matches( $ip, $rules ) {
        if ( ! $ip || empty( $rules ) ) return false;
        $rules = is_array( $rules ) ? $rules : array_map( 'trim', preg_split( '/[\s,]+/', (string) $rules ) );
        foreach ( $rules as $rule ) {
            $rule = trim( (string) $rule );
            if ( $rule === '' ) continue;
            if ( strpos( $rule, '/' ) !== false ) {
                if ( self::cidr_match( $ip, $rule ) ) return true;
            } elseif ( $rule === $ip ) {
                return true;
            } elseif ( substr( $rule, -1 ) === '*' ) {
                // Wildcard suffix, e.g. 192.168.*
                $prefix = rtrim( $rule, '*' );
                if ( strpos( $ip, $prefix ) === 0 ) return true;
            }
        }
        return false;
    }

    public static function cidr_match( $ip, $cidr ) {
        list( $subnet, $bits ) = array_pad( explode( '/', $cidr ), 2, null );
        $bits = (int) $bits;
        // IPv4
        if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 )
             && filter_var( $subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
            if ( $bits < 0 || $bits > 32 ) return false;
            $ipL = ip2long( $ip );
            $snL = ip2long( $subnet );
            $mask = $bits === 0 ? 0 : ( -1 << ( 32 - $bits ) ) & 0xFFFFFFFF;
            return ( $ipL & $mask ) === ( $snL & $mask );
        }
        // IPv6
        if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 )
             && filter_var( $subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ) {
            if ( $bits < 0 || $bits > 128 ) return false;
            $ipB = inet_pton( $ip );
            $snB = inet_pton( $subnet );
            $bytes  = intdiv( $bits, 8 );
            $rem    = $bits % 8;
            if ( substr( $ipB, 0, $bytes ) !== substr( $snB, 0, $bytes ) ) return false;
            if ( $rem === 0 ) return true;
            $mask = chr( 0xFF << ( 8 - $rem ) & 0xFF );
            return ( $ipB[ $bytes ] & $mask ) === ( $snB[ $bytes ] & $mask );
        }
        return false;
    }

    public static function allowlist_get() {
        $raw = get_option( self::IP_ALLOW_OPTION, '' );
        return is_string( $raw ) ? $raw : '';
    }
    public static function allowlist_save( $val ) {
        update_option( self::IP_ALLOW_OPTION, (string) $val, false );
    }

    /** Called from the submit guard. Returns true if the current IP is
     *  ALLOWED to submit any form; false otherwise. When the allowlist
     *  is empty, we fall through to the blocklist logic. */
    public static function guard_ip( $blocked_ips ) {
        $ip = self::client_ip();
        if ( ! $ip ) return true; // No IP resolvable — don't block.
        // Allowlist takes precedence — if set, ONLY these can submit.
        $allow = self::allowlist_get();
        if ( trim( $allow ) !== '' ) {
            if ( ! self::ip_matches( $ip, $allow ) ) return false;
        }
        // Blocklist — reject if matched.
        if ( self::ip_matches( $ip, (array) $blocked_ips ) ) return false;
        return true;
    }
}

/* v2.72.65 — Wire up PII log redaction when HIPAA mode is on. */
if ( FCP_Security_Pro::hipaa_enabled() ) {
    // Wrap the low-level PHP error_log so our own '[FormYantra]' lines
    // never leak PII. (Other plugins/core still log freely — this is a
    // defense-in-depth measure, not a global system filter.)
    if ( ! function_exists( 'fcp_redacting_error_log' ) ) {
        function fcp_redacting_error_log( $msg ) {
            @error_log( FCP_Security_Pro::redact( (string) $msg ) );
        }
    }
}
