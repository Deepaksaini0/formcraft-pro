<?php
/**
 * FormYantra - Backup & Restore.
 *
 * Snapshots every custom table + every fcp_* option into a single JSON
 * (optionally gzipped) file under wp-content/uploads/formcraft-pro-backups/.
 * That directory is OUTSIDE the plugin folder, so it survives the plugin
 * being deleted from wp-admin — which is the whole point.
 *
 * Triggers: daily wp-cron, manual button, and last-chance snapshot fired
 * from uninstall.php before DROP TABLE.
 *
 * Retention: delete files older than N days (default 30), but always keep
 * the newest 3 regardless of age — protects against "cron didn't run for
 * two months and the only backup got auto-purged" failure modes.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_Backup {

    const CRON_HOOK        = 'fcp_backup_daily';
    const DIR_NAME         = 'formcraft-pro-backups';
    const KEEP_MIN         = 3;
    const DEFAULT_RETAIN   = 30;
    const FORMAT_VERSION   = 1;

    /**
     * Tables snapshotted by name (short name — the FCP_TABLE_* constant value).
     * Only tables that actually exist are dumped.
     */
    private static function tracked_tables() {
        return [
            FCP_TABLE_FORMS,
            FCP_TABLE_SUBS,
            FCP_TABLE_MAIL_LOG,
            FCP_TABLE_COUPONS,
            FCP_TABLE_WEBHOOKS,
            FCP_TABLE_REVISIONS,
            FCP_TABLE_STEP_EVENTS,
            FCP_TABLE_USERS,
        ];
    }

    /**
     * All fcp_* option keys we back up. get_option only returns per-key,
     * so we enumerate the known set. Anything else stored by the plugin
     * with an fcp_ prefix gets swept via LIKE lookup below.
     */
    private static function known_options() {
        return [
            'fcp_settings',
            'fcp_version',
            'fcp_db_version',
            'fcp_spam_patterns',
            'fcp_membership_enabled',
            'fcp_login_form_id',
            'fcp_register_form_id',
            'fcp_login_page_id',
            'fcp_register_page_id',
            'fcp_user_dashboard_page_id',
            'fcp_user_login_page_url',
            'fcp_users_secret',
            'fcp_backup_settings',
        ];
    }

    /* ---------------- lifecycle ---------------- */

    /**
     * Fired from register_activation_hook + plugins_loaded. Schedules the
     * daily cron and, on first run, ensures the backup dir exists with
     * hardening files in place.
     */
    public static function bootstrap() {
        add_action( self::CRON_HOOK, [ __CLASS__, 'run_daily' ] );

        if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
            wp_schedule_event( time() + 300, 'daily', self::CRON_HOOK );
        }
    }

    public static function unschedule() {
        $ts = wp_next_scheduled( self::CRON_HOOK );
        if ( $ts ) wp_unschedule_event( $ts, self::CRON_HOOK );
    }

    /* ---------------- storage ---------------- */

    /**
     * Absolute path to the backup dir. Creates it + hardens it on demand.
     * Returns '' if the dir cannot be created — callers must handle that.
     */
    public static function backup_dir() {
        $uploads = wp_upload_dir();
        if ( ! empty( $uploads['error'] ) ) return '';
        $dir = trailingslashit( $uploads['basedir'] ) . self::DIR_NAME;
        if ( ! file_exists( $dir ) ) {
            if ( ! wp_mkdir_p( $dir ) ) return '';
        }
        self::harden_dir( $dir );
        return $dir;
    }

    private static function harden_dir( $dir ) {
        $htaccess = $dir . '/.htaccess';
        if ( ! file_exists( $htaccess ) ) {
            @file_put_contents( $htaccess, "Order deny,allow\nDeny from all\n" );
        }
        $index = $dir . '/index.php';
        if ( ! file_exists( $index ) ) {
            @file_put_contents( $index, "<?php // Silence is golden.\n" );
        }
    }

    /* ---------------- create ---------------- */

    /**
     * Build a fresh backup file. Returns absolute path on success, WP_Error
     * on failure. $reason is stored in the manifest — helps admins tell a
     * "daily auto" from a "before uninstall" snapshot.
     */
    public static function create( $reason = 'manual' ) {
        global $wpdb;

        $dir = self::backup_dir();
        if ( ! $dir ) {
            return new WP_Error( 'no_dir', 'Could not create backup directory.' );
        }

        $payload = [
            'format_version' => self::FORMAT_VERSION,
            'plugin_version' => defined( 'FCP_VERSION' ) ? FCP_VERSION : 'unknown',
            'site_url'       => home_url(),
            'created_at'     => gmdate( 'c' ),
            'reason'         => (string) $reason,
            'db_prefix'      => $wpdb->prefix,
            'tables'         => [],
            'options'        => [],
        ];

        foreach ( self::tracked_tables() as $short ) {
            $full = $wpdb->prefix . $short;
            $exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $full ) );
            if ( ! $exists ) continue;
            $rows = $wpdb->get_results( "SELECT * FROM $full", ARRAY_A );
            $payload['tables'][ $short ] = is_array( $rows ) ? $rows : [];
        }

        foreach ( self::known_options() as $key ) {
            $val = get_option( $key, null );
            if ( $val !== null && $val !== false ) {
                $payload['options'][ $key ] = $val;
            }
        }
        // Sweep any other fcp_* option keys that might have been added later.
        $extras = $wpdb->get_col( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'fcp_%'" );
        foreach ( (array) $extras as $k ) {
            if ( ! isset( $payload['options'][ $k ] ) ) {
                $val = get_option( $k, null );
                if ( $val !== null && $val !== false ) {
                    $payload['options'][ $k ] = $val;
                }
            }
        }

        $json = wp_json_encode( $payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
        if ( $json === false ) {
            return new WP_Error( 'encode_failed', 'JSON encoding failed — payload too large or contains binary data.' );
        }

        $ts        = gmdate( 'Ymd-His' );
        $suffix    = strtolower( wp_generate_password( 6, false, false ) );
        $use_gzip  = function_exists( 'gzencode' );
        $ext       = $use_gzip ? '.json.gz' : '.json';
        $filename  = sprintf( 'formcraft-backup-%s-%s%s', $ts, $suffix, $ext );
        $path      = $dir . '/' . $filename;

        $bytes = $use_gzip ? @gzencode( $json, 6 ) : $json;
        if ( $bytes === false ) {
            return new WP_Error( 'gzip_failed', 'gzip encoding failed.' );
        }
        $ok = @file_put_contents( $path, $bytes );
        if ( $ok === false ) {
            return new WP_Error( 'write_failed', 'Could not write backup file. Check uploads directory permissions.' );
        }

        // Retention sweep is a nice thing to do on every create too — keeps
        // the dir tidy even if daily cron is misfiring for some reason.
        self::prune();

        return $path;
    }

    /* ---------------- list ---------------- */

    /**
     * List backups, newest first. Each entry: { file, path, url, size, mtime, reason }.
     * URL is admin-ajax gated — direct file URL is deny'd by .htaccess.
     */
    public static function list_backups() {
        $dir = self::backup_dir();
        if ( ! $dir ) return [];
        $files = glob( $dir . '/formcraft-backup-*.json*' );
        if ( ! is_array( $files ) ) return [];
        $out = [];
        foreach ( $files as $f ) {
            if ( ! is_file( $f ) ) continue;
            $out[] = [
                'file'   => basename( $f ),
                'path'   => $f,
                'size'   => (int) @filesize( $f ),
                'mtime'  => (int) @filemtime( $f ),
                'reason' => self::parse_reason( $f ),
            ];
        }
        usort( $out, function ( $a, $b ) { return $b['mtime'] - $a['mtime']; } );
        return $out;
    }

    /**
     * Peek inside a backup file (without loading rows) to get manifest info.
     * Cheaper than restore for the UI's row-hover preview.
     */
    public static function inspect( $file ) {
        $path = self::resolve_path( $file );
        if ( is_wp_error( $path ) ) return $path;
        $data = self::read_json( $path );
        if ( is_wp_error( $data ) ) return $data;

        $summary = [
            'file'           => basename( $path ),
            'size'           => (int) @filesize( $path ),
            'mtime'          => (int) @filemtime( $path ),
            'plugin_version' => isset( $data['plugin_version'] ) ? (string) $data['plugin_version'] : 'unknown',
            'created_at'     => isset( $data['created_at'] )     ? (string) $data['created_at'] : '',
            'reason'         => isset( $data['reason'] )         ? (string) $data['reason'] : 'unknown',
            'site_url'       => isset( $data['site_url'] )       ? (string) $data['site_url'] : '',
            'table_counts'   => [],
            'option_count'   => isset( $data['options'] ) && is_array( $data['options'] ) ? count( $data['options'] ) : 0,
        ];
        if ( isset( $data['tables'] ) && is_array( $data['tables'] ) ) {
            foreach ( $data['tables'] as $short => $rows ) {
                $summary['table_counts'][ $short ] = is_array( $rows ) ? count( $rows ) : 0;
            }
        }
        return $summary;
    }

    /* ---------------- restore ---------------- */

    /**
     * Full restore. TRUNCATES the tracked tables + rewrites tracked options
     * from the file. Returns array summary on success, WP_Error on failure.
     *
     * Deliberately does NOT touch WP core tables or non-fcp options.
     */
    public static function restore( $file ) {
        global $wpdb;

        $path = self::resolve_path( $file );
        if ( is_wp_error( $path ) ) return $path;
        $data = self::read_json( $path );
        if ( is_wp_error( $data ) ) return $data;
        if ( empty( $data['tables'] ) && empty( $data['options'] ) ) {
            return new WP_Error( 'empty_backup', 'Backup file appears to be empty or corrupted.' );
        }

        // Make sure the schema exists — restoring into a freshly reinstalled
        // plugin needs the tables to be there before we truncate + insert.
        if ( class_exists( 'FCP_DB' ) ) FCP_DB::activate();
        if ( class_exists( 'FCP_Tokens' ) )  FCP_Tokens::install_table();
        if ( class_exists( 'FCP_2FA' ) )     FCP_2FA::install_table();
        if ( class_exists( 'FCP_Audit' ) )   FCP_Audit::install_table();
        if ( class_exists( 'FCP_Migrator' ) ) FCP_Migrator::ensure_log_table();
        if ( class_exists( 'FCP_Retry_Queue' ) ) FCP_Retry_Queue::ensure_table();

        $restored_tables = [];
        $restored_opts   = 0;

        if ( ! empty( $data['tables'] ) && is_array( $data['tables'] ) ) {
            foreach ( $data['tables'] as $short => $rows ) {
                $full = $wpdb->prefix . $short;
                $exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $full ) );
                if ( ! $exists ) continue;

                $wpdb->query( "TRUNCATE TABLE $full" );
                $inserted = 0;
                if ( is_array( $rows ) ) {
                    foreach ( $rows as $row ) {
                        if ( ! is_array( $row ) ) continue;
                        $safe = [];
                        foreach ( $row as $k => $v ) {
                            $safe[ $k ] = ( $v === null ) ? null : $v;
                        }
                        $r = $wpdb->insert( $full, $safe );
                        if ( $r !== false ) $inserted++;
                    }
                }
                $restored_tables[ $short ] = $inserted;
            }
        }

        if ( ! empty( $data['options'] ) && is_array( $data['options'] ) ) {
            foreach ( $data['options'] as $k => $v ) {
                if ( strpos( $k, 'fcp_' ) !== 0 ) continue; // hard safety fence
                update_option( $k, $v );
                $restored_opts++;
            }
        }

        return [
            'file'    => basename( $path ),
            'tables'  => $restored_tables,
            'options' => $restored_opts,
        ];
    }

    /* ---------------- delete ---------------- */

    public static function delete( $file ) {
        $path = self::resolve_path( $file );
        if ( is_wp_error( $path ) ) return $path;
        if ( ! @unlink( $path ) ) {
            return new WP_Error( 'delete_failed', 'Could not delete file (permissions?).' );
        }
        return true;
    }

    /**
     * Delete files older than settings.retain_days but always keep newest KEEP_MIN.
     * Returns number of files removed.
     */
    public static function prune() {
        $settings = self::get_settings();
        $retain   = max( 1, (int) $settings['retain_days'] );
        $now      = time();
        $cutoff   = $now - ( $retain * DAY_IN_SECONDS );

        $files = self::list_backups();
        $removed = 0;
        $kept    = 0;
        foreach ( $files as $f ) {
            // Always keep the newest KEEP_MIN, no matter how old.
            if ( $kept < self::KEEP_MIN ) { $kept++; continue; }
            if ( $f['mtime'] < $cutoff ) {
                if ( @unlink( $f['path'] ) ) $removed++;
            } else {
                $kept++;
            }
        }
        return $removed;
    }

    /* ---------------- cron ---------------- */

    public static function run_daily() {
        $settings = self::get_settings();
        if ( empty( $settings['auto_enabled'] ) ) return;
        $res = self::create( 'daily-auto' );
        // Prune runs inside create() already; nothing else to do here.
        if ( is_wp_error( $res ) ) {
            error_log( '[FormYantra] Backup failed: ' . $res->get_error_message() );
        }
    }

    /* ---------------- settings ---------------- */

    public static function get_settings() {
        $defaults = [
            'auto_enabled' => 1,
            'retain_days'  => self::DEFAULT_RETAIN,
        ];
        $s = get_option( 'fcp_backup_settings', [] );
        if ( ! is_array( $s ) ) $s = [];
        $s = array_merge( $defaults, $s );
        $s['auto_enabled'] = ! empty( $s['auto_enabled'] ) ? 1 : 0;
        $s['retain_days']  = max( 1, min( 365, (int) $s['retain_days'] ) );
        return $s;
    }

    public static function save_settings( $incoming ) {
        $curr = self::get_settings();
        if ( isset( $incoming['auto_enabled'] ) ) {
            $curr['auto_enabled'] = $incoming['auto_enabled'] ? 1 : 0;
        }
        if ( isset( $incoming['retain_days'] ) ) {
            $curr['retain_days'] = max( 1, min( 365, (int) $incoming['retain_days'] ) );
        }
        update_option( 'fcp_backup_settings', $curr );
        return $curr;
    }

    /* ---------------- helpers ---------------- */

    /**
     * Resolve a caller-supplied filename to a path inside the backup dir.
     * Rejects anything that tries to break out with slashes or "..".
     */
    private static function resolve_path( $file ) {
        $file = basename( (string) $file );
        if ( $file === '' || strpos( $file, 'formcraft-backup-' ) !== 0 ) {
            return new WP_Error( 'bad_name', 'Invalid backup filename.' );
        }
        $dir = self::backup_dir();
        if ( ! $dir ) return new WP_Error( 'no_dir', 'Backup directory not available.' );
        $path = $dir . '/' . $file;
        if ( ! is_file( $path ) ) return new WP_Error( 'not_found', 'Backup file not found.' );
        return $path;
    }

    private static function read_json( $path ) {
        $raw = @file_get_contents( $path );
        if ( $raw === false ) return new WP_Error( 'read_failed', 'Could not read backup file.' );
        // Auto-detect gzip magic bytes (1f 8b).
        if ( strlen( $raw ) >= 2 && substr( $raw, 0, 2 ) === "\x1f\x8b" ) {
            if ( ! function_exists( 'gzdecode' ) ) {
                return new WP_Error( 'no_gzip', 'This backup is gzipped but zlib is unavailable on this server.' );
            }
            $raw = @gzdecode( $raw );
            if ( $raw === false ) return new WP_Error( 'gunzip_failed', 'Could not decompress backup file.' );
        }
        $data = json_decode( $raw, true );
        if ( ! is_array( $data ) ) return new WP_Error( 'bad_json', 'Backup file is not valid JSON.' );
        return $data;
    }

    private static function parse_reason( $path ) {
        // Optional cheap peek — grab first 512 bytes and look for "reason":
        // gz-compressed files hide it, so fall back to "unknown" there.
        $fh = @fopen( $path, 'rb' );
        if ( ! $fh ) return 'unknown';
        $head = fread( $fh, 512 );
        fclose( $fh );
        if ( $head === false || $head === '' ) return 'unknown';
        if ( substr( $head, 0, 2 ) === "\x1f\x8b" ) return 'unknown'; // gzipped
        if ( preg_match( '/"reason"\s*:\s*"([a-z0-9_-]+)"/i', $head, $m ) ) {
            return $m[1];
        }
        return 'unknown';
    }
}
