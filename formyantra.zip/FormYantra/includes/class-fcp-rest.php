<?php
/**
 * FormYantra - REST API.
 *
 * Endpoints under /wp-json/formcraft/v1/:
 *   GET    /forms                 list forms
 *   POST   /forms                 create a form
 *   GET    /forms/{id}            get a form
 *   PUT    /forms/{id}            update a form
 *   DELETE /forms/{id}            delete a form
 *   POST   /forms/{id}/submit     PUBLIC submit a form (also bumps view)
 *   GET    /submissions           list submissions
 *   GET    /submissions/{id}      get one
 *   PUT    /submissions/{id}      update (mark read/spam, notes)
 *   DELETE /submissions/{id}      delete
 *   GET    /settings              get settings
 *   PUT    /settings              save settings
 *
 * Authenticated endpoints require the 'manage_options' capability via the
 * standard WP REST nonce. The /submit endpoint is intentionally open and
 * protected by reCAPTCHA + honeypot + IP rate limit instead.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_REST {

    const NAMESPACE = 'formcraft/v1';

    public function __construct() {
        add_action( 'rest_api_init', [ $this, 'register' ] );
    }

    public function register() {
        $ns = self::NAMESPACE;

        register_rest_route( $ns, '/forms', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [ $this, 'list_forms' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [ $this, 'create_form' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
        ] );

        register_rest_route( $ns, '/forms/(?P<id>\d+)', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [ $this, 'get_form' ],
                'permission_callback' => '__return_true', // public for rendering
            ],
            [
                'methods'             => WP_REST_Server::EDITABLE,
                'callback'            => [ $this, 'update_form' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
            [
                'methods'             => WP_REST_Server::DELETABLE,
                'callback'            => [ $this, 'delete_form' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
        ] );

        register_rest_route( $ns, '/forms/(?P<id>\d+)/submit', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'submit_form' ],
            'permission_callback' => '__return_true',
        ] );

        register_rest_route( $ns, '/forms/import', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'import_form' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        /* ---------- 1-Click Migration endpoints ---------- */
        register_rest_route( $ns, '/migrator/detect', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'migrator_detect' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/migrator/(?P<source>[a-z0-9_-]+)/forms', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'migrator_list_forms' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/migrator/import', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'migrator_import' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/migrator/history', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'migrator_history' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/migrator/rollback/(?P<id>\d+)', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'migrator_rollback' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        // Dry-run: same shape as /migrator/import but writes nothing,
        // returns a preview form payload so the UI can render a diff.
        register_rest_route( $ns, '/migrator/dry-run', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'migrator_dry_run' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        // Compatibility matrix + per-source feature scores — the UI uses
        // this to render the score chip and the "what carries over"
        // tooltip on each source card.
        register_rest_route( $ns, '/migrator/compatibility', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'migrator_compatibility' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        // Site-wide shortcode swap. POST { source, old_id, new_form_id }
        // → { posts: N, widgets: N, locations: [...] }
        register_rest_route( $ns, '/migrator/replace-shortcodes', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'migrator_replace_shortcodes' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        // Send a test notification from a freshly-imported form so the
        // admin can verify that emails work BEFORE the first real visitor
        // submits. POST { form_id }
        register_rest_route( $ns, '/migrator/test-notification', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'migrator_test_notification' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        // v2.54 — Force-send a digest right now (admin testing the cadence).
        register_rest_route( $ns, '/digest/send-now', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'digest_send_now' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        register_rest_route( $ns, '/forms/(?P<id>\d+)/status', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'set_form_status' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        register_rest_route( $ns, '/forms/(?P<id>\d+)/revisions', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'list_revisions' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/forms/(?P<id>\d+)/revisions/(?P<rid>\d+)/restore', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'restore_revision' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        register_rest_route( $ns, '/forms/(?P<id>\d+)/view', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'track_view' ],
            'permission_callback' => '__return_true',
        ] );

        register_rest_route( $ns, '/forms/(?P<id>\d+)/step-event', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'track_step_event' ],
            'permission_callback' => '__return_true',
        ] );

        // Form Abandonment: auto-save partial form data. Public — anyone
        // filling the form can hit it.
        register_rest_route( $ns, '/forms/(?P<id>\d+)/track-partial', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'track_partial' ],
            'permission_callback' => '__return_true',
        ] );

        // Admin: list / delete / recover abandoned entries.
        register_rest_route( $ns, '/abandoned', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'list_abandoned' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/abandoned/(?P<id>\d+)', [
            'methods'             => WP_REST_Server::DELETABLE,
            'callback'            => [ $this, 'delete_abandoned' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/abandoned/(?P<id>\d+)/recover', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'send_recovery_email' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        register_rest_route( $ns, '/forms/(?P<id>\d+)/poll-results', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'get_poll_results' ],
            'permission_callback' => '__return_true',
        ] );

        register_rest_route( $ns, '/forms/(?P<id>\d+)/slot-availability', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'get_slot_availability' ],
            'permission_callback' => '__return_true',
        ] );

        register_rest_route( $ns, '/forms/(?P<id>\d+)/dropoff', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'get_dropoff' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        register_rest_route( $ns, '/submissions', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'list_submissions' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        register_rest_route( $ns, '/submissions/(?P<id>\d+)', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [ $this, 'get_submission' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
            [
                'methods'             => WP_REST_Server::EDITABLE,
                'callback'            => [ $this, 'update_submission' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
            [
                'methods'             => WP_REST_Server::DELETABLE,
                'callback'            => [ $this, 'delete_submission' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
        ] );

        register_rest_route( $ns, '/settings', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [ $this, 'get_settings' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
            [
                'methods'             => WP_REST_Server::EDITABLE,
                'callback'            => [ $this, 'update_settings' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
        ] );

        register_rest_route( $ns, '/stats', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'get_stats' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        // v2.72.35 — GoHighLevel (GHL) integration.
        //   /ghl/test-connection  → admin-only, verifies token + location.
        //   /ghl/workflows        → admin-only, lists workflows for the mapped dropdown.
        //   /ghl/webhook          → PUBLIC, HMAC-verified in the handler.
        register_rest_route( $ns, '/ghl/test-connection', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => function () { return rest_ensure_response( FCP_GHL::test_connection() ); },
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/ghl/workflows', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => function () { return rest_ensure_response( FCP_GHL::list_workflows() ); },
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/ghl/webhook', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ 'FCP_GHL', 'handle_webhook' ],
            'permission_callback' => '__return_true',
        ] );

        // v2.72.9 — Primary REST API key for the Settings → Advanced widget.
        // GET reveals the current key (or auto-mints one if missing).
        // POST regenerates it. Stored in wp_options.fcp_settings.rest_api_key.
        register_rest_route( $ns, '/settings/api-key', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [ $this, 'get_api_key' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [ $this, 'regenerate_api_key' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
        ] );

        register_rest_route( $ns, '/test-email', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'send_test_email' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        register_rest_route( $ns, '/support', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'send_support_request' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        register_rest_route( $ns, '/submissions/(?P<id>\d+)/resend', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'resend_submission_email' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        register_rest_route( $ns, '/submissions/(?P<id>\d+)/verify-payment', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'verify_payment' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        register_rest_route( $ns, '/submissions/(?P<id>\d+)/approve', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'approve_submission' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        // v2.52 — Submission workflow endpoints
        register_rest_route( $ns, '/submissions/(?P<id>\d+)/assignee', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'set_submission_assignee' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/submissions/(?P<id>\d+)/comment', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'add_submission_comment' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/submissions/(?P<id>\d+)/field', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'inline_edit_submission_field' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/submissions/(?P<id>\d+)/reply-email', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'send_reply_email' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/submissions/(?P<id>\d+)/mark-spam', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'mark_submission_spam' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/users-list', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'get_wp_users_list' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        register_rest_route( $ns, '/mail-log', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'get_mail_log' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        register_rest_route( $ns, '/smtp-status', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'get_smtp_status' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        /* ---------- Payment gateway endpoints (public) ---------- */
        register_rest_route( $ns, '/payment/create-order', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'payment_create_order' ],
            'permission_callback' => '__return_true', // visitors can pay
        ] );
        register_rest_route( $ns, '/payment/verify', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'payment_verify' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( $ns, '/payment/webhook/(?P<gateway>[a-z]+)', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'payment_webhook' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( $ns, '/payment/refund/(?P<id>\d+)', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'payment_refund' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        /* ---------- Coupons ---------- */
        register_rest_route( $ns, '/coupons', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [ $this, 'list_coupons' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [ $this, 'create_coupon' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
        ] );
        register_rest_route( $ns, '/coupons/(?P<id>\d+)', [
            [
                'methods'             => WP_REST_Server::EDITABLE,
                'callback'            => [ $this, 'update_coupon' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
            [
                'methods'             => WP_REST_Server::DELETABLE,
                'callback'            => [ $this, 'delete_coupon' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
        ] );
        register_rest_route( $ns, '/coupons/validate', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'validate_coupon' ],
            'permission_callback' => '__return_true', // public — form visitors apply codes
        ] );

        /* ---------- Webhooks ---------- */
        register_rest_route( $ns, '/webhooks', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [ $this, 'list_webhooks' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [ $this, 'create_webhook' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
        ] );
        register_rest_route( $ns, '/webhooks/(?P<id>\d+)', [
            [
                'methods'             => WP_REST_Server::EDITABLE,
                'callback'            => [ $this, 'update_webhook' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
            [
                'methods'             => WP_REST_Server::DELETABLE,
                'callback'            => [ $this, 'delete_webhook' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
        ] );
        register_rest_route( $ns, '/webhooks/(?P<id>\d+)/test', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'test_webhook' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        /* ---------- AI form generator ---------- */
        register_rest_route( $ns, '/ai/generate-form', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'ai_generate_form' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        // v2.58 — AI Smart Layer endpoints
        register_rest_route( $ns, '/ai/detect-purpose', [
            'methods' => WP_REST_Server::CREATABLE, 'callback' => [ $this, 'ai_detect_purpose' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/ai/normalize-labels', [
            'methods' => WP_REST_Server::CREATABLE, 'callback' => [ $this, 'ai_normalize_labels' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/ai/suggest-fields', [
            'methods' => WP_REST_Server::CREATABLE, 'callback' => [ $this, 'ai_suggest_fields' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/ai/draft-reply', [
            'methods' => WP_REST_Server::CREATABLE, 'callback' => [ $this, 'ai_draft_reply' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/ai/categorize', [
            'methods' => WP_REST_Server::CREATABLE, 'callback' => [ $this, 'ai_categorize' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/ai/sentiment', [
            'methods' => WP_REST_Server::CREATABLE, 'callback' => [ $this, 'ai_sentiment' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/ai/ocr', [
            'methods' => WP_REST_Server::CREATABLE, 'callback' => [ $this, 'ai_ocr' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        // v2.59 — Translation (DeepL / Google / Anthropic)
        register_rest_route( $ns, '/i18n/translate', [
            'methods' => WP_REST_Server::CREATABLE, 'callback' => [ $this, 'i18n_translate' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        // v2.61 — Audit log + GDPR + RTBF
        register_rest_route( $ns, '/audit/list', [
            'methods' => WP_REST_Server::READABLE, 'callback' => [ $this, 'audit_list' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/audit/summary', [
            'methods' => WP_REST_Server::READABLE, 'callback' => [ $this, 'audit_summary' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/pii/inventory', [
            'methods' => WP_REST_Server::READABLE, 'callback' => [ $this, 'pii_inventory' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/pii/lookup', [
            'methods' => WP_REST_Server::CREATABLE, 'callback' => [ $this, 'pii_lookup' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/pii/forget', [
            'methods' => WP_REST_Server::CREATABLE, 'callback' => [ $this, 'pii_forget' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        /* ---------- Membership toggle (admin) ---------- */
        register_rest_route( $ns, '/membership', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [ $this, 'get_membership' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [ $this, 'set_membership' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
        ] );

        /* ---------- Form Users (admin) ---------- */
        register_rest_route( $ns, '/form-users', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'list_form_users' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/form-users/(?P<id>\d+)', [
            [
                'methods'             => WP_REST_Server::EDITABLE,
                'callback'            => [ $this, 'update_form_user' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
            [
                'methods'             => WP_REST_Server::DELETABLE,
                'callback'            => [ $this, 'delete_form_user' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
        ] );

        /* ---------- Spam log (real submissions where is_spam=1) ---------- */
        register_rest_route( $ns, '/spam-log', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'get_spam_log' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        /* ---------- Save & Continue (public) ---------- */
        register_rest_route( $ns, '/forms/(?P<id>\d+)/save-draft', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'save_draft' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( $ns, '/forms/(?P<id>\d+)/resume-draft', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'resume_draft' ],
            'permission_callback' => '__return_true',
        ] );

        /* ---------- File upload (public — used by File/Image fields) ---------- */
        register_rest_route( $ns, '/upload-file', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'upload_file' ],
            'permission_callback' => '__return_true',
        ] );

        /* ---------- OTP ---------- */
        register_rest_route( $ns, '/otp/send', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'otp_send' ],
            'permission_callback' => '__return_true', // form visitors
        ] );
        register_rest_route( $ns, '/otp/verify', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'otp_verify' ],
            'permission_callback' => '__return_true',
        ] );

        /* ---------- WooCommerce ---------- */
        register_rest_route( $ns, '/wc/status', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'wc_status' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/wc/products', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'wc_products' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        /* ---------- Currency / Locale detection (public) ---------- */
        register_rest_route( $ns, '/detect-currency', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'detect_currency_endpoint' ],
            'permission_callback' => '__return_true',
        ] );

        /* ---------- Backfill country on existing submissions (admin) ---------- */
        register_rest_route( $ns, '/backfill-countries', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'backfill_countries' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        /* ---------- Airtable schema discovery (admin only) ---------- */
        register_rest_route( $ns, '/integrations/airtable/test', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'airtable_test' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/integrations/airtable/bases', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'airtable_bases' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/integrations/airtable/tables', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'airtable_tables' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        // v2.70.14 — Google Sheets test-connection endpoint
        register_rest_route( $ns, '/integrations/google-sheets/test', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'google_sheets_test' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        /* ---------- Backup & Restore (v2.68) ---------- */
        register_rest_route( $ns, '/backups', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [ $this, 'backup_list' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
            [
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => [ $this, 'backup_create' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
        ] );
        register_rest_route( $ns, '/backups/settings', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [ $this, 'backup_get_settings' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
            [
                'methods'             => WP_REST_Server::EDITABLE,
                'callback'            => [ $this, 'backup_save_settings' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
        ] );
        register_rest_route( $ns, '/backups/(?P<file>[A-Za-z0-9._-]+)', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [ $this, 'backup_inspect' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
            [
                'methods'             => WP_REST_Server::DELETABLE,
                'callback'            => [ $this, 'backup_delete' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
        ] );
        register_rest_route( $ns, '/backups/(?P<file>[A-Za-z0-9._-]+)/restore', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'backup_restore' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/backups/(?P<file>[A-Za-z0-9._-]+)/download', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'backup_download' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        /* ---------- Payment Analytics (v2.70.2) ---------- */
        register_rest_route( $ns, '/payments/analytics', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'payments_analytics' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );

        /* ---------- India Suite (v2.70) ---------- */
        // IFSC lookup — PUBLIC (rate-limited by transient cache + upstream)
        register_rest_route( $ns, '/india/ifsc/(?P<code>[A-Za-z0-9]{11})', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'india_ifsc' ],
            'permission_callback' => '__return_true',
        ] );
        // Vehicle lookup — requires manage_options (uses paid API keys)
        register_rest_route( $ns, '/india/vehicle', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'india_vehicle' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        // Settings get/save
        register_rest_route( $ns, '/india/settings', [
            [
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => [ $this, 'india_get_settings' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
            [
                'methods'             => WP_REST_Server::EDITABLE,
                'callback'            => [ $this, 'india_save_settings' ],
                'permission_callback' => [ $this, 'can_manage' ],
            ],
        ] );
        // Manual test buttons
        register_rest_route( $ns, '/india/test-whatsapp', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'india_test_whatsapp' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        register_rest_route( $ns, '/india/test-sms', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'india_test_sms' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
        // GST invoice HTML (streams for print-to-PDF)
        register_rest_route( $ns, '/submissions/(?P<id>\d+)/invoice', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'india_invoice' ],
            'permission_callback' => [ $this, 'can_manage' ],
        ] );
    }

    /**
     * v2.70.9 — Sum up the priced picks in a submission's data against the
     * form's field definitions. Product Selector matches by product name,
     * Pricing Table by tier name, Calculation reads its numeric value. Used
     * by verify_payment to auto-fill payment_amount for manual UPI / Bank /
     * COD verifications, and by the one-shot healer that back-fills the
     * counter on legacy zero-amount paid rows.
     */
    public static function compute_amount_from_form_data( $form, $data ) {
        if ( ! is_array( $form ) || empty( $form['steps'] ) || ! is_array( $data ) ) return 0;
        $total = 0;
        foreach ( (array) $form['steps'] as $step ) {
            foreach ( (array) ( $step['fields'] ?? [] ) as $f ) {
                if ( ! is_array( $f ) || empty( $f['label'] ) ) continue;
                $picked = $data[ $f['label'] ] ?? null;
                if ( $picked === null || $picked === '' ) continue;
                $type = $f['type'] ?? '';

                if ( $type === 'product' && ! empty( $f['products'] ) && is_array( $f['products'] ) ) {
                    foreach ( $f['products'] as $p ) {
                        if ( is_array( $p ) && strcasecmp( (string) ( $p['name'] ?? '' ), (string) $picked ) === 0 ) {
                            $total += (float) ( $p['price'] ?? 0 );
                            break;
                        }
                    }
                } elseif ( $type === 'pricing' && ! empty( $f['tiers'] ) && is_array( $f['tiers'] ) ) {
                    foreach ( $f['tiers'] as $t ) {
                        if ( is_array( $t ) && strcasecmp( (string) ( $t['name'] ?? '' ), (string) $picked ) === 0 ) {
                            $total += (float) ( $t['price'] ?? 0 );
                            break;
                        }
                    }
                } elseif ( $type === 'calculation' ) {
                    $n = (float) preg_replace( '/[^0-9.\-]/', '', (string) $picked );
                    if ( $n > 0 ) $total += $n;
                }
            }
        }
        return $total;
    }

    /* ---------- Payment Analytics handler (v2.70.2) ---------- */
    /**
     * Aggregate everything the Payment Analytics dashboard needs in ONE
     * REST hit. Accepts ?range=7d|30d|90d|12mo|all. All amounts stay in
     * their original currency — the UI renders per-currency totals so
     * mixed INR + USD forms don't silently sum incompatible values.
     */
    public function payments_analytics( $req ) {
        global $wpdb;
        $table   = FCP_DB::subs_table();
        $forms_t = FCP_DB::forms_table();
        $range   = sanitize_key( (string) ( $req->get_param( 'range' ) ?? '30d' ) );

        // v2.70.9 — 60-second cache keyed by range. The 8-query aggregate is
        // cheap on small sites but scales O(rows). Two admins hitting refresh
        // one after another now share the same computation. Explicit bust
        // happens on any submission mutation (create/update/delete) via
        // fcp_bust_payment_analytics — see the hooks at the end of this file.
        $cache_key = 'fcp_pay_analytics_' . $range;
        $cached = wp_cache_get( $cache_key, 'formcraft-pro' );
        if ( is_array( $cached ) ) {
            return rest_ensure_response( $cached );
        }

        $range_map = [
            '7d'   => '7 DAY',
            '30d'  => '30 DAY',
            '90d'  => '90 DAY',
            '12mo' => '365 DAY',
            'all'  => null,
        ];
        $interval = $range_map[ $range ] ?? '30 DAY';
        $where_time = $interval
            ? "AND paid_at >= DATE_SUB(NOW(), INTERVAL $interval)"
            : '';

        // ---- Headline KPIs (paid only, positive amounts) ----
        $kpi_row = $wpdb->get_row(
            "SELECT
                COUNT(*)                                    AS txn_count,
                COALESCE(SUM(payment_amount), 0)            AS revenue,
                COALESCE(AVG(payment_amount), 0)            AS aov,
                COALESCE(SUM(coupon_discount), 0)           AS discount_total,
                COUNT(DISTINCT submitter_email)             AS unique_buyers
             FROM $table
             WHERE payment_status = 'paid' AND payment_amount > 0 $where_time",
            ARRAY_A
        );

        // ---- Time series for chart (bucketed by day, or by month for 12mo) ----
        $bucket_fmt = ( $range === '12mo' ) ? "DATE_FORMAT(paid_at, '%Y-%m')" : "DATE(paid_at)";
        $series = $wpdb->get_results(
            "SELECT $bucket_fmt AS bucket,
                    COUNT(*) AS txns,
                    COALESCE(SUM(payment_amount), 0) AS revenue
             FROM $table
             WHERE payment_status = 'paid' AND payment_amount > 0 $where_time
             GROUP BY bucket ORDER BY bucket ASC",
            ARRAY_A
        );

        // ---- Top gateways breakdown ----
        $gateways = $wpdb->get_results(
            "SELECT COALESCE(NULLIF(payment_provider, ''), 'other') AS gateway,
                    COUNT(*) AS txns,
                    COALESCE(SUM(payment_amount), 0) AS revenue
             FROM $table
             WHERE payment_status = 'paid' AND payment_amount > 0 $where_time
             GROUP BY gateway
             ORDER BY revenue DESC
             LIMIT 10",
            ARRAY_A
        );

        // ---- Top forms by revenue ----
        $top_forms = $wpdb->get_results(
            "SELECT s.form_id, f.title AS form_title,
                    COUNT(*) AS txns,
                    COALESCE(SUM(s.payment_amount), 0) AS revenue
             FROM $table s
             LEFT JOIN $forms_t f ON f.id = s.form_id
             WHERE s.payment_status = 'paid' AND s.payment_amount > 0 $where_time
             GROUP BY s.form_id
             ORDER BY revenue DESC
             LIMIT 5",
            ARRAY_A
        );

        // ---- Currency mix (so mixed-currency admins see totals per currency) ----
        $currencies = $wpdb->get_results(
            "SELECT COALESCE(NULLIF(payment_currency, ''), 'INR') AS currency,
                    COUNT(*) AS txns,
                    COALESCE(SUM(payment_amount), 0) AS revenue
             FROM $table
             WHERE payment_status = 'paid' AND payment_amount > 0 $where_time
             GROUP BY currency
             ORDER BY revenue DESC",
            ARRAY_A
        );

        // ---- Payment status breakdown (paid/failed/pending/refunded) ----
        $statuses = $wpdb->get_results(
            "SELECT COALESCE(NULLIF(payment_status, ''), 'none') AS status,
                    COUNT(*) AS txns,
                    COALESCE(SUM(payment_amount), 0) AS revenue
             FROM $table
             WHERE payment_status != 'none'
               " . ( $interval ? "AND (paid_at >= DATE_SUB(NOW(), INTERVAL $interval) OR created_at >= DATE_SUB(NOW(), INTERVAL $interval))" : "" ) . "
             GROUP BY status
             ORDER BY txns DESC",
            ARRAY_A
        );

        // ---- Recent transactions (latest 12 paid) ----
        $recent = $wpdb->get_results(
            "SELECT s.id, s.form_id, s.submitter_name, s.submitter_email,
                    s.payment_amount, s.payment_currency, s.payment_provider,
                    s.payment_id, s.paid_at,
                    f.title AS form_title
             FROM $table s
             LEFT JOIN $forms_t f ON f.id = s.form_id
             WHERE s.payment_status = 'paid' AND s.payment_amount > 0 $where_time
             ORDER BY s.paid_at DESC
             LIMIT 12",
            ARRAY_A
        );

        // ---- Coupon usage summary ----
        $coupon_usage = $wpdb->get_row(
            "SELECT COUNT(*) AS txns_with_coupon,
                    COALESCE(SUM(coupon_discount), 0) AS discount_given
             FROM $table
             WHERE payment_status = 'paid' AND coupon_code IS NOT NULL AND coupon_code != '' $where_time",
            ARRAY_A
        );

        // ---- Compare-to-previous-period lift (for the KPI arrows) ----
        $lift = null;
        if ( $interval ) {
            $prev_row = $wpdb->get_row(
                "SELECT COUNT(*) AS txn_count,
                        COALESCE(SUM(payment_amount), 0) AS revenue
                 FROM $table
                 WHERE payment_status = 'paid' AND payment_amount > 0
                   AND paid_at >= DATE_SUB(NOW(), INTERVAL $interval) * 2
                   AND paid_at <  DATE_SUB(NOW(), INTERVAL $interval)",
                ARRAY_A
            );
            $lift = [
                'revenue_prev' => (float) ( $prev_row['revenue']   ?? 0 ),
                'txns_prev'    => (int)   ( $prev_row['txn_count'] ?? 0 ),
            ];
        }

        $response = [
            'range'        => $range,
            'kpi'          => [
                'revenue'        => (float) $kpi_row['revenue'],
                'txn_count'      => (int)   $kpi_row['txn_count'],
                'aov'            => (float) $kpi_row['aov'],
                'discount_total' => (float) $kpi_row['discount_total'],
                'unique_buyers'  => (int)   $kpi_row['unique_buyers'],
            ],
            'lift'         => $lift,
            'series'       => array_map( function ( $r ) {
                return [ 'bucket' => $r['bucket'], 'txns' => (int) $r['txns'], 'revenue' => (float) $r['revenue'] ];
            }, (array) $series ),
            'gateways'     => array_map( function ( $r ) {
                return [ 'gateway' => $r['gateway'], 'txns' => (int) $r['txns'], 'revenue' => (float) $r['revenue'] ];
            }, (array) $gateways ),
            'top_forms'    => array_map( function ( $r ) {
                return [ 'form_id' => (int) $r['form_id'], 'title' => $r['form_title'] ?: '(deleted form)', 'txns' => (int) $r['txns'], 'revenue' => (float) $r['revenue'] ];
            }, (array) $top_forms ),
            'currencies'   => array_map( function ( $r ) {
                return [ 'currency' => $r['currency'], 'txns' => (int) $r['txns'], 'revenue' => (float) $r['revenue'] ];
            }, (array) $currencies ),
            'statuses'     => array_map( function ( $r ) {
                return [ 'status' => $r['status'], 'txns' => (int) $r['txns'], 'revenue' => (float) $r['revenue'] ];
            }, (array) $statuses ),
            'recent'       => array_map( function ( $r ) {
                return [
                    'id'       => (int) $r['id'],
                    'form_id'  => (int) $r['form_id'],
                    'form'     => $r['form_title'] ?: '(deleted form)',
                    'name'     => (string) $r['submitter_name'],
                    'email'    => (string) $r['submitter_email'],
                    'amount'   => (float) $r['payment_amount'],
                    'currency' => (string) $r['payment_currency'],
                    'gateway'  => (string) $r['payment_provider'],
                    'payment_id' => (string) $r['payment_id'],
                    'paid_at'  => (string) $r['paid_at'],
                ];
            }, (array) $recent ),
            'coupons'      => [
                'txns_with_coupon' => (int)   ( $coupon_usage['txns_with_coupon'] ?? 0 ),
                'discount_given'   => (float) ( $coupon_usage['discount_given']   ?? 0 ),
            ],
        ];
        // v2.70.9 — Store in object cache for 60s. Redis / Memcached / any
        // persistent object cache picks this up; if none is installed, this
        // silently no-ops and every request runs the queries fresh (same
        // behaviour as before).
        wp_cache_set( $cache_key, $response, 'formcraft-pro', 60 );
        return rest_ensure_response( $response );
    }

    /* ---------- India handlers (v2.70) ---------- */
    public function india_ifsc( $req ) {
        if ( ! class_exists( 'FCP_India' ) ) return new WP_Error( 'unavailable', 'India suite unavailable.', [ 'status' => 500 ] );
        $res = FCP_India::lookup_ifsc( (string) $req['code'] );
        if ( is_wp_error( $res ) ) return new WP_Error( $res->get_error_code(), $res->get_error_message(), [ 'status' => 404 ] );
        return rest_ensure_response( $res );
    }
    public function india_vehicle( $req ) {
        $body = $req->get_json_params();
        $reg  = isset( $body['registration'] ) ? (string) $body['registration'] : '';
        $res  = FCP_India::lookup_vehicle( $reg );
        if ( is_wp_error( $res ) ) return new WP_Error( $res->get_error_code(), $res->get_error_message(), [ 'status' => 400 ] );
        return rest_ensure_response( $res );
    }
    public function india_get_settings() {
        return rest_ensure_response( FCP_India::get_settings() );
    }
    public function india_save_settings( $req ) {
        $body = $req->get_json_params();
        if ( ! is_array( $body ) ) $body = [];
        return rest_ensure_response( FCP_India::save_settings( $body ) );
    }
    public function india_test_whatsapp( $req ) {
        $body = $req->get_json_params();
        $to   = (string) ( $body['to'] ?? '' );
        $res  = FCP_India::send_whatsapp( $to, 'admin', [ 'FormYantra Test', 'Test Admin', 'Test Phone', home_url() ] );
        if ( is_wp_error( $res ) ) return new WP_Error( $res->get_error_code(), $res->get_error_message(), [ 'status' => 400 ] );
        return rest_ensure_response( $res );
    }
    public function india_test_sms( $req ) {
        $body = $req->get_json_params();
        $to   = (string) ( $body['to'] ?? '' );
        $res  = FCP_India::send_sms( $to, 'FormYantra test SMS. If you received this, integration works.' );
        if ( is_wp_error( $res ) ) return new WP_Error( $res->get_error_code(), $res->get_error_message(), [ 'status' => 400 ] );
        return rest_ensure_response( $res );
    }
    public function india_invoice( $req ) {
        $res = FCP_India::generate_gst_invoice( (int) $req['id'] );
        if ( is_wp_error( $res ) ) return new WP_Error( $res->get_error_code(), $res->get_error_message(), [ 'status' => 404 ] );
        nocache_headers();
        header( 'Content-Type: text/html; charset=UTF-8' );
        echo $res['html'];
        exit;
    }

    /* ---------- Backup handlers (v2.68) ---------- */

    public function backup_list() {
        if ( ! class_exists( 'FCP_Backup' ) ) {
            return new WP_Error( 'unavailable', 'Backup class not loaded.', [ 'status' => 500 ] );
        }
        return rest_ensure_response( [
            'backups'  => FCP_Backup::list_backups(),
            'settings' => FCP_Backup::get_settings(),
            'dir'      => FCP_Backup::backup_dir(),
        ] );
    }

    public function backup_create() {
        $res = FCP_Backup::create( 'manual' );
        if ( is_wp_error( $res ) ) {
            return new WP_Error( $res->get_error_code(), $res->get_error_message(), [ 'status' => 500 ] );
        }
        return rest_ensure_response( [ 'ok' => true, 'file' => basename( $res ) ] );
    }

    public function backup_get_settings() {
        return rest_ensure_response( FCP_Backup::get_settings() );
    }

    public function backup_save_settings( $req ) {
        $body = $req->get_json_params();
        if ( ! is_array( $body ) ) $body = [];
        return rest_ensure_response( FCP_Backup::save_settings( $body ) );
    }

    public function backup_inspect( $req ) {
        $res = FCP_Backup::inspect( (string) $req['file'] );
        if ( is_wp_error( $res ) ) {
            return new WP_Error( $res->get_error_code(), $res->get_error_message(), [ 'status' => 404 ] );
        }
        return rest_ensure_response( $res );
    }

    public function backup_delete( $req ) {
        $res = FCP_Backup::delete( (string) $req['file'] );
        if ( is_wp_error( $res ) ) {
            return new WP_Error( $res->get_error_code(), $res->get_error_message(), [ 'status' => 400 ] );
        }
        return rest_ensure_response( [ 'ok' => true ] );
    }

    public function backup_restore( $req ) {
        $res = FCP_Backup::restore( (string) $req['file'] );
        if ( is_wp_error( $res ) ) {
            return new WP_Error( $res->get_error_code(), $res->get_error_message(), [ 'status' => 500 ] );
        }
        return rest_ensure_response( [ 'ok' => true, 'restored' => $res ] );
    }

    /**
     * Streams the backup file to the browser. The file itself is deny'd via
     * .htaccess in the backup dir — this handler is the only path to it, and
     * it's guarded by manage_options.
     */
    public function backup_download( $req ) {
        $file = basename( (string) $req['file'] );
        $dir  = FCP_Backup::backup_dir();
        if ( ! $dir ) {
            return new WP_Error( 'no_dir', 'Backup directory not available.', [ 'status' => 500 ] );
        }
        $path = $dir . '/' . $file;
        if ( ! is_file( $path ) || strpos( $file, 'formcraft-backup-' ) !== 0 ) {
            return new WP_Error( 'not_found', 'File not found.', [ 'status' => 404 ] );
        }
        $is_gz = substr( $file, -3 ) === '.gz';
        nocache_headers();
        header( 'Content-Type: ' . ( $is_gz ? 'application/gzip' : 'application/json' ) );
        header( 'Content-Disposition: attachment; filename="' . $file . '"' );
        header( 'Content-Length: ' . filesize( $path ) );
        readfile( $path );
        exit;
    }

    /* ---------- Save & Continue ---------- */
    /**
     * Save a partial submission as a transient and email the visitor a
     * resume URL. The token is a SHA1 of random_bytes — unguessable and
     * unique per draft. Drafts expire after 7 days by default.
     */
    public function save_draft( $req ) {
        $form_id = (int) $req['id'];
        $form    = FCP_DB::get_form( $form_id );
        if ( ! $form ) return new WP_Error( 'not_found', 'Form not found.', [ 'status' => 404 ] );
        $body    = $req->get_json_params();
        $email   = isset( $body['email'] ) ? sanitize_email( $body['email'] ) : '';
        $data    = isset( $body['data'] ) && is_array( $body['data'] ) ? $body['data'] : [];
        $step    = isset( $body['step'] ) ? (int) $body['step'] : 0;
        if ( ! is_email( $email ) ) {
            return new WP_Error( 'bad_email', 'Please enter a valid email so we can send you the resume link.', [ 'status' => 400 ] );
        }

        // Rate-limit: max 5 draft saves per IP per 10 minutes.
        $ip = FCP_DB::get_ip();
        if ( $ip ) {
            $rk = 'fcp_draft_rl_' . md5( $ip );
            $ct = (int) get_transient( $rk );
            if ( $ct >= 5 ) {
                return new WP_Error( 'rate_limited', 'Too many draft saves — try again later.', [ 'status' => 429 ] );
            }
            set_transient( $rk, $ct + 1, 10 * MINUTE_IN_SECONDS );
        }

        $token = bin2hex( random_bytes( 16 ) );
        set_transient( 'fcp_draft_' . $token, [
            'form_id' => $form_id,
            'email'   => $email,
            'data'    => $data,
            'step'    => $step,
            'saved'   => time(),
        ], 7 * DAY_IN_SECONDS );

        // Build the resume URL. The form-engine reads ?fcp_draft=<token> on
        // load and prefills every field by label.
        $page_url = ! empty( $body['return_url'] ) ? esc_url_raw( $body['return_url'] ) : home_url( '/' );
        $resume_url = add_query_arg( 'fcp_draft', $token, $page_url );

        $site       = get_bloginfo( 'name' );
        $form_title = isset( $form['title'] ) ? $form['title'] : $site;
        $subject    = sprintf( '%s — Your form draft has been saved', $form_title );
        $html  = '<div style="font-family:Inter,Arial,sans-serif;color:#0f172a;max-width:640px;margin:0 auto;line-height:1.55;">';
        $html .= '<div style="background:#fff;padding:28px;border:1px solid #e5e7eb;border-radius:10px;border-top:4px solid #6366f1;">';
        $html .= '<h2 style="margin:0 0 8px;font-size:22px;">Pick up where you left off</h2>';
        $html .= '<p style="margin:0 0 18px;color:#475569;">We saved your progress on <strong>' . esc_html( $form_title ) . '</strong>. Click the button below to continue — your link is valid for 7 days.</p>';
        $html .= '<p style="margin:24px 0;"><a href="' . esc_url( $resume_url ) . '" style="display:inline-block;background:#6366f1;color:#fff;padding:12px 22px;border-radius:8px;font-weight:700;text-decoration:none;">Resume your form →</a></p>';
        $html .= '<p style="margin:18px 0 0;color:#64748b;font-size:13px;">Or paste this link into your browser:<br><code style="background:#f8fafc;padding:4px 8px;border-radius:4px;display:inline-block;margin-top:4px;word-break:break-all;">' . esc_html( $resume_url ) . '</code></p>';
        $html .= '<p style="margin-top:24px;color:#94a3b8;font-size:12px;">' . esc_html( $site ) . '</p>';
        $html .= '</div></div>';

        $settings  = get_option( 'fcp_settings', [] );
        $email_cfg = isset( $settings['email'] ) ? $settings['email'] : [];
        $headers   = $this->mail_headers( $email_cfg );
        $sent      = wp_mail( $email, $subject, $html, $headers );

        FCP_DB::log_mail( [
            'recipient' => $email,
            'subject'   => $subject,
            'form_id'   => $form_id,
            'purpose'   => 'save_draft',
            'status'    => $sent ? 'delivered' : 'failed',
        ] );

        return rest_ensure_response( [
            'success'    => true,
            'token'      => $token,
            'resume_url' => $resume_url,
            'email_sent' => (bool) $sent,
            'expires_in' => 7 * DAY_IN_SECONDS,
        ] );
    }

    /**
     * Hand back a saved draft so the form-engine can prefill the fields.
     * Token is consumed on actual submit (server reads body.draft_token and
     * deletes the transient there) so back-button still works.
     */
    public function resume_draft( $req ) {
        $token = sanitize_text_field( (string) $req->get_param( 'token' ) );
        if ( ! $token ) return new WP_Error( 'bad_token', 'Missing token.', [ 'status' => 400 ] );
        $draft = get_transient( 'fcp_draft_' . $token );
        if ( ! is_array( $draft ) ) {
            return new WP_Error( 'expired', 'This draft link has expired or already been used.', [ 'status' => 410 ] );
        }
        if ( (int) $draft['form_id'] !== (int) $req['id'] ) {
            return new WP_Error( 'form_mismatch', 'Draft belongs to a different form.', [ 'status' => 400 ] );
        }
        return rest_ensure_response( [
            'success' => true,
            'data'    => $draft['data'],
            'step'    => $draft['step'],
            'email'   => $draft['email'],
            'saved'   => $draft['saved'],
        ] );
    }

    /* ---------- File upload handler ---------- */
    /**
     * Public endpoint. Form visitors POST a multipart 'file' part here when
     * they pick something in a File/Image field. We validate extension + size
     * against the settings security rules, then move the upload to
     * /wp-content/uploads/formcraft-pro/{Y}/{m}/. Returns the public URL the
     * form-engine writes into a hidden input so the submission row stores it.
     */
    public function upload_file( $req ) {
        if ( empty( $_FILES['file'] ) || ! is_array( $_FILES['file'] ) ) {
            return new WP_Error( 'no_file', 'No file uploaded.', [ 'status' => 400 ] );
        }
        // Rate-limit by IP to stop drive-by upload floods.
        $ip = FCP_DB::get_ip();
        if ( $ip ) {
            $key = 'fcp_up_' . md5( $ip );
            $ct  = (int) get_transient( $key );
            if ( $ct > 30 ) {
                return new WP_Error( 'rate_limited', 'Too many uploads — try again in a minute.', [ 'status' => 429 ] );
            }
            set_transient( $key, $ct + 1, 60 );
        }

        $settings  = get_option( 'fcp_settings', [] );
        $sec       = isset( $settings['security'] ) ? $settings['security'] : [];
        $allowed   = ! empty( $sec['allowed_ext'] )
            ? array_filter( array_map( 'trim', explode( ',', strtolower( (string) $sec['allowed_ext'] ) ) ) )
            : [ 'pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png' ];
        $max_mb    = isset( $sec['max_upload'] ) ? max( 1, (int) $sec['max_upload'] ) : 10;
        $max_bytes = $max_mb * 1024 * 1024;

        $file = $_FILES['file'];
        if ( ! empty( $file['error'] ) ) {
            return new WP_Error( 'upload_err', 'PHP upload error code ' . (int) $file['error'], [ 'status' => 400 ] );
        }
        if ( (int) $file['size'] <= 0 ) {
            return new WP_Error( 'empty', 'Empty file.', [ 'status' => 400 ] );
        }
        if ( (int) $file['size'] > $max_bytes ) {
            return new WP_Error( 'too_large', 'File exceeds the ' . $max_mb . ' MB limit.', [ 'status' => 413 ] );
        }
        $ext = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
        if ( ! $ext || ! in_array( $ext, $allowed, true ) ) {
            return new WP_Error( 'bad_ext', 'Allowed extensions: ' . implode( ', ', $allowed ), [ 'status' => 415 ] );
        }

        if ( ! function_exists( 'wp_handle_upload' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        // Stash uploads under a plugin-specific subfolder so they're easy to
        // find + clean up later. The upload_dir filter only fires for our call.
        $filter = function ( $dirs ) {
            $sub             = '/formcraft-pro';
            $dirs['path']    = $dirs['basedir'] . $sub . $dirs['subdir'];
            $dirs['url']     = $dirs['baseurl'] . $sub . $dirs['subdir'];
            $dirs['subdir']  = $sub . $dirs['subdir'];
            return $dirs;
        };
        add_filter( 'upload_dir', $filter );
        $overrides = [
            'test_form' => false,
            'mimes'     => $this->allowed_mimes_for_exts( $allowed ),
        ];
        $result = wp_handle_upload( $file, $overrides );
        remove_filter( 'upload_dir', $filter );

        if ( ! is_array( $result ) || isset( $result['error'] ) ) {
            $msg = is_array( $result ) ? $result['error'] : 'Upload failed.';
            return new WP_Error( 'upload_failed', $msg, [ 'status' => 500 ] );
        }

        return rest_ensure_response( [
            'success' => true,
            'url'     => $result['url'],
            'name'    => sanitize_file_name( $file['name'] ),
            'size'    => (int) $file['size'],
            'type'    => isset( $result['type'] ) ? $result['type'] : (string) $file['type'],
        ] );
    }

    /**
     * Map a list of bare extensions to the corresponding WP mime entries.
     * Used to scope wp_handle_upload to only the formats the admin permits.
     */
    private function allowed_mimes_for_exts( $exts ) {
        $all = get_allowed_mime_types();
        $out = [];
        foreach ( $all as $key => $mime ) {
            foreach ( explode( '|', $key ) as $e ) {
                if ( in_array( strtolower( $e ), $exts, true ) ) {
                    $out[ $key ] = $mime;
                    break;
                }
            }
        }
        return $out;
    }

    /* ---------- OTP handlers ---------- */
    public function otp_send( $req ) {
        $body    = $req->get_json_params();
        $target  = isset( $body['target'] ) ? sanitize_text_field( $body['target'] ) : '';
        $channel = isset( $body['channel'] ) ? sanitize_key( $body['channel'] ) : 'email';
        $form_id = isset( $body['form_id'] ) ? (int) $body['form_id'] : 0;
        $form    = $form_id ? FCP_DB::get_form( $form_id ) : null;
        $title   = $form ? ( $form['title'] ?? '' ) : get_bloginfo( 'name' );
        $result  = FCP_OTP::send( $target, $channel, $form_id, $title );
        if ( is_wp_error( $result ) ) return $result;
        return rest_ensure_response( $result );
    }

    public function otp_verify( $req ) {
        $body    = $req->get_json_params();
        $target  = isset( $body['target'] ) ? sanitize_text_field( $body['target'] ) : '';
        $channel = isset( $body['channel'] ) ? sanitize_key( $body['channel'] ) : 'email';
        $code    = isset( $body['code'] ) ? preg_replace( '/\D/', '', (string) $body['code'] ) : '';
        $form_id = isset( $body['form_id'] ) ? (int) $body['form_id'] : 0;
        $result  = FCP_OTP::verify( $target, $channel, $code, $form_id );
        if ( is_wp_error( $result ) ) return $result;
        return rest_ensure_response( [ 'ok' => true ] );
    }

    /* ---------- Membership toggle handlers ---------- */
    public function get_membership( $req ) {
        return rest_ensure_response( FCP_Shortcode::membership_state() );
    }
    public function set_membership( $req ) {
        $body    = $req->get_json_params();
        $enabled = isset( $body['enabled'] ) ? (bool) $body['enabled'] : false;
        return rest_ensure_response( FCP_Shortcode::set_membership_enabled( $enabled ) );
    }

    /* ---------- Form Users (admin handlers) ---------- */
    public function list_form_users( $req ) {
        $rows = FCP_Users::list_users( [
            'search' => sanitize_text_field( (string) $req->get_param( 'search' ) ),
            'status' => sanitize_text_field( (string) $req->get_param( 'status' ) ),
        ] );
        foreach ( $rows as &$r ) {
            $r['id']          = (int) $r['id'];
            $r['login_count'] = (int) $r['login_count'];
        }
        return rest_ensure_response( $rows );
    }
    public function update_form_user( $req ) {
        $body = $req->get_json_params();
        FCP_Users::update_user( (int) $req['id'], is_array( $body ) ? $body : [] );
        return rest_ensure_response( [ 'success' => true ] );
    }
    public function delete_form_user( $req ) {
        FCP_Users::delete_user( (int) $req['id'] );
        return rest_ensure_response( [ 'success' => true ] );
    }

    /* ---------- WooCommerce handlers ---------- */
    public function wc_status( $req ) {
        if ( ! class_exists( 'FCP_WooCommerce' ) ) {
            return rest_ensure_response( [
                'active'  => false,
                'message' => 'FormYantra WooCommerce module not loaded.',
            ] );
        }
        return rest_ensure_response( FCP_WooCommerce::status() );
    }

    public function wc_products( $req ) {
        if ( ! class_exists( 'FCP_WooCommerce' ) || ! FCP_WooCommerce::is_active() ) {
            return new WP_Error( 'wc_inactive', 'WooCommerce is not active on this site.', [ 'status' => 412 ] );
        }
        $args = [
            'limit'  => min( 200, max( 1, (int) ( $req->get_param( 'limit' ) ?: 100 ) ) ),
            'search' => sanitize_text_field( (string) $req->get_param( 'search' ) ),
        ];
        return rest_ensure_response( FCP_WooCommerce::list_products( $args ) );
    }

    /**
     * Public REST endpoint: returns the visitor's detected country +
     * currency. The form engine calls this on page load when the form
     * has auto_currency enabled; the response is cached client-side
     * so subsequent forms on the same page reuse it.
     */
    public function detect_currency_endpoint( $req ) {
        return rest_ensure_response( self::detect_currency() );
    }

    /**
     * One-shot admin tool: walks all submissions with empty/Unknown
     * country and looks each one up via ip-api.com using the stored
     * ip_address. Caches results per-IP for the session so we never
     * hit the same IP twice. Capped at 100 rows per request so the
     * UI stays responsive — admin can click again to continue.
     */
    public function backfill_countries( $req ) {
        global $wpdb;
        $table = FCP_DB::subs_table();
        $rows = $wpdb->get_results(
            "SELECT id, ip_address FROM $table
              WHERE ( country IS NULL OR country = '' OR country = 'Unknown' )
                AND ip_address IS NOT NULL AND ip_address <> ''
              ORDER BY id DESC LIMIT 100",
            ARRAY_A
        );
        $updated = 0;
        $cache = [];
        foreach ( (array) $rows as $r ) {
            $ip = (string) $r['ip_address'];
            if ( ! $ip || $ip === '0.0.0.0' ) continue;
            if ( ! isset( $cache[ $ip ] ) ) {
                $resp = wp_remote_get(
                    'http://ip-api.com/json/' . rawurlencode( $ip ) . '?fields=countryCode',
                    [ 'timeout' => 3 ]
                );
                $code = '';
                if ( ! is_wp_error( $resp ) && (int) wp_remote_retrieve_response_code( $resp ) === 200 ) {
                    $b = json_decode( wp_remote_retrieve_body( $resp ), true );
                    if ( is_array( $b ) && ! empty( $b['countryCode'] ) && preg_match( '/^[A-Z]{2}$/', $b['countryCode'] ) ) {
                        $code = $b['countryCode'];
                    }
                }
                $cache[ $ip ] = $code;
                // Soft throttle: ip-api allows 45/min so a 100ms sleep
                // keeps us well under the limit.
                usleep( 100000 );
            }
            if ( $cache[ $ip ] ) {
                $wpdb->update( $table, [ 'country' => $cache[ $ip ] ], [ 'id' => (int) $r['id'] ] );
                $updated++;
            }
        }
        return rest_ensure_response( [
            'scanned' => count( $rows ),
            'updated' => $updated,
            'done'    => count( $rows ) < 100,
        ] );
    }

    /* ---------- Airtable schema discovery handlers ---------- */

    /**
     * Resolve the PAT to use for an Airtable API call. Tries body first
     * (so admins can test a fresh PAT before saving), then falls back to
     * the already-saved one in fcp_settings.
     */
    private function airtable_pat( $req ) {
        $body = $req->get_json_params();
        if ( ! empty( $body['pat'] ) ) return trim( (string) $body['pat'] );
        $settings = get_option( 'fcp_settings', [] );
        return trim( (string) ( $settings['integrations']['airtable']['pat'] ?? '' ) );
    }

    public function airtable_test( $req ) {
        $pat = $this->airtable_pat( $req );
        if ( ! $pat ) return new WP_Error( 'no_pat', 'Paste your Airtable Personal Access Token first.', [ 'status' => 400 ] );
        $result = FCP_Integrations::airtable_test( $pat );
        if ( is_wp_error( $result ) ) return $result;
        return rest_ensure_response( [ 'ok' => true ] );
    }

    /* v2.70.14 — Google Sheets test-connection */
    public function google_sheets_test( $req ) {
        $body = $req->get_json_params();
        if ( ! is_array( $body ) ) $body = [];
        $cfg = [
            'client_email'   => sanitize_text_field( (string) ( $body['client_email']   ?? '' ) ),
            'private_key'    => (string) ( $body['private_key']    ?? '' ), // keep newlines
            'spreadsheet_id' => sanitize_text_field( (string) ( $body['spreadsheet_id'] ?? '' ) ),
            'sheet_name'     => sanitize_text_field( (string) ( $body['sheet_name']     ?? 'Sheet1' ) ),
        ];
        $result = FCP_Integrations::test_google_sheets( $cfg );
        if ( is_wp_error( $result ) ) {
            return new WP_Error( $result->get_error_code(), $result->get_error_message(), [ 'status' => 400 ] );
        }
        return rest_ensure_response( $result );
    }

    public function airtable_bases( $req ) {
        $pat = $this->airtable_pat( $req );
        if ( ! $pat ) return new WP_Error( 'no_pat', 'Save your Airtable PAT in Settings → Integrations first.', [ 'status' => 400 ] );
        $bases = FCP_Integrations::airtable_list_bases( $pat );
        if ( is_wp_error( $bases ) ) return $bases;
        return rest_ensure_response( $bases );
    }

    public function airtable_tables( $req ) {
        $pat = $this->airtable_pat( $req );
        if ( ! $pat ) return new WP_Error( 'no_pat', 'Save your Airtable PAT in Settings → Integrations first.', [ 'status' => 400 ] );
        $base = sanitize_text_field( (string) $req->get_param( 'base' ) );
        if ( ! $base ) return new WP_Error( 'no_base', 'Pick a base first.', [ 'status' => 400 ] );
        $tables = FCP_Integrations::airtable_list_tables( $pat, $base );
        if ( is_wp_error( $tables ) ) return $tables;
        return rest_ensure_response( $tables );
    }

    public function ai_generate_form( $req ) {
        $body   = $req->get_json_params();
        $prompt = isset( $body['prompt'] ) ? (string) $body['prompt'] : '';
        $form   = FCP_AI::generate_form( $prompt );
        if ( is_wp_error( $form ) ) return $form;
        return rest_ensure_response( $form );
    }

    /**
     * v2.58 — AI Smart Layer REST handlers.
     * Body shapes:
     *   /ai/detect-purpose     { form: {steps:[...], title} }
     *   /ai/normalize-labels   { labels: [...] }
     *   /ai/suggest-fields     { form: {steps:[...], title} }
     *   /ai/draft-reply        { sub_id: int, tone: "professional"|"friendly"|"apologetic" }
     *   /ai/categorize         { sub_id: int }   → also persists to _meta.ai.category
     *   /ai/sentiment          { sub_id: int }   → also persists to _meta.ai.sentiment
     *   /ai/ocr                { sub_id?: int, field?: string, image_url?: string }
     */
    public function ai_detect_purpose( $req ) {
        $body = $req->get_json_params();
        $form = isset( $body['form'] ) && is_array( $body['form'] ) ? $body['form'] : null;
        if ( ! $form ) return new WP_Error( 'bad_input', 'form required', [ 'status' => 400 ] );
        $r = FCP_AI::detect_purpose( $form );
        if ( is_wp_error( $r ) ) return $r;
        return rest_ensure_response( [ 'purpose' => $r ] );
    }

    public function ai_normalize_labels( $req ) {
        $body = $req->get_json_params();
        $labels = isset( $body['labels'] ) && is_array( $body['labels'] ) ? $body['labels'] : [];
        if ( ! $labels ) return new WP_Error( 'bad_input', 'labels required', [ 'status' => 400 ] );
        $r = FCP_AI::normalize_field_labels( $labels );
        if ( is_wp_error( $r ) ) return $r;
        return rest_ensure_response( [ 'map' => $r ] );
    }

    public function ai_suggest_fields( $req ) {
        $body = $req->get_json_params();
        $form = isset( $body['form'] ) && is_array( $body['form'] ) ? $body['form'] : null;
        if ( ! $form ) return new WP_Error( 'bad_input', 'form required', [ 'status' => 400 ] );
        $r = FCP_AI::suggest_fields( $form );
        if ( is_wp_error( $r ) ) return $r;
        return rest_ensure_response( [ 'suggestions' => $r ] );
    }

    /**
     * v2.64 — Block helper. Every AI handler runs this BEFORE calling the
     * external provider so a quota-busted site doesn't get charged for
     * calls that the admin's plan doesn't allow. Returns null when ok,
     * WP_Error when we should bail.
     */
    private function ai_quota_check( $metric ) {
        if ( ! class_exists( 'FCP_SaaS' ) ) return null;
        if ( FCP_SaaS::would_block( $metric ) ) {
            return new WP_Error( 'quota_exceeded',
                'You\'ve hit your monthly ' . str_replace( '_', ' ', $metric ) . ' quota. Upgrade your plan under SaaS &amp; White-label → License key.',
                [ 'status' => 429 ] );
        }
        return null;
    }

    public function ai_draft_reply( $req ) {
        if ( $err = $this->ai_quota_check( 'ai_calls' ) ) return $err;
        $body = $req->get_json_params();
        $sid  = (int) ( $body['sub_id'] ?? 0 );
        $tone = (string) ( $body['tone']   ?? 'professional' );
        $data = $this->ai_load_sub_data( $sid );
        if ( is_wp_error( $data ) ) return $data;
        $r = FCP_AI::draft_reply( $data, $tone );
        if ( is_wp_error( $r ) ) return $r;
        if ( class_exists( 'FCP_SaaS' ) ) FCP_SaaS::increment_usage( 'ai_calls', 1 );
        return rest_ensure_response( [ 'reply' => $r ] );
    }

    public function ai_categorize( $req ) {
        if ( $err = $this->ai_quota_check( 'ai_calls' ) ) return $err;
        $body = $req->get_json_params();
        $sid  = (int) ( $body['sub_id'] ?? 0 );
        $data = $this->ai_load_sub_data( $sid );
        if ( is_wp_error( $data ) ) return $data;
        $r = FCP_AI::categorize_submission( $data );
        if ( is_wp_error( $r ) ) return $r;
        $this->ai_persist_to_meta( $sid, 'category', $r );
        if ( class_exists( 'FCP_SaaS' ) ) FCP_SaaS::increment_usage( 'ai_calls', 1 );
        return rest_ensure_response( [ 'category' => $r ] );
    }

    public function ai_sentiment( $req ) {
        if ( $err = $this->ai_quota_check( 'ai_calls' ) ) return $err;
        $body = $req->get_json_params();
        $sid  = (int) ( $body['sub_id'] ?? 0 );
        $data = $this->ai_load_sub_data( $sid );
        if ( is_wp_error( $data ) ) return $data;
        $r = FCP_AI::analyze_sentiment( $data );
        if ( is_wp_error( $r ) ) return $r;
        $this->ai_persist_to_meta( $sid, 'sentiment', $r );
        if ( class_exists( 'FCP_SaaS' ) ) FCP_SaaS::increment_usage( 'ai_calls', 1 );
        return rest_ensure_response( [ 'sentiment' => $r ] );
    }

    public function ai_ocr( $req ) {
        if ( $err = $this->ai_quota_check( 'ocr_calls' ) ) return $err;
        $body  = $req->get_json_params();
        $sid   = (int) ( $body['sub_id']    ?? 0 );
        $field = (string) ( $body['field']  ?? '' );
        $url   = (string) ( $body['image_url'] ?? '' );
        if ( $sid && $field ) {
            // Resolve the image URL from the submission's field value.
            $data = $this->ai_load_sub_data( $sid );
            if ( is_wp_error( $data ) ) return $data;
            $val  = isset( $data[ $field ] ) ? (string) $data[ $field ] : '';
            if ( ! $val ) return new WP_Error( 'no_image', 'Field has no value', [ 'status' => 400 ] );
            $url = $val;
        }
        if ( ! $url ) return new WP_Error( 'no_image', 'image_url or sub_id+field required', [ 'status' => 400 ] );
        $r = FCP_AI::ocr_extract( $url );
        if ( is_wp_error( $r ) ) return $r;
        if ( $sid && $field ) $this->ai_persist_to_meta( $sid, 'ocr_' . sanitize_key( $field ), $r );
        if ( class_exists( 'FCP_SaaS' ) ) FCP_SaaS::increment_usage( 'ocr_calls', 1 );
        return rest_ensure_response( [ 'text' => $r ] );
    }

    /* ===================================================================
     * v2.61 — Audit + GDPR + RTBF handlers.
     * =================================================================== */
    public function audit_list( $req ) {
        $out = FCP_Audit::query( [
            'action'      => sanitize_text_field( (string) $req->get_param( 'action' ) ),
            'user_id'     => (int) $req->get_param( 'user_id' ),
            'target_type' => sanitize_text_field( (string) $req->get_param( 'target_type' ) ),
            'since'       => sanitize_text_field( (string) $req->get_param( 'since' ) ),
            'until'       => sanitize_text_field( (string) $req->get_param( 'until' ) ),
            'page'        => max( 1, (int) ( $req->get_param( 'page' ) ?: 1 ) ),
            'per_page'    => max( 1, min( 200, (int) ( $req->get_param( 'per_page' ) ?: 50 ) ) ),
        ] );
        return rest_ensure_response( $out );
    }

    public function audit_summary() {
        return rest_ensure_response( [
            'summary'      => FCP_Audit::action_summary( 30 ),
            'total_30_day' => array_sum( array_column( FCP_Audit::action_summary( 30 ), 'n' ) ),
        ] );
    }

    /**
     * PII inventory — counts of personal-data field types across all
     * forms + total volume of stored submissions per category. Powers
     * the GDPR dashboard's at-a-glance view.
     */
    public function pii_inventory() {
        global $wpdb;
        $forms = $wpdb->get_results( "SELECT id, title, data FROM " . FCP_DB::forms_table(), ARRAY_A );
        $tally = [ 'email' => 0, 'tel' => 0, 'name' => 0, 'address' => 0, 'file' => 0, 'idcard' => 0, 'signature' => 0, 'date' => 0, 'other' => 0 ];
        $per_form = [];
        foreach ( $forms ?: [] as $row ) {
            $f = json_decode( $row['data'], true );
            $counts = [ 'email' => 0, 'tel' => 0, 'name' => 0, 'address' => 0, 'file' => 0, 'idcard' => 0, 'signature' => 0, 'date' => 0, 'other' => 0 ];
            foreach ( ( $f['steps'] ?? [] ) as $step ) {
                foreach ( ( $step['fields'] ?? [] ) as $field ) {
                    $t = (string) ( $field['type'] ?? '' );
                    $l = strtolower( (string) ( $field['label'] ?? '' ) );
                    if ( $t === 'email' )                                  $counts['email']++;
                    elseif ( $t === 'tel' || $t === 'phone' )              $counts['tel']++;
                    elseif ( strpos( $l, 'name' ) !== false )              $counts['name']++;
                    elseif ( strpos( $l, 'address' ) !== false )           $counts['address']++;
                    elseif ( $t === 'file' )                               $counts['file']++;
                    elseif ( strpos( $l, 'id' ) !== false || strpos( $l, 'passport' ) !== false ) $counts['idcard']++;
                    elseif ( $t === 'signature' )                          $counts['signature']++;
                    elseif ( $t === 'date' )                               $counts['date']++;
                }
            }
            foreach ( $counts as $k => $v ) $tally[ $k ] += $v;
            $per_form[] = [
                'id'     => (int) $row['id'],
                'title'  => (string) $row['title'],
                'counts' => $counts,
                'pii_total' => array_sum( $counts ),
            ];
        }
        $sub_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . FCP_DB::subs_table() );
        $oldest    = (string) $wpdb->get_var( "SELECT MIN(created_at) FROM " . FCP_DB::subs_table() );
        return rest_ensure_response( [
            'tally'           => $tally,
            'per_form'        => $per_form,
            'submission_total'=> $sub_count,
            'oldest_record'   => $oldest,
        ] );
    }

    /**
     * RTBF lookup — given an email, return every submission, abandoned
     * draft, and form-user record across the system. Caller then sends
     * the same email to /pii/forget after confirming. No PII is logged.
     */
    public function pii_lookup( $req ) {
        global $wpdb;
        // v2.66.2 — Null-safe body parse. PHP 8 throws TypeError on
        // null['email']; if the client sent no body, get_json_params()
        // returns null. Coerce to array first.
        $body  = $req->get_json_params();
        $email = sanitize_email( (string) ( is_array( $body ) ? ( $body['email'] ?? '' ) : '' ) );
        if ( ! $email || ! is_email( $email ) ) return new WP_Error( 'bad_email', 'Valid email required', [ 'status' => 400 ] );
        $subs = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, form_id, created_at, status FROM " . FCP_DB::subs_table() . " WHERE submitter_email = %s ORDER BY id DESC", $email
        ), ARRAY_A );
        $abandoned_count = 0;
        if ( method_exists( 'FCP_DB', 'abandoned_table' ) ) {
            $abandoned_count = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM " . FCP_DB::abandoned_table() . " WHERE email = %s", $email
            ) );
        }
        return rest_ensure_response( [
            'email'           => $email,
            'submissions'     => $subs ?: [],
            'abandoned'       => $abandoned_count,
            'submission_count'=> count( $subs ?: [] ),
        ] );
    }

    /**
     * RTBF execute — cascades a "forget" across every store this plugin
     * owns. Submissions are anonymized (email/name nulled, data stripped
     * of identifying values, anonymized=true flag set) NOT hard-deleted —
     * that preserves form-level analytics counts. Abandoned drafts ARE
     * hard-deleted (they're never aggregated). Caller can opt into hard
     * deletion via { hard_delete: true }.
     */
    public function pii_forget( $req ) {
        global $wpdb;
        $body  = $req->get_json_params();
        $email = sanitize_email( (string) ( $body['email'] ?? '' ) );
        $hard  = ! empty( $body['hard_delete'] );
        if ( ! $email || ! is_email( $email ) ) return new WP_Error( 'bad_email', 'Valid email required', [ 'status' => 400 ] );

        $subs_table = FCP_DB::subs_table();
        $matched    = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $subs_table WHERE submitter_email = %s", $email ) );

        if ( $hard ) {
            $deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM $subs_table WHERE submitter_email = %s", $email ) );
            // v2.69.10 — Rebase every affected form's cached counter so
            // GDPR erasure doesn't leave the Forms list showing stale totals.
            if ( $deleted ) {
                FCP_DB::recount_all_form_submissions();
                // v2.69.11 — Feed the global "Deleted" counter shown on the
                // Submissions overview cards.
                FCP_DB::bump_deleted_counter( (int) $deleted );
            }
        } else {
            // Soft anonymize — null PII columns + flag the JSON.
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $subs_table WHERE submitter_email = %s", $email ), ARRAY_A );
            foreach ( $rows ?: [] as $r ) {
                $data = json_decode( $r['data'], true );
                if ( ! is_array( $data ) ) $data = [];
                foreach ( $data as $k => $v ) {
                    if ( strpos( $k, '_' ) === 0 ) continue;
                    if ( is_string( $v ) ) $data[ $k ] = '[forgotten]';
                }
                $data['_meta'] = $data['_meta'] ?? [];
                $data['_meta']['anonymized']    = true;
                $data['_meta']['anonymized_at'] = current_time( 'mysql' );
                $wpdb->update( $subs_table, [
                    'submitter_email' => null,
                    'submitter_name'  => null,
                    'submitter_phone' => null,
                    'ip_address'      => null,
                    'data'            => wp_json_encode( $data ),
                ], [ 'id' => (int) $r['id'] ] );
            }
            $deleted = $matched;
        }

        $abandoned = 0;
        if ( method_exists( 'FCP_DB', 'abandoned_table' ) ) {
            $abandoned = (int) $wpdb->query( $wpdb->prepare( "DELETE FROM " . FCP_DB::abandoned_table() . " WHERE email = %s", $email ) );
        }

        if ( class_exists( 'FCP_Audit' ) ) FCP_Audit::log( 'user_data_erased', 'email', md5( $email ), null, [
            'submissions' => $matched, 'abandoned' => $abandoned, 'hard' => $hard,
        ] );

        return rest_ensure_response( [
            'submissions_affected' => $matched,
            'abandoned_deleted'    => $abandoned,
            'hard_delete'          => $hard,
        ] );
    }

    /**
     * v2.59 — Translate a batch of strings into a target language.
     * Body: { strings: [...], target_lang: "es", source_lang?: "en" }
     * Returns: { translations: [...] }  (same order as input)
     */
    public function i18n_translate( $req ) {
        $body    = $req->get_json_params();
        $strings = isset( $body['strings'] ) && is_array( $body['strings'] ) ? $body['strings'] : [];
        $target  = isset( $body['target_lang'] ) ? (string) $body['target_lang'] : '';
        $source  = isset( $body['source_lang'] ) ? (string) $body['source_lang'] : 'en';
        if ( ! $strings || ! $target ) {
            return new WP_Error( 'bad_input', 'strings + target_lang required', [ 'status' => 400 ] );
        }
        $out = FCP_I18n::batch_translate( $strings, $target, $source );
        if ( is_wp_error( $out ) ) return $out;
        return rest_ensure_response( [ 'translations' => $out ] );
    }

    /** Load + decode a submission's data JSON. */
    private function ai_load_sub_data( $sid ) {
        if ( ! $sid ) return new WP_Error( 'bad_input', 'sub_id required', [ 'status' => 400 ] );
        $row = FCP_DB::get_submission( (int) $sid );
        if ( ! $row ) return new WP_Error( 'not_found', 'Submission not found', [ 'status' => 404 ] );
        $data = is_string( $row['data'] ?? '' ) ? json_decode( $row['data'], true ) : ( $row['data'] ?? [] );
        return is_array( $data ) ? $data : [];
    }

    /** Stash an AI result on the submission's _meta.ai block for later display. */
    private function ai_persist_to_meta( $sid, $key, $value ) {
        $row = FCP_DB::get_submission( (int) $sid );
        if ( ! $row ) return;
        $data = is_string( $row['data'] ?? '' ) ? json_decode( $row['data'], true ) : [];
        if ( ! is_array( $data ) ) $data = [];
        if ( ! isset( $data['_meta'] ) || ! is_array( $data['_meta'] ) )       $data['_meta']       = [];
        if ( ! isset( $data['_meta']['ai'] ) || ! is_array( $data['_meta']['ai'] ) ) $data['_meta']['ai'] = [];
        $data['_meta']['ai'][ $key ] = is_string( $value ) ? $value : wp_json_encode( $value );
        $data['_meta']['ai'][ $key . '_at' ] = current_time( 'mysql' );
        FCP_DB::update_submission( (int) $sid, [ 'data' => wp_json_encode( $data ) ] );
    }

    /**
     * Returns the last N spam-classified submissions with the form they came
     * from. Replaces the hardcoded reCAPTCHA demo log. Each row also includes
     * a short reason string built from the available signal flags.
     */
    public function get_spam_log( $req ) {
        global $wpdb;
        $limit  = max( 1, min( 100, (int) ( $req->get_param( 'limit' ) ?: 20 ) ) );
        $subs_t = FCP_DB::subs_table();
        $forms_t = FCP_DB::forms_table();
        $rows = $wpdb->get_results(
            "SELECT s.id, s.form_id, s.submitter_email, s.ip_address, s.country, s.device, s.browser, s.created_at, f.title AS form_title
             FROM $subs_t s
             LEFT JOIN $forms_t f ON s.form_id = f.id
             WHERE s.is_spam = 1
             ORDER BY s.created_at DESC
             LIMIT $limit",
            ARRAY_A
        );
        if ( ! $rows ) return rest_ensure_response( [] );
        foreach ( $rows as &$r ) {
            $r['id']      = (int) $r['id'];
            $r['form_id'] = (int) $r['form_id'];
            // Best-effort heuristic reason (we don't currently store per-row
            // signal flags, so build one from device + browser sniff).
            $reason = 'Heuristic spam (honeypot / signals)';
            if ( empty( $r['submitter_email'] ) ) $reason = 'No email provided';
            $r['reason'] = $reason;
        }
        return rest_ensure_response( $rows );
    }

    /* ---------- Webhooks CRUD ---------- */
    public function list_webhooks( $req ) {
        return rest_ensure_response( FCP_DB::get_webhooks() );
    }
    public function create_webhook( $req ) {
        $body = $req->get_json_params();
        if ( empty( $body['url'] ) ) {
            return new WP_Error( 'bad_request', 'Webhook URL is required.', [ 'status' => 400 ] );
        }
        if ( ! filter_var( $body['url'], FILTER_VALIDATE_URL ) ) {
            return new WP_Error( 'bad_url', 'Please enter a valid https:// URL.', [ 'status' => 400 ] );
        }
        $id = FCP_DB::insert_webhook( $body );
        if ( is_wp_error( $id ) ) return $id;
        return rest_ensure_response( FCP_DB::get_webhook( $id ) );
    }
    public function update_webhook( $req ) {
        FCP_DB::update_webhook( (int) $req['id'], $req->get_json_params() );
        return rest_ensure_response( FCP_DB::get_webhook( (int) $req['id'] ) );
    }
    public function delete_webhook( $req ) {
        FCP_DB::delete_webhook( (int) $req['id'] );
        return rest_ensure_response( [ 'deleted' => true ] );
    }
    /**
     * Send a synthetic ping to the webhook URL so the admin can verify the
     * destination is reachable + parsing the payload correctly. Result is
     * recorded on the webhook row the same way a live fire would be.
     */
    public function test_webhook( $req ) {
        $hook = FCP_DB::get_webhook( (int) $req['id'] );
        if ( ! $hook ) return new WP_Error( 'not_found', 'Webhook not found.', [ 'status' => 404 ] );
        $payload = [
            'event' => 'test',
            'submission' => [
                'id'           => 0,
                'form_id'      => 0,
                'form_title'   => 'Test webhook',
                'submitted_at' => current_time( 'c' ),
                'data'         => [
                    'Name'    => 'FormYantra Test',
                    'Email'   => get_option( 'admin_email' ),
                    'Message' => 'This is a test ping from your FormYantra webhook configuration.',
                ],
            ],
            'site' => [ 'name' => get_bloginfo( 'name' ), 'url' => home_url() ],
        ];
        FCP_Integrations::dispatch_webhook( $hook, $payload );
        $hook = FCP_DB::get_webhook( (int) $req['id'] ); // re-fetch to return updated last_status
        return rest_ensure_response( [
            'success'     => $hook['last_status'] >= 200 && $hook['last_status'] < 300,
            'http_status' => $hook['last_status'],
            'error'       => $hook['last_error'] ?: '',
            'webhook'     => $hook,
        ] );
    }

    /* ---------- Coupons CRUD ---------- */
    public function list_coupons( $req ) {
        return rest_ensure_response( FCP_DB::get_coupons() );
    }
    public function create_coupon( $req ) {
        $body = $req->get_json_params();
        if ( empty( $body['code'] ) ) {
            return new WP_Error( 'bad_request', 'Coupon code is required.', [ 'status' => 400 ] );
        }
        $id = FCP_DB::insert_coupon( $body );
        if ( is_wp_error( $id ) ) return $id;
        return rest_ensure_response( FCP_DB::get_coupon( $id ) );
    }
    public function update_coupon( $req ) {
        $body = $req->get_json_params();
        FCP_DB::update_coupon( (int) $req['id'], $body );
        return rest_ensure_response( FCP_DB::get_coupon( (int) $req['id'] ) );
    }
    public function delete_coupon( $req ) {
        FCP_DB::delete_coupon( (int) $req['id'] );
        return rest_ensure_response( [ 'deleted' => true ] );
    }

    /**
     * Public endpoint. Form visitors click "Apply" on the Coupon field and
     * the front-end calls here with { code, amount, form_id }. We respond
     * with the discount + final amount (or an error message). The actual
     * discount enforcement happens again server-side in payment_create_order
     * so a tampering client can't bypass validation.
     */
    public function validate_coupon( $req ) {
        $body    = $req->get_json_params();
        $code    = isset( $body['code'] ) ? sanitize_text_field( $body['code'] ) : '';
        $amount  = isset( $body['amount'] ) ? (float) $body['amount'] : 0;
        $form_id = isset( $body['form_id'] ) ? (int) $body['form_id'] : 0;

        if ( $code === '' ) {
            return rest_ensure_response( [ 'ok' => false, 'message' => 'Please enter a coupon code.' ] );
        }
        if ( $amount <= 0 ) {
            return rest_ensure_response( [ 'ok' => false, 'message' => 'Cannot apply a coupon before a product or amount is selected.' ] );
        }
        $result = FCP_DB::evaluate_coupon( $code, $amount, $form_id );
        if ( ! $result['ok'] ) {
            return rest_ensure_response( $result );
        }
        // Strip private fields from the public response (don't leak usage counts, etc.)
        return rest_ensure_response( [
            'ok'              => true,
            'code'            => $result['coupon']['code'],
            'discount_type'   => $result['coupon']['discount_type'],
            'discount_value'  => $result['coupon']['discount_value'],
            'discount'        => $result['discount'],
            'original_amount' => round( $amount, 2 ),
            'final_amount'    => $result['final'],
            'message'         => 'Coupon applied.',
        ] );
    }

    /* ---------- Payment dispatchers ---------- */

    /**
     * Step 1 of two-phase submit. Caller passes the chosen gateway slug +
     * the form data; we save the row as `payment_status = pending` and ask
     * the gateway for the checkout details to hand back to the front end.
     */
    public function payment_create_order( $req ) {
        $body     = $req->get_json_params();
        $form_id  = isset( $body['form_id'] ) ? (int) $body['form_id'] : 0;
        $gw_slug  = isset( $body['gateway'] ) ? sanitize_key( $body['gateway'] ) : '';
        $amount   = isset( $body['amount'] )  ? (float) $body['amount']         : 0;
        $currency = isset( $body['currency'] ) ? strtoupper( substr( sanitize_text_field( $body['currency'] ), 0, 8 ) ) : 'INR';
        $data     = isset( $body['data'] ) && is_array( $body['data'] ) ? $body['data'] : [];
        $coupon_code = isset( $body['coupon_code'] ) ? sanitize_text_field( $body['coupon_code'] ) : '';

        $form = FCP_DB::get_form( $form_id );
        if ( ! $form )         return new WP_Error( 'bad_form', 'Form not found.', [ 'status' => 404 ] );
        if ( $amount <= 0 )    return new WP_Error( 'bad_amount', 'Payment amount missing or invalid.', [ 'status' => 400 ] );
        if ( ! $gw_slug )      return new WP_Error( 'no_gateway', 'No payment gateway specified.', [ 'status' => 400 ] );

        // Re-evaluate the coupon server-side. The client may have applied it
        // and adjusted the displayed total, but we must NEVER trust that —
        // recalculate the discount from the canonical coupon row.
        $coupon_meta = [
            'coupon_code'            => '',
            'coupon_discount'        => 0,
            'coupon_original_amount' => 0,
        ];
        $original_amount = $amount;
        if ( $coupon_code !== '' ) {
            $eval = FCP_DB::evaluate_coupon( $coupon_code, $amount, $form_id );
            if ( ! $eval['ok'] ) {
                return new WP_Error( 'invalid_coupon', $eval['message'], [ 'status' => 400 ] );
            }
            $amount = $eval['final'];
            $coupon_meta = [
                'coupon_code'            => $eval['coupon']['code'],
                'coupon_discount'        => $eval['discount'],
                'coupon_original_amount' => $original_amount,
            ];
            if ( $amount <= 0 ) {
                return new WP_Error( 'zero_after_coupon', 'After applying this coupon the total is zero. Submit the form without a payment gateway instead.', [ 'status' => 400 ] );
            }
        }

        $gateway = FCP_Payment::get_gateway( $gw_slug );
        if ( is_wp_error( $gateway ) ) return $gateway;

        // Sanitize visitor data (same rules as a normal submit)
        $clean = [];
        foreach ( $data as $k => $v ) {
            $k = sanitize_text_field( (string) $k );
            if ( strpos( $k, '_fcp_' ) === 0 || strpos( $k, 'fcp_hp_' ) === 0 ) continue;
            $clean[ $k ] = is_array( $v ) ? array_map( 'sanitize_text_field', $v ) : sanitize_textarea_field( (string) $v );
        }

        // Save the row immediately as "pending" so the order is tracked even
        // if the user closes the checkout. We update it on successful verify.
        $extra = [
            'ip'      => FCP_DB::get_ip(),
            'device'  => wp_is_mobile() ? 'Mobile' : 'Desktop',
            'browser' => $this->detect_browser(),
            'country' => self::detect_country(),
            'spam'    => false,
        ];
        $sid = FCP_DB::insert_submission( $form_id, $clean, $extra );
        if ( ! $sid ) return new WP_Error( 'db', 'Could not store submission row.', [ 'status' => 500 ] );

        // Ask the gateway to create the order
        $name    = $this->detect_name( $clean );
        $email   = $this->detect_email( $clean );
        $contact = isset( $clean['Phone'] ) ? $clean['Phone'] : ( isset( $clean['phone'] ) ? $clean['phone'] : '' );
        $order = $gateway->create_order( [
            'amount'      => $amount,
            'currency'    => $currency,
            'name'        => $form['title'] . ' — ' . get_bloginfo( 'name' ),
            'description' => 'Submission #' . $sid,
            'return_url'  => isset( $body['return_url'] ) ? esc_url_raw( $body['return_url'] ) : home_url( '/' ),
            'notes'       => [ 'submission_id' => $sid, 'form_id' => $form_id ],
            'prefill'     => [ 'name' => $name, 'email' => $email, 'contact' => $contact ],
        ] );
        if ( is_wp_error( $order ) ) {
            // Roll the pending submission status to failed so it doesn't pollute the unpaid queue.
            FCP_DB::update_submission( $sid, [ 'payment_status' => 'failed' ] );
            return $order;
        }

        // Persist the order id + amount on the submission so verify can match.
        FCP_DB::update_submission( $sid, array_merge( [
            'payment_status'  => 'pending',
            'payment_provider'=> $gw_slug,
            'payment_order_id'=> isset( $order['order_id'] ) ? $order['order_id'] : '',
            'payment_amount'  => $amount,
            'payment_currency'=> $currency,
        ], $coupon_meta ) );

        return rest_ensure_response( [
            'success'       => true,
            'submission_id' => $sid,
            'order'         => $order,
        ] );
    }

    /**
     * Step 2 of two-phase submit. Caller provides whatever the gateway
     * handed back after the user paid; we verify it server-side, mark the
     * submission as paid, and fire the notification emails.
     */
    public function payment_verify( $req ) {
        $body = $req->get_json_params();
        $sid       = isset( $body['submission_id'] ) ? (int) $body['submission_id'] : 0;
        $gw_slug   = isset( $body['gateway'] ) ? sanitize_key( $body['gateway'] ) : '';
        $proof     = isset( $body['proof'] ) && is_array( $body['proof'] ) ? $body['proof'] : [];

        if ( ! $sid || ! $gw_slug ) return new WP_Error( 'bad_request', 'Missing submission_id or gateway.', [ 'status' => 400 ] );
        $sub = FCP_DB::get_submission( $sid );
        if ( ! $sub ) return new WP_Error( 'not_found', 'Submission not found.', [ 'status' => 404 ] );

        $gateway = FCP_Payment::get_gateway( $gw_slug );
        if ( is_wp_error( $gateway ) ) return $gateway;

        // The verify result MUST tell us amount + ideally the order id so we
        // can sanity-check against what we stored when creating the order.
        $verify = $gateway->verify_payment( $proof );
        if ( is_wp_error( $verify ) ) {
            FCP_DB::update_submission( $sid, [ 'payment_status' => 'failed' ] );
            return $verify;
        }

        // Cross-check the order id we stored matches the one the gateway returned.
        if ( ! empty( $verify['order_id'] ) && ! empty( $sub['payment_order_id'] )
             && $verify['order_id'] !== $sub['payment_order_id'] ) {
            return new WP_Error( 'order_mismatch', 'Verified order id does not match the pending submission.', [ 'status' => 400 ] );
        }

        FCP_DB::update_submission( $sid, [
            'payment_status' => 'paid',
            'payment_id'     => isset( $verify['payment_id'] ) ? substr( $verify['payment_id'], 0, 128 ) : '',
            'payment_amount' => isset( $verify['amount'] )   ? $verify['amount']  : ( $sub['payment_amount'] ?? null ),
            'payment_currency' => isset( $verify['currency'] ) ? $verify['currency'] : ( $sub['payment_currency'] ?? '' ),
            'paid_at'        => current_time( 'mysql' ),
        ] );

        // Coupon was already saved on the submission at create-order time.
        // Bump its usage counter now that the payment actually succeeded.
        if ( ! empty( $sub['coupon_code'] ) ) {
            FCP_DB::bump_coupon_use( $sub['coupon_code'] );
        }

        // Now that the payment is confirmed, fire the notification emails.
        $form = FCP_DB::get_form( (int) $sub['form_id'] );
        $data = is_string( $sub['data'] ) ? json_decode( $sub['data'], true ) : ( is_array( $sub['data'] ) ? $sub['data'] : [] );
        $mail = null;
        if ( $form ) $mail = $this->send_emails( $form, is_array( $data ) ? $data : [], $sid );

        // v2.70.1 — Fire the payment-verified action so downstream features
        // (India Suite GST invoice, WhatsApp payment-confirmed alerts, custom
        // integrations via hooks) can react to successful payments. Was
        // previously never fired — the India class registered a listener
        // that never received any events.
        if ( $form ) {
            try {
                do_action( 'fcp_payment_verified', (int) $sid, $form, $data );
            } catch ( \Throwable $e ) {
                error_log( '[FormYantra] fcp_payment_verified action failed for #' . $sid . ': ' . $e->getMessage() );
            }
        }

        // ---- WooCommerce order: created during the payment_create_order
        // submit (now), and flipped to processing/paid here. ----
        if ( $form
             && class_exists( 'FCP_WooCommerce' )
             && FCP_WooCommerce::is_active()
             && FCP_WooCommerce::form_has_wc_field( $form ) ) {
            $existing_id = isset( $sub['wc_order_id'] ) ? (int) $sub['wc_order_id'] : 0;
            if ( ! $existing_id ) {
                $existing_id = FCP_WooCommerce::create_order_from_submission(
                    $form,
                    is_array( $data ) ? $data : [],
                    $sid,
                    [
                        'paid'          => true,
                        'amount'        => isset( $verify['amount'] )   ? (float) $verify['amount']   : 0,
                        'currency'      => isset( $verify['currency'] ) ? $verify['currency']        : '',
                        'gateway'       => $gw_slug,
                        'gateway_title' => ucfirst( $gw_slug ),
                        'id'            => isset( $verify['payment_id'] ) ? (string) $verify['payment_id'] : '',
                    ]
                );
            } else {
                // Order already created at submit (pending). Mark it paid now.
                $wc_order = wc_get_order( $existing_id );
                if ( $wc_order && ! $wc_order->is_paid() ) {
                    $wc_order->set_payment_method( $gw_slug );
                    $wc_order->set_payment_method_title( ucfirst( $gw_slug ) );
                    if ( ! empty( $verify['payment_id'] ) ) {
                        $wc_order->set_transaction_id( sanitize_text_field( $verify['payment_id'] ) );
                    }
                    $wc_order->payment_complete( $verify['payment_id'] ?? '' );
                }
            }
            if ( ! is_wp_error( $existing_id ) && $existing_id ) {
                $wc_order = wc_get_order( $existing_id );
                FCP_DB::update_submission( $sid, [
                    'wc_order_id'     => (int) $existing_id,
                    'wc_order_status' => $wc_order ? $wc_order->get_status() : 'processing',
                    'wc_order_total'  => $wc_order ? (float) $wc_order->get_total() : 0,
                ] );
            }
        }

        // Fire payment-event integrations (e.g. Slack: "Payment received").
        if ( $form ) {
            FCP_Integrations::fire( 'payment', $form, is_array( $data ) ? $data : [], $sid, [
                'payment' => [
                    'amount'   => isset( $verify['amount'] )   ? $verify['amount']   : null,
                    'currency' => isset( $verify['currency'] ) ? $verify['currency'] : '',
                    'gateway'  => $gw_slug,
                    'payment_id' => isset( $verify['payment_id'] ) ? $verify['payment_id'] : '',
                ],
                'coupon' => ! empty( $sub['coupon_code'] ) ? [
                    'code'     => $sub['coupon_code'],
                    'discount' => isset( $sub['coupon_discount'] ) ? $sub['coupon_discount'] : 0,
                ] : null,
            ] );
        }

        return rest_ensure_response( [
            'success' => true,
            'submission_id' => $sid,
            'payment' => $verify,
            'mail'    => $mail,
        ] );
    }

    public function payment_webhook( $req ) {
        $slug    = sanitize_key( $req['gateway'] );
        $gateway = FCP_Payment::get_gateway( $slug );
        if ( is_wp_error( $gateway ) ) return $gateway;
        $body    = $req->get_body();
        $headers = [];
        foreach ( $req->get_headers() as $k => $v ) {
            $headers[ str_replace( '_', '-', $k ) ] = is_array( $v ) ? $v[0] : $v;
        }
        $result = $gateway->handle_webhook( $body, $headers );
        if ( is_wp_error( $result ) ) return $result;
        // Webhook events are logged for debugging — actual state updates
        // already happen in payment_verify; this is the safety net for
        // async/missed flows.
        error_log( '[FormYantra] Payment webhook (' . $slug . '): ' . ( $result['event'] ?? 'received' ) );
        return rest_ensure_response( [ 'ok' => true, 'event' => $result['event'] ?? '' ] );
    }

    public function payment_refund( $req ) {
        $sid = (int) $req['id'];
        $sub = FCP_DB::get_submission( $sid );
        if ( ! $sub || empty( $sub['payment_id'] ) ) return new WP_Error( 'no_payment', 'No payment found on this submission.', [ 'status' => 404 ] );

        $gateway = FCP_Payment::get_gateway( $sub['payment_provider'] );
        if ( is_wp_error( $gateway ) ) return $gateway;
        $amount = (float) $req->get_param( 'amount' );
        $res = $gateway->refund( $sub['payment_id'], $amount > 0 ? $amount : null );
        if ( is_wp_error( $res ) ) return $res;
        FCP_DB::update_submission( $sid, [ 'payment_status' => 'refunded' ] );
        return rest_ensure_response( [ 'success' => true, 'refund' => $res ] );
    }

    public function get_mail_log( $req ) {
        $limit = max( 1, min( 200, (int) $req->get_param( 'limit' ) ?: 50 ) );
        return rest_ensure_response( FCP_DB::get_mail_log( $limit ) );
    }

    public function get_smtp_status( $req ) {
        $smtp = $this->detect_smtp_state();
        return rest_ensure_response( [
            'plugin'        => $smtp['plugin'],
            'configured'    => $smtp['configured'],
            'mailer'        => $smtp['mailer'],
            'settings_url'  => $smtp['settings_url'],
            'last_sent_at'  => FCP_DB::last_mail_sent_at(),
            'admin_email'   => get_option( 'admin_email' ),
        ] );
    }

    /**
     * Re-send the admin (or user) notification for an existing submission.
     * Used by the "Resend email" button on the Submission Detail page when
     * the original send_emails() attempt failed (e.g. SMTP wasn't yet set up
     * at the time the form was submitted).
     */
    public function resend_submission_email( $req ) {
        $sub = FCP_DB::get_submission( $req['id'] );
        if ( ! $sub ) {
            return new WP_Error( 'not_found', 'Submission not found', [ 'status' => 404 ] );
        }
        $form = FCP_DB::get_form( $sub['form_id'] );
        if ( ! $form ) {
            return new WP_Error( 'not_found', 'Form for this submission no longer exists', [ 'status' => 404 ] );
        }
        $data = is_string( $sub['data'] ) ? json_decode( $sub['data'], true ) : ( $sub['data'] ?: [] );
        if ( ! is_array( $data ) ) $data = [];

        $body = $req->get_json_params();
        $only = isset( $body['only'] ) ? $body['only'] : 'both'; // 'admin' | 'user' | 'both'

        // Temporarily toggle settings to control which mail is sent.
        $original = isset( $form['settings']['notifications'] ) ? $form['settings']['notifications'] : null;
        if ( $only === 'admin' ) {
            $form['settings']['notifications']['admin']['enabled'] = true;
            $form['settings']['notifications']['user']['enabled']  = false;
        } elseif ( $only === 'user' ) {
            $form['settings']['notifications']['admin']['enabled'] = false;
            $form['settings']['notifications']['user']['enabled']  = true;
        }

        $results = $this->send_emails( $form, $data, (int) $sub['id'] );
        return rest_ensure_response( [ 'success' => true, 'mail' => $results ] );
    }

    /**
     * Run "after submit" actions configured on the form: create a WordPress
     * user, create a post/CPT. Each block is optional and independent. We
     * record the resulting IDs as submission meta so the admin can jump from
     * the submission to the user/post (and so re-submits don't dupe).
     */
    private function run_after_submit_actions( $form, $data, $sub_id, $cfg ) {
        // ----- Create WP User -----
        if ( ! empty( $cfg['createUser']['enabled'] ) ) {
            $u_cfg = $cfg['createUser'];
            $email = $this->pick_field_value( $data, $u_cfg['emailField'] ?? '' );
            if ( ! $email ) $email = $this->detect_email( $data );
            $name  = $this->pick_field_value( $data, $u_cfg['nameField']  ?? '' );
            if ( ! $name )  $name  = $this->detect_name( $data );
            $role  = isset( $u_cfg['role'] ) ? sanitize_key( $u_cfg['role'] ) : 'subscriber';
            $send  = ! empty( $u_cfg['sendCredentials'] );
            if ( $email && is_email( $email ) ) {
                $existing = get_user_by( 'email', $email );
                if ( $existing ) {
                    // Don't recreate — just remember the link.
                    update_post_meta( 0, '', '' ); // no-op (no post meta on submissions)
                    error_log( '[FormYantra] User already exists for ' . $email . ' — skipping createUser' );
                } else {
                    $username  = $this->generate_unique_username( $email, $name );
                    $password  = wp_generate_password( 16, true, false );
                    $user_id   = wp_insert_user( [
                        'user_login'   => $username,
                        'user_email'   => $email,
                        'user_pass'    => $password,
                        'display_name' => $name ?: $username,
                        'first_name'   => $name ? strtok( $name, ' ' ) : '',
                        'role'         => in_array( $role, [ 'subscriber','contributor','author','editor' ], true ) ? $role : 'subscriber',
                    ] );
                    if ( is_wp_error( $user_id ) ) {
                        error_log( '[FormYantra] createUser failed: ' . $user_id->get_error_message() );
                    } else {
                        // Tag the new user as FormCraft-created so the admin can audit.
                        update_user_meta( $user_id, '_fcp_created_from_submission', (int) $sub_id );
                        update_user_meta( $user_id, '_fcp_form_id', isset( $form['id'] ) ? (int) $form['id'] : 0 );
                        if ( $send ) {
                            $this->send_user_credentials_email( $user_id, $password, $form );
                        }
                    }
                }
            }
        }

        // ----- Create Post / CPT -----
        if ( ! empty( $cfg['createPost']['enabled'] ) ) {
            $p_cfg     = $cfg['createPost'];
            $post_type = sanitize_key( $p_cfg['postType'] ?? 'post' );
            $title     = $this->pick_field_value( $data, $p_cfg['titleField']   ?? '' );
            $content   = $this->pick_field_value( $data, $p_cfg['contentField'] ?? '' );
            $status    = sanitize_key( $p_cfg['status'] ?? 'draft' );
            if ( ! in_array( $status, [ 'draft','pending','publish','private' ], true ) ) $status = 'draft';
            if ( ! $title ) {
                $name  = $this->detect_name( $data );
                $title = $name ? sprintf( 'Submission from %s', $name ) : sprintf( 'Submission #%d', (int) $sub_id );
            }
            if ( ! post_type_exists( $post_type ) ) $post_type = 'post';
            $post_id = wp_insert_post( [
                'post_type'    => $post_type,
                'post_status'  => $status,
                'post_title'   => $title,
                'post_content' => $content ?: $this->build_post_content_from_data( $data ),
                'meta_input'   => [
                    '_fcp_submission_id' => (int) $sub_id,
                    '_fcp_form_id'       => isset( $form['id'] ) ? (int) $form['id'] : 0,
                ],
            ], true );
            if ( is_wp_error( $post_id ) ) {
                error_log( '[FormYantra] createPost failed: ' . $post_id->get_error_message() );
            } elseif ( $post_id ) {
                // ---- Featured image ----
                if ( ! empty( $p_cfg['imageField'] ) ) {
                    $img_url = $this->pick_field_value( $data, $p_cfg['imageField'] );
                    if ( $img_url && filter_var( $img_url, FILTER_VALIDATE_URL ) ) {
                        $attach_id = $this->sideload_attachment( $img_url, $post_id );
                        if ( ! is_wp_error( $attach_id ) && $attach_id ) {
                            set_post_thumbnail( $post_id, $attach_id );
                        }
                    }
                }
                // ---- Taxonomies ----
                // Each rule { taxonomy: "category", field: "Topic" } sets the
                // term(s) named by the field's value. Hierarchical taxonomies
                // (category) get the term ID; tag-style ones get the name.
                $taxes = is_array( $p_cfg['taxonomies'] ?? null ) ? $p_cfg['taxonomies'] : [];
                foreach ( $taxes as $rule ) {
                    $tax_name = sanitize_key( $rule['taxonomy'] ?? '' );
                    $field    = $rule['field'] ?? '';
                    if ( ! $tax_name || ! $field || ! taxonomy_exists( $tax_name ) ) continue;
                    $raw = $data[ $field ] ?? '';
                    if ( ! $raw ) continue;
                    $terms_input = is_array( $raw ) ? $raw : array_map( 'trim', explode( ',', (string) $raw ) );
                    $terms_input = array_values( array_filter( $terms_input ) );
                    if ( empty( $terms_input ) ) continue;
                    $tax = get_taxonomy( $tax_name );
                    if ( $tax && $tax->hierarchical ) {
                        // Convert names → ids (create if missing)
                        $ids = [];
                        foreach ( $terms_input as $t ) {
                            $term = term_exists( $t, $tax_name );
                            if ( ! $term ) $term = wp_insert_term( $t, $tax_name );
                            if ( ! is_wp_error( $term ) ) $ids[] = (int) ( $term['term_id'] ?? $term );
                        }
                        if ( $ids ) wp_set_object_terms( $post_id, $ids, $tax_name );
                    } else {
                        // Flat (tags) — accepts an array of names
                        wp_set_object_terms( $post_id, $terms_input, $tax_name );
                    }
                }
                // ---- Custom fields (post meta) ----
                $meta_rules = is_array( $p_cfg['metaMap'] ?? null ) ? $p_cfg['metaMap'] : [];
                foreach ( $meta_rules as $rule ) {
                    $key   = sanitize_key( $rule['key'] ?? '' );
                    $field = $rule['field'] ?? '';
                    if ( ! $key || ! $field ) continue;
                    $val = $data[ $field ] ?? '';
                    if ( is_array( $val ) ) $val = wp_json_encode( $val );
                    update_post_meta( $post_id, $key, sanitize_text_field( (string) $val ) );
                }
            }
        }
    }

    /**
     * Pull a remote image / file URL into the WP media library as a real
     * attachment, parented to the given post. Returns the attachment ID
     * or WP_Error. Reuses an existing attachment when the URL was already
     * sideloaded — avoids dupes on re-submissions.
     */
    private function sideload_attachment( $url, $post_id ) {
        global $wpdb;
        // Already in our library? Match by guid (set on upload).
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND guid = %s LIMIT 1",
            $url
        ) );
        if ( $existing ) return (int) $existing;

        if ( ! function_exists( 'media_handle_sideload' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }
        // Local file path optimization — if the URL points at our own
        // uploads dir, we can attachment-create it directly instead of
        // re-downloading.
        $upload  = wp_get_upload_dir();
        if ( strpos( $url, $upload['baseurl'] ) === 0 ) {
            $rel_path = str_replace( $upload['baseurl'], '', $url );
            $abs_path = $upload['basedir'] . $rel_path;
            if ( file_exists( $abs_path ) ) {
                $filetype = wp_check_filetype( basename( $abs_path ), null );
                $attach   = wp_insert_attachment( [
                    'guid'           => $url,
                    'post_mime_type' => $filetype['type'] ?? '',
                    'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $abs_path ) ),
                    'post_content'   => '',
                    'post_status'    => 'inherit',
                ], $abs_path, $post_id );
                if ( is_wp_error( $attach ) ) return $attach;
                $meta = wp_generate_attachment_metadata( $attach, $abs_path );
                wp_update_attachment_metadata( $attach, $meta );
                return $attach;
            }
        }
        // Remote — download into the media library via media_sideload_image.
        $tmp = download_url( $url, 30 );
        if ( is_wp_error( $tmp ) ) return $tmp;
        $file = [
            'name'     => basename( parse_url( $url, PHP_URL_PATH ) ?: 'image.jpg' ),
            'tmp_name' => $tmp,
        ];
        $attach_id = media_handle_sideload( $file, $post_id );
        if ( file_exists( $tmp ) ) @unlink( $tmp );
        return $attach_id;
    }

    /**
     * Pick a single field's value out of the submission data, by label match.
     * Returns "" if the label doesn't exist or the value is an array.
     */
    private function pick_field_value( $data, $label ) {
        if ( ! $label ) return '';
        if ( ! isset( $data[ $label ] ) ) return '';
        $v = $data[ $label ];
        if ( is_array( $v ) ) return '';
        return (string) $v;
    }

    /**
     * Derive a unique WP username from email + name. Falls back to a
     * timestamp suffix if both are taken.
     */
    private function generate_unique_username( $email, $name ) {
        $candidates = [];
        if ( $email ) $candidates[] = strtolower( substr( $email, 0, strpos( $email, '@' ) ) );
        if ( $name )  $candidates[] = sanitize_user( strtolower( str_replace( ' ', '_', $name ) ), true );
        $candidates[] = 'user_' . wp_generate_password( 6, false, false );
        foreach ( $candidates as $c ) {
            $c = sanitize_user( $c, true );
            if ( ! $c ) continue;
            if ( ! username_exists( $c ) ) return $c;
            for ( $i = 2; $i < 20; $i++ ) {
                $try = $c . $i;
                if ( ! username_exists( $try ) ) return $try;
            }
        }
        return 'user_' . time();
    }

    /**
     * Build post content from the submitted data when the admin didn't
     * map a specific Content field.
     */
    private function build_post_content_from_data( $data ) {
        $html = '<table style="border-collapse:collapse;border:1px solid #e5e7eb;width:100%;">';
        foreach ( $data as $k => $v ) {
            $val = is_array( $v ) ? wp_json_encode( $v ) : (string) $v;
            $html .= '<tr><th style="text-align:left;padding:8px;background:#f8fafc;width:35%;">' . esc_html( $k ) . '</th>';
            $html .= '<td style="padding:8px;">' . nl2br( esc_html( $val ) ) . '</td></tr>';
        }
        $html .= '</table>';
        return $html;
    }

    /**
     * Send a freshly-created user their login credentials. Uses our existing
     * SMTP path so it routes through the configured mail provider.
     */
    private function send_user_credentials_email( $user_id, $password, $form ) {
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) return false;
        $site = get_bloginfo( 'name' );
        $login_url = wp_login_url();
        $subject   = sprintf( '[%s] Your new account', $site );
        $html  = '<div style="font-family:Inter,Arial,sans-serif;color:#0f172a;max-width:640px;margin:0 auto;line-height:1.55;">';
        $html .= '<div style="background:#fff;padding:28px;border:1px solid #e5e7eb;border-radius:10px;border-top:4px solid #6366f1;">';
        $html .= '<h2 style="margin:0 0 8px;">Welcome to ' . esc_html( $site ) . '</h2>';
        $html .= '<p style="margin:0 0 18px;color:#475569;">An account has been created for you. Here are your login details:</p>';
        $html .= '<table cellpadding="0" cellspacing="0" style="border-collapse:collapse;border:1px solid #e5e7eb;border-radius:8px;width:100%;">';
        $html .= '<tr><th align="left" style="background:#f8fafc;padding:10px;border-bottom:1px solid #e5e7eb;width:35%;">Username</th>';
        $html .= '<td style="padding:10px;border-bottom:1px solid #e5e7eb;font-family:monospace;">' . esc_html( $user->user_login ) . '</td></tr>';
        $html .= '<tr><th align="left" style="background:#f8fafc;padding:10px;border-bottom:1px solid #e5e7eb;">Password</th>';
        $html .= '<td style="padding:10px;border-bottom:1px solid #e5e7eb;font-family:monospace;">' . esc_html( $password ) . '</td></tr>';
        $html .= '<tr><th align="left" style="background:#f8fafc;padding:10px;">Login</th>';
        $html .= '<td style="padding:10px;"><a href="' . esc_url( $login_url ) . '" style="color:#6366f1;">' . esc_html( $login_url ) . '</a></td></tr>';
        $html .= '</table>';
        $html .= '<p style="margin-top:24px;color:#94a3b8;font-size:12px;">For your security, change this password after your first login.</p>';
        $html .= '</div></div>';
        $settings  = get_option( 'fcp_settings', [] );
        $email_cfg = isset( $settings['email'] ) ? $settings['email'] : [];
        $headers   = $this->mail_headers( $email_cfg );
        $sent      = wp_mail( $user->user_email, $subject, $html, $headers );
        FCP_DB::log_mail( [
            'recipient' => $user->user_email,
            'subject'   => $subject,
            'form_id'   => isset( $form['id'] ) ? (int) $form['id'] : null,
            'purpose'   => 'user_credentials',
            'status'    => $sent ? 'delivered' : 'failed',
        ] );
        return (bool) $sent;
    }

    /**
     * Approve or reject a submission. Forms with approval enabled save with
     * status `pending_review` — admin then flips to `approved` / `rejected`
     * here, optionally with a note. An email is sent to the submitter.
     */
    public function approve_submission( $req ) {
        $sub_id = (int) $req['id'];
        $sub    = FCP_DB::get_submission( $sub_id );
        if ( ! $sub ) return new WP_Error( 'not_found', 'Submission not found.', [ 'status' => 404 ] );
        $body     = $req->get_json_params();
        $decision = isset( $body['decision'] ) ? sanitize_key( $body['decision'] ) : '';
        $note     = isset( $body['note'] ) ? sanitize_textarea_field( $body['note'] ) : '';
        if ( ! in_array( $decision, [ 'approved', 'rejected', 'pending_review', 'none' ], true ) ) {
            return new WP_Error( 'bad_decision', 'decision must be approved | rejected | pending_review | none.', [ 'status' => 400 ] );
        }

        $form = FCP_DB::get_form( (int) $sub['form_id'] );
        $data = is_string( $sub['data'] ) ? json_decode( $sub['data'], true ) : ( is_array( $sub['data'] ) ? $sub['data'] : [] );
        if ( ! is_array( $data ) ) $data = [];

        FCP_DB::update_submission( $sub_id, [
            'approval_status' => $decision,
            'approval_note'   => $note,
            'approved_by'     => get_current_user_id() ?: null,
            'approved_at'     => current_time( 'mysql' ),
        ] );

        $mail = null;
        if ( $decision === 'approved' || $decision === 'rejected' ) {
            $mail = $this->send_approval_email( $form, $data, $sub_id, $decision, $note );
        }

        return rest_ensure_response( [
            'success'  => true,
            'decision' => $decision,
            'mail'     => $mail,
        ] );
    }

    /**
     * v2.52 — Append an entry to the submission's activity timeline.
     * The timeline is a JSON array in the row's `data` column under
     * `_meta.activity`. Every workflow action (status change, comment,
     * assignee change, inline edit, reply-email, spam mark) appends one
     * row so admins can audit who did what.
     */
    private function log_submission_activity( $sub_id, $type, $text = '', $extra = [] ) {
        $row = FCP_DB::get_submission( (int) $sub_id );
        if ( ! $row ) return false;
        $payload = is_string( $row['data'] ) ? json_decode( $row['data'], true ) : ( is_array( $row['data'] ) ? $row['data'] : [] );
        if ( ! is_array( $payload ) ) $payload = [];
        if ( ! isset( $payload['_meta'] ) || ! is_array( $payload['_meta'] ) ) $payload['_meta'] = [];
        if ( ! isset( $payload['_meta']['activity'] ) ) $payload['_meta']['activity'] = [];
        $user = wp_get_current_user();
        $payload['_meta']['activity'][] = array_merge( [
            'at'      => current_time( 'mysql' ),
            'type'    => sanitize_key( $type ),
            'by_id'   => $user && $user->ID ? (int) $user->ID : 0,
            'by_name' => $user && $user->display_name ? $user->display_name : 'system',
            'text'    => (string) $text,
        ], is_array( $extra ) ? $extra : [] );
        // Cap timeline at 200 entries — older rows fall off so the data
        // column doesn't grow unbounded for high-touch submissions.
        if ( count( $payload['_meta']['activity'] ) > 200 ) {
            $payload['_meta']['activity'] = array_slice( $payload['_meta']['activity'], -200 );
        }
        FCP_DB::update_submission( (int) $sub_id, [ 'data' => wp_json_encode( $payload ) ] );
        return true;
    }

    /**
     * v2.52 — Set the admin user assigned to handle this submission.
     * Body: { user_id: int|null }. Null clears the assignment.
     */
    public function set_submission_assignee( $req ) {
        $sub_id  = (int) $req['id'];
        $body    = $req->get_json_params();
        $user_id = isset( $body['user_id'] ) ? (int) $body['user_id'] : 0;
        $row     = FCP_DB::get_submission( $sub_id );
        if ( ! $row ) return new WP_Error( 'not_found', 'Submission not found.', [ 'status' => 404 ] );
        $payload = is_string( $row['data'] ) ? json_decode( $row['data'], true ) : ( is_array( $row['data'] ) ? $row['data'] : [] );
        if ( ! is_array( $payload ) ) $payload = [];
        if ( ! isset( $payload['_meta'] ) || ! is_array( $payload['_meta'] ) ) $payload['_meta'] = [];
        $assignee = $user_id ? get_user_by( 'id', $user_id ) : null;
        $payload['_meta']['assignee_id']   = $assignee ? (int) $assignee->ID : 0;
        $payload['_meta']['assignee_name'] = $assignee ? $assignee->display_name : '';
        FCP_DB::update_submission( $sub_id, [ 'data' => wp_json_encode( $payload ) ] );
        $this->log_submission_activity( $sub_id, 'assigned',
            $assignee ? 'Assigned to ' . $assignee->display_name : 'Unassigned' );
        return rest_ensure_response( [
            'assignee_id'   => $payload['_meta']['assignee_id'],
            'assignee_name' => $payload['_meta']['assignee_name'],
        ] );
    }

    /**
     * v2.52 — Add a free-text comment / internal note to a submission.
     * Body: { text: string }. Text supports @mentions (rendered client-side
     * as links); server stores the raw text + extracts mentioned usernames.
     */
    public function add_submission_comment( $req ) {
        $sub_id = (int) $req['id'];
        $body   = $req->get_json_params();
        $text   = isset( $body['text'] ) ? sanitize_textarea_field( (string) $body['text'] ) : '';
        if ( $text === '' ) return new WP_Error( 'empty', 'Comment text required.', [ 'status' => 400 ] );

        // Extract @mentions for notification — server-side parse so we don't
        // trust whatever the client tells us was mentioned.
        $mentions = [];
        if ( preg_match_all( '/@([a-zA-Z0-9_.-]+)/', $text, $m ) ) {
            foreach ( array_unique( $m[1] ) as $login ) {
                $u = get_user_by( 'login', $login ) ?: get_user_by( 'slug', $login );
                if ( $u ) $mentions[] = [ 'id' => (int) $u->ID, 'name' => $u->display_name, 'email' => $u->user_email ];
            }
        }
        $this->log_submission_activity( $sub_id, 'comment', $text, [ 'mentions' => $mentions ] );

        // Email-notify each @mentioned admin. Best-effort; failure doesn't
        // fail the comment (it's already saved to the activity log).
        if ( $mentions ) {
            $sub = FCP_DB::get_submission( $sub_id );
            $admin_url = admin_url( 'admin.php?page=formcraft-pro-submissions' ); // detail link added later
            foreach ( $mentions as $m_user ) {
                wp_mail(
                    $m_user['email'],
                    sprintf( '[FormCraft] You were mentioned in submission #%d', $sub_id ),
                    "You were mentioned by " . wp_get_current_user()->display_name . " on submission #{$sub_id}:\n\n" .
                    $text . "\n\nOpen: " . $admin_url
                );
            }
        }
        return rest_ensure_response( [ 'success' => true, 'mentions' => $mentions ] );
    }

    /**
     * v2.52 — Edit a single field's value on an existing submission.
     * Logs the before/after to the activity timeline. Body:
     *   { field: string, value: any }
     */
    public function inline_edit_submission_field( $req ) {
        $sub_id = (int) $req['id'];
        $body   = $req->get_json_params();
        $field  = isset( $body['field'] ) ? (string) $body['field'] : '';
        $value  = $body['value'] ?? '';
        if ( $field === '' || strpos( $field, '_' ) === 0 ) {
            return new WP_Error( 'bad_field', 'Field name required and must not start with underscore.', [ 'status' => 400 ] );
        }
        $row = FCP_DB::get_submission( $sub_id );
        if ( ! $row ) return new WP_Error( 'not_found', 'Submission not found.', [ 'status' => 404 ] );
        $payload = is_string( $row['data'] ) ? json_decode( $row['data'], true ) : ( is_array( $row['data'] ) ? $row['data'] : [] );
        if ( ! is_array( $payload ) ) $payload = [];
        $before  = isset( $payload[ $field ] ) ? $payload[ $field ] : '';
        $payload[ $field ] = is_string( $value ) ? sanitize_textarea_field( $value ) : $value;
        FCP_DB::update_submission( $sub_id, [ 'data' => wp_json_encode( $payload ) ] );
        $this->log_submission_activity( $sub_id, 'edit_field',
            sprintf( '%s: "%s" → "%s"', $field, is_string( $before ) ? $before : wp_json_encode( $before ), is_string( $value ) ? $value : wp_json_encode( $value ) ),
            [ 'field' => $field ]
        );
        return rest_ensure_response( [ 'success' => true, 'field' => $field, 'value' => $payload[ $field ] ] );
    }

    /**
     * v2.52 — Send a reply email to the submitter directly from the admin.
     * Composed message goes through wp_mail (respects SMTP). Logs to
     * activity timeline so the admin can audit who replied + when.
     */
    public function send_reply_email( $req ) {
        $sub_id = (int) $req['id'];
        $body   = $req->get_json_params();
        $subject = isset( $body['subject'] ) ? sanitize_text_field( (string) $body['subject'] ) : '';
        $message = isset( $body['message'] ) ? wp_kses_post( (string) $body['message'] ) : '';
        if ( $subject === '' || $message === '' ) {
            return new WP_Error( 'empty', 'Both subject and message are required.', [ 'status' => 400 ] );
        }
        $row = FCP_DB::get_submission( $sub_id );
        if ( ! $row ) return new WP_Error( 'not_found', 'Submission not found.', [ 'status' => 404 ] );
        $to = $row['submitter_email'] ?? '';
        if ( ! $to || ! is_email( $to ) ) {
            return new WP_Error( 'no_email', 'Submission has no submitter email to reply to.', [ 'status' => 400 ] );
        }
        $headers = [ 'Content-Type: text/html; charset=UTF-8' ];
        $from = get_option( 'fcp_settings' )['notifications']['from_email'] ?? '';
        if ( $from && is_email( $from ) ) $headers[] = 'From: ' . get_bloginfo( 'name' ) . ' <' . $from . '>';
        $sent = wp_mail( $to, $subject, wpautop( $message ), $headers );
        $this->log_submission_activity( $sub_id, 'reply_email',
            $sent ? sprintf( 'Replied to %s — subject: %s', $to, $subject ) : sprintf( 'Reply failed (%s)', $to ),
            [ 'to' => $to, 'subject' => $subject, 'sent' => (bool) $sent ]
        );
        return rest_ensure_response( [ 'sent' => (bool) $sent, 'to' => $to ] );
    }

    /**
     * v2.52 — Mark a submission as spam (or unmark). Server learns the
     * fingerprint of marked-spam submissions so future submits with
     * matching patterns get a higher spam-confidence score.
     */
    public function mark_submission_spam( $req ) {
        $sub_id = (int) $req['id'];
        $body   = $req->get_json_params();
        $spam   = ! empty( $body['spam'] );
        $row    = FCP_DB::get_submission( $sub_id );
        if ( ! $row ) return new WP_Error( 'not_found', 'Submission not found.', [ 'status' => 404 ] );

        FCP_DB::update_submission( $sub_id, [ 'is_spam' => $spam ? 1 : 0 ] );
        $this->log_submission_activity( $sub_id, $spam ? 'marked_spam' : 'marked_ham', '' );
        self::learn_spam_pattern( $row, $spam );

        return rest_ensure_response( [ 'is_spam' => $spam ] );
    }

    /**
     * v2.52 — Smart spam learning. Stores fingerprints of marked-spam and
     * marked-ham submissions in `fcp_spam_patterns` option. Each pattern
     * captures: lowercased email-host, IP /24 prefix, first-100-char hash
     * of any text > 20 chars. On every new submission, FCP_REST::evaluate_spam
     * checks these patterns and bumps the spam score for matches.
     *
     * Capped at 500 patterns each (spam + ham) — FIFO eviction.
     */
    public static function learn_spam_pattern( $row, $is_spam ) {
        $store = get_option( 'fcp_spam_patterns', [ 'spam' => [], 'ham' => [] ] );
        if ( ! is_array( $store ) ) $store = [ 'spam' => [], 'ham' => [] ];
        $bucket = $is_spam ? 'spam' : 'ham';
        $store[ $bucket ] = isset( $store[ $bucket ] ) && is_array( $store[ $bucket ] ) ? $store[ $bucket ] : [];

        $patterns = self::extract_spam_fingerprint( $row );
        foreach ( $patterns as $p ) {
            if ( ! in_array( $p, $store[ $bucket ], true ) ) $store[ $bucket ][] = $p;
        }
        // FIFO cap at 500 each.
        if ( count( $store[ $bucket ] ) > 500 ) {
            $store[ $bucket ] = array_slice( $store[ $bucket ], -500 );
        }
        update_option( 'fcp_spam_patterns', $store, false );
    }

    /**
     * Build a list of compact pattern strings that uniquely-but-loosely
     * identify a submission's "kind." Returned strings are short so the
     * stored option doesn't bloat over time.
     */
    public static function extract_spam_fingerprint( $row ) {
        $out  = [];
        $email = $row['submitter_email'] ?? '';
        if ( $email && strpos( $email, '@' ) !== false ) {
            $out[] = 'host:' . strtolower( substr( strrchr( $email, '@' ), 1 ) );
        }
        // IP /24 prefix — same subnet often submits spam waves.
        $ip = $row['ip_address'] ?? '';
        if ( $ip && filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
            $parts = explode( '.', $ip );
            if ( count( $parts ) === 4 ) $out[] = 'ip24:' . $parts[0] . '.' . $parts[1] . '.' . $parts[2];
        }
        // Hash any long text content (>20 chars) — catches templated
        // spam where the body repeats across many submissions.
        $payload = is_string( $row['data'] ?? '' ) ? json_decode( $row['data'], true ) : null;
        if ( is_array( $payload ) ) {
            foreach ( $payload as $k => $v ) {
                if ( strpos( (string) $k, '_' ) === 0 ) continue;          // skip _meta etc.
                if ( ! is_string( $v ) || strlen( $v ) < 20 ) continue;
                $out[] = 'txt:' . md5( strtolower( substr( trim( $v ), 0, 100 ) ) );
                break;                                                       // one text sample per submission is enough
            }
        }
        return $out;
    }

    /**
     * v2.52 — Duplicate detection. For each new submission, scan the last
     * 200 submissions of the same form and count how many field values
     * exact-match the new one. Score = (matching_fields / total_fields)
     * × 100. Threshold for "possible duplicate" is 50% — anything above
     * gets flagged in _meta.dup_score + _meta.dup_of.
     *
     * Tradeoffs:
     *   - Email + phone field matches weight 2× (high signal).
     *   - We only check string values, not files or arrays.
     *   - The scan is bounded to 200 rows so a 10k-submission form
     *     doesn't make submit slow.
     */
    public static function run_duplicate_detection( $form_id, $new_sid, $new_clean ) {
        global $wpdb;
        $table = FCP_DB::subs_table();
        $rows  = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, data FROM $table
             WHERE form_id = %d AND id <> %d AND is_spam = 0 AND is_abandoned = 0
             ORDER BY id DESC LIMIT 200",
            $form_id, $new_sid
        ), ARRAY_A );
        if ( ! $rows ) return;

        // Normalize new submission's values for comparison.
        $new_vals = [];
        foreach ( $new_clean as $k => $v ) {
            if ( strpos( (string) $k, '_' ) === 0 ) continue;     // skip _meta etc.
            if ( ! is_string( $v ) ) continue;
            $clean = strtolower( trim( $v ) );
            if ( $clean === '' ) continue;
            $new_vals[ strtolower( $k ) ] = $clean;
        }
        $weight = function ( $key ) {
            $k = strtolower( $key );
            return ( strpos( $k, 'email' ) !== false || strpos( $k, 'phone' ) !== false || strpos( $k, 'tel' ) !== false )
                ? 2 : 1;
        };
        $total_weight = 0;
        foreach ( $new_vals as $k => $_ ) $total_weight += $weight( $k );
        if ( $total_weight === 0 ) return;

        $best_score = 0;
        $best_of    = null;
        foreach ( $rows as $r ) {
            $old = json_decode( $r['data'], true );
            if ( ! is_array( $old ) ) continue;
            $matched_w = 0;
            foreach ( $new_vals as $k => $v ) {
                // Match either exact-key or case-insensitive label match.
                foreach ( $old as $ok => $ov ) {
                    if ( strpos( (string) $ok, '_' ) === 0 ) continue;
                    if ( strtolower( $ok ) !== $k ) continue;
                    if ( is_string( $ov ) && strtolower( trim( $ov ) ) === $v ) {
                        $matched_w += $weight( $k );
                    }
                    break;
                }
            }
            $score = (int) round( ( $matched_w / max( 1, $total_weight ) ) * 100 );
            if ( $score > $best_score ) {
                $best_score = $score;
                $best_of    = (int) $r['id'];
            }
        }

        if ( $best_score >= 50 && $best_of ) {
            // Stash on the new row's _meta.
            $new_row = FCP_DB::get_submission( $new_sid );
            $payload = is_string( $new_row['data'] ) ? json_decode( $new_row['data'], true ) : [];
            if ( ! is_array( $payload ) ) $payload = [];
            if ( ! isset( $payload['_meta'] ) || ! is_array( $payload['_meta'] ) ) $payload['_meta'] = [];
            $payload['_meta']['dup_score'] = $best_score;
            $payload['_meta']['dup_of']    = $best_of;
            FCP_DB::update_submission( $new_sid, [ 'data' => wp_json_encode( $payload ) ] );
        }
    }

    /**
     * v2.52 — List WP users for the assignee dropdown. Only users with
     * edit_posts capability (i.e. potential admins) — random subscribers
     * shouldn't show up as assignment targets.
     */
    public function get_wp_users_list() {
        $users = get_users( [
            'capability__in' => [ 'edit_posts' ],
            'number'         => 100,
            'fields'         => [ 'ID', 'display_name', 'user_login', 'user_email' ],
            'orderby'        => 'display_name',
            'order'          => 'ASC',
        ] );
        $out = [];
        foreach ( $users as $u ) {
            $out[] = [
                'id'     => (int) $u->ID,
                'name'   => $u->display_name,
                'login'  => $u->user_login,
                'email'  => $u->user_email,
                'avatar' => get_avatar_url( (int) $u->ID, [ 'size' => 48 ] ),
            ];
        }
        return rest_ensure_response( [ 'users' => $out ] );
    }

    private function send_approval_email( $form, $data, $sub_id, $decision, $note ) {
        $to = $this->detect_email( $data );
        if ( ! $to ) return [ 'sent' => false, 'error' => 'No email address on the submission.' ];
        $title    = $form['title'] ?? get_bloginfo( 'name' );
        $approved = $decision === 'approved';
        $subject  = sprintf( '%s — Your submission was %s', $title, $approved ? 'approved ✓' : 'declined' );
        $color    = $approved ? '#10b981' : '#ef4444';
        $badge    = $approved ? 'APPROVED' : 'DECLINED';
        $intro    = $approved
            ? 'Good news — your submission has been reviewed and approved.'
            : 'Thanks for submitting. After review, we won\'t be moving forward this time.';

        $html  = '<div style="font-family:Inter,Arial,sans-serif;color:#0f172a;max-width:640px;margin:0 auto;line-height:1.55;">';
        $html .= '<div style="background:#fff;padding:28px;border:1px solid #e5e7eb;border-radius:10px;border-top:4px solid ' . $color . ';">';
        $html .= '<h2 style="margin:0 0 8px;">' . esc_html( $title ) . '</h2>';
        $html .= '<p style="margin:0 0 18px;"><span style="display:inline-block;padding:4px 10px;border-radius:999px;background:' . $color . ';color:#fff;font-weight:700;font-size:12px;">' . $badge . '</span></p>';
        $html .= '<p>' . esc_html( $intro ) . '</p>';
        if ( $note ) {
            $html .= '<p style="margin:18px 0 0;padding:12px 14px;background:#f8fafc;border-left:3px solid ' . $color . ';border-radius:4px;"><strong>From the reviewer:</strong><br>' . nl2br( esc_html( $note ) ) . '</p>';
        }
        $html .= '<p style="margin-top:24px;color:#94a3b8;font-size:12px;">Submission #' . (int) $sub_id . '</p>';
        $html .= '</div></div>';

        $settings  = get_option( 'fcp_settings', [] );
        $email_cfg = isset( $settings['email'] ) ? $settings['email'] : [];
        $headers   = $this->mail_headers( $email_cfg );
        $sent      = wp_mail( $to, $subject, $html, $headers );
        FCP_DB::log_mail( [
            'recipient'     => $to,
            'subject'       => $subject,
            'form_id'       => isset( $form['id'] ) ? (int) $form['id'] : null,
            'submission_id' => (int) $sub_id,
            'purpose'       => 'approval_' . $decision,
            'status'        => $sent ? 'delivered' : 'failed',
        ] );
        return [ 'sent' => (bool) $sent, 'to' => $to ];
    }

    /**
     * Manually mark a UPI/bank submission as paid or unpaid. The admin checks
     * their bank/UPI app, then clicks Verified or Unverified here. We update
     * the submission's payment_status and send the customer a status email so
     * they know whether their order is going through.
     */
    public function verify_payment( $req ) {
        $sub_id = (int) $req['id'];
        $sub    = FCP_DB::get_submission( $sub_id );
        if ( ! $sub ) {
            return new WP_Error( 'not_found', 'Submission not found.', [ 'status' => 404 ] );
        }
        $body     = $req->get_json_params();
        $verified = ! empty( $body['verified'] );
        $note     = isset( $body['note'] ) ? sanitize_textarea_field( $body['note'] ) : '';

        $form = FCP_DB::get_form( (int) $sub['form_id'] );
        $data = is_string( $sub['data'] ) ? json_decode( $sub['data'], true ) : ( is_array( $sub['data'] ) ? $sub['data'] : [] );
        if ( ! is_array( $data ) ) $data = [];

        $changes = [
            'payment_status'   => $verified ? 'paid' : 'failed',
            'payment_provider' => $sub['payment_provider'] ?: 'upi-manual',
        ];
        if ( $verified ) {
            $changes['paid_at'] = current_time( 'mysql' );

            // v2.70.9 — When marking a manual UPI/Bank/COD submission as
            // paid, we now COMPUTE the amount from the form's priced fields
            // (Product Selector / Pricing Table / Calculation) so that the
            // Payment Analytics dashboard, revenue reports, and GST invoices
            // all reflect the real money-in. Previously payment_amount was
            // 0 for every manual verification, and analytics showed empty
            // "no data" cards even after 5+ paid submissions.
            $existing_amt = (float) ( $sub['payment_amount'] ?? 0 );
            if ( $existing_amt <= 0 && $form && class_exists( 'FCP_India' ) ) {
                $computed = self::compute_amount_from_form_data( $form, $data );
                if ( $computed > 0 ) {
                    // v2.72.2 — If a coupon was recognized on this submission
                    // (paid gateway path stores discount at create-order,
                    // the general submit path may also stash it), subtract
                    // it so payment_amount matches what the visitor actually
                    // paid. Also backfill coupon_original_amount so the UI
                    // can render the "was ₹X now ₹Y" strike-through.
                    $discount = (float) ( $sub['coupon_discount'] ?? 0 );
                    $final    = ( $discount > 0 && $discount < $computed )
                        ? $computed - $discount
                        : $computed;
                    $changes['payment_amount']   = $final;
                    $changes['payment_currency'] = $sub['payment_currency']
                        ?: ( ( $form['settings']['currency'] ?? '' ) ?: 'INR' );
                    if ( empty( $sub['coupon_original_amount'] ) && $discount > 0 ) {
                        $changes['coupon_original_amount'] = $computed;
                    }
                }
            }
        }
        FCP_DB::update_submission( $sub_id, $changes );

        $mail = $this->send_payment_status_email( $form, $data, $sub_id, $verified, $note );

        // v2.70.1 — Fire the payment-verified action so India Suite (GST
        // invoice, WhatsApp payment-confirmed alerts) reacts on MANUAL
        // verification too. Only fires for the successful path.
        if ( $verified && $form ) {
            try {
                do_action( 'fcp_payment_verified', (int) $sub_id, $form, $data );
            } catch ( \Throwable $e ) {
                error_log( '[FormYantra] fcp_payment_verified action failed for #' . $sub_id . ': ' . $e->getMessage() );
            }
        }

        // Webhooks subscribed to the 'payment' event hear about manual
        // verifications too — same payload shape as gateway-verified payments.
        if ( $form ) {
            FCP_Integrations::fire(
                $verified ? 'payment' : 'submission',
                $form,
                $data,
                $sub_id,
                [
                    'payment' => [
                        'amount'   => isset( $sub['payment_amount'] )   ? (float) $sub['payment_amount']   : null,
                        'currency' => isset( $sub['payment_currency'] ) ? $sub['payment_currency']         : '',
                        'gateway'  => 'upi-manual',
                        'manual_verified' => $verified,
                        'note'     => $note,
                    ],
                ]
            );
        }

        return rest_ensure_response( [
            'success' => true,
            'status'  => $changes['payment_status'],
            'mail'    => $mail,
        ] );
    }

    /**
     * Schedule field callback: when a visitor books a slot, send a meeting
     * confirmation (with .ics + meeting URL) to both visitor + admin, then
     * register a wp_cron event N minutes before the slot for the reminder
     * email. Slot value is "YYYY-MM-DDTHH:MM".
     */
    private function schedule_meeting_notifications( $form, $data, $sub_id, $field, $slot ) {
        if ( ! preg_match( '/^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})$/', $slot, $m ) ) return;
        $start_ts = strtotime( $m[1] . ' ' . $m[2] . ':00 ' . wp_timezone_string() );
        if ( ! $start_ts ) return;
        $duration_min = max( 5, (int) ( $field['slotMinutes'] ?? 30 ) );
        $end_ts       = $start_ts + ( $duration_min * 60 );

        // ---- Meeting URL ----
        $meeting_url = self::generate_meeting_url( $field, $sub_id );

        // Persist the resolved URL on the submission so future re-sends use
        // the same room (otherwise each cron tick would create a new Jitsi
        // room and the visitor would be stranded).
        $sub = FCP_DB::get_submission( $sub_id );
        if ( $sub ) {
            $existing_data = is_string( $sub['data'] ) ? json_decode( $sub['data'], true ) : ( $sub['data'] ?: [] );
            if ( is_array( $existing_data ) ) {
                $existing_data[ ( $field['label'] ?? 'Schedule' ) . ' · Meeting Link' ] = $meeting_url;
                FCP_DB::update_submission( $sub_id, [ 'data' => wp_json_encode( $existing_data ) ] );
                $data[ ( $field['label'] ?? 'Schedule' ) . ' · Meeting Link' ] = $meeting_url;
            }
        }

        // ---- Send confirmation now ----
        $this->send_meeting_email( $form, $data, $sub_id, $field, $start_ts, $end_ts, $meeting_url, 'confirmation' );

        // ---- Schedule reminder ----
        if ( ! empty( $field['sendReminder'] ) || ! isset( $field['sendReminder'] ) ) {
            $lead_min   = max( 5, (int) ( $field['reminderMinutes'] ?? 30 ) );
            $remind_at  = $start_ts - ( $lead_min * 60 );
            // Don't schedule into the past.
            if ( $remind_at > current_time( 'timestamp' ) ) {
                wp_schedule_single_event( $remind_at, 'fcp_meeting_reminder', [ $sub_id, $field['label'] ?? '' ] );
            }
        }
    }

    /**
     * Cron callback — sends the "your meeting starts in N minutes" reminder.
     * Public + static so the global add_action() bound in formcraft-pro.php
     * can call it without needing the FCP_REST singleton.
     */
    public static function send_meeting_reminder( $sub_id, $field_label ) {
        $sub = FCP_DB::get_submission( $sub_id );
        if ( ! $sub ) return;
        $form = FCP_DB::get_form( (int) $sub['form_id'] );
        if ( ! $form ) return;
        $data = is_string( $sub['data'] ) ? json_decode( $sub['data'], true ) : ( $sub['data'] ?: [] );
        if ( ! is_array( $data ) ) return;

        // Find the schedule field
        $field = null;
        foreach ( $form['steps'] as $step ) {
            foreach ( $step['fields'] ?? [] as $f ) {
                if ( ( $f['type'] ?? '' ) === 'schedule' && ( $f['label'] ?? '' ) === $field_label ) { $field = $f; break 2; }
            }
        }
        if ( ! $field ) return;
        $slot = $data[ $field_label ] ?? '';
        if ( ! preg_match( '/^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})$/', $slot, $m ) ) return;
        $start_ts = strtotime( $m[1] . ' ' . $m[2] . ':00 ' . wp_timezone_string() );
        if ( ! $start_ts ) return;
        $end_ts = $start_ts + ( max( 5, (int) ( $field['slotMinutes'] ?? 30 ) ) * 60 );

        $meeting_url = $data[ $field_label . ' · Meeting Link' ] ?? self::generate_meeting_url( $field, $sub_id );
        $self = new self();
        $self->send_meeting_email( $form, $data, $sub_id, $field, $start_ts, $end_ts, $meeting_url, 'reminder' );
    }

    /**
     * Build a meeting URL. Auto-Jitsi creates a unique random room per
     * booking so different bookings can't collide. Custom = the URL the
     * admin pasted (e.g. a recurring Zoom room). None = no URL.
     */
    private static function generate_meeting_url( $field, $sub_id ) {
        $provider = $field['meetingProvider'] ?? 'jitsi';
        if ( $provider === 'custom' ) return (string) ( $field['meetingUrl'] ?? '' );
        if ( $provider === 'none' )   return '';
        // Jitsi — random room name. Includes site host so it's recognizable.
        $host = preg_replace( '/[^a-z0-9-]/i', '', parse_url( home_url(), PHP_URL_HOST ) ?: 'meet' );
        $room = 'fcp-' . $host . '-' . $sub_id . '-' . wp_generate_password( 8, false, false );
        return 'https://meet.jit.si/' . $room;
    }

    /**
     * Render + send the meeting confirmation OR reminder. $kind is
     * "confirmation" (sent immediately) or "reminder" (sent by cron).
     */
    private function send_meeting_email( $form, $data, $sub_id, $field, $start_ts, $end_ts, $meeting_url, $kind ) {
        $visitor_email = $this->detect_email( $data );
        $visitor_name  = $this->detect_name( $data );
        $admin_email   = '';
        $settings      = get_option( 'fcp_settings', [] );
        $email_cfg     = isset( $settings['email'] ) ? $settings['email'] : [];
        if ( ! empty( $email_cfg['admin_recipients'] ) ) {
            $admin_email = preg_split( '/[,;\s]+/', $email_cfg['admin_recipients'] )[0];
        }
        if ( ! $admin_email ) $admin_email = get_option( 'admin_email' );

        $form_title  = $form['title'] ?? get_bloginfo( 'name' );
        $title_line  = $field['meetingTitle'] ?: $form_title;
        $is_reminder = $kind === 'reminder';
        $start_pretty = wp_date( get_option( 'date_format', 'M j, Y' ) . ' · ' . get_option( 'time_format', 'g:i a' ), $start_ts );
        $lead_min     = max( 5, (int) ( $field['reminderMinutes'] ?? 30 ) );

        $subject_visitor = $is_reminder
            ? sprintf( '⏰ Starting in %d min — %s', $lead_min, $title_line )
            : sprintf( '✅ Booking confirmed — %s', $title_line );
        $subject_admin   = $is_reminder
            ? sprintf( '⏰ Upcoming meeting in %d min — %s', $lead_min, $title_line )
            : sprintf( '📅 New booking — %s', $title_line );

        // ICS file (only for the confirmation — reminder skips it).
        $headers   = $this->mail_headers( $email_cfg );
        $attachments = [];
        if ( ! $is_reminder ) {
            $ics_path = $this->build_ics_file( $sub_id, $title_line, $start_ts, $end_ts, $meeting_url, $visitor_name );
            if ( $ics_path ) $attachments[] = $ics_path;
        }

        // ---- Email body (HTML, shared shape) ----
        $body_for = function ( $audience ) use ( $title_line, $start_pretty, $meeting_url, $visitor_name, $is_reminder, $lead_min, $field, $form_title, $sub_id ) {
            $heading = $is_reminder
                ? sprintf( 'Your meeting starts in %d minutes', $lead_min )
                : 'Your booking is confirmed';
            $hello   = $audience === 'visitor'
                ? ( $visitor_name ? sprintf( 'Hi %s,', esc_html( $visitor_name ) ) : 'Hello,' )
                : 'Hi admin,';
            $intro   = $is_reminder
                ? 'Just a quick heads up — the meeting is about to start.'
                : ( $audience === 'visitor'
                    ? sprintf( 'Thanks for booking %s. Here are the details:', esc_html( $title_line ) )
                    : sprintf( 'A new booking just came in for %s.', esc_html( $title_line ) ) );

            $html  = '<div style="font-family:Inter,Arial,sans-serif;color:#0f172a;max-width:640px;margin:0 auto;line-height:1.55;">';
            $html .= '<div style="background:#fff;padding:28px;border:1px solid #e5e7eb;border-radius:10px;border-top:4px solid #6366f1;">';
            $html .= '<h2 style="margin:0 0 8px;font-size:22px;">' . esc_html( $heading ) . '</h2>';
            $html .= '<p style="margin:0 0 6px;color:#475569;">' . $hello . '</p>';
            $html .= '<p style="margin:0 0 18px;color:#475569;">' . $intro . '</p>';
            $html .= '<table cellpadding="0" cellspacing="0" style="border-collapse:collapse;border:1px solid #e5e7eb;border-radius:8px;width:100%;font-size:14px;">';
            $html .= '<tr><th align="left" style="background:#f8fafc;border-bottom:1px solid #e5e7eb;padding:10px;width:35%;">When</th>';
            $html .= '<td style="border-bottom:1px solid #e5e7eb;padding:10px;font-weight:700;">' . esc_html( $start_pretty ) . '</td></tr>';
            if ( $meeting_url ) {
                $html .= '<tr><th align="left" style="background:#f8fafc;padding:10px;">Join</th>';
                $html .= '<td style="padding:10px;"><a href="' . esc_url( $meeting_url ) . '" style="display:inline-block;background:#6366f1;color:#fff;padding:8px 16px;border-radius:6px;text-decoration:none;font-weight:700;">Open meeting →</a><br><span style="color:#64748b;font-size:12px;word-break:break-all;">' . esc_html( $meeting_url ) . '</span></td></tr>';
            }
            $html .= '</table>';
            $html .= '<p style="margin-top:24px;color:#94a3b8;font-size:12px;">' . esc_html( $form_title ) . ' · Booking #' . (int) $sub_id . '</p>';
            $html .= '</div></div>';
            return $html;
        };

        $sent_v = false;
        $sent_a = false;
        if ( $visitor_email ) {
            $sent_v = wp_mail( $visitor_email, $subject_visitor, $body_for( 'visitor' ), $headers, $attachments );
            FCP_DB::log_mail( [
                'recipient'     => $visitor_email,
                'subject'       => $subject_visitor,
                'form_id'       => isset( $form['id'] ) ? (int) $form['id'] : null,
                'submission_id' => (int) $sub_id,
                'purpose'       => $is_reminder ? 'meeting_reminder' : 'meeting_confirmation',
                'status'        => $sent_v ? 'delivered' : 'failed',
            ] );
        }
        if ( $admin_email ) {
            $sent_a = wp_mail( $admin_email, $subject_admin, $body_for( 'admin' ), $headers, $attachments );
            FCP_DB::log_mail( [
                'recipient'     => $admin_email,
                'subject'       => $subject_admin,
                'form_id'       => isset( $form['id'] ) ? (int) $form['id'] : null,
                'submission_id' => (int) $sub_id,
                'purpose'       => $is_reminder ? 'meeting_reminder_admin' : 'meeting_confirmation_admin',
                'status'        => $sent_a ? 'delivered' : 'failed',
            ] );
        }
        // Clean up the temporary .ics file after wp_mail handles it.
        foreach ( $attachments as $att ) {
            if ( $att && file_exists( $att ) ) @unlink( $att );
        }
        return [ 'visitor' => $sent_v, 'admin' => $sent_a ];
    }

    /**
     * Write a one-shot .ics calendar file to the system temp dir so wp_mail
     * can attach it. Caller deletes the file after sending.
     */
    private function build_ics_file( $sub_id, $title, $start_ts, $end_ts, $meeting_url, $visitor_name ) {
        $tmp = wp_tempnam( 'fcp-booking-' . $sub_id . '.ics' );
        if ( ! $tmp ) return '';
        // ICS wants UTC times in YYYYMMDDTHHMMSSZ
        $fmt = fn( $ts ) => gmdate( 'Ymd\THis\Z', $ts );
        $uid = 'fcp-booking-' . $sub_id . '@' . parse_url( home_url(), PHP_URL_HOST );
        $desc_lines = [];
        if ( $meeting_url )  $desc_lines[] = 'Meeting link: ' . $meeting_url;
        if ( $visitor_name ) $desc_lines[] = 'Booked by: '   . $visitor_name;
        $desc = implode( '\\n', $desc_lines );
        $ics  = "BEGIN:VCALENDAR\r\n";
        $ics .= "VERSION:2.0\r\n";
        $ics .= "PRODID:-//FormYantra//Booking//EN\r\n";
        $ics .= "METHOD:REQUEST\r\n";
        $ics .= "BEGIN:VEVENT\r\n";
        $ics .= "UID:" . $uid . "\r\n";
        $ics .= "DTSTAMP:" . $fmt( time() ) . "\r\n";
        $ics .= "DTSTART:" . $fmt( $start_ts ) . "\r\n";
        $ics .= "DTEND:"   . $fmt( $end_ts )   . "\r\n";
        $ics .= "SUMMARY:" . str_replace( "\n", "\\n", $title ) . "\r\n";
        $ics .= "DESCRIPTION:" . $desc . "\r\n";
        if ( $meeting_url ) {
            $ics .= "LOCATION:" . $meeting_url . "\r\n";
            $ics .= "URL:" . $meeting_url . "\r\n";
        }
        $ics .= "END:VEVENT\r\n";
        $ics .= "END:VCALENDAR\r\n";
        $renamed = $tmp . '.ics';
        @rename( $tmp, $renamed );
        file_put_contents( $renamed, $ics );
        return $renamed;
    }

    /**
     * Send the customer a "your payment was verified / could not be verified"
     * email. Picks the recipient from the submission's known email fields and
     * routes through the same SMTP path as the regular confirmation mail.
     */
    private function send_payment_status_email( $form, $data, $sub_id, $verified, $note ) {
        $to = $this->detect_email( $data );
        if ( ! $to ) {
            return [ 'sent' => false, 'error' => 'No email address on this submission.' ];
        }
        $settings   = get_option( 'fcp_settings', [] );
        $email_cfg  = isset( $settings['email'] ) ? $settings['email'] : [];
        $site       = get_bloginfo( 'name' );
        $form_title = isset( $form['title'] ) ? $form['title'] : $site;
        $sub        = FCP_DB::get_submission( $sub_id );
        $amount     = $sub && $sub['payment_amount']   ? number_format_i18n( (float) $sub['payment_amount'], 2 ) : '';
        $currency   = $sub && $sub['payment_currency'] ? $sub['payment_currency'] : '';
        $ref        = '';
        foreach ( $data as $k => $v ) {
            if ( ! is_string( $v ) ) continue;
            if ( stripos( $k, 'reference' ) !== false || stripos( $k, '__upi_ref' ) !== false || stripos( $k, '__bank_ref' ) !== false ) {
                if ( trim( $v ) !== '' ) { $ref = $v; break; }
            }
        }

        if ( $verified ) {
            $subject = sprintf( '%s — Payment received ✓', $form_title );
            $intro   = 'Great news — we\'ve verified your payment and your submission is now confirmed.';
            $badge   = '<span style="display:inline-block;padding:4px 10px;border-radius:999px;background:#10b981;color:#fff;font-weight:700;font-size:12px;">PAID</span>';
            $color   = '#10b981';
        } else {
            $subject = sprintf( '%s — Payment could not be verified', $form_title );
            $intro   = 'We could not verify your recent payment. Please double-check the transaction or reach out to us with your reference ID.';
            $badge   = '<span style="display:inline-block;padding:4px 10px;border-radius:999px;background:#ef4444;color:#fff;font-weight:700;font-size:12px;">UNVERIFIED</span>';
            $color   = '#ef4444';
        }

        $html  = '<div style="font-family:Inter,Arial,sans-serif;color:#0f172a;max-width:640px;margin:0 auto;line-height:1.55;">';
        $html .= '<div style="border-top:4px solid ' . $color . ';background:#fff;padding:28px;border:1px solid #e5e7eb;border-radius:10px;">';
        $html .= '<h2 style="margin:0 0 8px;font-size:22px;">' . esc_html( $form_title ) . '</h2>';
        $html .= '<p style="margin:0 0 18px;color:#64748b;">' . $badge . '</p>';
        $html .= '<p style="margin:0 0 18px;font-size:15px;">' . esc_html( $intro ) . '</p>';
        $html .= '<table cellpadding="0" cellspacing="0" style="border-collapse:collapse;border:1px solid #e5e7eb;border-radius:8px;width:100%;font-size:14px;">';
        if ( $amount ) {
            $html .= '<tr><th align="left" style="background:#f8fafc;border-bottom:1px solid #e5e7eb;padding:10px;width:35%;">Amount</th>';
            $html .= '<td style="border-bottom:1px solid #e5e7eb;padding:10px;font-weight:700;">' . esc_html( trim( $currency . ' ' . $amount ) ) . '</td></tr>';
        }
        if ( $ref ) {
            $html .= '<tr><th align="left" style="background:#f8fafc;border-bottom:1px solid #e5e7eb;padding:10px;">Reference</th>';
            $html .= '<td style="border-bottom:1px solid #e5e7eb;padding:10px;font-family:monospace;">' . esc_html( $ref ) . '</td></tr>';
        }
        $html .= '<tr><th align="left" style="background:#f8fafc;padding:10px;">Submission ID</th>';
        $html .= '<td style="padding:10px;">#' . (int) $sub_id . '</td></tr>';
        $html .= '</table>';
        if ( $note ) {
            $html .= '<p style="margin:18px 0 0;padding:12px 14px;background:#f8fafc;border-left:3px solid ' . $color . ';border-radius:4px;font-size:14px;"><strong>Note from us:</strong><br>' . nl2br( esc_html( $note ) ) . '</p>';
        }
        $html .= '<p style="margin-top:24px;color:#64748b;font-size:13px;">If you have any questions, just reply to this email.</p>';
        $html .= '<p style="margin-top:8px;color:#94a3b8;font-size:12px;">' . esc_html( $site ) . '</p>';
        $html .= '</div></div>';

        $headers = $this->mail_headers( $email_cfg );
        $sent    = wp_mail( $to, $subject, $html, $headers );

        FCP_DB::log_mail( [
            'recipient'     => $to,
            'subject'       => $subject,
            'form_id'       => isset( $form['id'] ) ? (int) $form['id'] : null,
            'submission_id' => (int) $sub_id,
            'purpose'       => $verified ? 'payment_verified' : 'payment_unverified',
            'status'        => $sent ? 'delivered' : 'failed',
        ] );

        return [ 'sent' => (bool) $sent, 'to' => $to ];
    }

    /**
     * Forward a support request from the Help & Docs modal to the
     * FormYantra support inbox.
     */
    public function send_support_request( $req ) {
        $body    = $req->get_json_params();
        $name    = isset( $body['name'] )    ? sanitize_text_field( $body['name'] )         : '';
        $email   = isset( $body['email'] )   ? sanitize_email( $body['email'] )             : '';
        $subject = isset( $body['subject'] ) ? sanitize_text_field( $body['subject'] )      : '';
        $message = isset( $body['message'] ) ? sanitize_textarea_field( $body['message'] )  : '';

        if ( $name === '' || ! is_email( $email ) || $message === '' ) {
            return new WP_Error(
                'bad_request',
                'Please provide your name, a valid email, and a message.',
                [ 'status' => 400 ]
            );
        }

        $support_email   = 'deepak@imarkinfotech.com'; // FormYantra support inbox
        $email_subject   = '[FormYantra Support] ' . ( $subject !== '' ? $subject : 'Support request from ' . $name );

        $html  = '<div style="font-family:Inter,Arial,sans-serif;color:#0f172a;line-height:1.55;max-width:640px;">';
        $html .= '<h2 style="color:#6366f1;margin:0 0 14px;">FormYantra · New support request</h2>';
        $html .= '<table cellpadding="8" style="border-collapse:collapse;border:1px solid #e5e7eb;border-radius:8px;width:100%;">';
        $html .= '<tr><th align="left" style="background:#f8fafc;border-bottom:1px solid #e5e7eb;width:30%;">From</th>';
        $html .= '<td style="border-bottom:1px solid #e5e7eb;">' . esc_html( $name ) . ' &lt;' . esc_html( $email ) . '&gt;</td></tr>';
        if ( $subject !== '' ) {
            $html .= '<tr><th align="left" style="background:#f8fafc;border-bottom:1px solid #e5e7eb;">Subject</th>';
            $html .= '<td style="border-bottom:1px solid #e5e7eb;">' . esc_html( $subject ) . '</td></tr>';
        }
        $html .= '<tr><th align="left" style="background:#f8fafc;vertical-align:top;">Message</th>';
        $html .= '<td>' . nl2br( esc_html( $message ) ) . '</td></tr>';
        $html .= '</table>';

        // Diagnostic footer — useful for the support team.
        $html .= '<p style="color:#64748b;font-size:12px;margin-top:16px;">';
        $html .= '<strong>Site:</strong> ' . esc_html( get_bloginfo( 'name' ) ) . ' &lt;' . esc_url( home_url() ) . '&gt;<br>';
        $html .= '<strong>Plugin:</strong> FormYantra v' . FCP_VERSION . '<br>';
        $html .= '<strong>WordPress:</strong> ' . esc_html( get_bloginfo( 'version' ) ) . '<br>';
        $html .= '<strong>PHP:</strong> ' . esc_html( PHP_VERSION );
        $html .= '</p>';
        $html .= '</div>';

        $settings = get_option( 'fcp_settings', [] );
        $headers  = [
            'Content-Type: text/html; charset=UTF-8',
            $this->build_from_header( isset( $settings['email'] ) ? $settings['email'] : [] ),
            'Reply-To: ' . sprintf( '%s <%s>', $name, $email ),
        ];

        // Capture any wp_mail_failed error for diagnostics.
        $caught_error = '';
        $cb = function ( $wp_error ) use ( &$caught_error ) {
            if ( is_wp_error( $wp_error ) ) $caught_error = $wp_error->get_error_message();
        };
        add_action( 'wp_mail_failed', $cb );
        $sent = wp_mail( $support_email, $email_subject, $html, $headers );
        remove_action( 'wp_mail_failed', $cb );

        FCP_DB::log_mail( [
            'recipient'     => $support_email,
            'subject'       => $email_subject,
            'purpose'       => 'support',
            'status'        => $sent ? 'delivered' : 'failed',
            'error_message' => $sent ? '' : $caught_error,
        ] );

        if ( $sent ) {
            // Also send a confirmation to the user.
            $confirm_subject = 'We received your FormYantra support request';
            $confirm_html    = '<p>Hi ' . esc_html( $name ) . ',</p>'
                             . '<p>Thanks for reaching out! Our team has received your request and will reply within 24 hours.</p>'
                             . '<p style="color:#64748b;font-size:13px;">For your records, here is what you sent:</p>'
                             . '<blockquote style="border-left:3px solid #6366f1;padding:8px 14px;color:#475569;">' . nl2br( esc_html( $message ) ) . '</blockquote>'
                             . '<p>— The FormYantra Team</p>';
            wp_mail( $email, $confirm_subject, $confirm_html, [
                'Content-Type: text/html; charset=UTF-8',
                $this->build_from_header( isset( $settings['email'] ) ? $settings['email'] : [] ),
            ] );

            return rest_ensure_response( [
                'success' => true,
                'message' => 'Your request has been sent. Our team will reply to ' . $email . ' within 24 hours.'
            ] );
        }

        return rest_ensure_response( [
            'success' => false,
            'message' => 'Could not send the request automatically' .
                ( $caught_error ? ' (' . $caught_error . ')' : '' ) .
                '. Please email us directly at ' . $support_email . '.'
        ] );
    }

    /**
     * Send a real test email through wp_mail() and return rich
     * diagnostics so the dashboard can show the user exactly what
     * happened — and exactly what to do if it failed.
     */
    public function send_test_email( $req ) {
        $body = $req->get_json_params();
        $to   = isset( $body['to'] ) ? sanitize_email( $body['to'] ) : '';
        if ( ! is_email( $to ) ) {
            return new WP_Error( 'bad_email', 'Please provide a valid recipient email.', [ 'status' => 400 ] );
        }

        $settings = get_option( 'fcp_settings', [] );
        $email    = isset( $settings['email'] ) ? $settings['email'] : [];

        // Capture every wp_mail_failed event in this request, including
        // the raw PHPMailerException data which usually pinpoints the
        // exact reason (auth failure, blocked port, missing function, …).
        $errors = [];
        $cb = function ( $wp_error ) use ( &$errors ) {
            if ( is_wp_error( $wp_error ) ) {
                $errors[] = [
                    'code'    => $wp_error->get_error_code(),
                    'message' => $wp_error->get_error_message(),
                    'data'    => $wp_error->get_error_data(),
                ];
            }
        };
        add_action( 'wp_mail_failed', $cb );

        $subject   = sprintf( __( 'FormYantra · Test email from %s', 'formcraft-pro' ), get_bloginfo( 'name' ) );
        $body_html =
            '<div style="font-family:Inter,Arial,sans-serif;color:#0f172a;line-height:1.55;">' .
            '<h2 style="color:#6366f1;margin:0 0 10px;">FormYantra test email ✓</h2>' .
            '<p>If you can read this, your WordPress site can send mail and FormCraft notifications will work reliably.</p>' .
            '<p style="color:#64748b;font-size:13px;">Sent ' . esc_html( current_time( 'F j, Y \a\t g:i a' ) ) . ' from <strong>' . esc_html( get_bloginfo( 'name' ) ) . '</strong>.</p>' .
            '</div>';

        // ---- Attempt 1: simplest possible wp_mail (no custom From) ----
        // Many shared hosts reject a custom From header that doesn't match
        // the server domain, so we start with WordPress's defaults.
        $attempt1_errors = [];
        $errors          = [];
        $ok1 = wp_mail( $to, $subject, $body_html, [ 'Content-Type: text/html; charset=UTF-8' ] );
        $attempt1_errors = $errors;

        // ---- Attempt 2: with the user's configured From header ----
        $ok2             = false;
        $attempt2_errors = [];
        if ( ! $ok1 ) {
            $errors = [];
            $headers_with_from = [
                'Content-Type: text/html; charset=UTF-8',
                $this->build_from_header( $email ),
            ];
            $ok2 = wp_mail( $to, $subject, $body_html, $headers_with_from );
            $attempt2_errors = $errors;
        }

        remove_action( 'wp_mail_failed', $cb );

        // Inspect installed SMTP plugins and — critically — whether they
        // have actually been configured. A plugin that's active but with
        // no mailer set up is the #1 cause of "WP Mail SMTP installed
        // but mail still doesn't send".
        $smtp = $this->detect_smtp_state();

        $diagnostics = [
            'site_url'       => home_url(),
            'admin_email'    => get_option( 'admin_email' ),
            'wp_version'     => get_bloginfo( 'version' ),
            'php_version'    => PHP_VERSION,
            'plugin_version' => FCP_VERSION,
            'smtp_plugin'    => $smtp['plugin'],
            'smtp_mailer'    => $smtp['mailer'],
            'smtp_configured'=> $smtp['configured'],
            'smtp_settings_url' => $smtp['settings_url'],
            'mail_function'  => function_exists( 'mail' ) ? 'available' : 'missing',
        ];

        if ( $ok1 || $ok2 ) {
            FCP_DB::log_mail( [
                'recipient' => $to,
                'subject'   => $subject,
                'purpose'   => 'test',
                'status'    => 'delivered',
            ] );
            return rest_ensure_response( [
                'success'      => true,
                'message'      => $ok2
                    ? 'Sent successfully (using your configured From address).'
                    : 'Sent successfully (using WordPress default From address).',
                'used_default' => ! $ok2,
                'diagnostics'  => $diagnostics,
            ] );
        }

        // Both attempts failed — return everything we know.
        $all_errors  = array_merge( $attempt1_errors, $attempt2_errors );
        $last_msg    = $all_errors ? end( $all_errors )['message'] : '';
        $fix_steps   = [];

        // The most useful diagnosis is whether an SMTP plugin is installed
        // but un-configured — that's the #1 trip-up after "Install".
        if ( $smtp['plugin'] && ! $smtp['configured'] ) {
            $fix_steps[] = sprintf(
                "%s is installed but no mailer is configured yet. Open %s → run the setup wizard and connect Gmail / SendGrid / Mailgun / SES.",
                $smtp['plugin'], $smtp['plugin']
            );
        } elseif ( ! $smtp['plugin'] ) {
            $fix_steps[] = "No SMTP plugin found. Install and configure WP Mail SMTP or FluentSMTP — both free.";
        }
        if ( stripos( $last_msg, 'authent' ) !== false || stripos( $last_msg, 'login' ) !== false ) {
            $fix_steps[] = "Your SMTP username or password is incorrect — double-check the credentials inside your SMTP plugin.";
        }
        if ( stripos( $last_msg, 'connect' ) !== false || stripos( $last_msg, 'timeout' ) !== false ) {
            $fix_steps[] = "The SMTP port is blocked by your host. Try a different port (587 / 465 / 2525) or switch to an API mailer (SendGrid, Mailgun, Brevo).";
        }
        if ( stripos( $last_msg, 'mail()' ) !== false || stripos( $last_msg, 'function' ) !== false ) {
            $fix_steps[] = "PHP's mail() function is disabled on your server. You MUST use an SMTP plugin.";
        }
        if ( stripos( $last_msg, 'from' ) !== false && $ok1 === false ) {
            $fix_steps[] = "Your configured \"From Email\" doesn't match what the mailer allows. In WP Mail SMTP, enable \"Force From Email\" or change the From Email to match the authenticated sender.";
        }
        if ( empty( $fix_steps ) ) {
            $fix_steps[] = "Open your SMTP plugin and run its built-in test email. Once that works, FormYantra will too — both use wp_mail().";
        }

        FCP_DB::log_mail( [
            'recipient'     => $to,
            'subject'       => $subject,
            'purpose'       => 'test',
            'status'        => 'failed',
            'error_message' => $last_msg ?: 'wp_mail() returned false',
        ] );

        return rest_ensure_response( [
            'success'     => false,
            'message'     => $last_msg ?: 'wp_mail() returned false. PHP mail is likely disabled or misconfigured on this host.',
            'attempts'    => [
                'no_from_header'    => [ 'sent' => $ok1, 'errors' => $attempt1_errors ],
                'with_from_header'  => [ 'sent' => $ok2, 'errors' => $attempt2_errors ],
            ],
            'fix_steps'   => $fix_steps,
            'diagnostics' => $diagnostics,
        ] );
    }

    public function can_manage() {
        return current_user_can( 'manage_options' );
    }

    /* ------------------ Forms ------------------ */
    public function list_forms( $req ) {
        return rest_ensure_response( FCP_DB::get_forms() );
    }
    public function get_form( $req ) {
        $f = FCP_DB::get_form( $req['id'] );
        return $f ? rest_ensure_response( $f )
                  : new WP_Error( 'not_found', 'Form not found', [ 'status' => 404 ] );
    }
    public function create_form( $req ) {
        $form = $req->get_json_params();
        if ( empty( $form ) ) {
            return new WP_Error( 'bad_request', 'Empty payload', [ 'status' => 400 ] );
        }
        $id = FCP_DB::insert_form( $form );
        $saved = FCP_DB::get_form( $id );
        // v2.59 — Register translatable strings with WPML/Polylang (if active)
        if ( class_exists( 'FCP_I18n' ) && ! empty( $saved['settings']['wpmlRegister'] ) ) {
            FCP_I18n::register_form_strings( $saved );
        }
        // v2.61 — Audit
        if ( class_exists( 'FCP_Audit' ) ) FCP_Audit::log( 'form_created', 'form', $id, null, [ 'title' => $saved['title'] ?? '' ] );
        return rest_ensure_response( $saved );
    }
    public function update_form( $req ) {
        $form = $req->get_json_params();
        $before = FCP_DB::get_form( $req['id'] );
        FCP_DB::update_form( $req['id'], $form );
        $saved = FCP_DB::get_form( $req['id'] );
        if ( class_exists( 'FCP_I18n' ) && ! empty( $saved['settings']['wpmlRegister'] ) ) {
            FCP_I18n::register_form_strings( $saved );
        }
        if ( class_exists( 'FCP_Audit' ) ) {
            $diff = [];
            if ( ($before['title'] ?? '') !== ($saved['title'] ?? '') )   $diff['title']  = [ $before['title']  ?? '', $saved['title']  ?? '' ];
            if ( ($before['status'] ?? '') !== ($saved['status'] ?? '') ) $diff['status'] = [ $before['status'] ?? '', $saved['status'] ?? '' ];
            FCP_Audit::log( 'form_updated', 'form', $req['id'], null, $diff ?: [ 'fields_count' => count( $saved['steps'][0]['fields'] ?? [] ) ] );
        }
        return rest_ensure_response( $saved );
    }
    public function delete_form( $req ) {
        if ( class_exists( 'FCP_Audit' ) ) {
            $before = FCP_DB::get_form( $req['id'] );
            FCP_Audit::log( 'form_deleted', 'form', $req['id'], [ 'title' => $before['title'] ?? '' ], null );
        }
        FCP_DB::delete_form( $req['id'] );
        return rest_ensure_response( [ 'deleted' => true ] );
    }
    /**
     * Return vote tallies for every Poll field on a form. Public endpoint
     * (visitors see live results) — we expose counts only, no names.
     */
    public function get_poll_results( $req ) {
        $form_id = (int) $req['id'];
        $form    = FCP_DB::get_form( $form_id );
        if ( ! $form ) return new WP_Error( 'not_found', 'Form not found.', [ 'status' => 404 ] );

        $poll_fields = [];
        foreach ( $form['steps'] ?? [] as $step ) {
            foreach ( $step['fields'] ?? [] as $f ) {
                if ( ( $f['type'] ?? '' ) === 'poll' ) {
                    $poll_fields[ $f['id'] ] = [
                        'id'      => $f['id'],
                        'label'   => $f['label'] ?? '',
                        'options' => array_values( array_map( fn( $o ) => [ 'label' => $o, 'votes' => 0 ], $f['options'] ?? [] ) ),
                    ];
                }
            }
        }
        if ( empty( $poll_fields ) ) return rest_ensure_response( [ 'polls' => [] ] );

        // Tally from non-spam submissions
        global $wpdb;
        $rows = $wpdb->get_col( $wpdb->prepare(
            "SELECT data FROM " . FCP_DB::subs_table() . " WHERE form_id = %d AND is_spam = 0",
            $form_id
        ) );
        foreach ( $rows as $raw ) {
            $d = json_decode( $raw, true );
            if ( ! is_array( $d ) ) continue;
            foreach ( $poll_fields as $fid => &$poll ) {
                $val = $d[ $poll['label'] ] ?? '';
                if ( ! is_string( $val ) || $val === '' ) continue;
                foreach ( $poll['options'] as &$opt ) {
                    if ( $opt['label'] === $val ) { $opt['votes']++; break; }
                }
            }
        }
        $out = [];
        foreach ( $poll_fields as $fid => $poll ) {
            $total = array_sum( array_column( $poll['options'], 'votes' ) );
            $poll['total'] = $total;
            foreach ( $poll['options'] as &$opt ) {
                $opt['pct'] = $total > 0 ? round( ( $opt['votes'] / $total ) * 100, 1 ) : 0;
            }
            $out[ $fid ] = $poll;
        }
        return rest_ensure_response( [ 'polls' => $out ] );
    }

    public function track_view( $req ) {
        FCP_DB::bump_views( $req['id'] );
        return rest_ensure_response( [ 'ok' => true ] );
    }

    /**
     * Public endpoint — returns the per-slot booked count for a given date
     * across every Schedule field on the form. The front-end uses this to
     * disable slots that have hit their capacity. We only count non-spam
     * submissions so spam attempts can't artificially block a slot.
     *
     * Response: { date, booked: { "09:00": 2, "09:30": 1, ... } }
     */
    public function get_slot_availability( $req ) {
        $form_id = (int) $req['id'];
        $date    = sanitize_text_field( (string) $req->get_param( 'date' ) );
        if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
            return new WP_Error( 'bad_date', 'date must be YYYY-MM-DD', [ 'status' => 400 ] );
        }
        $form = FCP_DB::get_form( $form_id );
        if ( ! $form ) return new WP_Error( 'not_found', 'Form not found.', [ 'status' => 404 ] );

        // Find every schedule field's label so we know which keys to scan.
        $sched_labels = [];
        foreach ( $form['steps'] ?? [] as $step ) {
            foreach ( $step['fields'] ?? [] as $f ) {
                if ( ( $f['type'] ?? '' ) === 'schedule' && ! empty( $f['label'] ) ) {
                    $sched_labels[] = $f['label'];
                }
            }
        }
        if ( empty( $sched_labels ) ) return rest_ensure_response( [ 'date' => $date, 'booked' => (object) [] ] );

        global $wpdb;
        $rows = $wpdb->get_col( $wpdb->prepare(
            "SELECT data FROM " . FCP_DB::subs_table() . " WHERE form_id = %d AND is_spam = 0 AND data LIKE %s",
            $form_id,
            '%' . $wpdb->esc_like( $date ) . '%'
        ) );

        $booked = [];
        foreach ( $rows as $raw ) {
            $d = json_decode( $raw, true );
            if ( ! is_array( $d ) ) continue;
            foreach ( $sched_labels as $lbl ) {
                $v = $d[ $lbl ] ?? '';
                if ( ! is_string( $v ) || strlen( $v ) < 16 ) continue;
                // Expect "YYYY-MM-DDTHH:MM" — only count this date's slots
                if ( substr( $v, 0, 10 ) !== $date ) continue;
                $slot = substr( $v, 11, 5 );
                if ( ! preg_match( '/^\d{2}:\d{2}$/', $slot ) ) continue;
                $booked[ $slot ] = ( $booked[ $slot ] ?? 0 ) + 1;
            }
        }
        return rest_ensure_response( [ 'date' => $date, 'booked' => (object) $booked ] );
    }

    /**
     * Record a step-level event so analytics can compute drop-off. The
     * front-end emits "view" when a step opens and "complete" when the user
     * moves past it (or "submit" on the final step). Per-IP rate-limited to
     * keep noise down — abandoned sessions still record one row per step.
     */
    public function track_step_event( $req ) {
        $form_id = (int) $req['id'];
        $body    = $req->get_json_params();
        $session = isset( $body['session_id'] ) ? sanitize_text_field( $body['session_id'] ) : '';
        $step    = isset( $body['step'] )       ? (int) $body['step']                         : 0;
        $type    = isset( $body['type'] )       ? sanitize_key( $body['type'] )               : 'view';
        if ( ! in_array( $type, [ 'view', 'complete', 'submit' ], true ) ) $type = 'view';
        if ( ! $session || $step < 0 || ! $form_id ) {
            return rest_ensure_response( [ 'ok' => false ] );
        }
        // De-dupe: skip if the same (session, step, type) already exists.
        global $wpdb;
        $t = FCP_DB::step_events_table();
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM $t WHERE form_id=%d AND session_id=%s AND step_index=%d AND event_type=%s LIMIT 1",
            $form_id, $session, $step, $type
        ) );
        if ( ! $exists ) {
            $wpdb->insert( $t, [
                'form_id'    => $form_id,
                'session_id' => $session,
                'step_index' => $step,
                'event_type' => $type,
                'created_at' => current_time( 'mysql' ),
            ] );
        }
        return rest_ensure_response( [ 'ok' => true ] );
    }

    /**
     * Form Abandonment: auto-save partial form data while the visitor is
     * still typing. Keyed by (form_id, session_id) — repeat calls update
     * the same row instead of creating duplicates. When the visitor
     * eventually submits, finalize_abandoned() promotes the row to a
     * normal submission. Honors a per-form opt-in flag in the form's
     * settings.abandonment.enabled.
     *
     * Body: { session_id, data: { ... }, country, device, browser }
     * Returns: { ok, id } where id is the abandoned-row id (or 0 if disabled).
     */
    public function track_partial( $req ) {
        $form_id = (int) $req['id'];
        $body    = $req->get_json_params();
        $session = isset( $body['session_id'] ) ? sanitize_text_field( (string) $body['session_id'] ) : '';
        $data    = ( isset( $body['data'] ) && is_array( $body['data'] ) ) ? $body['data'] : [];

        if ( ! $form_id || ! $session ) {
            return rest_ensure_response( [ 'ok' => false, 'id' => 0 ] );
        }

        $form = FCP_DB::get_form( $form_id );
        if ( ! $form ) {
            return rest_ensure_response( [ 'ok' => false, 'id' => 0 ] );
        }

        // Per-form opt-in (defaults to off so this is purely a Pro feature
        // admins enable per form in Settings → Abandonment).
        $abandon = $form['settings']['abandonment'] ?? [];
        if ( empty( $abandon['enabled'] ) ) {
            return rest_ensure_response( [ 'ok' => false, 'id' => 0, 'reason' => 'disabled' ] );
        }

        // Require BOTH a name AND a valid email before persisting an
        // abandoned row. Without those, the entry is useless for the admin
        // (can't identify the visitor, can't email recovery). Walks every
        // field label in the payload so it works regardless of whether the
        // admin labelled the field "Name", "Full Name", "Your Name", etc.
        $found_name  = '';
        $found_email = '';
        foreach ( $data as $k => $v ) {
            if ( ! is_string( $v ) || $v === '' ) continue;
            $lk = strtolower( (string) $k );
            if ( ! $found_email && is_email( trim( $v ) ) ) {
                $found_email = trim( $v );
                continue;
            }
            if ( ! $found_name && ( strpos( $lk, 'name' ) !== false || $lk === 'full name' || $lk === 'name' ) ) {
                $found_name = trim( $v );
            }
        }
        if ( ! $found_name || ! $found_email ) {
            return rest_ensure_response( [ 'ok' => false, 'id' => 0, 'reason' => 'need_name_email' ] );
        }

        // Sanitize each value at top-level. Nested arrays (repeater, file lists)
        // pass through unchanged — they were already validated by the field.
        $clean = [];
        foreach ( $data as $k => $v ) {
            $key = sanitize_text_field( (string) $k );
            if ( is_array( $v ) ) {
                $clean[ $key ] = $v;
            } else {
                $clean[ $key ] = sanitize_textarea_field( (string) $v );
            }
        }

        $extra = [
            'country' => isset( $body['country'] ) ? sanitize_text_field( $body['country'] ) : '',
            'device'  => isset( $body['device'] )  ? sanitize_text_field( $body['device'] )  : '',
            'browser' => isset( $body['browser'] ) ? sanitize_text_field( $body['browser'] ) : '',
        ];
        $id = FCP_DB::upsert_abandoned( $form_id, $session, $clean, $extra );
        return rest_ensure_response( [ 'ok' => true, 'id' => (int) $id ] );
    }

    /**
     * Admin: list abandoned submissions for review / manual recovery.
     */
    public function list_abandoned( $req ) {
        global $wpdb;
        $table   = FCP_DB::subs_table();
        $form_id = (int) $req->get_param( 'form_id' );
        $where   = 'is_abandoned = 1';
        if ( $form_id ) $where .= $wpdb->prepare( ' AND form_id = %d', $form_id );
        $rows = $wpdb->get_results( "SELECT * FROM $table WHERE $where ORDER BY last_touched_at DESC LIMIT 500", ARRAY_A );
        return rest_ensure_response( $rows ?: [] );
    }

    public function delete_abandoned( $req ) {
        global $wpdb;
        $id = (int) $req['id'];
        $wpdb->delete( FCP_DB::subs_table(), [ 'id' => $id, 'is_abandoned' => 1 ] );
        return rest_ensure_response( [ 'success' => true ] );
    }

    /**
     * Admin: send a recovery email immediately for a specific abandoned
     * entry (bypass the cron). Useful for the per-row "Send recovery"
     * button in the admin UI.
     */
    public function send_recovery_email( $req ) {
        $id = (int) $req['id'];
        $sent = self::dispatch_recovery_email( $id );
        if ( is_wp_error( $sent ) ) {
            return new WP_Error( $sent->get_error_code(), $sent->get_error_message(), [ 'status' => 400 ] );
        }
        return rest_ensure_response( [ 'success' => true ] );
    }

    /**
     * Compose + send a recovery email for one abandoned row. Shared by
     * the manual REST endpoint AND the cron job. Returns WP_Error on any
     * problem so the caller can surface it.
     */
    public static function dispatch_recovery_email( $abandoned_id ) {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . FCP_DB::subs_table() . " WHERE id = %d AND is_abandoned = 1 LIMIT 1",
            (int) $abandoned_id
        ), ARRAY_A );
        if ( ! $row ) return new WP_Error( 'fcp_abandon_not_found', 'Abandoned entry not found.' );
        if ( empty( $row['submitter_email'] ) || ! is_email( $row['submitter_email'] ) ) {
            return new WP_Error( 'fcp_abandon_no_email', 'No email captured for this entry.' );
        }

        $form = FCP_DB::get_form( (int) $row['form_id'] );
        if ( ! $form ) return new WP_Error( 'fcp_abandon_no_form', 'Source form is missing.' );

        $cfg     = $form['settings']['abandonment'] ?? [];
        $subject = ! empty( $cfg['recovery_subject'] )
            ? $cfg['recovery_subject']
            : sprintf( 'Finish your "%s" submission', $form['title'] );
        $body    = ! empty( $cfg['recovery_body'] )
            ? $cfg['recovery_body']
            : "Hi {first_name},\n\nLooks like you started filling out our \"{form_title}\" form but didn't finish.\n\nNo pressure — if it'd help, click below to pick up where you left off.\n\n{form_url}\n\nThanks!";

        $first   = trim( explode( ' ', (string) $row['submitter_name'], 2 )[0] ?? '' );
        if ( ! $first ) $first = 'there';
        $form_url = '';
        if ( ! empty( $form['slug'] ) ) {
            $form_url = home_url( '/formcraft-pro/' . rawurlencode( $form['slug'] ) . '/' );
        }
        $vars = [
            '{first_name}' => $first,
            '{name}'       => $row['submitter_name'] ?: 'there',
            '{form_title}' => $form['title'],
            '{form_url}'   => $form_url,
            '{site_name}'  => get_bloginfo( 'name' ),
        ];
        $subject = strtr( $subject, $vars );
        $body    = strtr( $body, $vars );

        $headers = [ 'Content-Type: text/html; charset=UTF-8' ];
        $html    = '<div style="font-family:system-ui,sans-serif;line-height:1.55;color:#0f172a;max-width:560px;margin:0 auto;">'
                 . nl2br( esc_html( $body ) )
                 . '</div>';
        $ok = wp_mail( $row['submitter_email'], $subject, $html, $headers );

        if ( $ok ) {
            $wpdb->update( FCP_DB::subs_table(), [
                'recovery_sent_at' => current_time( 'mysql' ),
            ], [ 'id' => (int) $abandoned_id ] );
        }
        return $ok ? true : new WP_Error( 'fcp_abandon_mail_failed', 'wp_mail returned false. Check SMTP settings.' );
    }

    /**
     * Compute drop-off per step for a form over the last N days.
     * Returns [ { step, views, completed, dropoff_rate } ... ] in step order.
     */
    public function get_dropoff( $req ) {
        global $wpdb;
        $form_id = (int) $req['id'];
        $days    = max( 1, min( 365, (int) ( $req->get_param( 'days' ) ?: 30 ) ) );
        $t       = FCP_DB::step_events_table();
        $since   = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT step_index, event_type, COUNT(*) AS n
             FROM $t
             WHERE form_id = %d AND created_at >= %s
             GROUP BY step_index, event_type
             ORDER BY step_index ASC",
            $form_id, $since
        ), ARRAY_A );

        $by_step = [];
        foreach ( $rows as $r ) {
            $s = (int) $r['step_index'];
            if ( ! isset( $by_step[ $s ] ) ) $by_step[ $s ] = [ 'step' => $s, 'views' => 0, 'completed' => 0 ];
            if ( $r['event_type'] === 'view' )                                   $by_step[ $s ]['views']     = (int) $r['n'];
            if ( $r['event_type'] === 'complete' || $r['event_type'] === 'submit' ) $by_step[ $s ]['completed'] += (int) $r['n'];
        }
        ksort( $by_step );
        $out = array_values( $by_step );
        foreach ( $out as &$s ) {
            $s['dropoff_rate'] = $s['views'] > 0 ? round( ( ( $s['views'] - $s['completed'] ) / $s['views'] ) * 100, 1 ) : 0;
        }
        return rest_ensure_response( [
            'form_id' => $form_id,
            'days'    => $days,
            'steps'   => $out,
        ] );
    }

    /* ------------------ Submit ------------------ */
    /**
     * Import a form from JSON. Accepts the same shape that GET /forms/{id}
     * returns — title, description, status, steps[], settings, etc. We strip
     * any ids that came from the source site so the importer creates a brand
     * new row (no slug collision, no orphan field ids).
     */
    public function import_form( $req ) {
        $body = $req->get_json_params();
        $form = isset( $body['form'] ) && is_array( $body['form'] ) ? $body['form'] : null;
        if ( ! $form && is_array( $body ) && isset( $body['title'] ) && isset( $body['steps'] ) ) {
            // Allow posting the raw form object too (when admin pastes file contents).
            $form = $body;
        }
        if ( ! is_array( $form ) || empty( $form['steps'] ) ) {
            return new WP_Error( 'bad_form', 'Invalid form JSON — must include title + steps[].', [ 'status' => 400 ] );
        }
        // Strip server-owned identity fields so a fresh row is created.
        unset( $form['id'], $form['slug'], $form['wpId'], $form['views'], $form['submissions'], $form['created_at'], $form['updated_at'] );
        $form['title']  = sanitize_text_field( $form['title'] ?? 'Imported Form' ) . ( ! empty( $body['suffix'] ) ? ' ' . sanitize_text_field( $body['suffix'] ) : ' (imported)' );
        $form['status'] = 'draft';
        $id = FCP_DB::insert_form( $form );
        if ( ! $id ) return new WP_Error( 'db', 'Could not import the form.', [ 'status' => 500 ] );
        // Snapshot the imported form as revision 1.
        FCP_DB::insert_revision( $id, $form, 'Imported from JSON' );
        return rest_ensure_response( FCP_DB::get_form( $id ) );
    }

    /**
     * Lightweight endpoint that ONLY updates the form's status column. Used
     * by the inline status dropdown on the Forms list — much cheaper than
     * round-tripping the entire form definition through the regular PUT
     * (which would also overwrite the `data` JSON column).
     */
    public function set_form_status( $req ) {
        global $wpdb;
        $id     = (int) $req['id'];
        $body   = $req->get_json_params();
        $status = isset( $body['status'] ) ? sanitize_text_field( $body['status'] ) : '';
        $allowed = [ 'active', 'draft', 'paused', 'archived' ];
        if ( ! in_array( $status, $allowed, true ) ) {
            return new WP_Error( 'bad_status', 'Invalid status. Allowed: ' . implode( ', ', $allowed ), [ 'status' => 400 ] );
        }
        $ok = $wpdb->update(
            FCP_DB::forms_table(),
            [ 'status' => $status, 'updated_at' => current_time( 'mysql' ) ],
            [ 'id' => $id ]
        );
        if ( $ok === false ) {
            return new WP_Error( 'db', 'Could not update status.', [ 'status' => 500 ] );
        }
        return rest_ensure_response( [ 'success' => true, 'id' => $id, 'status' => $status ] );
    }

    /* ---------- Revisions ---------- */
    public function list_revisions( $req ) {
        $rows = FCP_DB::get_revisions( (int) $req['id'] );
        return rest_ensure_response( $rows );
    }
    public function restore_revision( $req ) {
        $form_id = (int) $req['id'];
        $rid     = (int) $req['rid'];
        $rev     = FCP_DB::get_revision( $rid );
        if ( ! $rev || (int) $rev['form_id'] !== $form_id ) {
            return new WP_Error( 'not_found', 'Revision not found.', [ 'status' => 404 ] );
        }
        $snapshot = json_decode( $rev['snapshot'], true );
        if ( ! is_array( $snapshot ) ) return new WP_Error( 'bad_snapshot', 'Snapshot is corrupt.', [ 'status' => 500 ] );
        // Preserve the current form's slug + title flags by merging.
        $current = FCP_DB::get_form( $form_id );
        $snapshot['title']  = $snapshot['title']  ?? $current['title'];
        $snapshot['status'] = $current['status']; // keep live status
        FCP_DB::update_form( $form_id, $snapshot );
        FCP_DB::insert_revision( $form_id, $snapshot, 'Restored from revision #' . $rid );
        return rest_ensure_response( FCP_DB::get_form( $form_id ) );
    }

    /**
     * Pick which confirmation (success message + redirect URL) to use for
     * the visitor based on conditional rules. Rules are evaluated in order;
     * first match wins. Falls back to the form's default message + redirect.
     */
    private function resolve_confirmation( $form, $data ) {
        $default = [
            'message'  => $form['settings']['successMessage'] ?? 'Thanks! We received your submission.',
            'redirect' => $form['settings']['redirect']       ?? '',
        ];
        $rules = $form['settings']['confirmations'] ?? [];
        if ( ! is_array( $rules ) || empty( $rules ) ) return $default;
        foreach ( $rules as $r ) {
            if ( ! self::evaluate_confirmation_rule( $r, $data ) ) continue;
            return [
                'message'  => ! empty( $r['message'] )  ? $r['message']  : $default['message'],
                'redirect' => ! empty( $r['redirect'] ) ? $r['redirect'] : $default['redirect'],
            ];
        }
        return $default;
    }

    /**
     * Evaluate a single confirmation rule against the submission data.
     * Rule shape: { match: "all"|"any", conditions: [{ field, op, value }] }
     * Supported ops: equals / not_equals / contains / greater_than / less_than / is_empty / is_not_empty.
     */
    private static function evaluate_confirmation_rule( $rule, $data ) {
        $conditions = is_array( $rule['conditions'] ?? null ) ? $rule['conditions'] : [];
        if ( empty( $conditions ) ) return false;
        $match = ( $rule['match'] ?? 'all' ) === 'any' ? 'any' : 'all';
        $hits  = 0;
        foreach ( $conditions as $c ) {
            $field = $c['field'] ?? '';
            $op    = $c['op']    ?? 'equals';
            $val   = (string) ( $c['value'] ?? '' );
            $actual = isset( $data[ $field ] ) ? $data[ $field ] : '';
            if ( is_array( $actual ) ) $actual = implode( ',', $actual );
            $actual = (string) $actual;
            $ok = false;
            switch ( $op ) {
                case 'equals':       $ok = strcasecmp( $actual, $val ) === 0; break;
                case 'not_equals':   $ok = strcasecmp( $actual, $val ) !== 0; break;
                case 'contains':     $ok = $val !== '' && stripos( $actual, $val ) !== false; break;
                case 'greater_than': $ok = is_numeric( $actual ) && is_numeric( $val ) && (float) $actual >  (float) $val; break;
                case 'less_than':    $ok = is_numeric( $actual ) && is_numeric( $val ) && (float) $actual <  (float) $val; break;
                case 'is_empty':     $ok = $actual === '';     break;
                case 'is_not_empty': $ok = $actual !== '';     break;
            }
            if ( $ok ) $hits++;
            if ( $match === 'any' && $ok ) return true;
            if ( $match === 'all' && ! $ok ) return false;
        }
        return $match === 'all' ? ( $hits === count( $conditions ) ) : ( $hits > 0 );
    }

    /**
     * Handle Form User actions (register / login / forgot / reset). These
     * forms don't save a submission row — they manipulate the
     * wp_fcp_users table directly. Mode is set by the admin in After
     * Submit → Form Users.
     */
    private function handle_form_user_action( $form, $cfg, $body ) {
        $data = ( isset( $body['data'] ) && is_array( $body['data'] ) ) ? $body['data'] : [];
        $mode = $cfg['mode'] ?? 'none';
        $args = FCP_Users::args_from_form_data( $cfg, $data );
        $ip   = FCP_DB::get_ip();
        $form_title = $form['title'] ?? '';

        // Resolve the redirect target: explicit form setting wins, then the
        // auto-created User Dashboard page, then site home as a last resort.
        $explicit_redirect = trim( (string) ( $cfg['redirectUrl'] ?? '' ) );
        if ( $explicit_redirect === '' ) {
            $dash_id = class_exists( 'FCP_Shortcode' ) ? FCP_Shortcode::ensure_user_dashboard_page() : 0;
            $explicit_redirect = $dash_id ? get_permalink( $dash_id ) : home_url( '/' );
        }
        $explicit_redirect = esc_url_raw( $explicit_redirect );

        switch ( $mode ) {
            case 'register':
                $args['form_id'] = (int) ( $form['id'] ?? 0 );
                $uid = FCP_Users::create( $args );
                if ( is_wp_error( $uid ) ) {
                    return new WP_Error( $uid->get_error_code(), $uid->get_error_message(), [ 'status' => 400 ] );
                }
                // Auto-login the newly registered user.
                $user = FCP_Users::find_by_id( $uid );
                if ( $user ) FCP_Users::start_session( $user );
                return rest_ensure_response( [
                    'success'  => true,
                    'login'    => true,
                    'message'  => 'Account created. You\'re signed in.',
                    'redirect' => $explicit_redirect,
                ] );

            case 'login':
                $user = FCP_Users::authenticate( $args['email'], $args['password'], $ip );
                if ( is_wp_error( $user ) ) {
                    return new WP_Error( $user->get_error_code(), $user->get_error_message(), [ 'status' => 401 ] );
                }
                FCP_Users::start_session( $user );
                return rest_ensure_response( [
                    'success'  => true,
                    'login'    => true,
                    'message'  => sprintf( 'Welcome back, %s', $user['display_name'] ?: $user['email'] ),
                    'redirect' => $explicit_redirect,
                ] );

            case 'forgot':
                if ( ! is_email( $args['email'] ) ) {
                    return new WP_Error( 'fcp_users_bad_email', 'Please enter a valid email address.', [ 'status' => 400 ] );
                }
                $r = FCP_Users::request_password_reset( $args['email'], $form_title );
                return rest_ensure_response( [
                    'success' => true,
                    'message' => $r['message'],
                ] );

            case 'reset':
                $code = isset( $data['Reset Code'] ) ? $data['Reset Code']
                      : ( isset( $data['Code'] ) ? $data['Code']
                      : ( isset( $data['OTP'] ) ? $data['OTP'] : '' ) );
                if ( ! $code ) {
                    return new WP_Error( 'fcp_users_no_code', 'Add a text field labelled "Reset Code", "Code" or "OTP" so visitors can type the code they received.', [ 'status' => 400 ] );
                }
                $r = FCP_Users::reset_password( $args['email'], $code, $args['password'] );
                if ( is_wp_error( $r ) ) {
                    return new WP_Error( $r->get_error_code(), $r->get_error_message(), [ 'status' => 400 ] );
                }
                return rest_ensure_response( [
                    'success'  => true,
                    'message'  => 'Password updated — please sign in with your new password.',
                    'redirect' => esc_url_raw( $cfg['redirectUrl'] ?? '' ) ?: '',
                ] );
        }
        return new WP_Error( 'fcp_users_bad_mode', 'Unknown form-user mode: ' . esc_html( $mode ), [ 'status' => 400 ] );
    }

    /**
     * Handle a form submitted as a Login form. Pulls credentials out of the
     * form's `data` payload using the admin-configured field labels, applies
     * an IP-keyed brute-force lockout, and then runs them through wp_signon.
     *
     * On success the visitor is signed in (auth cookie set) and we hand back
     * a redirect URL the front-end follows. On failure we leak as little as
     * possible — same message for "no such user" vs "wrong password".
     */
    private function handle_form_login( $form, $cfg, $body ) {
        $data = ( isset( $body['data'] ) && is_array( $body['data'] ) ) ? $body['data'] : [];

        $email_field    = $cfg['emailField']    ?? '';
        $pass_field     = $cfg['passwordField'] ?? '';
        $remember_field = $cfg['rememberField'] ?? '';
        $login          = $email_field ? trim( (string) ( $data[ $email_field ] ?? '' ) ) : '';
        $password       = $pass_field  ?            (string) ( $data[ $pass_field ]  ?? '' )  : '';
        $remember       = false;
        if ( $remember_field && isset( $data[ $remember_field ] ) ) {
            $rv = $data[ $remember_field ];
            if ( is_array( $rv ) ) $rv = $rv[0] ?? '';
            $remember = in_array( strtolower( (string) $rv ), [ '1', 'yes', 'on', 'true' ], true );
        }
        $fail_msg = $cfg['failMessage'] ?: 'Incorrect email or password. Try again.';

        if ( $login === '' || $password === '' ) {
            return new WP_Error( 'fcp_login_missing', 'Please enter both your email/username and your password.', [ 'status' => 400 ] );
        }

        // ---- Brute-force lockout: 5 wrong tries / 15 min per IP+login pair ----
        $client_ip = FCP_DB::get_ip();
        $lock_key  = 'fcp_login_fails_' . md5( $client_ip . '|' . strtolower( $login ) );
        $fail_cnt  = (int) get_transient( $lock_key );
        if ( $fail_cnt >= 5 ) {
            return new WP_Error(
                'fcp_login_locked',
                'Too many failed login attempts. Try again in 15 minutes.',
                [ 'status' => 429 ]
            );
        }

        // wp_signon accepts either a username or an email — let it disambiguate.
        $user = wp_signon( [
            'user_login'    => $login,
            'user_password' => $password,
            'remember'      => $remember,
        ], is_ssl() );

        if ( is_wp_error( $user ) ) {
            // Bump the lockout counter — refresh the 15-min TTL each fail.
            set_transient( $lock_key, $fail_cnt + 1, 15 * MINUTE_IN_SECONDS );
            return new WP_Error(
                'fcp_login_failed',
                $fail_msg,
                [ 'status' => 401, 'remaining' => max( 0, 4 - $fail_cnt ) ]
            );
        }

        // Success — drop the lockout counter, set the current user, and tell
        // the front-end where to go next.
        delete_transient( $lock_key );
        wp_set_current_user( $user->ID );

        $redirect = $cfg['redirectUrl'] ?? '';
        if ( $redirect === '' ) {
            // Sensible default: send admins to wp-admin, everyone else home.
            $redirect = user_can( $user, 'edit_posts' ) ? admin_url() : home_url( '/' );
        }

        return rest_ensure_response( [
            'success'  => true,
            'login'    => true,
            'message'  => sprintf( 'Welcome back, %s', $user->display_name ?: $user->user_login ),
            'redirect' => esc_url_raw( $redirect ),
            'user'     => [
                'id'    => $user->ID,
                'login' => $user->user_login,
                'email' => $user->user_email,
            ],
        ] );
    }

    public function submit_form( $req ) {
        $form_id = (int) $req['id'];
        $form = FCP_DB::get_form( $form_id );
        if ( ! $form ) {
            return new WP_Error( 'not_found', 'Form not found', [ 'status' => 404 ] );
        }

        // Per-form CSRF token — bound to this form's id so a stale token
        // captured from form A cannot be replayed against form B. We accept
        // submissions WITHOUT the token (older cached pages, embed via
        // popup-button shortcode) but log them as a soft signal — full
        // rejection would break legacy embeds.
        $body_for_nonce = $req->get_json_params();
        $form_nonce     = isset( $body_for_nonce['_fcp_form_nonce'] ) ? (string) $body_for_nonce['_fcp_form_nonce'] : '';
        if ( $form_nonce && ! wp_verify_nonce( $form_nonce, 'fcp_form_' . $form_id ) ) {
            return new WP_Error( 'csrf', 'Form session expired. Please refresh and resubmit.', [ 'status' => 403 ] );
        }

        // ---- Form Users short-circuit ----
        // Self-contained user store (wp_fcp_users) — when the admin set the
        // form's role to register/login/forgot/reset, we route here instead
        // of the normal submission pipeline.
        $fu_cfg = $form['settings']['afterSubmit']['formUser'] ?? [];
        if ( ! empty( $fu_cfg['mode'] ) && $fu_cfg['mode'] !== 'none' ) {
            return $this->handle_form_user_action( $form, $fu_cfg, $req->get_json_params() );
        }

        // ---- WordPress-user Login form short-circuit ----
        $login_cfg = $form['settings']['afterSubmit']['loginUser'] ?? [];
        if ( ! empty( $login_cfg['enabled'] ) ) {
            return $this->handle_form_login( $form, $login_cfg, $req->get_json_params() );
        }

        // ============================================================
        // Form Locker access control — 5 gates that run BEFORE the
        // existing schedule / limits checks. Order matters:
        //   1) Password    — quickest, no DB lookup needed
        //   2) Login       — also fast, just session check
        //   3) Geo         — header read, no DB
        //   4) One-per-user — DB query
        //   5) Unique field — DB query
        // ============================================================
        $locker = $form['settings']['locker'] ?? [];
        $body_for_locker = $req->get_json_params();

        // 1) Password gate — accept either an explicit form_password in the
        // submit body OR the unlock cookie set when the visitor passed the
        // password prompt on the public form page.
        $pw_cfg = $locker['password'] ?? [];
        if ( ! empty( $pw_cfg['enabled'] ) && ! empty( $pw_cfg['password'] ) ) {
            $cookie_key  = 'fcp_form_pw_' . $form_id;
            $expect_hash = wp_hash( (string) $pw_cfg['password'] );
            $cookie_ok   = isset( $_COOKIE[ $cookie_key ] ) && hash_equals( $expect_hash, (string) $_COOKIE[ $cookie_key ] );
            $given       = isset( $body_for_locker['form_password'] ) ? (string) $body_for_locker['form_password'] : '';
            $body_ok     = $given !== '' && hash_equals( (string) $pw_cfg['password'], $given );
            if ( ! $cookie_ok && ! $body_ok ) {
                return new WP_Error( 'fcp_locker_password', $pw_cfg['prompt'] ?: 'Invalid form password.', [ 'status' => 401 ] );
            }
        }

        // 2) Login required gate
        $login_lock = $locker['login'] ?? [];
        if ( ! empty( $login_lock['enabled'] ) ) {
            $type = $login_lock['type'] ?? 'wp';
            $is_wp_user      = is_user_logged_in();
            $is_form_user    = class_exists( 'FCP_Users' ) && FCP_Users::current_user();
            $ok = ( $type === 'wp' && $is_wp_user )
                  || ( $type === 'form_users' && $is_form_user )
                  || ( $type === 'any' && ( $is_wp_user || $is_form_user ) );
            // Optional role restriction for WP users
            if ( $ok && $type === 'wp' && ! empty( $login_lock['roles'] ) && is_array( $login_lock['roles'] ) ) {
                $user  = wp_get_current_user();
                $roles = (array) $user->roles;
                $ok    = (bool) array_intersect( $login_lock['roles'], $roles );
            }
            if ( ! $ok ) {
                return new WP_Error( 'fcp_locker_login', $login_lock['message'] ?: 'Please log in to submit this form.', [ 'status' => 401 ] );
            }
        }

        // 3) Geo gate
        $geo = $locker['geo'] ?? [];
        if ( ! empty( $geo['enabled'] ) && ! empty( $geo['countries'] ) && is_array( $geo['countries'] ) ) {
            $country = self::detect_country();
            $mode    = ( $geo['mode'] ?? 'allow' ) === 'block' ? 'block' : 'allow';
            $list    = array_map( 'strtoupper', $geo['countries'] );
            $in_list = $country && in_array( strtoupper( $country ), $list, true );
            $denied  = ( $mode === 'allow' ) ? ! $in_list : $in_list;
            if ( $denied ) {
                return new WP_Error( 'fcp_locker_geo', $geo['message'] ?: 'This form is not available in your region.', [ 'status' => 423 ] );
            }
        }

        // 4) One-submission-per-user gate
        $opu = $locker['one_per_user'] ?? [];
        if ( ! empty( $opu['enabled'] ) ) {
            global $wpdb;
            $strategy = $opu['strategy'] ?? 'ip';
            $table    = FCP_DB::subs_table();
            $where    = $wpdb->prepare( 'form_id = %d AND is_abandoned = 0', $form_id );
            $blocked  = false;

            if ( $strategy === 'ip' || $strategy === 'ip_email' ) {
                $ip_now = FCP_DB::get_ip();
                if ( $ip_now ) {
                    $hit = (int) $wpdb->get_var( "SELECT id FROM $table WHERE $where AND ip_address = " . $wpdb->prepare( '%s', $ip_now ) . " LIMIT 1" );
                    if ( $hit ) $blocked = true;
                }
            }
            if ( ! $blocked && ( $strategy === 'user' ) ) {
                if ( is_user_logged_in() ) {
                    $email_now = wp_get_current_user()->user_email;
                    if ( $email_now ) {
                        $hit = (int) $wpdb->get_var( "SELECT id FROM $table WHERE $where AND submitter_email = " . $wpdb->prepare( '%s', $email_now ) . " LIMIT 1" );
                        if ( $hit ) $blocked = true;
                    }
                } else {
                    // Not logged in but we required user-based dedup — only
                    // block submission if they're a Form User.
                    $cu = class_exists( 'FCP_Users' ) ? FCP_Users::current_user() : null;
                    if ( $cu && ! empty( $cu['email'] ) ) {
                        $hit = (int) $wpdb->get_var( "SELECT id FROM $table WHERE $where AND submitter_email = " . $wpdb->prepare( '%s', $cu['email'] ) . " LIMIT 1" );
                        if ( $hit ) $blocked = true;
                    }
                }
            }
            if ( ! $blocked && ( $strategy === 'email' || $strategy === 'ip_email' ) ) {
                $body_data = isset( $body_for_locker['data'] ) && is_array( $body_for_locker['data'] ) ? $body_for_locker['data'] : [];
                $email_in  = '';
                foreach ( $body_data as $k => $v ) {
                    if ( is_string( $v ) && is_email( $v ) ) { $email_in = $v; break; }
                }
                if ( $email_in ) {
                    $hit = (int) $wpdb->get_var( "SELECT id FROM $table WHERE $where AND submitter_email = " . $wpdb->prepare( '%s', $email_in ) . " LIMIT 1" );
                    if ( $hit ) $blocked = true;
                }
            }
            if ( $blocked ) {
                return new WP_Error( 'fcp_locker_dup', $opu['message'] ?: "You've already submitted this form.", [ 'status' => 409 ] );
            }
        }

        // 5) Per-field unique-value gate (each visitor's value for a flagged
        //    field must not already exist in another submission)
        if ( ! empty( $body_for_locker['data'] ) && is_array( $body_for_locker['data'] ) ) {
            global $wpdb;
            $table     = FCP_DB::subs_table();
            $body_data = $body_for_locker['data'];
            foreach ( ( $form['steps'] ?? [] ) as $step ) {
                foreach ( ( $step['fields'] ?? [] ) as $field ) {
                    if ( empty( $field['unique'] ) ) continue;
                    $label = $field['label'] ?? '';
                    if ( ! $label ) continue;
                    $value = isset( $body_data[ $label ] ) ? trim( (string) $body_data[ $label ] ) : '';
                    if ( $value === '' ) continue;
                    // LIKE-search the JSON column for "label": "value"
                    $needle = '%' . $wpdb->esc_like( wp_json_encode( $value ) ) . '%';
                    $key    = '%' . $wpdb->esc_like( '"' . $label . '":' ) . '%';
                    $hit = (int) $wpdb->get_var( $wpdb->prepare(
                        "SELECT id FROM $table WHERE form_id = %d AND is_abandoned = 0 AND data LIKE %s AND data LIKE %s LIMIT 1",
                        $form_id, $key, $needle
                    ) );
                    if ( $hit ) {
                        $msg = $field['uniqueMessage'] ?? sprintf( '"%s" has already been used. Please enter a different value.', $label );
                        return new WP_Error( 'fcp_locker_unique', $msg, [ 'status' => 409 ] );
                    }
                }
            }
        }

        // ---- Scheduling window check ----
        $schedule = $form['settings']['schedule'] ?? [];
        if ( ! empty( $schedule['enabled'] ) ) {
            $now = current_time( 'timestamp' );
            if ( ! empty( $schedule['openAt'] ) ) {
                $open_ts = strtotime( $schedule['openAt'] );
                if ( $open_ts && $now < $open_ts ) {
                    return new WP_Error( 'not_open', $schedule['closedMessage'] ?? 'This form is not open yet.', [ 'status' => 423 ] );
                }
            }
            if ( ! empty( $schedule['closeAt'] ) ) {
                $close_ts = strtotime( $schedule['closeAt'] );
                if ( $close_ts && $now > $close_ts ) {
                    return new WP_Error( 'closed', $schedule['closedMessage'] ?? 'This form is no longer accepting submissions.', [ 'status' => 423 ] );
                }
            }
        }
        // ---- Submission cap check ----
        $caps = $form['settings']['limits'] ?? [];
        if ( ! empty( $caps['enabled'] ) && ! empty( $caps['maxTotal'] ) ) {
            $current = (int) ( $form['submissions'] ?? 0 );
            if ( $current >= (int) $caps['maxTotal'] ) {
                return new WP_Error( 'limit_reached', $caps['limitMessage'] ?? 'This form has reached its submission limit.', [ 'status' => 423 ] );
            }
        }

        $body = $req->get_json_params();
        $data = isset( $body['data'] ) && is_array( $body['data'] ) ? $body['data'] : [];

        // Extract the bot-detection signals injected by the form engine
        // and remove them from the visitor-facing data before we save.
        $signals = ( isset( $data['_fcp_signals'] ) && is_array( $data['_fcp_signals'] ) )
            ? $data['_fcp_signals']
            : [];
        unset( $data['_fcp_signals'] );

        // v2.51 — capture UTM attribution + referrer. Both get parked in
        // the submission's _meta block so analytics can break submissions
        // down by acquisition source without polluting the visible data.
        $utm = ( isset( $data['_fcp_utm'] ) && is_array( $data['_fcp_utm'] ) )
            ? array_filter( array_map( 'sanitize_text_field', $data['_fcp_utm'] ) )
            : [];
        $referrer = isset( $data['_fcp_referrer'] ) ? esc_url_raw( $data['_fcp_referrer'] ) : '';
        // v2.54 — fill-duration (seconds) + A/B variant ("A" or "B"). Both
        // are stored on the submission's _meta block so the Analytics
        // page can render the time distribution + A/B winner.
        $fill_duration = isset( $data['_fcp_duration'] ) ? max( 0, min( 86400, (int) $data['_fcp_duration'] ) ) : 0;
        $ab_variant    = '';
        if ( isset( $data['_fcp_ab_variant'] ) ) {
            $v = strtoupper( (string) $data['_fcp_ab_variant'] );
            if ( $v === 'A' || $v === 'B' ) $ab_variant = $v;
        }
        unset( $data['_fcp_utm'], $data['_fcp_referrer'], $data['_fcp_duration'], $data['_fcp_ab_variant'] );

        // v2.72.15 — Security enforcement: IP blocklist + per-hour rate limit.
        // Both driven by the admin's Settings → Security values (previously
        // the limit was hardcoded to 10/minute and the blocklist did nothing).
        $ip = FCP_DB::get_ip();
        if ( $ip ) {
            $settings_all = get_option( 'fcp_settings', [] );
            $sec          = isset( $settings_all['security'] ) && is_array( $settings_all['security'] ) ? $settings_all['security'] : [];

            // Blocklist — accepts newlines, commas, or spaces as separators.
            $blocklist_raw = isset( $sec['ip_blocklist'] ) ? (string) $sec['ip_blocklist'] : '';
            if ( $blocklist_raw !== '' ) {
                $blocked = array_filter( array_map( 'trim', preg_split( '/[\s,]+/', $blocklist_raw ) ) );
                if ( in_array( $ip, $blocked, true ) ) {
                    return new WP_Error( 'ip_blocked', 'Your IP address is not allowed to submit this form.', [ 'status' => 403 ] );
                }
            }

            // Per-hour rate limit. Default 30 if unset; 0 disables the check.
            $limit = isset( $sec['rate_limit'] ) ? (int) $sec['rate_limit'] : 30;
            if ( $limit > 0 ) {
                $key   = 'fcp_rl_' . md5( $ip );
                $count = (int) get_transient( $key );
                if ( $count >= $limit ) {
                    return new WP_Error(
                        'rate_limited',
                        sprintf( 'Rate limit reached (%d submissions per hour from this IP). Try again later.', $limit ),
                        [ 'status' => 429 ]
                    );
                }
                set_transient( $key, $count + 1, HOUR_IN_SECONDS );
            }
        }

        // ---- reCAPTCHA server-side verification ----
        // Only enforced when the global reCAPTCHA is enabled + a secret is
        // configured AND the form contains a captcha field. If the client
        // sent a token, we ALWAYS verify it (defence-in-depth).
        $rc_token = isset( $body['recaptcha_token'] ) ? (string) $body['recaptcha_token'] : '';
        $settings = get_option( 'fcp_settings', [] );
        $rc_cfg   = isset( $settings['recaptcha'] ) ? $settings['recaptcha'] : [];
        $form_uses_captcha = false;
        foreach ( $form['steps'] as $step ) {
            foreach ( ( $step['fields'] ?? [] ) as $fld ) {
                if ( ( $fld['type'] ?? '' ) === 'captcha' ) { $form_uses_captcha = true; break 2; }
            }
        }
        if ( $form_uses_captcha && ! empty( $rc_cfg['enabled'] ) ) {
            $provider = $rc_cfg['provider'] ?? 'recaptcha';

            // v2.72.28 — Math captcha: self-hosted, no third-party call.
            // Client sends fcp_math_a / fcp_math_b / fcp_math_op / fcp_math_answer.
            // We recompute the expected result and compare. Operator is
            // whitelisted to prevent injection into eval-adjacent code.
            if ( $provider === 'math' ) {
                $ma  = isset( $body['fcp_math_a'] ) ? (int) $body['fcp_math_a'] : null;
                $mb  = isset( $body['fcp_math_b'] ) ? (int) $body['fcp_math_b'] : null;
                $mop = isset( $body['fcp_math_op'] ) ? (string) $body['fcp_math_op'] : '';
                $man = isset( $body['fcp_math_answer'] ) ? trim( (string) $body['fcp_math_answer'] ) : '';
                if ( $ma === null || $mb === null || $man === '' ) {
                    return new WP_Error( 'math_missing', 'Please solve the math question.', [ 'status' => 400 ] );
                }
                $expected = null;
                if ( $mop === '+' ) $expected = $ma + $mb;
                elseif ( $mop === '-' ) $expected = $ma - $mb;
                elseif ( $mop === '*' ) $expected = $ma * $mb;
                if ( $expected === null || ! is_numeric( $man ) || (int) $man !== $expected ) {
                    $err = ! empty( $rc_cfg['math']['errorMessage'] )
                        ? (string) $rc_cfg['math']['errorMessage']
                        : "That answer wasn't right. Please try again.";
                    return new WP_Error( 'math_failed', $err, [ 'status' => 403 ] );
                }
                // Math captcha passed — skip the token-based provider path.
                goto after_captcha_check;
            }

            // Pull the secret + verify URL for the configured provider. Each
            // major provider uses the same { secret, response, remoteip }
            // payload shape so we keep one verification path.
            if ( $provider === 'hcaptcha' ) {
                $secret = $rc_cfg['hcaptcha']['secret_key'] ?? '';
                $url    = 'https://api.hcaptcha.com/siteverify';
            } elseif ( $provider === 'turnstile' ) {
                $secret = $rc_cfg['turnstile']['secret_key'] ?? '';
                $url    = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';
            } else {
                $secret = $rc_cfg['secret_key'] ?? '';
                $url    = 'https://www.google.com/recaptcha/api/siteverify';
            }
            if ( ! $secret ) {
                // Provider configured but secret missing — fail open with a
                // clearer error for the admin (won't leak details to bots).
                return new WP_Error( 'captcha_unconfigured', 'CAPTCHA provider has no secret key set.', [ 'status' => 500 ] );
            }
            if ( $rc_token === '' ) {
                return new WP_Error( 'recaptcha_missing', 'CAPTCHA verification required.', [ 'status' => 400 ] );
            }
            $verify = wp_remote_post( $url, [
                'timeout' => 10,
                'body'    => [
                    'secret'   => $secret,
                    'response' => $rc_token,
                    'remoteip' => $ip,
                ],
            ] );
            if ( is_wp_error( $verify ) ) {
                return new WP_Error( 'recaptcha_http', 'Could not reach CAPTCHA provider: ' . $verify->get_error_message(), [ 'status' => 502 ] );
            }
            $r  = json_decode( wp_remote_retrieve_body( $verify ), true );
            $ok = isset( $r['success'] ) && $r['success'];
            // reCAPTCHA v3 also returns a score 0.0-1.0 — fail closed under
            // the configured threshold. hCaptcha + Turnstile don't.
            if ( $ok && $provider === 'recaptcha' && ( $rc_cfg['version'] ?? 'v3' ) === 'v3' && isset( $r['score'] ) ) {
                $threshold = isset( $rc_cfg['score_threshold'] ) ? (float) $rc_cfg['score_threshold'] : 0.5;
                if ( (float) $r['score'] < $threshold ) {
                    $ok = false;
                }
            }
            if ( ! $ok ) {
                return new WP_Error( 'recaptcha_failed', 'CAPTCHA verification failed.', [ 'status' => 403, 'detail' => $r ] );
            }
        }
        after_captcha_check:

        // ---- OTP verification (server-side, mandatory) ----
        // If the form has an OTP field, the front-end must send
        // body.otp = { target, channel, code }. We verify it here so a
        // client that bypasses the JS verify step can't submit unverified.
        $form_uses_otp = false;
        foreach ( $form['steps'] as $step ) {
            foreach ( ( $step['fields'] ?? [] ) as $fld ) {
                if ( ( $fld['type'] ?? '' ) === 'otp' ) { $form_uses_otp = true; break 2; }
            }
        }
        if ( $form_uses_otp ) {
            $otp = isset( $body['otp'] ) && is_array( $body['otp'] ) ? $body['otp'] : [];
            $otp_target  = isset( $otp['target'] )  ? sanitize_text_field( $otp['target'] )  : '';
            $otp_channel = isset( $otp['channel'] ) ? sanitize_key( $otp['channel'] )         : 'email';
            $otp_code    = isset( $otp['code'] )    ? preg_replace( '/\D/', '', (string) $otp['code'] ) : '';
            if ( ! $otp_target || ! $otp_code ) {
                return new WP_Error( 'otp_required', 'Please verify your code before submitting.', [ 'status' => 400 ] );
            }
            $verify = FCP_OTP::verify( $otp_target, $otp_channel, $otp_code, $form_id );
            if ( is_wp_error( $verify ) ) return $verify;
        }

        // ---- Schedule field: enforce slot capacity server-side ----
        // We need to do this BEFORE we save the submission so we don't
        // accept overbooked rows. Race-condition window is tiny but
        // technically possible; for true serialization use a transient lock
        // (out of scope here — rejection-on-collision is the GF model too).
        global $wpdb;
        $sched_fields = [];
        foreach ( $form['steps'] as $step ) {
            foreach ( ( $step['fields'] ?? [] ) as $fld ) {
                if ( ( $fld['type'] ?? '' ) === 'schedule' ) $sched_fields[] = $fld;
            }
        }
        foreach ( $sched_fields as $sf ) {
            $label = $sf['label'] ?? '';
            if ( ! $label || empty( $data[ $label ] ) ) continue;
            $val = (string) $data[ $label ];
            if ( ! preg_match( '/^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})$/', $val, $m ) ) {
                return new WP_Error( 'bad_slot', 'The selected booking slot is not in the expected format.', [ 'status' => 400 ] );
            }
            $picked_date = $m[1];
            $picked_slot = $m[2];

            // Weekday check
            $dow = (int) gmdate( 'w', strtotime( $picked_date ) );
            $days_allowed = is_array( $sf['days'] ?? null ) ? array_map( 'intval', $sf['days'] ) : [ 1,2,3,4,5 ];
            if ( ! in_array( $dow, $days_allowed, true ) ) {
                return new WP_Error( 'slot_closed', 'Bookings are not accepted on this weekday.', [ 'status' => 400 ] );
            }
            // Skip-dates check
            $skip = is_array( $sf['skipDates'] ?? null ) ? $sf['skipDates'] : [];
            if ( in_array( $picked_date, $skip, true ) ) {
                return new WP_Error( 'slot_blocked', 'This date is blocked out.', [ 'status' => 400 ] );
            }
            // Lead-time check
            $picked_ts = strtotime( $picked_date . ' ' . $picked_slot );
            $lead_secs = max( 0, ( (int) ( $sf['leadHours'] ?? 24 ) ) * 3600 );
            if ( $picked_ts && ( $picked_ts - current_time( 'timestamp' ) ) < $lead_secs ) {
                return new WP_Error( 'too_soon', 'This slot is too close to now — pick a later time.', [ 'status' => 400 ] );
            }
            // Capacity check
            $cap = max( 1, (int) ( $sf['capacity'] ?? 1 ) );
            $needle = '%' . $wpdb->esc_like( $picked_date . 'T' . $picked_slot ) . '%';
            $count  = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM " . FCP_DB::subs_table() . " WHERE form_id = %d AND is_spam = 0 AND data LIKE %s",
                $form_id, $needle
            ) );
            if ( $count >= $cap ) {
                return new WP_Error( 'slot_full', 'Sorry, that slot just filled up — please pick another time.', [ 'status' => 409 ] );
            }
        }

        // Sanitize visible fields. Internal _fcp_* keys are stripped here
        // too in case any survived (e.g. older client without signals key).
        // Repeater field values arrive as a list of row-objects — each row
        // becomes a label-keyed assoc array of strings.
        $clean = [];
        foreach ( $data as $k => $v ) {
            $k = sanitize_text_field( (string) $k );
            if ( strpos( $k, '_fcp_' ) === 0 || strpos( $k, 'fcp_hp_' ) === 0 ) continue;
            if ( is_array( $v ) ) {
                // Detect repeater: array whose values are themselves assoc
                // arrays of scalars. Otherwise treat as a simple list of
                // strings (multi-select / checkboxes).
                $is_repeater = false;
                foreach ( $v as $row ) {
                    if ( is_array( $row ) ) { $is_repeater = true; break; }
                }
                if ( $is_repeater ) {
                    $rows = [];
                    foreach ( $v as $row ) {
                        if ( ! is_array( $row ) ) continue;
                        $clean_row = [];
                        foreach ( $row as $rk => $rv ) {
                            $rk = sanitize_text_field( (string) $rk );
                            $clean_row[ $rk ] = is_array( $rv )
                                ? array_map( 'sanitize_text_field', $rv )
                                : sanitize_textarea_field( (string) $rv );
                        }
                        if ( ! empty( $clean_row ) ) $rows[] = $clean_row;
                    }
                    $clean[ $k ] = $rows;
                } else {
                    $clean[ $k ] = array_map( 'sanitize_text_field', $v );
                }
            } else {
                $clean[ $k ] = sanitize_textarea_field( (string) $v );
            }
        }

        // ---- Spam classification ----
        list( $is_spam, $spam_reasons ) = $this->evaluate_spam( $signals, $body, $clean );

        $extra = [
            'ip'      => $ip,
            'device'  => wp_is_mobile() ? 'Mobile' : 'Desktop',
            'browser' => $this->detect_browser(),
            'country' => self::detect_country(),
            'spam'    => $is_spam,
        ];

        // Form Abandonment: if the visitor was auto-saving partial data and
        // their session_id matches an existing abandoned row, promote that
        // row to a real submission instead of creating a duplicate. The
        // form-engine sends session_id with every submit.
        $sid = 0;
        $session_id = isset( $body['session_id'] ) ? sanitize_text_field( (string) $body['session_id'] ) : '';
        // v2.61 — Encrypt any field flagged `access: "encrypted"` BEFORE
        // the row hits the DB. Re-uses $clean array — downstream
        // notification/integration code sees plaintext (so emails still
        // include the value), only the persisted row is encrypted.
        if ( class_exists( 'FCP_Crypto' ) ) {
            $clean = FCP_Crypto::encrypt_submission( $form, $clean );
        }
        if ( $session_id ) {
            $sid = FCP_DB::finalize_abandoned( $form_id, $session_id, $clean, $extra );
        }
        if ( ! $sid ) {
            $sid = FCP_DB::insert_submission( $form_id, $clean, $extra );
        }

        // User Journey: persist the visitor's pre-submit path. Stored in
        // the journey column as compact JSON. Only saved when a journey
        // is supplied (visitor's browser supports localStorage + JS).
        if ( $sid && ! empty( $body['journey'] ) && is_array( $body['journey'] ) ) {
            $journey = self::sanitize_journey( $body['journey'] );
            if ( $journey ) {
                FCP_DB::update_submission( $sid, [ 'journey' => wp_json_encode( $journey ) ] );
            }
        }

        // v2.51 — Attribution attribution: stash UTM + referrer in the
        // submission's data JSON under _meta. Analytics aggregates these
        // for the "where do my submissions come from?" breakdown.
        if ( $sid && ( $utm || $referrer || $fill_duration || $ab_variant ) ) {
            $row = FCP_DB::get_submission( $sid );
            $existing = json_decode( $row['data'] ?? '{}', true );
            if ( is_array( $existing ) ) {
                $meta_add = [
                    'utm'      => $utm,
                    'referrer' => $referrer,
                ];
                if ( $fill_duration ) $meta_add['duration']   = $fill_duration;
                if ( $ab_variant )    $meta_add['ab_variant'] = $ab_variant;
                $existing['_meta'] = array_merge(
                    is_array( $existing['_meta'] ?? null ) ? $existing['_meta'] : [],
                    $meta_add
                );
                FCP_DB::update_submission( $sid, [ 'data' => wp_json_encode( $existing ) ] );
            }
        }

        // Form Abandonment cleanup: drop any other abandoned drafts the
        // same visitor left behind. Matched by email so it catches cases
        // where the visitor came back in a different browser/session.
        if ( $sid ) {
            $row = FCP_DB::get_submission( $sid );
            if ( $row && ! empty( $row['submitter_email'] ) ) {
                FCP_DB::purge_abandoned_for_email( $form_id, $row['submitter_email'], $sid );
            }
        }

        // v2.52 — Duplicate detection. Compare the new submission's
        // field values against the last 200 submissions for the same form.
        // We count fields whose values match; ≥3 matching → flagged as a
        // possible duplicate with a confidence score (0-100). Score is
        // surfaced in the admin UI; nothing is auto-rejected — duplicates
        // are sometimes legitimate (same visitor genuinely re-submitting).
        if ( $sid && ! $is_spam ) {
            self::run_duplicate_detection( (int) $form_id, (int) $sid, $clean );
        }

        // Mark as pending_review when the form requires approval. The
        // notification emails still go out — the submitter sees the success
        // page and admin sees the new pending row.
        if ( $sid && ! empty( $form['settings']['approval']['enabled'] ) && ! $is_spam ) {
            FCP_DB::update_submission( $sid, [ 'approval_status' => 'pending_review' ] );
        }

        // Track applied coupon for non-payment forms (the payment flow handles
        // its own coupon attribution via payment_create_order). We re-validate
        // the code here so the client can't fabricate a discount line.
        $coupon_code = isset( $body['coupon_code'] ) ? sanitize_text_field( $body['coupon_code'] ) : '';
        if ( $coupon_code !== '' && ! $is_spam ) {
            $eval = FCP_DB::evaluate_coupon( $coupon_code, isset( $body['amount'] ) ? (float) $body['amount'] : 0, $form_id );
            if ( $eval['ok'] ) {
                FCP_DB::update_submission( $sid, [
                    'coupon_code'            => $eval['coupon']['code'],
                    'coupon_discount'        => $eval['discount'],
                    'coupon_original_amount' => (float) ( $body['amount'] ?? 0 ),
                ] );
                FCP_DB::bump_coupon_use( $eval['coupon']['code'] );
            }
        }

        // ---- After-submit actions: create WP user / create post ----
        // Both are opt-in per form via form.settings.afterSubmit. Failures
        // are logged but don't abort the submission — the row is already
        // saved so the customer's data isn't lost.
        $after = isset( $form['settings']['afterSubmit'] ) && is_array( $form['settings']['afterSubmit'] )
            ? $form['settings']['afterSubmit'] : [];
        if ( ! $is_spam ) {
            try {
                $this->run_after_submit_actions( $form, $clean, $sid, $after );
            } catch ( \Throwable $e ) {
                error_log( '[FormYantra] run_after_submit_actions failed for submission #' . $sid . ': ' . $e->getMessage() );
            }
        }

        // ---- WooCommerce order creation ----
        // Forms with a wc-products field create a real WC order at submit
        // time. The order starts as "pending" — if a payment field on the
        // form succeeds later, payment_verify flips it to "processing".
        $wc_meta = [];
        if ( ! $is_spam
             && class_exists( 'FCP_WooCommerce' )
             && FCP_WooCommerce::is_active()
             && FCP_WooCommerce::form_has_wc_field( $form ) ) {
            try {
                $order_id = FCP_WooCommerce::create_order_from_submission( $form, $clean, $sid );
                if ( ! is_wp_error( $order_id ) && $order_id ) {
                    $wc_order = wc_get_order( $order_id );
                    $wc_meta = [
                        'wc_order_id'     => $order_id,
                        'wc_order_status' => $wc_order ? $wc_order->get_status() : 'pending',
                        'wc_order_total'  => $wc_order ? (float) $wc_order->get_total() : 0,
                    ];
                    FCP_DB::update_submission( $sid, $wc_meta );
                } elseif ( is_wp_error( $order_id ) ) {
                    error_log( '[FormYantra] WC order creation failed: ' . $order_id->get_error_message() );
                }
            } catch ( \Throwable $e ) {
                error_log( '[FormYantra] WC order creation threw for submission #' . $sid . ': ' . $e->getMessage() );
            }
        }

        // ---- Post-insert side effects ----
        // The submission row is already saved. Every phase below is a
        // best-effort side effect — emails, calendar links, webhooks,
        // CRM pushes. If any of them throw, we MUST NOT let the visitor
        // see a fatal error: their data is safely on disk. We catch +
        // log + carry on so the success response still reaches them.

        $mail_results = null;
        if ( ! $is_spam ) {
            try {
                $mail_results = $this->send_emails( $form, $clean, $sid );
            } catch ( \Throwable $e ) {
                error_log( '[FormYantra] send_emails failed for submission #' . $sid . ': ' . $e->getMessage() );
            }
        }

        // ---- Schedule field: meeting confirmation + reminder ----
        // Looks at every Schedule field on the form; for those with a
        // booked slot, generates the meeting link, sends a confirmation
        // to the visitor + admin (with .ics attached), and schedules a
        // wp_cron reminder N minutes before the slot.
        if ( ! $is_spam && ! empty( $sched_fields ) ) {
            foreach ( $sched_fields as $sf ) {
                $slot_val = $clean[ $sf['label'] ?? '' ] ?? '';
                if ( $slot_val ) {
                    try {
                        $this->schedule_meeting_notifications( $form, $clean, $sid, $sf, $slot_val );
                    } catch ( \Throwable $e ) {
                        error_log( '[FormYantra] schedule_meeting_notifications failed for submission #' . $sid . ': ' . $e->getMessage() );
                    }
                }
            }
        }

        // Webhooks fire for every submission so integrations can decide.
        try {
            do_action( 'fcp_submission_created', $sid, $form, $clean, $is_spam );
        } catch ( \Throwable $e ) {
            error_log( '[FormYantra] fcp_submission_created action failed for submission #' . $sid . ': ' . $e->getMessage() );
        }

        // Fire real integrations (webhooks / Zapier / Slack / Mailchimp / HubSpot).
        // Spam submissions go to the 'spam' event channel so admins can route
        // them differently (e.g. to a moderation queue) without polluting the
        // main submission webhooks.
        try {
            FCP_Integrations::fire(
                $is_spam ? 'spam' : 'submission',
                $form,
                $clean,
                $sid,
                [ 'spam_reasons' => $spam_reasons ]
            );
        } catch ( \Throwable $e ) {
            error_log( '[FormYantra] FCP_Integrations::fire failed for submission #' . $sid . ': ' . $e->getMessage() );
        }

        // ---- Resolve confirmation (conditional or default) ----
        try {
            $confirmation = $this->resolve_confirmation( $form, $clean );
        } catch ( \Throwable $e ) {
            error_log( '[FormYantra] resolve_confirmation failed for submission #' . $sid . ': ' . $e->getMessage() );
            $confirmation = [
                'message'  => 'Thank you — your submission was received.',
                'redirect' => '',
            ];
        }

        // Always return success to the visitor — never tip off a bot that
        // it was detected, or it will adapt and try again differently.
        $response = [
            'success' => true,
            'id'      => $sid,
            'message' => $confirmation['message'],
            'redirect'=> $is_spam ? '' : $confirmation['redirect'],
            'mail'    => $mail_results,
        ];
        if ( ! empty( $wc_meta['wc_order_id'] ) ) {
            $response['wc'] = [
                'order_id' => (int) $wc_meta['wc_order_id'],
                'status'   => $wc_meta['wc_order_status'],
                'total'    => $wc_meta['wc_order_total'],
            ];
        }
        return rest_ensure_response( $response );
    }

    /**
     * Heuristic spam classifier. Combines multiple signals so a single
     * borderline value doesn't trip a false positive. Returns
     * [ bool $is_spam, string[] $reasons ].
     */
    /**
     * Ping Akismet's "comment-check" endpoint with the submission's name,
     * email and the longest text value as the body. Returns 'spam', 'ham'
     * or 'error'. Akismet's API uses 'true'/'false' string responses.
     *
     * We deliberately do NOT pass through every form field — Akismet's
     * model is tuned for short-form text (comments, contact-form bodies),
     * so we pick the longest user-supplied string and treat it as the
     * comment body. Hits the right shape for ~all use cases.
     */
    private static function akismet_check( $data ) {
        if ( ! function_exists( 'akismet_get_key' ) ) return 'error';
        $key = akismet_get_key();
        if ( ! $key ) return 'error';

        $email = '';
        $name  = '';
        $longest = '';
        foreach ( $data as $k => $v ) {
            if ( ! is_string( $v ) || $v === '' ) continue;
            $lk = strtolower( (string) $k );
            if ( ! $email && is_email( trim( $v ) ) ) { $email = trim( $v ); continue; }
            if ( ! $name && strpos( $lk, 'name' ) !== false ) { $name = trim( $v ); continue; }
            if ( strlen( $v ) > strlen( $longest ) ) $longest = $v;
        }

        $params = [
            'blog'                 => home_url(),
            'user_ip'              => FCP_DB::get_ip(),
            'user_agent'           => substr( $_SERVER['HTTP_USER_AGENT'] ?? '', 0, 250 ),
            'referrer'             => $_SERVER['HTTP_REFERER'] ?? '',
            'permalink'            => home_url( add_query_arg( null, null ) ),
            'comment_type'         => 'contact-form',
            'comment_author'       => $name,
            'comment_author_email' => $email,
            'comment_content'      => $longest ?: '(no text content)',
        ];

        // Akismet expects key embedded in the host, per its protocol.
        $url  = 'https://' . rawurlencode( $key ) . '.rest.akismet.com/1.1/comment-check';
        $resp = wp_remote_post( $url, [
            'timeout'   => 3,           // hard cap so a slow Akismet doesn't stall the submit
            'sslverify' => true,
            'headers'   => [ 'Content-Type' => 'application/x-www-form-urlencoded' ],
            'body'      => http_build_query( $params ),
        ] );

        if ( is_wp_error( $resp ) ) return 'error';
        $code = (int) wp_remote_retrieve_response_code( $resp );
        if ( $code !== 200 ) return 'error';
        $body = trim( (string) wp_remote_retrieve_body( $resp ) );
        return $body === 'true' ? 'spam' : ( $body === 'false' ? 'ham' : 'error' );
    }

    private function evaluate_spam( $signals, $body, $clean ) {
        $reasons = [];

        // 1) Any of the four honeypot fields filled = certain bot.
        if ( ! empty( $signals['hp'] ) ) $reasons[] = 'honeypot';
        if ( ! empty( $body['hp_field'] ) ) $reasons[] = 'honeypot_legacy';

        // v2.72 — Behavioral bot detection. The form-engine tracks mouse
        // moves, key presses, focus events, and time-to-first-interaction
        // as hidden fields. A real human's numbers are non-zero and vary;
        // naive bots submit with all zeros. Combined with the existing
        // time-to-submit floor + honeypot, this catches the middle tier
        // of bots that spoof User-Agent but don't fake pointer/typing.
        $data     = isset( $body['data'] ) && is_array( $body['data'] ) ? $body['data'] : [];
        $bh_mouse = (int) ( $data['fcp_bh_mouse']    ?? 0 );
        $bh_keys  = (int) ( $data['fcp_bh_keys']     ?? 0 );
        $bh_focus = (int) ( $data['fcp_bh_focuses']  ?? 0 );
        $bh_first = (int) ( $data['fcp_bh_ms_first'] ?? 0 );
        $bh_last  = (int) ( $data['fcp_bh_ms_last']  ?? 0 );
        if ( $bh_mouse === 0 && $bh_keys === 0 && $bh_focus === 0 && $bh_first === 0 && $bh_last === 0 ) {
            // Nothing recorded at all — either an ancient browser without JS,
            // or a headless bot that skipped the form JS entirely. Flag as
            // suspect but don't hard-reject alone.
            $reasons[] = 'no_behavior';
        } else {
            // Signals are present — check for bot-like patterns.
            if ( $bh_mouse === 0 && $bh_focus <= 1 ) $reasons[] = 'no_pointer';
            if ( $bh_keys  === 0 && $bh_focus <= 1 ) $reasons[] = 'no_typing';
            // First interaction < 200ms is inhumanly fast — visitors take
            // at least a few hundred ms to move their eyes to the first field.
            if ( $bh_first > 0 && $bh_first < 200 ) $reasons[] = 'instant_interaction';
            // Last interaction = first interaction means the visitor's only
            // "touch" was submit click — no field editing happened.
            if ( $bh_last > 0 && $bh_first > 0 && $bh_last - $bh_first < 100 ) $reasons[] = 'zero_engagement';
        }

        // 1b) Akismet check — only fires if the admin has the Akismet
        // plugin installed AND an API key configured. Adds 50-200ms to
        // the submit but slashes false-negatives vs. our heuristic.
        if ( function_exists( 'akismet_get_key' ) && akismet_get_key() ) {
            $verdict = self::akismet_check( $clean );
            if ( $verdict === 'spam' ) $reasons[] = 'akismet';
        }

        // 1c) Smart spam learning (v2.52). Check the submission's
        // fingerprint against patterns the admin previously marked as
        // spam. Each match adds a reason; we don't auto-reject from
        // learned patterns alone — too risky for false positives — but
        // the row gets flagged with a higher confidence score so the
        // admin can review.
        $learned = get_option( 'fcp_spam_patterns', [] );
        if ( is_array( $learned ) && ! empty( $learned['spam'] ) ) {
            // Build a fake row shape just to reuse extract_spam_fingerprint().
            $fp = self::extract_spam_fingerprint( [
                'submitter_email' => $clean['email'] ?? ( $clean['Email'] ?? '' ),
                'ip_address'      => FCP_DB::get_ip(),
                'data'            => wp_json_encode( $clean ),
            ] );
            foreach ( $fp as $p ) {
                if ( in_array( $p, $learned['spam'], true ) ) {
                    $reasons[] = 'learned:' . substr( $p, 0, 4 );
                    break;
                }
            }
        }

        $time         = isset( $signals['time'] )         ? (int) $signals['time']         : null;
        $interactions = isset( $signals['interactions'] ) ? (int) $signals['interactions'] : null;
        $pointer      = isset( $signals['pointer'] )      ? (int) $signals['pointer']      : null;
        $field_count  = max( 1, count( $clean ) );

        // 2) Filled too fast to be human. 2s threshold catches Fake Filler
        //    (≈ instant) and most automated submitters, while leaving room
        //    for legitimate users with browser autofill on small forms.
        if ( $time !== null && $time < 2 && $field_count >= 2 ) {
            $reasons[] = 'too_fast';
        }

        // 3) Zero keystrokes / change events with a multi-field form means
        //    the values were set programmatically (Fake Filler often does
        //    this via .value = "..." which doesn't generate input events
        //    on older browsers).
        if ( $interactions !== null && $interactions === 0 && $field_count >= 2 ) {
            $reasons[] = 'no_keystrokes';
        }

        // 4) No mouse / touch activity at all = headless browser or
        //    extension-driven fill. Combined with one other weak signal.
        if ( $pointer !== null && $pointer === 0 && $field_count >= 2 ) {
            $reasons[] = 'no_pointer';
        }

        // 5) Signals object entirely missing → very old or non-JS client.
        if ( empty( $signals ) ) {
            $reasons[] = 'no_signals';
        }

        // Decide: any single "strong" reason marks it spam, OR two weak
        // reasons together. Strong = honeypot, too_fast.
        $strong = [ 'honeypot', 'honeypot_legacy', 'too_fast' ];
        $has_strong = (bool) array_intersect( $strong, $reasons );
        $is_spam    = $has_strong || count( $reasons ) >= 2;

        return [ $is_spam, $reasons ];
    }

    private function detect_browser() {
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if ( stripos( $ua, 'Firefox' ) !== false ) return 'Firefox';
        if ( stripos( $ua, 'Edg' )     !== false ) return 'Edge';
        if ( stripos( $ua, 'OPR' )     !== false ) return 'Opera';
        if ( stripos( $ua, 'Chrome' )  !== false ) return 'Chrome';
        if ( stripos( $ua, 'Safari' )  !== false ) return 'Safari';
        return 'Other';
    }

    /**
     * Sanitize a journey payload coming from journey-tracker.js before
     * we persist it. The shape is:
     *   { entry: {url, referrer, ref_source, ts}, utm: {...}, pages: [ {url, title, ts, duration, search}, ... ] }
     * We cap at 30 pages, esc_url every URL, trim text fields, and reject
     * anything outside a known shape. Returns the cleaned array or null
     * when the payload is unusable.
     */
    public static function sanitize_journey( $j ) {
        if ( ! is_array( $j ) ) return null;
        $out = [];

        if ( isset( $j['entry'] ) && is_array( $j['entry'] ) ) {
            $e = $j['entry'];
            $out['entry'] = [
                'url'        => isset( $e['url'] )        ? esc_url_raw( substr( (string) $e['url'], 0, 500 ) )        : '',
                'referrer'   => isset( $e['referrer'] )   ? esc_url_raw( substr( (string) $e['referrer'], 0, 500 ) )   : '',
                'ref_source' => isset( $e['ref_source'] ) ? sanitize_key( substr( (string) $e['ref_source'], 0, 32 ) ) : '',
                'ts'         => isset( $e['ts'] )         ? (int) $e['ts']                                              : 0,
            ];
        }

        if ( isset( $j['utm'] ) && is_array( $j['utm'] ) ) {
            $allowed = [ 'utm_source','utm_medium','utm_campaign','utm_term','utm_content','gclid','fbclid','msclkid' ];
            $utm = [];
            foreach ( $allowed as $k ) {
                if ( ! empty( $j['utm'][ $k ] ) ) {
                    $utm[ $k ] = sanitize_text_field( substr( (string) $j['utm'][ $k ], 0, 200 ) );
                }
            }
            if ( $utm ) $out['utm'] = $utm;
        }

        if ( isset( $j['pages'] ) && is_array( $j['pages'] ) ) {
            $pages = [];
            foreach ( array_slice( $j['pages'], -30 ) as $p ) {
                if ( ! is_array( $p ) || empty( $p['url'] ) ) continue;
                $row = [
                    'url'   => esc_url_raw( substr( (string) $p['url'], 0, 500 ) ),
                    'title' => isset( $p['title'] )    ? sanitize_text_field( substr( (string) $p['title'], 0, 200 ) ) : '',
                    'ts'    => isset( $p['ts'] )       ? (int) $p['ts']                                                : 0,
                ];
                if ( isset( $p['duration'] ) ) $row['duration'] = max( 0, min( 7200, (int) $p['duration'] ) );
                if ( ! empty( $p['search'] ) )  $row['search']   = sanitize_text_field( substr( (string) $p['search'], 0, 200 ) );
                $pages[] = $row;
            }
            if ( $pages ) $out['pages'] = $pages;
        }

        return $out ?: null;
    }

    /**
     * Map an ISO 3166-1 alpha-2 country code to its primary currency
     * (ISO 4217) + the conventional symbol. Used by detect_currency() and
     * the /detect-currency REST endpoint so payment fields can auto-set
     * to the visitor's local currency.
     *
     * Currencies that aren't generally supported by Stripe/Razorpay/etc.
     * are mapped to a fallback (USD for AMERICAS/AFRICA, EUR for EU,
     * INR for SE Asia, etc.). The "best-effort" docstring applies.
     */
    public static function country_to_currency( $country_code ) {
        $code = strtoupper( substr( (string) $country_code, 0, 2 ) );
        $map = [
            // Tier 1
            'US' => [ 'USD', '$' ], 'CA' => [ 'CAD', 'C$' ], 'GB' => [ 'GBP', '£' ], 'AU' => [ 'AUD', 'A$' ], 'NZ' => [ 'NZD', 'NZ$' ],
            'JP' => [ 'JPY', '¥' ], 'SG' => [ 'SGD', 'S$' ], 'HK' => [ 'HKD', 'HK$' ], 'CH' => [ 'CHF', 'CHF' ],
            // Eurozone
            'DE' => [ 'EUR', '€' ], 'FR' => [ 'EUR', '€' ], 'IT' => [ 'EUR', '€' ], 'ES' => [ 'EUR', '€' ],
            'NL' => [ 'EUR', '€' ], 'BE' => [ 'EUR', '€' ], 'AT' => [ 'EUR', '€' ], 'PT' => [ 'EUR', '€' ],
            'IE' => [ 'EUR', '€' ], 'FI' => [ 'EUR', '€' ], 'GR' => [ 'EUR', '€' ], 'LU' => [ 'EUR', '€' ],
            'MT' => [ 'EUR', '€' ], 'CY' => [ 'EUR', '€' ], 'SK' => [ 'EUR', '€' ], 'SI' => [ 'EUR', '€' ],
            'EE' => [ 'EUR', '€' ], 'LV' => [ 'EUR', '€' ], 'LT' => [ 'EUR', '€' ], 'HR' => [ 'EUR', '€' ],
            // Other Europe
            'SE' => [ 'SEK', 'kr' ], 'NO' => [ 'NOK', 'kr' ], 'DK' => [ 'DKK', 'kr' ], 'PL' => [ 'PLN', 'zł' ],
            'CZ' => [ 'CZK', 'Kč' ], 'HU' => [ 'HUF', 'Ft' ], 'RO' => [ 'RON', 'lei' ], 'BG' => [ 'BGN', 'лв' ],
            'IS' => [ 'ISK', 'kr' ], 'RS' => [ 'RSD', 'дин' ], 'UA' => [ 'UAH', '₴' ], 'TR' => [ 'TRY', '₺' ],
            // Asia
            'IN' => [ 'INR', '₹' ], 'CN' => [ 'CNY', '¥' ], 'KR' => [ 'KRW', '₩' ], 'TW' => [ 'TWD', 'NT$' ],
            'TH' => [ 'THB', '฿' ], 'PH' => [ 'PHP', '₱' ], 'ID' => [ 'IDR', 'Rp' ], 'MY' => [ 'MYR', 'RM' ],
            'VN' => [ 'VND', '₫' ], 'PK' => [ 'PKR', '₨' ], 'BD' => [ 'BDT', '৳' ], 'LK' => [ 'LKR', 'Rs' ],
            'NP' => [ 'NPR', 'Rs' ], 'KH' => [ 'KHR', '៛' ], 'MM' => [ 'MMK', 'K' ], 'IL' => [ 'ILS', '₪' ],
            // Middle East
            'AE' => [ 'AED', 'AED' ], 'SA' => [ 'SAR', 'SAR' ], 'QA' => [ 'QAR', 'QAR' ], 'KW' => [ 'KWD', 'KWD' ],
            'BH' => [ 'BHD', 'BHD' ], 'OM' => [ 'OMR', 'OMR' ], 'JO' => [ 'JOD', 'JOD' ], 'LB' => [ 'LBP', 'LBP' ],
            'EG' => [ 'EGP', 'E£' ],
            // Africa
            'ZA' => [ 'ZAR', 'R' ], 'NG' => [ 'NGN', '₦' ], 'KE' => [ 'KES', 'KSh' ], 'GH' => [ 'GHS', 'GH₵' ],
            'MA' => [ 'MAD', 'MAD' ], 'TN' => [ 'TND', 'TND' ], 'DZ' => [ 'DZD', 'DA' ],
            // Latin America
            'BR' => [ 'BRL', 'R$' ], 'MX' => [ 'MXN', '$' ], 'AR' => [ 'ARS', '$' ], 'CL' => [ 'CLP', '$' ],
            'CO' => [ 'COP', '$' ], 'PE' => [ 'PEN', 'S/' ], 'UY' => [ 'UYU', '$U' ], 'VE' => [ 'VES', 'Bs' ],
            // Russia / CIS
            'RU' => [ 'RUB', '₽' ], 'KZ' => [ 'KZT', '₸' ], 'UZ' => [ 'UZS', "so'm" ], 'BY' => [ 'BYN', 'Br' ],
        ];
        if ( isset( $map[ $code ] ) ) {
            return [ 'currency' => $map[ $code ][0], 'symbol' => $map[ $code ][1] ];
        }
        return [ 'currency' => 'USD', 'symbol' => '$' ];
    }

    /**
     * Combined helper: detect country then map to currency. Returns
     * { country, currency, symbol }. Country is empty string when the
     * visitor's network has no CDN country headers — in that case
     * currency defaults to USD (most globally accepted).
     */
    public static function detect_currency() {
        $country = self::detect_country();
        $cc      = self::country_to_currency( $country );
        return [
            'country'  => $country,
            'currency' => $cc['currency'],
            'symbol'   => $cc['symbol'],
        ];
    }

    /**
     * Best-effort visitor country detection. Tiered fallback:
     *   1) Per-request cache (don't re-detect within one request)
     *   2) CDN headers (Cloudflare / AWS CloudFront / GAE / Fastly / Akamai)
     *      — instant, free, accurate, no external call
     *   3) GeoIP lookup via ip-api.com (free, no key, 45 req/min/IP)
     *      — only used when (2) yields nothing. Result is cached for 24h
     *      per visitor IP using a WP transient so we never hammer the API.
     * Returns ISO 3166-1 alpha-2 like "IN", "US", or "" when even GeoIP fails.
     */
    public static function detect_country() {
        static $cached = null;
        if ( $cached !== null ) return $cached;

        // Layer 1: CDN headers (instant, no network call)
        $candidates = [
            'HTTP_CF_IPCOUNTRY',
            'HTTP_CLOUDFRONT_VIEWER_COUNTRY',
            'HTTP_X_APPENGINE_COUNTRY',
            'HTTP_X_GEO_COUNTRY',
            'HTTP_X_COUNTRY_CODE',
            'HTTP_X_REAL_IP_COUNTRY',
        ];
        foreach ( $candidates as $h ) {
            if ( ! empty( $_SERVER[ $h ] ) ) {
                $code = strtoupper( substr( (string) $_SERVER[ $h ], 0, 2 ) );
                if ( preg_match( '/^[A-Z]{2}$/', $code ) ) {
                    $cached = $code;
                    return $cached;
                }
            }
        }

        // Layer 2: IP-based GeoIP fallback (cached per IP for 24 hours).
        // Admins can disable this in Settings if they prefer not to make
        // external requests for privacy / latency reasons. Defaults to ON.
        $settings = get_option( 'fcp_settings', [] );
        $geo_enabled = ! isset( $settings['general']['geoip_fallback'] ) || ! empty( $settings['general']['geoip_fallback'] );
        if ( ! $geo_enabled ) {
            $cached = '';
            return $cached;
        }

        $ip = FCP_DB::get_ip();
        if ( ! $ip || $ip === '127.0.0.1' || $ip === '::1' ) {
            $cached = '';
            return $cached;
        }

        $cache_key = 'fcp_geo_' . md5( $ip );
        $hit = get_transient( $cache_key );
        if ( $hit !== false ) {
            $cached = (string) $hit;
            return $cached;
        }

        // ip-api.com — free, no API key required, returns ISO 2-letter code.
        // 3-second timeout so a slow lookup never stalls the form for long.
        $resp = wp_remote_get(
            'http://ip-api.com/json/' . rawurlencode( $ip ) . '?fields=countryCode',
            [ 'timeout' => 3, 'redirection' => 1 ]
        );
        $code = '';
        if ( ! is_wp_error( $resp ) && (int) wp_remote_retrieve_response_code( $resp ) === 200 ) {
            $body = json_decode( wp_remote_retrieve_body( $resp ), true );
            if ( is_array( $body ) && ! empty( $body['countryCode'] ) && preg_match( '/^[A-Z]{2}$/', $body['countryCode'] ) ) {
                $code = $body['countryCode'];
            }
        }

        // Cache result (even if empty) for 24 hours to avoid repeat lookups.
        set_transient( $cache_key, $code, DAY_IN_SECONDS );
        $cached = $code;
        return $cached;
    }

    /**
     * Find any field whose value looks like an email address. Works
     * regardless of the field's label (e.g. "Work Email", "Your Email",
     * "Email Address", or just a plain Email type field).
     */
    private function detect_email( $data ) {
        // 1. Prefer common explicit keys.
        foreach ( [ 'email', 'Email', 'Email Address', 'email_address', 'Work Email', 'Your Email', 'E-mail' ] as $k ) {
            if ( ! empty( $data[ $k ] ) && is_email( $data[ $k ] ) ) {
                return $data[ $k ];
            }
        }
        // 2. Fall back: first value that is an email.
        foreach ( $data as $v ) {
            if ( is_string( $v ) && is_email( $v ) ) return $v;
        }
        return '';
    }

    private function detect_name( $data ) {
        foreach ( [ 'name', 'Name', 'Full Name', 'Your Name', 'full_name', 'first_name', 'First Name' ] as $k ) {
            if ( ! empty( $data[ $k ] ) ) return $data[ $k ];
        }
        return '';
    }

    /**
     * Build the From header used for every outgoing FormCraft email.
     *
     * Returns an empty string when the user hasn't explicitly configured a
     * From address — in that case we let WordPress (and any installed SMTP
     * plugin like WP Mail SMTP or FluentSMTP) decide the sender. Forcing a
     * From in code conflicts with WP Mail SMTP's "Force From Email"
     * feature, and on Gmail / SendGrid mailers it causes outright reject
     * because the From doesn't match the authenticated sender.
     */
    private function build_from_header( $email ) {
        if ( empty( $email['from_email'] ) || ! is_email( $email['from_email'] ) ) {
            return ''; // No explicit From → let SMTP plugin / WP defaults handle it.
        }
        $from_name = ! empty( $email['from_name'] ) ? $email['from_name'] : get_bloginfo( 'name' );
        return 'From: ' . sprintf( '%s <%s>', wp_strip_all_tags( $from_name ), $email['from_email'] );
    }

    /**
     * Look for the popular SMTP plugins and inspect whether they have
     * actually been configured (mailer chosen, not the PHP fallback).
     * This catches the most common failure: WP Mail SMTP installed but
     * the user never ran the setup wizard.
     *
     * Returns an array: [plugin, configured, mailer, settings_url].
     */
    private function detect_smtp_state() {
        $out = [
            'plugin'       => null,
            'configured'   => false,
            'mailer'       => null,
            'settings_url' => '',
        ];

        // 1) FormYantra built-in SMTP — checked first so users who
        //    configured it here see it surfaced as the active mailer.
        if ( class_exists( 'FCP_Mailer' ) && FCP_Mailer::is_configured() ) {
            $settings = get_option( 'fcp_settings', [] );
            $email    = isset( $settings['email'] ) ? $settings['email'] : [];
            $out['plugin']       = 'FormYantra · built-in SMTP';
            $out['settings_url'] = admin_url( 'admin.php?page=formcraft-pro-email' );
            $out['mailer']       = 'smtp:' . ( isset( $email['smtp_host'] ) ? $email['smtp_host'] : '' );
            $out['configured']   = true;
            return $out;
        }

        if ( ! function_exists( 'is_plugin_active' ) ) {
            @include_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        // WP Mail SMTP — stores settings in 'wp_mail_smtp' option.
        // The 'mail.mailer' field is 'mail' until the user picks a real
        // mailer (gmail / sendgrid / mailgun / sendinblue / smtpcom /
        // smtp / outlook / amazon-ses / zoho / postmark).
        if ( function_exists( 'is_plugin_active' ) && is_plugin_active( 'wp-mail-smtp/wp_mail_smtp.php' ) ) {
            $out['plugin']       = 'WP Mail SMTP';
            $out['settings_url'] = admin_url( 'admin.php?page=wp-mail-smtp' );
            $opt    = get_option( 'wp_mail_smtp', [] );
            $mailer = isset( $opt['mail']['mailer'] ) ? $opt['mail']['mailer'] : 'mail';
            $out['mailer']     = $mailer;
            $out['configured'] = $mailer && $mailer !== 'mail';
            return $out;
        }

        // FluentSMTP — stores settings in 'fluentmail-settings' option.
        // 'misc.default_connection' is set when a real mailer is added.
        if ( function_exists( 'is_plugin_active' ) && is_plugin_active( 'fluent-smtp/fluent-smtp.php' ) ) {
            $out['plugin']       = 'FluentSMTP';
            $out['settings_url'] = admin_url( 'options-general.php?page=fluent-mail' );
            $opt    = get_option( 'fluentmail-settings', [] );
            $mailer = isset( $opt['misc']['default_connection'] ) ? $opt['misc']['default_connection'] : '';
            $out['mailer']     = $mailer ?: 'unconfigured';
            $out['configured'] = ! empty( $mailer );
            return $out;
        }

        // Post SMTP.
        if ( function_exists( 'is_plugin_active' ) && ( is_plugin_active( 'post-smtp/postman-smtp.php' ) || is_plugin_active( 'post-smtp-mailer/postman-smtp.php' ) ) ) {
            $out['plugin']       = 'Post SMTP';
            $out['settings_url'] = admin_url( 'admin.php?page=postman' );
            $opt    = get_option( 'postman_options', [] );
            $out['mailer']     = isset( $opt['transport_type'] ) ? $opt['transport_type'] : '';
            $out['configured'] = ! empty( $opt['transport_type'] );
            return $out;
        }

        // Easy WP SMTP.
        if ( function_exists( 'is_plugin_active' ) && is_plugin_active( 'easy-wp-smtp/easy-wp-smtp.php' ) ) {
            $out['plugin']       = 'Easy WP SMTP';
            $out['settings_url'] = admin_url( 'admin.php?page=swpsmtp_settings' );
            $opt = get_option( 'swpsmtp_options', [] );
            $out['mailer']     = isset( $opt['smtp_settings']['host'] ) ? $opt['smtp_settings']['host'] : '';
            $out['configured'] = ! empty( $out['mailer'] );
            return $out;
        }

        return $out;
    }

    /**
     * Helper that returns the headers array for a wp_mail() call,
     * including the From header only when one is configured.
     */
    private function mail_headers( $email, $extras = [] ) {
        $headers = [ 'Content-Type: text/html; charset=UTF-8' ];
        $from    = $this->build_from_header( $email );
        if ( $from )  $headers[] = $from;
        foreach ( (array) $extras as $h ) {
            if ( $h ) $headers[] = $h;
        }
        return $headers;
    }

    /**
     * Build the set of tag → value pairs used in every mail template.
     * Per-field tags (e.g. {{Full Name}}) come from the submitted data
     * keyed by field label.
     */
    private function build_tag_replacements( $form, $data, $sub_id ) {
        $name  = $this->detect_name( $data );
        $email = $this->detect_email( $data );

        // Build the all_fields HTML table. Captured signatures (data URLs)
        // are rendered as inline <img> tags so the email shows the actual
        // signature instead of a 50KB base64 wall of text.
        $rows_html = '';
        $upload_re = '#^https?://[^\s]+\.(jpe?g|png|gif|webp|svg|pdf|docx?|xlsx?|pptx?|zip|csv|txt|mp3|mp4|mov|wav|ogg)(\?|$)#i';
        $self      = $this;
        $is_repeater_value = function ( $v ) {
            if ( ! is_array( $v ) || empty( $v ) ) return false;
            foreach ( $v as $row ) {
                if ( is_array( $row ) ) return true;
            }
            return false;
        };
        $render_repeater_table = function ( $rows ) {
            if ( ! is_array( $rows ) || empty( $rows ) ) return '<em style="color:#94a3b8;">No rows</em>';
            $cols = [];
            foreach ( $rows as $row ) {
                if ( ! is_array( $row ) ) continue;
                foreach ( array_keys( $row ) as $c ) {
                    if ( ! in_array( $c, $cols, true ) ) $cols[] = $c;
                }
            }
            $html  = '<table cellpadding="0" cellspacing="0" style="border-collapse:collapse;border:1px solid #e5e7eb;border-radius:6px;width:100%;font-size:13px;">';
            $html .= '<thead><tr>';
            foreach ( $cols as $c ) {
                $html .= '<th align="left" style="background:#f1f5f9;border-bottom:1px solid #e5e7eb;padding:6px 8px;font-weight:600;color:#475569;">' . esc_html( $c ) . '</th>';
            }
            $html .= '</tr></thead><tbody>';
            foreach ( $rows as $row ) {
                if ( ! is_array( $row ) ) continue;
                $html .= '<tr>';
                foreach ( $cols as $c ) {
                    $cv = isset( $row[ $c ] ) ? $row[ $c ] : '';
                    if ( is_array( $cv ) ) $cv = implode( ', ', $cv );
                    $html .= '<td style="border-top:1px solid #e5e7eb;padding:6px 8px;">' . nl2br( esc_html( (string) $cv ) ) . '</td>';
                }
                $html .= '</tr>';
            }
            $html .= '</tbody></table>';
            return $html;
        };
        foreach ( $data as $k => $v ) {
            // Repeater → nested table per row
            if ( $is_repeater_value( $v ) ) {
                $rows_html .= '<tr>';
                $rows_html .= '<th align="left" style="background:#f8fafc;border-bottom:1px solid #e5e7eb;font-size:13px;color:#64748b;font-weight:600;width:35%;padding:8px;vertical-align:top;">' . esc_html( $k ) . '</th>';
                $rows_html .= '<td style="border-bottom:1px solid #e5e7eb;padding:8px;">' . $render_repeater_table( $v ) . '</td>';
                $rows_html .= '</tr>';
                continue;
            }
            $val = is_array( $v ) ? implode( ', ', $v ) : (string) $v;
            $cell = nl2br( esc_html( $val ) );
            if ( is_string( $val ) && strpos( $val, 'data:image/' ) === 0 ) {
                $cell = '<img src="' . esc_attr( $val ) . '" alt="' . esc_attr( $k ) . '" style="max-width:280px;max-height:120px;background:#fff;border:1px solid #e5e7eb;border-radius:6px;padding:4px;">';
            } elseif ( is_string( $val ) && preg_match( $upload_re, $val ) ) {
                // Uploaded file — show as a clickable download link in the email.
                $fname = basename( parse_url( $val, PHP_URL_PATH ) ?: '' );
                $fname = $fname ?: 'file';
                $cell  = '<a href="' . esc_url( $val ) . '" style="color:#6366f1;text-decoration:underline;">' . esc_html( urldecode( $fname ) ) . '</a>';
            } elseif ( is_string( $val ) && preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $val ) ) {
                // Booking slot — prettify the ISO datetime
                $ts = strtotime( $val );
                if ( $ts ) {
                    $cell = '<strong>📅 ' . esc_html( date_i18n( get_option( 'date_format', 'M j, Y' ), $ts ) ) . '</strong> at <strong>' . esc_html( date_i18n( get_option( 'time_format', 'g:i a' ), $ts ) ) . '</strong>';
                }
            }
            $rows_html .= '<tr>';
            $rows_html .= '<th align="left" style="background:#f8fafc;border-bottom:1px solid #e5e7eb;font-size:13px;color:#64748b;font-weight:600;width:35%;padding:8px;">' . esc_html( $k ) . '</th>';
            $rows_html .= '<td style="border-bottom:1px solid #e5e7eb;font-size:14px;padding:8px;">' . $cell . '</td>';
            $rows_html .= '</tr>';
        }
        $all_fields = '<table cellpadding="0" style="border-collapse:collapse;border:1px solid #e5e7eb;border-radius:8px;width:100%;">' . $rows_html . '</table>';

        $r = [
            '{{form_name}}'        => isset( $form['title'] ) ? $form['title'] : '',
            '{{site_name}}'        => get_bloginfo( 'name' ),
            '{{submitter_name}}'   => $name,
            '{{submitter_email}}'  => $email,
            '{{name}}'             => $name,  // legacy alias
            '{{email}}'            => $email, // legacy alias
            '{{submission_id}}'    => $sub_id,
            '{{date}}'             => current_time( 'F j, Y \a\t g:i a' ),
            '{{admin_link}}'       => admin_url( 'admin.php?page=formcraft-pro-submissions' ),
            '{{all_fields}}'       => $all_fields,
        ];
        // Per-field tags — each field label becomes a tag {{Label}}.
        // Image data URLs are turned into inline <img> tags so {{Signature}}
        // renders the picture rather than the raw base64 string. Uploaded
        // files become clickable download links. Repeater rows render as
        // an inline mini-table.
        foreach ( $data as $k => $v ) {
            if ( $is_repeater_value( $v ) ) {
                $r[ '{{' . $k . '}}' ] = $render_repeater_table( $v );
                continue;
            }
            $val = is_array( $v ) ? implode( ', ', $v ) : (string) $v;
            if ( is_string( $val ) && strpos( $val, 'data:image/' ) === 0 ) {
                $r[ '{{' . $k . '}}' ] = '<img src="' . esc_attr( $val ) . '" alt="' . esc_attr( $k ) . '" style="max-width:280px;max-height:120px;background:#fff;border:1px solid #e5e7eb;border-radius:6px;padding:4px;">';
            } elseif ( is_string( $val ) && preg_match( $upload_re, $val ) ) {
                $fname = basename( parse_url( $val, PHP_URL_PATH ) ?: '' ) ?: 'file';
                $r[ '{{' . $k . '}}' ] = '<a href="' . esc_url( $val ) . '" style="color:#6366f1;text-decoration:underline;">' . esc_html( urldecode( $fname ) ) . '</a>';
            } else {
                $r[ '{{' . $k . '}}' ] = esc_html( $val );
            }
        }
        return $r;
    }

    /**
     * Send admin + user notification emails. Per-form notification config
     * (form.settings.notifications) takes priority over global settings,
     * which in turn fall back to the WordPress admin email. Captures any
     * wp_mail_failed errors so we can surface them in the API response
     * (and the error log) — the most common reason for "no email
     * arrived" is wp_mail() returning false because the host doesn't
     * have a working mail transport.
     */
    private function send_emails( $form, $data, $sub_id ) {
        $settings = get_option( 'fcp_settings', [] );
        $globalE  = isset( $settings['email'] ) ? $settings['email'] : [];
        $perForm  = isset( $form['settings']['notifications'] ) ? $form['settings']['notifications'] : [];
        $results  = [ 'admin' => null, 'user' => null ];

        // Capture wp_mail_failed errors — populated whenever wp_mail returns
        // false during this function's lifetime.
        $last_error  = '';
        $error_cb    = function ( $wp_error ) use ( &$last_error ) {
            if ( is_wp_error( $wp_error ) ) $last_error = $wp_error->get_error_message();
        };
        add_action( 'wp_mail_failed', $error_cb );

        $tags = $this->build_tag_replacements( $form, $data, $sub_id );

        /* ---------- Admin notification ---------- */
        $adminCfg      = isset( $perForm['admin'] ) ? $perForm['admin'] : [];
        $admin_enabled = isset( $adminCfg['enabled'] )
            ? (bool) $adminCfg['enabled']
            : ( isset( $globalE['send_admin'] ) ? (bool) $globalE['send_admin'] : true );

        if ( $admin_enabled ) {
            // Recipient priority: per-form > global > wp admin_email
            $raw = ! empty( $adminCfg['to'] )                   ? $adminCfg['to']
                 : ( ! empty( $globalE['admin_recipients'] )    ? $globalE['admin_recipients']
                 :   get_option( 'admin_email' ) );
            $recipients = array_filter( array_map( 'trim', explode( ',', (string) $raw ) ), 'is_email' );

            if ( $recipients ) {
                $subject_tpl = ! empty( $adminCfg['subject'] )
                    ? $adminCfg['subject']
                    : sprintf( __( 'New submission on %s', 'formcraft-pro' ), isset( $form['title'] ) ? $form['title'] : 'Form' );
                $body_tpl    = ! empty( $adminCfg['body'] ) ? $adminCfg['body'] : $this->default_admin_body( $form );

                $subject = strtr( $subject_tpl, $tags );
                $body    = $this->wrap_html_email( strtr( $body_tpl, $tags ) );

                // Reply-To the submitter so the admin can hit "Reply" once.
                $reply_to_email  = $this->detect_email( $data );
                $reply_to_header = '';
                if ( $reply_to_email ) {
                    $reply_to_name   = $this->detect_name( $data );
                    $reply_to_header = 'Reply-To: ' . ( $reply_to_name
                        ? sprintf( '%s <%s>', $reply_to_name, $reply_to_email )
                        : $reply_to_email );
                }
                $admin_headers = $this->mail_headers( $globalE, [ $reply_to_header ] );

                $last_error = '';
                $sent = wp_mail( $recipients, $subject, $body, $admin_headers );
                $error_msg = $sent ? '' : ( $last_error ?: 'wp_mail returned false (host likely has no working mail transport — install WP Mail SMTP or FluentSMTP)' );

                $results['admin'] = [
                    'to'    => $recipients,
                    'sent'  => (bool) $sent,
                    'error' => $error_msg,
                ];
                if ( ! $sent ) {
                    error_log( '[FormYantra] Admin email failed for submission #' . $sub_id . ': ' . $error_msg );
                }
                // Log every attempt — one row per recipient.
                foreach ( $recipients as $rcpt ) {
                    FCP_DB::log_mail( [
                        'recipient'     => $rcpt,
                        'subject'       => $subject,
                        'form_id'       => isset( $form['id'] ) ? $form['id'] : null,
                        'submission_id' => $sub_id,
                        'purpose'       => 'admin_notify',
                        'status'        => $sent ? 'delivered' : 'failed',
                        'error_message' => $error_msg,
                    ] );
                }
            } else {
                $results['admin'] = [ 'to' => [], 'sent' => false, 'error' => 'No valid admin recipients configured' ];
                error_log( '[FormYantra] No valid admin recipients for submission #' . $sub_id );
            }
        } else {
            $results['admin'] = [ 'sent' => false, 'error' => 'disabled' ];
        }

        /* ---------- User confirmation ---------- */
        $userCfg      = isset( $perForm['user'] ) ? $perForm['user'] : [];
        $user_enabled = isset( $userCfg['enabled'] )
            ? (bool) $userCfg['enabled']
            : ( isset( $globalE['send_user'] ) ? (bool) $globalE['send_user'] : true );

        if ( $user_enabled ) {
            $to = $this->detect_email( $data );
            if ( $to ) {
                $subject_tpl = ! empty( $userCfg['subject'] )
                    ? $userCfg['subject']
                    : ( ! empty( $globalE['confirmation_subject'] )
                        ? $globalE['confirmation_subject']
                        : __( 'Thanks for contacting us!', 'formcraft-pro' ) );

                $body_tpl = ! empty( $userCfg['body'] )
                    ? $userCfg['body']
                    : ( ! empty( $globalE['confirmation_body'] )
                        ? $globalE['confirmation_body']
                        : '<p>Hi {{submitter_name}},</p><p>We received your submission and will reply soon.</p>' );

                $subject = strtr( $subject_tpl, $tags );
                $body    = $this->wrap_html_email( strtr( $body_tpl, $tags ) );

                $last_error = '';
                $sent = wp_mail( $to, $subject, $body, $this->mail_headers( $globalE ) );
                $error_msg = $sent ? '' : ( $last_error ?: 'wp_mail returned false' );
                $results['user'] = [
                    'to'    => $to,
                    'sent'  => (bool) $sent,
                    'error' => $error_msg,
                ];
                if ( ! $sent ) {
                    error_log( '[FormYantra] User confirmation failed for submission #' . $sub_id . ': ' . $error_msg );
                }
                FCP_DB::log_mail( [
                    'recipient'     => $to,
                    'subject'       => $subject,
                    'form_id'       => isset( $form['id'] ) ? $form['id'] : null,
                    'submission_id' => $sub_id,
                    'purpose'       => 'user_confirm',
                    'status'        => $sent ? 'delivered' : 'failed',
                    'error_message' => $error_msg,
                ] );
            } else {
                $results['user'] = [ 'to' => '', 'sent' => false, 'error' => 'No email field found in submission' ];
            }
        } else {
            $results['user'] = [ 'sent' => false, 'error' => 'disabled' ];
        }

        remove_action( 'wp_mail_failed', $error_cb );
        return $results;
    }

    private function default_admin_body( $form ) {
        $rows = '<p>Form: <strong>{{form_name}}</strong></p>'
              . '<p>Submitted: {{date}}</p><hr>'
              . '{{all_fields}}'
              . '<hr><p><a href="{{admin_link}}">View submission in dashboard →</a></p>';
        return '<h2>New submission received</h2>' . $rows;
    }

    private function wrap_html_email( $inner ) {
        return '<div style="font-family:Inter,Arial,sans-serif;color:#0f172a;line-height:1.55;max-width:640px;">'
             . $inner
             . '</div>';
    }

    /* ------------------ Submissions admin ------------------ */
    public function list_submissions( $req ) {
        $args = [];
        if ( $req->get_param( 'form_id' ) ) $args['form_id'] = (int) $req->get_param( 'form_id' );
        if ( $req->get_param( 'spam' ) !== null ) $args['is_spam'] = (int) $req->get_param( 'spam' );
        $rows = FCP_DB::get_submissions( $args );
        foreach ( $rows as &$r ) {
            $r = self::normalize_submission( $r );
        }
        return rest_ensure_response( $rows );
    }
    public function get_submission( $req ) {
        $r = FCP_DB::get_submission( $req['id'] );
        if ( $r ) {
            $r = self::normalize_submission( $r );
            // v2.61 — Field-level access control + decryption.
            // Decrypt access="encrypted" fields the viewer has permission
            // for; redact other access-controlled fields they don't.
            if ( class_exists( 'FCP_Crypto' ) ) {
                $form = FCP_DB::get_form( (int) $r['form_id'] );
                $data = is_string( $r['data'] ) ? json_decode( $r['data'], true ) : ( $r['data'] ?: [] );
                if ( ! is_array( $data ) ) $data = [];
                if ( $form ) {
                    foreach ( ( $form['steps'] ?? [] ) as $step ) {
                        foreach ( ( $step['fields'] ?? [] ) as $field ) {
                            $access = $field['access'] ?? 'all';
                            if ( $access === 'all' ) continue;
                            $name = $field['name'] ?? $field['label'] ?? '';
                            if ( $name === '' || ! isset( $data[ $name ] ) ) continue;
                            if ( ! FCP_Crypto::viewer_can_see( $access, $form ) ) {
                                $data[ $name ] = '🔒 Restricted';
                                continue;
                            }
                            if ( $access === 'encrypted' && is_string( $data[ $name ] ) ) {
                                $data[ $name ] = FCP_Crypto::decrypt( $data[ $name ] );
                            }
                        }
                    }
                    $r['data'] = $data;
                }
            }

            // v2.72.7 — Attach per-submission mail delivery log so the
            // detail page can show whether the admin notification and user
            // confirmation actually went out.
            global $wpdb;
            $log_t = $wpdb->prefix . FCP_TABLE_MAIL_LOG;
            $rows  = $wpdb->get_results( $wpdb->prepare(
                "SELECT purpose, recipient, subject, status, error_message, sent_at
                 FROM $log_t WHERE submission_id = %d ORDER BY sent_at ASC",
                (int) $r['id']
            ), ARRAY_A );
            $r['email_log'] = $rows ?: [];
        }
        return rest_ensure_response( $r );
    }

    /**
     * MySQL via $wpdb returns every column as a string. Cast the numeric /
     * boolean columns so the JSON payload exposes proper int / bool values
     * — otherwise the JS side sees is_spam="0" and `!!"0"` evaluates true.
     */
    private static function normalize_submission( $r ) {
        if ( ! is_array( $r ) ) return $r;
        $r['id']      = isset( $r['id'] )      ? (int) $r['id']      : 0;
        $r['form_id'] = isset( $r['form_id'] ) ? (int) $r['form_id'] : 0;
        $r['is_spam'] = ! empty( $r['is_spam'] ) && $r['is_spam'] !== '0' ? 1 : 0;
        $r['is_read'] = ! empty( $r['is_read'] ) && $r['is_read'] !== '0' ? 1 : 0;
        $r['notes']   = isset( $r['notes'] ) ? (string) $r['notes'] : '';
        // Payment fields
        $r['payment_status']   = isset( $r['payment_status'] )   ? (string) $r['payment_status']   : 'none';
        $r['payment_provider'] = isset( $r['payment_provider'] ) ? (string) $r['payment_provider'] : '';
        $r['payment_id']       = isset( $r['payment_id'] )       ? (string) $r['payment_id']       : '';
        $r['payment_order_id'] = isset( $r['payment_order_id'] ) ? (string) $r['payment_order_id'] : '';
        $r['payment_amount']   = isset( $r['payment_amount'] )   ? (float)  $r['payment_amount']   : 0;
        $r['payment_currency']= isset( $r['payment_currency'] ) ? (string) $r['payment_currency'] : '';
        $r['paid_at']          = isset( $r['paid_at'] )          ? (string) $r['paid_at']          : '';
        $r['coupon_code']             = isset( $r['coupon_code'] )             ? (string) $r['coupon_code']             : '';
        $r['coupon_discount']         = isset( $r['coupon_discount'] )         ? (float)  $r['coupon_discount']         : 0;
        $r['coupon_original_amount']  = isset( $r['coupon_original_amount'] )  ? (float)  $r['coupon_original_amount']  : 0;
        $r['wc_order_id']      = isset( $r['wc_order_id'] )     ? (int)    $r['wc_order_id']     : 0;
        $r['wc_order_status']  = isset( $r['wc_order_status'] ) ? (string) $r['wc_order_status'] : '';
        $r['wc_order_total']   = isset( $r['wc_order_total'] )  ? (float)  $r['wc_order_total']  : 0;
        $r['approval_status']  = isset( $r['approval_status'] ) ? (string) $r['approval_status'] : 'none';
        $r['approval_note']    = isset( $r['approval_note'] )   ? (string) $r['approval_note']   : '';
        $r['journey']          = isset( $r['journey'] )         ? (string) $r['journey']         : '';
        // v2.72.35 — GoHighLevel per-submission state
        $r['ghl_contact_id']   = isset( $r['ghl_contact_id'] )  ? (string) $r['ghl_contact_id']  : '';
        $r['ghl_last_sync']    = isset( $r['ghl_last_sync'] )   ? (string) $r['ghl_last_sync']   : '';
        $r['ghl_status']       = isset( $r['ghl_status'] )      ? (string) $r['ghl_status']      : '';
        if ( $r['wc_order_id'] && class_exists( 'FCP_WooCommerce' ) ) {
            $r['wc_order_url'] = FCP_WooCommerce::admin_order_url( $r['wc_order_id'] );
        }
        if ( isset( $r['data'] ) && is_string( $r['data'] ) ) {
            $decoded = json_decode( $r['data'], true );
            $r['data'] = is_array( $decoded ) ? $decoded : [];
        }
        return $r;
    }
    public function update_submission( $req ) {
        $changes = $req->get_json_params();
        $allowed = [];
        if ( isset( $changes['is_read'] ) ) $allowed['is_read'] = (int) (bool) $changes['is_read'];
        if ( isset( $changes['is_spam'] ) ) $allowed['is_spam'] = (int) (bool) $changes['is_spam'];
        if ( isset( $changes['notes'] ) )   $allowed['notes']   = sanitize_textarea_field( (string) $changes['notes'] );
        FCP_DB::update_submission( $req['id'], $allowed );
        $row = FCP_DB::get_submission( $req['id'] );
        return rest_ensure_response( self::normalize_submission( $row ) );
    }
    public function delete_submission( $req ) {
        FCP_DB::delete_submission( $req['id'] );
        return rest_ensure_response( [ 'deleted' => true ] );
    }

    /* ------------------ 1-Click Migration ------------------ */
    public function migrator_detect() {
        if ( ! class_exists( 'FCP_Migrator' ) ) return new WP_Error( 'na', 'Migrator unavailable.' );
        return rest_ensure_response( [ 'sources' => FCP_Migrator::detect_plugins() ] );
    }
    public function migrator_list_forms( $req ) {
        if ( ! class_exists( 'FCP_Migrator' ) ) return new WP_Error( 'na', 'Migrator unavailable.' );
        $source = (string) $req['source'];
        return rest_ensure_response( [ 'forms' => FCP_Migrator::list_forms( $source ) ] );
    }
    public function migrator_import( $req ) {
        if ( ! class_exists( 'FCP_Migrator' ) ) return new WP_Error( 'na', 'Migrator unavailable.' );
        $body   = $req->get_json_params();
        $source = isset( $body['source'] ) ? sanitize_key( (string) $body['source'] ) : '';
        $ids    = isset( $body['ids'] ) && is_array( $body['ids'] ) ? array_map( 'intval', $body['ids'] ) : [];
        $opts   = [
            'include_submissions' => ! empty( $body['include_submissions'] ),
            'suffix'              => isset( $body['suffix'] ) ? sanitize_text_field( $body['suffix'] ) : '',
        ];
        if ( ! $source || ! $ids ) return new WP_Error( 'bad_input', 'source + ids[] are required.' );

        $results = [];
        $had_error = 0;
        foreach ( $ids as $id ) {
            $r = FCP_Migrator::import( $source, (int) $id, $opts );
            if ( is_wp_error( $r ) ) {
                $had_error++;
                $results[] = [ 'source_form_id' => (int) $id, 'error' => $r->get_error_message() ];
            } else {
                $r['source_form_id'] = (int) $id;
                $results[] = $r;
            }
        }
        return rest_ensure_response( [
            'imported'   => count( $results ) - $had_error,
            'failed'     => $had_error,
            'results'    => $results,
        ] );
    }
    public function migrator_history() {
        if ( ! class_exists( 'FCP_Migrator' ) ) return new WP_Error( 'na', 'Migrator unavailable.' );
        return rest_ensure_response( [ 'history' => FCP_Migrator::history() ] );
    }
    public function migrator_rollback( $req ) {
        if ( ! class_exists( 'FCP_Migrator' ) ) return new WP_Error( 'na', 'Migrator unavailable.' );
        $r = FCP_Migrator::rollback( (int) $req['id'] );
        if ( is_wp_error( $r ) ) return $r;
        return rest_ensure_response( [ 'rolled_back' => true ] );
    }
    /**
     * Dry-run preview. Same payload shape as migrator_import but writes
     * nothing to the DB — the UI uses the returned `preview_form` to show
     * a field-by-field diff before the admin commits.
     */
    public function migrator_dry_run( $req ) {
        if ( ! class_exists( 'FCP_Migrator' ) ) return new WP_Error( 'na', 'Migrator unavailable.' );
        $body  = $req->get_json_params();
        $src   = (string) ( $body['source']      ?? '' );
        $id    = (int) ( $body['external_id']    ?? 0 );
        $subs  = ! empty( $body['include_submissions'] );
        if ( ! $src || ! $id ) return new WP_Error( 'bad_input', 'source + external_id required.' );
        $out = FCP_Migrator::import( $src, $id, [
            'dry_run'             => true,
            'include_submissions' => $subs,
        ] );
        if ( is_wp_error( $out ) ) return $out;
        return rest_ensure_response( $out );
    }
    /**
     * Per-source feature matrix + compatibility percent for the UI to
     * render the score chip and the "what carries over" tooltip.
     */
    public function migrator_compatibility() {
        if ( ! class_exists( 'FCP_Migrator' ) ) return new WP_Error( 'na', 'Migrator unavailable.' );
        $matrix = FCP_Migrator::feature_matrix();
        $out    = [];
        foreach ( $matrix as $src => $row ) {
            $out[ $src ] = array_merge(
                [ 'features' => $row ],
                FCP_Migrator::compatibility_score( $src )
            );
        }
        return rest_ensure_response( [ 'matrix' => $out ] );
    }
    /**
     * Site-wide shortcode swap. Body: { source, old_id, new_form_id }.
     * Returns the per-post and per-widget swap counts.
     */
    public function migrator_replace_shortcodes( $req ) {
        if ( ! class_exists( 'FCP_Migrator' ) ) return new WP_Error( 'na', 'Migrator unavailable.' );
        $body  = $req->get_json_params();
        $src   = (string) ( $body['source']      ?? '' );
        $old   = (string) ( $body['old_id']      ?? '' );
        $newId = (int) ( $body['new_form_id']    ?? 0 );
        if ( ! $src || ! $old || ! $newId ) {
            return new WP_Error( 'bad_input', 'source + old_id + new_form_id required.' );
        }
        $rep = FCP_Migrator::replace_shortcodes_site_wide( $src, $old, $newId );
        if ( is_wp_error( $rep ) ) return $rep;
        return rest_ensure_response( $rep );
    }
    /**
     * Trigger the admin-notification email for a form using a synthetic
     * payload, so the admin can verify SMTP / merge-tag setup post-import
     * without sending a real submission.
     */
    public function migrator_test_notification( $req ) {
        $body = $req->get_json_params();
        $fid  = (int) ( $body['form_id'] ?? 0 );
        if ( ! $fid ) return new WP_Error( 'bad_input', 'form_id required.' );
        $form = FCP_DB::get_form( $fid );
        if ( ! $form ) return new WP_Error( 'not_found', 'Form not found.', [ 'status' => 404 ] );
        // Synthetic data that touches every common field name.
        $data = [
            'Full Name' => 'Test User',
            'Email'     => get_option( 'admin_email' ),
            'Phone'     => '+1 555 0123',
            'Message'   => 'This is a test notification sent from the FormYantra migrator. If you can read this, your post-migration email setup is working.',
        ];
        if ( class_exists( 'FCP_Mailer' ) ) {
            $r = FCP_Mailer::send_admin_notification( $form, $data, 0, [] );
            return rest_ensure_response( [ 'sent' => (bool) $r, 'to' => $form['settings']['notifications']['admin']['to'] ?? '' ] );
        }
        return new WP_Error( 'na', 'Mailer unavailable.' );
    }

    /**
     * v2.54 — Force-send the scheduled digest email immediately, using
     * the configured recipient + the current frequency window. Useful for
     * admins to preview what the email will look like before the next cron.
     */
    public function digest_send_now( $req ) {
        if ( ! class_exists( 'FCP_Digest' ) ) return new WP_Error( 'na', 'Digest module unavailable.' );
        $settings = get_option( 'fcp_settings', [] );
        $cfg      = isset( $settings['scheduled_reports'] ) && is_array( $settings['scheduled_reports'] ) ? $settings['scheduled_reports'] : [];
        $to       = ! empty( $cfg['recipient'] ) && is_email( $cfg['recipient'] ) ? $cfg['recipient'] : get_option( 'admin_email' );
        if ( ! $to ) return new WP_Error( 'no_recipient', 'No valid recipient configured.', [ 'status' => 400 ] );
        $freq     = $cfg['frequency'] ?? 'weekly';
        $window   = $freq === 'daily' ? 86400 : ( $freq === 'monthly' ? 30 * 86400 : 7 * 86400 );
        $html     = FCP_Digest::build_report( $window );
        $sent     = wp_mail(
            $to,
            sprintf( '[%s] Test · FormYantra digest', get_bloginfo( 'name' ) ),
            $html,
            [ 'Content-Type: text/html; charset=UTF-8' ]
        );
        return rest_ensure_response( [ 'sent' => (bool) $sent, 'to' => $to ] );
    }

    /* ------------------ Settings ------------------ */
    public function get_settings() {
        // Merge any persisted settings OVER the WP-derived defaults so that
        // newly-added keys (timezone, currency, language) auto-populate on
        // existing installs without needing an admin to re-save the form.
        $defaults = FCP_DB::default_settings();
        $saved    = get_option( 'fcp_settings', [] );
        $merged   = is_array( $saved ) ? array_replace_recursive( $defaults, $saved ) : $defaults;
        return rest_ensure_response( $merged );
    }
    public function update_settings( $req ) {
        $current = get_option( 'fcp_settings', FCP_DB::default_settings() );
        $patch   = $req->get_json_params();
        if ( is_array( $patch ) ) {
            $before  = $current;
            $current = array_replace_recursive( $current, $patch );
            update_option( 'fcp_settings', $current );

            // v2.72.16 — Audit every save so the Security → Audit Log tab
            // reflects settings activity. One entry per top-level section
            // that actually appears in the patch (security, email, ai,
            // maps, recaptcha, …) so admins can see who changed what and
            // when. Values are stored redacted for anything password-shaped.
            if ( class_exists( 'FCP_Audit' ) ) {
                $sections = array_keys( $patch );
                foreach ( $sections as $section ) {
                    $section = (string) $section;
                    if ( $section === '' ) continue;
                    $before_section = isset( $before[ $section ] )  ? $before[ $section ]  : null;
                    $after_section  = isset( $current[ $section ] ) ? $current[ $section ] : null;
                    if ( $before_section === $after_section ) continue; // no-op save; skip
                    if ( is_array( $before_section ) && is_array( $after_section )
                         && wp_json_encode( $before_section ) === wp_json_encode( $after_section ) ) continue;
                    $redact = function ( $v ) use ( &$redact ) {
                        if ( is_array( $v ) ) {
                            foreach ( $v as $k => $val ) {
                                if ( is_array( $val ) ) { $v[ $k ] = $redact( $val ); continue; }
                                if ( preg_match( '/(secret|token|password|api[_-]?key|access[_-]?key)/i', (string) $k ) ) {
                                    $v[ $k ] = $val ? '••••••' : '';
                                }
                            }
                        }
                        return $v;
                    };
                    FCP_Audit::log(
                        'settings_changed',
                        'settings',
                        $section,
                        $redact( $before_section ),
                        $redact( $after_section )
                    );
                }
            }
        }
        return rest_ensure_response( $current );
    }

    /* ------------------ Primary REST API key ------------------ */
    private function ensure_api_key() {
        $settings = get_option( 'fcp_settings', [] );
        if ( ! is_array( $settings ) ) $settings = [];
        if ( empty( $settings['rest_api_key'] ) ) {
            $settings['rest_api_key'] = 'sk_live_' . wp_generate_password( 32, false, false );
            update_option( 'fcp_settings', $settings );
        }
        return $settings['rest_api_key'];
    }
    public function get_api_key() {
        return rest_ensure_response( [
            'key'      => $this->ensure_api_key(),
            'endpoint' => rest_url( 'fcp/v1' ),
        ] );
    }
    public function regenerate_api_key() {
        $settings = get_option( 'fcp_settings', [] );
        if ( ! is_array( $settings ) ) $settings = [];
        $settings['rest_api_key'] = 'sk_live_' . wp_generate_password( 32, false, false );
        update_option( 'fcp_settings', $settings );
        if ( class_exists( 'FCP_Audit' ) ) {
            FCP_Audit::log( 'settings_changed', 'settings', 'rest_api_key', null, [ 'action' => 'regenerated' ] );
        }
        return rest_ensure_response( [
            'key'      => $settings['rest_api_key'],
            'endpoint' => rest_url( 'fcp/v1' ),
        ] );
    }

    /* ------------------ Stats ------------------ */
    public function get_stats() {
        global $wpdb;
        $forms_table = FCP_DB::forms_table();
        $subs_table  = FCP_DB::subs_table();
        // All "submissions" counts exclude abandoned partial rows — those
        // have their own page and shouldn't inflate dashboard stats.
        $stats = [
            'total_forms'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $forms_table" ),
            'active_forms'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $forms_table WHERE status = 'active'" ),
            'total_views'     => (int) $wpdb->get_var( "SELECT SUM(views) FROM $forms_table" ),
            'total_subs'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $subs_table WHERE is_spam = 0 AND is_abandoned = 0" ),
            'spam_blocked'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $subs_table WHERE is_spam = 1 AND is_abandoned = 0" ),
            'unread'          => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $subs_table WHERE is_read = 0 AND is_spam = 0 AND is_abandoned = 0" ),
            'this_week'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $subs_table WHERE is_spam = 0 AND is_abandoned = 0 AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)" ),
            'abandoned'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $subs_table WHERE is_abandoned = 1" ),
            // v2.69.11 — Lifetime submissions-deleted counter (persistent
            // option; increments on every DB delete, doesn't come back if
            // the row is later restored via backup).
            'deleted'         => FCP_DB::get_deleted_counter(),
        ];
        return rest_ensure_response( $stats );
    }
}
