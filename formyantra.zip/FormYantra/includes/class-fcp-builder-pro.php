<?php
/**
 * FormYantra — Builder Pro (v2.72.64).
 *
 * Ships four previously-missing builder capabilities:
 *   1. Live collaboration — presence-based ("who's editing this form
 *      right now") via polling. Warns when 2+ admins are on the same
 *      form so they don't clobber each other's saves.
 *   2. Named revision checkpoints — admin-supplied names for revisions
 *      ("v1 launch", "after Q1 feedback"). Persisted in the existing
 *      revisions `note` column, filtered/starred in the revisions list.
 *   3. Community template marketplace — ratings + reviews on templates.
 *      Local-first: templates published/imported to this site can be
 *      rated by anyone with `manage_options`. A future release will sync
 *      to a shared marketplace endpoint.
 *   4. External importers — Google Forms URL, Typeform JSON, Jotform
 *      JSON. Each returns a FormYantra form definition ready to save.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FCP_Builder_Pro {

    const PRESENCE_TABLE = 'fcp_presence';
    const RATINGS_TABLE  = 'fcp_template_ratings';
    const SCHEMA_OPT     = 'fcp_builder_pro_schema';
    const SCHEMA_VER     = 2;    // v2.72.79 — added current_field_* + started_at
    const PRESENCE_TTL   = 60;   // seconds — admin considered "gone" after this

    public static function ensure_schema() {
        if ( (int) get_option( self::SCHEMA_OPT, 0 ) === self::SCHEMA_VER ) return;
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $p = $wpdb->prefix . self::PRESENCE_TABLE;
        $r = $wpdb->prefix . self::RATINGS_TABLE;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        /* v2.72.79 — Added current_field_id + current_field_label + started_at
           so the presence dropdown can show WHICH field each admin is on right
           now. dbDelta safely adds the new columns on existing installs. */
        dbDelta( "CREATE TABLE $p (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            form_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            user_name VARCHAR(120) NOT NULL DEFAULT '',
            user_email VARCHAR(190) NOT NULL DEFAULT '',
            avatar_url VARCHAR(255) NOT NULL DEFAULT '',
            last_seen BIGINT UNSIGNED NOT NULL,
            current_field_id VARCHAR(64) NOT NULL DEFAULT '',
            current_field_label VARCHAR(190) NOT NULL DEFAULT '',
            started_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            UNIQUE KEY form_user (form_id, user_id),
            KEY last_seen (last_seen)
        ) $charset;" );
        dbDelta( "CREATE TABLE $r (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            template_id VARCHAR(64) NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            stars TINYINT UNSIGNED NOT NULL DEFAULT 5,
            review TEXT,
            created_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY tpl_user (template_id, user_id),
            KEY template_id (template_id)
        ) $charset;" );
        update_option( self::SCHEMA_OPT, self::SCHEMA_VER, false );
    }

    /* ─────────────────────────────────────────────────────────────
     * 1. Presence — heartbeat + query.
     * ───────────────────────────────────────────────────────────── */
    /* v2.72.79 — heartbeat now accepts the caller's currently-focused
       field (id + human label) so the presence dropdown can render
       "editing: Email" per user. Fields default to '' when no field is
       focused (e.g. admin is on the Settings tab). started_at is set once
       per session and preserved across heartbeats. */
    public static function heartbeat( $form_id, $user, $current_field_id = '', $current_field_label = '' ) {
        self::ensure_schema();
        global $wpdb;
        $table = $wpdb->prefix . self::PRESENCE_TABLE;
        // Preserve started_at if a row already exists for this (form, user).
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT started_at FROM $table WHERE form_id = %d AND user_id = %d",
            (int) $form_id, (int) $user->ID
        ) );
        $started = (int) $existing ?: time();
        $wpdb->replace( $table, [
            'form_id'    => (int) $form_id,
            'user_id'    => (int) $user->ID,
            'user_name'  => (string) $user->display_name,
            'user_email' => (string) $user->user_email,
            'avatar_url' => get_avatar_url( $user->ID, [ 'size' => 48 ] ),
            'last_seen'  => time(),
            'current_field_id'    => (string) $current_field_id,
            'current_field_label' => mb_substr( (string) $current_field_label, 0, 190 ),
            'started_at' => $started,
        ] );
    }

    public static function present( $form_id ) {
        self::ensure_schema();
        global $wpdb;
        $t = $wpdb->prefix . self::PRESENCE_TABLE;
        // Prune stale rows first (opportunistic).
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM $t WHERE last_seen < %d",
            time() - self::PRESENCE_TTL
        ) );
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT user_id, user_name, user_email, avatar_url, last_seen,
                    current_field_id, current_field_label, started_at
             FROM $t WHERE form_id = %d AND last_seen >= %d ORDER BY last_seen DESC",
            (int) $form_id, time() - self::PRESENCE_TTL
        ), ARRAY_A );
    }

    /* ─────────────────────────────────────────────────────────────
     * 2. Named revision checkpoints — pure convention on existing
     *    revisions table. A revision whose `note` starts with the
     *    marker "📌 " is considered a named checkpoint.
     * ───────────────────────────────────────────────────────────── */
    const CHECKPOINT_MARKER = '📌 ';
    public static function format_checkpoint_note( $name ) {
        $name = trim( wp_strip_all_tags( (string) $name ) );
        if ( $name === '' ) return '';
        return self::CHECKPOINT_MARKER . mb_substr( $name, 0, 120 );
    }
    public static function is_checkpoint( $note ) {
        return is_string( $note ) && strpos( $note, self::CHECKPOINT_MARKER ) === 0;
    }
    public static function checkpoint_name( $note ) {
        if ( ! self::is_checkpoint( $note ) ) return '';
        return trim( mb_substr( $note, mb_strlen( self::CHECKPOINT_MARKER ) ) );
    }

    /* ─────────────────────────────────────────────────────────────
     * 3. Template ratings.
     * ───────────────────────────────────────────────────────────── */
    public static function rate_template( $template_id, $user_id, $stars, $review = '' ) {
        self::ensure_schema();
        global $wpdb;
        $stars = max( 1, min( 5, (int) $stars ) );
        $wpdb->replace( $wpdb->prefix . self::RATINGS_TABLE, [
            'template_id' => (string) $template_id,
            'user_id'     => (int) $user_id,
            'stars'       => $stars,
            'review'      => mb_substr( (string) $review, 0, 1000 ),
            'created_at'  => time(),
        ] );
    }

    public static function template_ratings( $template_id ) {
        self::ensure_schema();
        global $wpdb;
        $t = $wpdb->prefix . self::RATINGS_TABLE;
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT user_id, stars, review, created_at FROM $t WHERE template_id = %s ORDER BY created_at DESC",
            (string) $template_id
        ), ARRAY_A );
        // Attach display names.
        foreach ( $rows as &$r ) {
            $u = get_userdata( (int) $r['user_id'] );
            $r['user_name'] = $u ? $u->display_name : 'Anonymous';
        }
        return $rows;
    }

    public static function template_summary( $template_id ) {
        self::ensure_schema();
        global $wpdb;
        $t = $wpdb->prefix . self::RATINGS_TABLE;
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT AVG(stars) AS avg_stars, COUNT(*) AS n FROM $t WHERE template_id = %s",
            (string) $template_id
        ), ARRAY_A );
        return [
            'avg_stars' => $row ? round( (float) $row['avg_stars'], 1 ) : 0,
            'count'     => $row ? (int) $row['n'] : 0,
        ];
    }

    /* ─────────────────────────────────────────────────────────────
     * 4. External form importers.
     * Each returns [ 'title'=>..., 'steps'=>[[fields=>[...]]], ...]
     * in the FormYantra form schema.
     * ───────────────────────────────────────────────────────────── */
    public static function import_google_forms_url( $url ) {
        $url = esc_url_raw( trim( (string) $url ) );
        if ( strpos( $url, 'docs.google.com/forms' ) === false ) {
            return new WP_Error( 'bad_url', 'Not a Google Forms URL.' );
        }
        // Ensure we hit the viewform variant (published, not editor).
        if ( strpos( $url, '/viewform' ) === false ) {
            $url = rtrim( $url, '/' ) . '/viewform';
        }
        $resp = wp_remote_get( $url, [ 'timeout' => 20, 'redirection' => 5 ] );
        if ( is_wp_error( $resp ) ) return $resp;
        $html = wp_remote_retrieve_body( $resp );
        if ( ! $html ) return new WP_Error( 'empty', 'Google Forms returned empty response.' );

        // Google embeds the form spec in a JS var FB_PUBLIC_LOAD_DATA_.
        if ( ! preg_match( '/FB_PUBLIC_LOAD_DATA_\s*=\s*(\[.*?\]);<\/script>/s', $html, $m ) ) {
            return new WP_Error( 'no_spec', 'Could not find form data on the Google Forms page. Make sure it is public.' );
        }
        $spec = json_decode( $m[1], true );
        if ( ! is_array( $spec ) ) return new WP_Error( 'parse', 'Failed to parse Google Forms data.' );

        // Google Forms spec: $spec[1][1] is the array of question blocks.
        //   Each block: [id, title, description, type_code, [answers...]]
        $title = isset( $spec[1][8] ) ? (string) $spec[1][8] : ( isset( $spec[3] ) ? (string) $spec[3] : 'Imported form' );
        $desc  = isset( $spec[1][0] ) ? (string) $spec[1][0] : '';
        $blocks = isset( $spec[1][1] ) && is_array( $spec[1][1] ) ? $spec[1][1] : [];

        $fields = [];
        // Map Google Forms question type codes → FormYantra field types.
        $type_map = [
            0 => 'text',      // Short answer
            1 => 'textarea',  // Paragraph
            2 => 'radio',     // Multiple choice
            3 => 'select',    // Dropdown
            4 => 'checkbox',  // Checkboxes
            5 => 'range',     // Linear scale
            6 => 'section',   // Section header
            7 => 'select',    // Grid — flatten to select
            9 => 'date',      // Date
            10 => 'time',     // Time
            11 => 'section',  // Page break
            13 => 'file',     // File upload
            18 => 'rating',   // Rating
        ];
        foreach ( $blocks as $b ) {
            $q_title = (string) ( $b[1] ?? '' );
            $q_desc  = (string) ( $b[2] ?? '' );
            $q_type  = (int) ( $b[3] ?? 0 );
            $q_id    = 'g' . ( $b[0] ?? '' );
            $type    = $type_map[ $q_type ] ?? 'text';
            $field   = [
                'id'          => $q_id,
                'label'       => $q_title ?: ( 'Question ' . ( count( $fields ) + 1 ) ),
                'type'        => $type,
                'help'        => $q_desc,
                'required'    => false,
                'placeholder' => '',
            ];
            // Google-detected email question → email input.
            if ( $type === 'text' && preg_match( '/email/i', $q_title ) ) $field['type'] = 'email';
            // Answers list for select/radio/checkbox.
            $answers = $b[4][0][1] ?? null;
            if ( is_array( $answers ) && in_array( $type, [ 'select', 'radio', 'checkbox' ], true ) ) {
                $opts = [];
                foreach ( $answers as $a ) if ( isset( $a[0] ) && $a[0] !== '' ) $opts[] = (string) $a[0];
                if ( $opts ) $field['options'] = $opts;
            }
            // Required flag is stored on ($b[4][0][2] ?? 0) == 1.
            $req = $b[4][0][2] ?? 0;
            if ( $req ) $field['required'] = true;
            $fields[] = $field;
        }
        return self::wrap_form( $title, $desc, $fields );
    }

    public static function import_typeform_json( $json ) {
        $spec = is_string( $json ) ? json_decode( $json, true ) : $json;
        if ( ! is_array( $spec ) ) return new WP_Error( 'parse', 'Invalid Typeform JSON.' );
        $title = (string) ( $spec['title'] ?? 'Imported Typeform' );
        $fields = [];
        $type_map = [
            'short_text'        => 'text',
            'long_text'         => 'textarea',
            'email'             => 'email',
            'phone_number'      => 'tel',
            'number'            => 'number',
            'multiple_choice'   => 'radio',
            'dropdown'          => 'select',
            'yes_no'            => 'yesno',
            'rating'            => 'rating',
            'opinion_scale'     => 'range',
            'date'              => 'date',
            'file_upload'       => 'file',
            'website'           => 'url',
            'nps'               => 'nps',
            'statement'         => 'html',
        ];
        foreach ( (array) ( $spec['fields'] ?? [] ) as $f ) {
            $t = $type_map[ $f['type'] ?? '' ] ?? 'text';
            $field = [
                'id'       => 't_' . ( $f['id'] ?? uniqid() ),
                'label'    => (string) ( $f['title'] ?? '' ),
                'type'     => $t,
                'help'     => (string) ( $f['properties']['description'] ?? '' ),
                'required' => ! empty( $f['validations']['required'] ),
            ];
            $choices = $f['properties']['choices'] ?? null;
            if ( is_array( $choices ) && in_array( $t, [ 'radio', 'select', 'checkbox' ], true ) ) {
                $field['options'] = array_map( function( $c ) { return (string) ( $c['label'] ?? '' ); }, $choices );
            }
            $fields[] = $field;
        }
        return self::wrap_form( $title, '', $fields );
    }

    public static function import_jotform_json( $json ) {
        $spec = is_string( $json ) ? json_decode( $json, true ) : $json;
        if ( ! is_array( $spec ) ) return new WP_Error( 'parse', 'Invalid Jotform JSON.' );
        // Jotform API response format: content.title + content.questions{qid → props}
        $c = $spec['content'] ?? $spec;
        $title = (string) ( $c['title'] ?? 'Imported Jotform' );
        $questions = is_array( $c['questions'] ?? null ) ? $c['questions'] : [];
        $type_map = [
            'control_textbox'    => 'text',
            'control_textarea'   => 'textarea',
            'control_email'      => 'email',
            'control_phone'      => 'tel',
            'control_number'     => 'number',
            'control_dropdown'   => 'select',
            'control_radio'      => 'radio',
            'control_checkbox'   => 'checkbox',
            'control_datetime'   => 'date',
            'control_time'       => 'time',
            'control_fileupload' => 'file',
            'control_rating'     => 'rating',
            'control_scale'      => 'range',
            'control_head'       => 'section',
            'control_signature'  => 'signature',
            'control_fullname'   => 'name',
            'control_address'    => 'address',
        ];
        // Sort by numeric order property.
        uasort( $questions, function( $a, $b ) { return (int) ( $a['order'] ?? 0 ) - (int) ( $b['order'] ?? 0 ); } );
        $fields = [];
        foreach ( $questions as $qid => $q ) {
            $t = $type_map[ $q['type'] ?? '' ] ?? 'text';
            $field = [
                'id'       => 'j_' . $qid,
                'label'    => (string) ( $q['text'] ?? '' ),
                'type'     => $t,
                'help'     => (string) ( $q['description'] ?? '' ),
                'required' => ( ( $q['required'] ?? 'No' ) === 'Yes' ),
                'placeholder' => (string) ( $q['hint'] ?? '' ),
            ];
            $options = $q['options'] ?? '';
            if ( $options && in_array( $t, [ 'select', 'radio', 'checkbox' ], true ) ) {
                $field['options'] = array_values( array_filter( array_map( 'trim', explode( '|', $options ) ) ) );
            }
            $fields[] = $field;
        }
        return self::wrap_form( $title, '', $fields );
    }

    /** Wrap parsed fields into a FormYantra form definition (single step). */
    private static function wrap_form( $title, $description, $fields ) {
        return [
            'title'       => $title,
            'description' => $description,
            'status'      => 'draft',
            'steps'       => [ [
                'name'   => 'Step 1',
                'fields' => $fields,
            ] ],
            'settings'    => [
                'submitText'      => 'Submit',
                'successMessage'  => 'Thanks — your response has been received.',
            ],
        ];
    }
}
