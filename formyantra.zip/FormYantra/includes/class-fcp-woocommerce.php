<?php
/**
 * FormYantra — WooCommerce integration.
 *
 * Real integration with WooCommerce: lists products for the form builder,
 * creates real WC orders from submissions, and links the order back to
 * the FormCraft submission row. Only loads when WooCommerce is active —
 * every public method is a no-op (and returns a clear error) otherwise.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_WooCommerce {

    public static function is_active() {
        return class_exists( 'WooCommerce' ) && function_exists( 'wc_get_product' );
    }

    public static function status() {
        if ( ! self::is_active() ) {
            return [
                'active'   => false,
                'version'  => null,
                'currency' => null,
                'message'  => 'WooCommerce is not installed or activated on this site.',
            ];
        }
        return [
            'active'   => true,
            'version'  => defined( 'WC_VERSION' ) ? WC_VERSION : null,
            'currency' => get_woocommerce_currency(),
            'message'  => 'WooCommerce is active.',
        ];
    }

    /**
     * Return up to N published products with a snapshot the form
     * builder can render. Variations are flattened to one entry per
     * variation so the admin can pick "T-Shirt — Red / L" directly.
     */
    public static function list_products( $args = [] ) {
        if ( ! self::is_active() ) return [];
        $defaults = [
            'limit'   => 100,
            'status'  => 'publish',
            'orderby' => 'date',
            'order'   => 'DESC',
        ];
        if ( ! empty( $args['search'] ) ) {
            $defaults['s'] = $args['search'];
        }
        $args = wp_parse_args( $args, $defaults );
        $products = wc_get_products( $args );
        $out = [];
        foreach ( $products as $p ) {
            $out[] = self::format_product( $p );
        }
        return $out;
    }

    public static function get_product( $id ) {
        if ( ! self::is_active() ) return null;
        $p = wc_get_product( (int) $id );
        return $p ? self::format_product( $p ) : null;
    }

    private static function format_product( $p ) {
        $img_id = $p->get_image_id();
        $variations = [];
        if ( $p->is_type( 'variable' ) ) {
            foreach ( $p->get_available_variations() as $v ) {
                $attrs = is_array( $v['attributes'] ?? null ) ? $v['attributes'] : [];
                $variations[] = [
                    'id'    => (int) $v['variation_id'],
                    'name'  => implode( ' / ', array_values( array_filter( $attrs ) ) ),
                    'price' => (float) ( $v['display_price'] ?? 0 ),
                    'in_stock' => ! empty( $v['is_in_stock'] ),
                ];
            }
        }
        return [
            'id'         => $p->get_id(),
            'name'       => $p->get_name(),
            'price'      => (float) $p->get_price(),
            'regular'    => (float) $p->get_regular_price(),
            'currency'   => get_woocommerce_currency(),
            'sku'        => (string) $p->get_sku(),
            'stock'      => $p->get_stock_status(),
            'image'      => $img_id ? wp_get_attachment_image_url( $img_id, 'thumbnail' ) : '',
            'type'       => $p->get_type(),
            'permalink'  => get_permalink( $p->get_id() ),
            'variations' => $variations,
        ];
    }

    /**
     * Create a WooCommerce order from a submission. Re-reads each product
     * from WC so the saved-form snapshot can't lie about price.
     *
     * @param array $form    The hydrated form definition (with steps[]).
     * @param array $data    The cleaned submission data (label-keyed).
     * @param int   $sid     The submission row ID.
     * @param array $payment Optional: [ 'paid' => bool, 'amount' => float, 'currency' => str, 'gateway' => str, 'id' => str ]
     *
     * @return int|WP_Error  The new WC order ID, or an error.
     */
    public static function create_order_from_submission( $form, $data, $sid, $payment = [] ) {
        if ( ! self::is_active() ) {
            return new WP_Error( 'wc_inactive', 'WooCommerce is not active on this site.' );
        }

        $items = self::extract_line_items( $form, $data );
        if ( empty( $items ) ) {
            return new WP_Error( 'wc_no_items', 'No WooCommerce product was selected in this submission.' );
        }

        $order = wc_create_order();
        if ( is_wp_error( $order ) ) return $order;

        // ---- Billing address from form data ----
        $email = '';
        $name  = '';
        $phone = '';
        foreach ( $data as $k => $v ) {
            if ( ! is_string( $v ) ) continue;
            if ( ! $email && is_email( $v ) ) $email = $v;
            $lk = strtolower( $k );
            if ( ! $name  && preg_match( '/(^|\s)(name|full ?name|your name)/i', $lk ) ) $name = $v;
            if ( ! $phone && preg_match( '/(phone|mobile|tel)/i', $lk ) ) $phone = $v;
        }
        if ( ! $name ) {
            $name = $data['name'] ?? $data['Name'] ?? $data['Full Name'] ?? '';
        }
        $parts = $name ? preg_split( '/\s+/', trim( $name ), 2 ) : [];
        $first = $parts[0] ?? '';
        $last  = $parts[1] ?? '';

        $order->set_address( [
            'first_name' => $first,
            'last_name'  => $last,
            'email'      => $email,
            'phone'      => $phone,
            'address_1'  => $data['Address'] ?? $data['address'] ?? '',
            'city'       => $data['City']    ?? $data['city']    ?? '',
            'state'      => $data['State']   ?? $data['state']   ?? '',
            'postcode'   => $data['Zip Code'] ?? $data['zip']    ?? '',
            'country'    => $data['Country'] ?? $data['country'] ?? '',
        ], 'billing' );

        // ---- Line items ----
        foreach ( $items as $item ) {
            $product_id = $item['variation_id'] ?: $item['product_id'];
            $product = wc_get_product( $product_id );
            if ( ! $product ) continue;
            $order->add_product( $product, max( 1, (int) $item['quantity'] ) );
        }

        // Link the order back to the submission so the admin can pivot
        // either way (and so resubmissions / refunds can be matched).
        $order->add_meta_data( '_fcp_submission_id', (int) $sid, true );
        $order->add_meta_data( '_fcp_form_id', (int) ( $form['id'] ?? 0 ), true );
        $order->add_meta_data( '_fcp_form_title', sanitize_text_field( $form['title'] ?? '' ), true );

        $order->calculate_totals();

        if ( ! empty( $payment['paid'] ) ) {
            $order->set_payment_method( $payment['gateway'] ?? 'other' );
            $order->set_payment_method_title( $payment['gateway_title'] ?? ucfirst( $payment['gateway'] ?? 'FormYantra' ) );
            if ( ! empty( $payment['id'] ) ) {
                $order->set_transaction_id( sanitize_text_field( $payment['id'] ) );
            }
            $order->payment_complete( $payment['id'] ?? '' );
        } else {
            $order->update_status(
                'pending',
                __( 'Submitted via FormYantra — awaiting payment.', 'formcraft-pro' )
            );
        }

        return $order->get_id();
    }

    /**
     * Walk the submitted form and pull every wc-products field into a
     * list of { product_id, variation_id, quantity } rows. The form
     * engine flattens these to label-keyed values:
     *   data["<label>"]              → chosen product ID (radio value)
     *   data["<label> Quantity"]     → integer (optional, defaults to 1)
     *   data["<label> Variation"]    → variation ID (optional)
     */
    private static function extract_line_items( $form, $data ) {
        $items = [];
        foreach ( $form['steps'] ?? [] as $step ) {
            foreach ( $step['fields'] ?? [] as $field ) {
                if ( ( $field['type'] ?? '' ) !== 'wc-products' ) continue;
                $label = $field['label'] ?? 'Product';

                $picked  = (int) ( $data[ $label ] ?? 0 );
                if ( $picked <= 0 ) continue;
                $var_id  = (int) ( $data[ $label . ' Variation' ] ?? 0 );
                $qty     = max( 1, (int) ( $data[ $label . ' Quantity' ] ?? 1 ) );
                $items[] = [
                    'product_id'   => $picked,
                    'variation_id' => $var_id,
                    'quantity'     => $qty,
                ];
            }
        }
        return $items;
    }

    /**
     * Detect whether the form contains a wc-products field — used by the
     * submit pipeline to decide whether to call create_order_from_submission.
     */
    public static function form_has_wc_field( $form ) {
        foreach ( $form['steps'] ?? [] as $step ) {
            foreach ( $step['fields'] ?? [] as $field ) {
                if ( ( $field['type'] ?? '' ) === 'wc-products' ) return true;
            }
        }
        return false;
    }

    public static function admin_order_url( $order_id ) {
        $order_id = (int) $order_id;
        if ( ! $order_id ) return '';
        // High-Performance Order Storage (WC 8+) uses a separate page; the
        // legacy permalink still works as a fallback redirect.
        if ( class_exists( '\\Automattic\\WooCommerce\\Utilities\\OrderUtil' )
             && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
            return admin_url( 'admin.php?page=wc-orders&action=edit&id=' . $order_id );
        }
        return admin_url( 'post.php?post=' . $order_id . '&action=edit' );
    }
}
