<?php
/**
 * FormYantra - AI form generator (Anthropic Claude).
 *
 * Calls the Anthropic Messages API with a system prompt that forces JSON
 * output matching the plugin's form schema. The admin's API key lives in
 * fcp_settings.ai.api_key — never exposed to the public form.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_AI {

    const API_ENDPOINT = 'https://api.anthropic.com/v1/messages';
    const API_VERSION  = '2023-06-01';

    /**
     * Generate a form definition from a natural-language description.
     *
     * @param string $prompt   User's description ("a job application form for chefs").
     * @return array|WP_Error  The form steps/fields ready to drop into the builder.
     */
    public static function generate_form( $prompt ) {
        $settings = get_option( 'fcp_settings', [] );
        $cfg      = isset( $settings['ai'] ) ? $settings['ai'] : [];
        $key      = isset( $cfg['api_key'] ) ? trim( $cfg['api_key'] ) : '';
        $model    = isset( $cfg['model'] ) && $cfg['model'] ? $cfg['model'] : 'claude-haiku-4-5-20251001';

        if ( $key === '' ) {
            return new WP_Error(
                'ai_not_configured',
                'AI form generation is not configured. Add your Anthropic API key under Settings → AI Assistant.',
                [ 'status' => 400 ]
            );
        }

        $prompt = trim( wp_strip_all_tags( (string) $prompt ) );
        if ( strlen( $prompt ) < 3 ) {
            return new WP_Error( 'bad_prompt', 'Please describe the form you want in at least a few words.', [ 'status' => 400 ] );
        }
        if ( strlen( $prompt ) > 2000 ) {
            $prompt = substr( $prompt, 0, 2000 );
        }

        $system = self::build_system_prompt();

        $resp = wp_remote_post( self::API_ENDPOINT, [
            'timeout' => 60,
            'headers' => [
                'x-api-key'         => $key,
                'anthropic-version' => self::API_VERSION,
                'content-type'      => 'application/json',
            ],
            'body' => wp_json_encode( [
                'model'      => $model,
                'max_tokens' => 4000,
                'system'     => $system,
                'messages'   => [
                    [ 'role' => 'user', 'content' => $prompt ],
                ],
            ] ),
        ] );

        if ( is_wp_error( $resp ) ) {
            return new WP_Error( 'ai_http', $resp->get_error_message(), [ 'status' => 502 ] );
        }
        $code = (int) wp_remote_retrieve_response_code( $resp );
        $body = json_decode( wp_remote_retrieve_body( $resp ), true );

        if ( $code === 401 || $code === 403 ) {
            return new WP_Error( 'ai_auth', 'Anthropic rejected the API key. Check it under Settings → AI Assistant.', [ 'status' => 401 ] );
        }
        if ( $code >= 400 || ! is_array( $body ) ) {
            $msg = isset( $body['error']['message'] ) ? $body['error']['message'] : ( 'HTTP ' . $code );
            return new WP_Error( 'ai_api', 'Anthropic API error: ' . $msg, [ 'status' => 502 ] );
        }

        // Concatenate text blocks (Claude can return multiple content blocks).
        $text = '';
        if ( isset( $body['content'] ) && is_array( $body['content'] ) ) {
            foreach ( $body['content'] as $block ) {
                if ( isset( $block['type'] ) && $block['type'] === 'text' && isset( $block['text'] ) ) {
                    $text .= $block['text'];
                }
            }
        }
        if ( $text === '' ) {
            return new WP_Error( 'ai_empty', 'AI returned an empty response. Try a different prompt.', [ 'status' => 502 ] );
        }

        // The system prompt instructs Claude to return ONLY JSON, but defensively
        // strip any markdown code fences (```json ... ```) before parsing.
        $clean = trim( $text );
        if ( strpos( $clean, '```' ) !== false ) {
            $clean = preg_replace( '/^```(?:json)?\s*/i', '', $clean );
            $clean = preg_replace( '/```\s*$/', '', $clean );
            $clean = trim( $clean );
        }

        $form = json_decode( $clean, true );
        if ( ! is_array( $form ) ) {
            return new WP_Error( 'ai_parse', 'AI returned invalid JSON. Try a different prompt.', [ 'status' => 502, 'raw' => substr( $text, 0, 500 ) ] );
        }

        $form = self::sanitize_form( $form );
        if ( empty( $form['steps'] ) ) {
            return new WP_Error( 'ai_empty_form', 'AI returned no usable fields. Try a more specific prompt.', [ 'status' => 502 ] );
        }

        return $form;
    }

    private static function build_system_prompt() {
        return 'You are a form builder for FormYantra, a WordPress plugin. ' .
               "Given a user's description, output a JSON object describing a multi-step form. " .
               "Output ONLY the JSON — no prose, no markdown fences.\n\n" .
               "Schema:\n" .
               "{\n" .
               '  "title": string (3-80 chars),' . "\n" .
               '  "description": string (optional, ≤200 chars),' . "\n" .
               '  "steps": [' . "\n" .
               '    { "id": "step_1", "title": string, "fields": [Field, ...] }' . "\n" .
               '  ],' . "\n" .
               '  "settings": { "submitText": string, "successMessage": string }' . "\n" .
               "}\n\n" .
               "Each Field object:\n" .
               '  { "id": "f_<random>", "type": <type>, "label": string, "required": boolean, "placeholder"?: string, "help"?: string }' . "\n" .
               'Choice fields ("select", "multiselect", "radio", "checkbox", "yesno") add: "options": string[]' . "\n" .
               'Product field adds: "products": [{ "name": string, "price": number }, ...]' . "\n" .
               'Pricing field adds: "tiers": [{ "name": string, "price": number, "features": string[] }, ...]' . "\n" .
               'Rating field adds: "max": number (3-10)' . "\n" .
               'Range field adds: "min": number, "max": number, "step": number, "defaultValue": number' . "\n" .
               'Calculation field adds: "formula": string (use {Field Label} placeholders), "decimals": number, "prefix"?: string, "suffix"?: string' . "\n" .
               "\nAvailable field types:\n" .
               '  Basic: text, textarea, email, tel, number, password, url, hidden' . "\n" .
               '  Choice: select, multiselect, radio, checkbox, toggle, rating, yesno' . "\n" .
               '  Advanced: file, image, date, time, datetime, range, color, signature, otp' . "\n" .
               '  Business: name, address, city, state, country, zip, company, gst' . "\n" .
               '  Payment: product, pricing, coupon, calculation, payment, bank, upi' . "\n" .
               '  Layout: section, divider, html, gdpr' . "\n\n" .
               "Rules:\n" .
               "- Use multiple steps (2-4) only if the form is long (>8 fields). Otherwise use a single step.\n" .
               "- Group related fields logically per step.\n" .
               "- Always include an email field for contact forms.\n" .
               "- Use the Name field type for full-name capture (not generic text).\n" .
               "- Set required=true on email, name, and other clearly required inputs.\n" .
               "- Keep field labels short (1-4 words). Use Help text for clarifications.\n" .
               "- For pricing / order forms, include Product or Pricing field with realistic prices.\n" .
               "- Field IDs must be unique within the form.";
    }

    /**
     * Defensive sanitisation. The AI is mostly reliable but never trust LLM
     * output blindly — strip unknown field types, force IDs, clip strings.
     */
    private static function sanitize_form( $form ) {
        $allowed_types = [
            'text','textarea','email','tel','number','password','url','hidden',
            'select','multiselect','radio','checkbox','toggle','rating','yesno',
            'file','image','date','time','datetime','range','color','signature','otp','captcha',
            'name','address','city','state','country','zip','company','gst',
            'product','pricing','coupon','calculation','payment','bank','upi','card',
            'section','divider','html','columns','gdpr',
        ];

        $out = [
            'title'       => self::clip( $form['title']       ?? 'Untitled Form', 80 ),
            'description' => self::clip( $form['description'] ?? '',              200 ),
            'steps'       => [],
            'settings'    => [
                'submitText'     => self::clip( $form['settings']['submitText']     ?? 'Submit',    40 ),
                'successMessage' => self::clip( $form['settings']['successMessage'] ?? 'Thanks for your submission!', 200 ),
            ],
        ];

        if ( ! isset( $form['steps'] ) || ! is_array( $form['steps'] ) ) return $out;

        $field_counter = 0;
        $used_ids = [];
        foreach ( $form['steps'] as $i => $step ) {
            if ( ! is_array( $step ) ) continue;
            $clean_step = [
                'id'     => 'step_' . ( $i + 1 ),
                'title'  => self::clip( $step['title'] ?? 'Step ' . ( $i + 1 ), 80 ),
                'fields' => [],
            ];
            if ( ! isset( $step['fields'] ) || ! is_array( $step['fields'] ) ) {
                $out['steps'][] = $clean_step;
                continue;
            }
            foreach ( $step['fields'] as $f ) {
                if ( ! is_array( $f ) ) continue;
                $type = $f['type'] ?? 'text';
                if ( ! in_array( $type, $allowed_types, true ) ) continue;

                // Ensure unique id
                $id = isset( $f['id'] ) ? sanitize_key( $f['id'] ) : '';
                if ( $id === '' || isset( $used_ids[ $id ] ) ) {
                    $id = 'f_' . ( ++$field_counter );
                    while ( isset( $used_ids[ $id ] ) ) $id = 'f_' . ( ++$field_counter );
                }
                $used_ids[ $id ] = true;

                $clean = [
                    'id'       => $id,
                    'type'     => $type,
                    'label'    => self::clip( $f['label'] ?? ucfirst( $type ), 80 ),
                    'required' => ! empty( $f['required'] ),
                ];
                if ( ! empty( $f['placeholder'] ) ) $clean['placeholder'] = self::clip( $f['placeholder'], 120 );
                if ( ! empty( $f['help'] ) )        $clean['help']        = self::clip( $f['help'], 200 );

                if ( in_array( $type, [ 'select', 'multiselect', 'radio', 'checkbox', 'yesno' ], true ) ) {
                    $opts = isset( $f['options'] ) && is_array( $f['options'] ) ? $f['options'] : [];
                    $clean['options'] = array_values( array_filter( array_map( function ( $o ) {
                        return self::clip( (string) $o, 100 );
                    }, $opts ) ) );
                    if ( empty( $clean['options'] ) ) $clean['options'] = [ 'Option 1', 'Option 2' ];
                }
                if ( $type === 'product' && isset( $f['products'] ) && is_array( $f['products'] ) ) {
                    $clean['products'] = [];
                    foreach ( $f['products'] as $p ) {
                        if ( ! is_array( $p ) ) continue;
                        $clean['products'][] = [
                            'name'  => self::clip( (string) ( $p['name'] ?? '' ), 80 ),
                            'price' => (float) ( $p['price'] ?? 0 ),
                        ];
                    }
                }
                if ( $type === 'pricing' && isset( $f['tiers'] ) && is_array( $f['tiers'] ) ) {
                    $clean['tiers'] = [];
                    foreach ( $f['tiers'] as $t ) {
                        if ( ! is_array( $t ) ) continue;
                        $clean['tiers'][] = [
                            'name'     => self::clip( (string) ( $t['name'] ?? '' ), 80 ),
                            'price'    => (float) ( $t['price'] ?? 0 ),
                            'features' => array_values( array_filter( array_map( function ( $x ) {
                                return self::clip( (string) $x, 100 );
                            }, (array) ( $t['features'] ?? [] ) ) ) ),
                        ];
                    }
                }
                if ( $type === 'rating' ) {
                    $clean['max'] = max( 3, min( 10, (int) ( $f['max'] ?? 5 ) ) );
                }
                if ( $type === 'range' ) {
                    $clean['min']  = (float) ( $f['min']  ?? 0 );
                    $clean['max']  = (float) ( $f['max']  ?? 100 );
                    $clean['step'] = (float) ( $f['step'] ?? 1 );
                    $clean['defaultValue'] = (float) ( $f['defaultValue'] ?? 50 );
                }
                if ( $type === 'calculation' ) {
                    $clean['formula']  = self::clip( (string) ( $f['formula']  ?? '' ), 500 );
                    $clean['decimals'] = max( 0, min( 6, (int) ( $f['decimals'] ?? 2 ) ) );
                    $clean['prefix']   = self::clip( (string) ( $f['prefix']   ?? '' ), 8 );
                    $clean['suffix']   = self::clip( (string) ( $f['suffix']   ?? '' ), 8 );
                }
                $clean_step['fields'][] = $clean;
            }
            $out['steps'][] = $clean_step;
        }
        return $out;
    }

    private static function clip( $s, $max ) {
        $s = sanitize_text_field( (string) $s );
        return mb_substr( $s, 0, $max );
    }

    /* ===================================================================
     * v2.58 — AI Smart Layer.
     * Seven additional capabilities built on the same Anthropic client.
     * Each method has a tight, deterministic prompt + parses JSON when
     * structured output is needed. All methods return WP_Error when the
     * API key is missing so the UI can prompt the admin to configure.
     * =================================================================== */

    /**
     * v2.59 — Public translate wrapper. FCP_I18n calls this when DeepL
     * and Google Translate aren't configured. Just an exposed alias of
     * ask() — kept separate so we can rate-limit translate calls
     * independently of other AI ops in the future.
     */
    public static function call_translate( $system, $user, $max_tokens = 800 ) {
        return self::ask( $system, $user, $max_tokens );
    }

    /**
     * Shared API call helper — DRYs the wp_remote_post boilerplate.
     * Returns the model's plain-text response, or WP_Error.
     */
    private static function ask( $system, $user, $max_tokens = 400 ) {
        $settings = get_option( 'fcp_settings', [] );
        $cfg      = isset( $settings['ai'] ) ? $settings['ai'] : [];
        $key      = isset( $cfg['api_key'] ) ? trim( $cfg['api_key'] ) : '';
        $model    = isset( $cfg['model'] ) && $cfg['model'] ? $cfg['model'] : 'claude-haiku-4-5-20251001';
        if ( $key === '' ) {
            return new WP_Error( 'ai_not_configured',
                'AI is not configured. Add your Anthropic API key under Settings → AI Assistant.',
                [ 'status' => 400 ] );
        }
        $resp = wp_remote_post( self::API_ENDPOINT, [
            'timeout' => 30,
            'headers' => [
                'x-api-key'         => $key,
                'anthropic-version' => self::API_VERSION,
                'content-type'      => 'application/json',
            ],
            'body' => wp_json_encode( [
                'model'      => $model,
                'max_tokens' => (int) $max_tokens,
                'system'     => (string) $system,
                'messages'   => [ [ 'role' => 'user', 'content' => (string) $user ] ],
            ] ),
        ] );
        if ( is_wp_error( $resp ) ) return $resp;
        $code = wp_remote_retrieve_response_code( $resp );
        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error( 'ai_http_' . $code, 'AI provider returned HTTP ' . $code, [ 'status' => 502 ] );
        }
        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        $text = '';
        if ( isset( $body['content'][0]['text'] ) ) $text = (string) $body['content'][0]['text'];
        return trim( $text );
    }

    /**
     * Strip code fences + parse a JSON response from the model. Some
     * answers come wrapped in ```json fences; we strip them before parsing.
     */
    private static function parse_json( $text ) {
        $text = trim( (string) $text );
        $text = preg_replace( '/^```(?:json)?\s*/i', '', $text );
        $text = preg_replace( '/```\s*$/', '', $text );
        $decoded = json_decode( $text, true );
        return is_array( $decoded ) ? $decoded : null;
    }

    /**
     * 1) Form purpose detection.
     * Given an existing form's titles + field labels, return one of a
     * fixed set of purposes so the builder can suggest a matching
     * template / confirmation message / status pipeline label.
     */
    public static function detect_purpose( $form ) {
        $labels = [];
        foreach ( ( $form['steps'] ?? [] ) as $step ) {
            foreach ( ( $step['fields'] ?? [] ) as $f ) {
                $labels[] = ( $f['label'] ?? '' ) . ' (' . ( $f['type'] ?? '' ) . ')';
            }
        }
        $summary = ( $form['title'] ?? '' ) . "\n" . implode( ", ", array_slice( $labels, 0, 30 ) );
        $system  = "You categorize WordPress form purposes. Respond with EXACTLY ONE of these labels, nothing else: CONTACT, LEAD, QUOTE, BOOKING, REGISTRATION, SUPPORT, APPLICATION, SURVEY, PAYMENT, EVENT, FEEDBACK, OTHER.";
        $r = self::ask( $system, $summary, 20 );
        if ( is_wp_error( $r ) ) return $r;
        $purpose = strtoupper( preg_replace( '/[^A-Z]/i', '', $r ) );
        $allowed = [ 'CONTACT','LEAD','QUOTE','BOOKING','REGISTRATION','SUPPORT','APPLICATION','SURVEY','PAYMENT','EVENT','FEEDBACK','OTHER' ];
        return in_array( $purpose, $allowed, true ) ? $purpose : 'OTHER';
    }

    /**
     * 2) Field name normalization.
     * Takes the current label set + returns a map old → suggested clean
     * label. Casual phrases become title-cased nouns. Returns array
     * keyed by original label.
     */
    public static function normalize_field_labels( $labels ) {
        $labels = array_values( array_filter( array_map( 'strval', (array) $labels ) ) );
        if ( ! $labels ) return [];
        $list = implode( "\n", array_map( fn( $l ) => '- ' . $l, $labels ) );
        $system = "You rename form field labels to short, clean, title-cased nouns or noun phrases (max 28 chars each). Examples: 'Your name?' → 'Full Name'; 'How can we help' → 'Message'. Return ONLY a JSON object mapping the original label to the suggested one. No commentary.";
        $r = self::ask( $system, $list, 600 );
        if ( is_wp_error( $r ) ) return $r;
        $map = self::parse_json( $r );
        if ( ! is_array( $map ) ) return [];
        $clean = [];
        foreach ( $map as $orig => $sugg ) {
            $orig = (string) $orig;
            $sugg = sanitize_text_field( (string) $sugg );
            if ( $sugg !== '' && $sugg !== $orig && mb_strlen( $sugg ) <= 60 ) {
                $clean[ $orig ] = $sugg;
            }
        }
        return $clean;
    }

    /**
     * 3) Smart field suggestions while building.
     * Looks at the current form + suggests up to 5 additional fields
     * that are common for this kind of form but currently missing.
     * Each suggestion: { label, type, why }.
     */
    public static function suggest_fields( $form ) {
        $existing = [];
        foreach ( ( $form['steps'] ?? [] ) as $step ) {
            foreach ( ( $step['fields'] ?? [] ) as $f ) {
                $existing[] = ( $f['label'] ?? '' );
            }
        }
        $title = $form['title'] ?? 'Untitled form';
        $user  = "Form title: {$title}\nExisting fields: " . implode( ', ', array_slice( $existing, 0, 30 ) );
        $system = "Suggest up to 5 fields commonly present in this kind of form but missing here. Return ONLY a JSON array. Each item: { \"label\": short title-cased, \"type\": one of (text/email/tel/number/textarea/select/checkbox/radio/date/file/url), \"why\": one short sentence }. No commentary.";
        $r = self::ask( $system, $user, 600 );
        if ( is_wp_error( $r ) ) return $r;
        $arr = self::parse_json( $r );
        if ( ! is_array( $arr ) ) return [];
        $valid_types = [ 'text','email','tel','number','textarea','select','checkbox','radio','date','file','url' ];
        $out = [];
        foreach ( $arr as $item ) {
            if ( ! is_array( $item ) ) continue;
            $type = strtolower( (string) ( $item['type'] ?? 'text' ) );
            if ( ! in_array( $type, $valid_types, true ) ) $type = 'text';
            $label = sanitize_text_field( (string) ( $item['label'] ?? '' ) );
            $why   = sanitize_text_field( (string) ( $item['why'] ?? '' ) );
            if ( $label === '' || in_array( $label, $existing, true ) ) continue;
            $out[] = [
                'label' => mb_substr( $label, 0, 60 ),
                'type'  => $type,
                'why'   => mb_substr( $why, 0, 180 ),
            ];
            if ( count( $out ) >= 5 ) break;
        }
        return $out;
    }

    /**
     * 4) Draft reply suggestion for a submission.
     * Writes a courteous, on-brand reply email body based on the
     * submission's text content + form purpose. Tone arg can be:
     * "professional" | "friendly" | "apologetic".
     */
    public static function draft_reply( $submission_data, $tone = 'professional' ) {
        $tone_map = [ 'professional' => 'professional', 'friendly' => 'friendly', 'apologetic' => 'apologetic' ];
        $tone = $tone_map[ $tone ] ?? 'professional';
        $compact = [];
        foreach ( (array) $submission_data as $k => $v ) {
            if ( strpos( (string) $k, '_' ) === 0 ) continue;
            if ( is_array( $v ) ) $v = implode( ', ', $v );
            if ( ! is_string( $v ) || $v === '' ) continue;
            $compact[] = '- ' . $k . ': ' . self::clip( $v, 400 );
            if ( count( $compact ) >= 25 ) break;
        }
        $user = implode( "\n", $compact );
        $system = "You draft email replies to form submissions. Tone: {$tone}. Write a 3-5 sentence reply that acknowledges what the person wrote and proposes a clear next step. No subject line. No 'Hi {Name}' templating — use the real name from the data. End with 'Best regards,' on its own line. Do not invent facts.";
        return self::ask( $system, $user, 400 );
    }

    /**
     * 5) Submission auto-categorization.
     * Returns one of: LEAD, SUPPORT, COMPLAINT, QUESTION, SPAM, OTHER.
     */
    public static function categorize_submission( $submission_data ) {
        $text = self::collect_text( $submission_data, 1500 );
        if ( $text === '' ) return 'OTHER';
        $system = "Classify this form submission into EXACTLY ONE of: LEAD, SUPPORT, COMPLAINT, QUESTION, SPAM, OTHER. Reply with just the label, no commentary.";
        $r = self::ask( $system, $text, 10 );
        if ( is_wp_error( $r ) ) return $r;
        $cat = strtoupper( preg_replace( '/[^A-Z]/i', '', $r ) );
        $allowed = [ 'LEAD','SUPPORT','COMPLAINT','QUESTION','SPAM','OTHER' ];
        return in_array( $cat, $allowed, true ) ? $cat : 'OTHER';
    }

    /**
     * 6) Sentiment analysis. POSITIVE | NEUTRAL | NEGATIVE.
     */
    public static function analyze_sentiment( $submission_data ) {
        $text = self::collect_text( $submission_data, 1500 );
        if ( $text === '' ) return 'NEUTRAL';
        $system = "Rate sentiment of this form submission. Reply with EXACTLY ONE word: POSITIVE, NEUTRAL, or NEGATIVE.";
        $r = self::ask( $system, $text, 10 );
        if ( is_wp_error( $r ) ) return $r;
        $s = strtoupper( preg_replace( '/[^A-Z]/i', '', $r ) );
        return in_array( $s, [ 'POSITIVE','NEUTRAL','NEGATIVE' ], true ) ? $s : 'NEUTRAL';
    }

    /**
     * 7) OCR via Anthropic vision. Pass an image URL or base64 data URL.
     * Returns plain text extracted from the image. For ID documents,
     * the prompt also asks for a key/value summary.
     */
    public static function ocr_extract( $image_input ) {
        $settings = get_option( 'fcp_settings', [] );
        $cfg      = isset( $settings['ai'] ) ? $settings['ai'] : [];
        $key      = isset( $cfg['api_key'] ) ? trim( $cfg['api_key'] ) : '';
        $model    = isset( $cfg['model'] ) && $cfg['model'] ? $cfg['model'] : 'claude-haiku-4-5-20251001';
        if ( $key === '' ) {
            return new WP_Error( 'ai_not_configured', 'Add your Anthropic API key under Settings → AI Assistant.', [ 'status' => 400 ] );
        }
        $image_block = self::build_image_block( $image_input );
        if ( is_wp_error( $image_block ) ) return $image_block;
        $resp = wp_remote_post( self::API_ENDPOINT, [
            'timeout' => 45,
            'headers' => [
                'x-api-key'         => $key,
                'anthropic-version' => self::API_VERSION,
                'content-type'      => 'application/json',
            ],
            'body' => wp_json_encode( [
                'model'      => $model,
                'max_tokens' => 800,
                'messages'   => [ [ 'role' => 'user', 'content' => [
                    $image_block,
                    [ 'type' => 'text', 'text' => "Extract every readable line of text from this image. If it's an ID document, also list the key fields as 'KEY: VALUE' pairs at the bottom (Name, DOB, ID Number, Expiry, etc.). Reply with raw text only — no commentary, no markdown." ],
                ] ] ],
            ] ),
        ] );
        if ( is_wp_error( $resp ) ) return $resp;
        $code = wp_remote_retrieve_response_code( $resp );
        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error( 'ai_http_' . $code, 'AI vision returned HTTP ' . $code, [ 'status' => 502 ] );
        }
        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        $text = isset( $body['content'][0]['text'] ) ? (string) $body['content'][0]['text'] : '';
        return trim( $text );
    }

    /**
     * Build the image content block for Anthropic vision. Accepts:
     *   - https:// URL → use as-is (type: image, source: url)
     *   - data: URL with base64 → repack into source: base64
     */
    private static function build_image_block( $input ) {
        $input = (string) $input;
        if ( strpos( $input, 'https://' ) === 0 || strpos( $input, 'http://' ) === 0 ) {
            return [ 'type' => 'image', 'source' => [ 'type' => 'url', 'url' => esc_url_raw( $input ) ] ];
        }
        if ( preg_match( '#^data:(image/[a-z]+);base64,(.+)$#', $input, $m ) ) {
            return [ 'type' => 'image', 'source' => [ 'type' => 'base64', 'media_type' => $m[1], 'data' => $m[2] ] ];
        }
        // Try to load from URL stored on server
        if ( strpos( $input, '/' ) === 0 ) {
            // Server path — read + base64
            $path = ABSPATH . ltrim( $input, '/' );
            if ( file_exists( $path ) && is_readable( $path ) ) {
                $bytes = file_get_contents( $path );
                if ( $bytes !== false ) {
                    $mime = function_exists( 'mime_content_type' ) ? mime_content_type( $path ) : 'image/jpeg';
                    return [ 'type' => 'image', 'source' => [ 'type' => 'base64', 'media_type' => $mime, 'data' => base64_encode( $bytes ) ] ];
                }
            }
        }
        return new WP_Error( 'bad_image', 'Image must be an http(s) URL or data:image/...;base64,... URL.', [ 'status' => 400 ] );
    }

    /**
     * Flatten submission text fields for prompt input. Trims to max chars.
     */
    private static function collect_text( $data, $max ) {
        $parts = [];
        foreach ( (array) $data as $k => $v ) {
            if ( strpos( (string) $k, '_' ) === 0 ) continue;
            if ( is_array( $v ) ) $v = implode( ', ', $v );
            if ( ! is_string( $v ) || strlen( $v ) < 2 ) continue;
            $parts[] = $k . ': ' . $v;
        }
        return mb_substr( implode( "\n", $parts ), 0, $max );
    }

    /* ═══════════════════════════════════════════════════════════════════
     * v2.72.61 — Advanced AI features
     * ═══════════════════════════════════════════════════════════════════ */

    /**
     * 8) AI form-fill assistant.
     * Visitor pastes free text ("I'm John Smith at Acme Corp, need enterprise
     * plan, budget $50k, decision by Q2"). AI parses it and returns a map of
     * { fieldLabel: extractedValue } that the runtime prefills.
     */
    public static function fill_from_text( $form, $text ) {
        $text = trim( wp_strip_all_tags( (string) $text ) );
        if ( mb_strlen( $text ) < 5 ) return [];
        if ( mb_strlen( $text ) > 3000 ) $text = mb_substr( $text, 0, 3000 );

        $labels = [];
        foreach ( ( $form['steps'] ?? [] ) as $step ) {
            foreach ( ( $step['fields'] ?? [] ) as $f ) {
                $t = $f['type'] ?? '';
                if ( in_array( $t, [ 'file','image','signature','captcha','payment','html','divider','section','otp','video' ], true ) ) continue;
                $label = trim( (string) ( $f['label'] ?? '' ) );
                if ( $label === '' ) continue;
                $labels[] = $label . ' (' . $t . ')';
            }
        }
        if ( ! $labels ) return [];

        $system = "You extract structured field values from free-form text a visitor pasted into a form. Given the list of form fields and the visitor's text, respond with STRICT JSON — no prose, no markdown fences — mapping each matched field's exact label to the extracted value. Rules: (1) only include fields you can extract confidently; leave unclear fields out. (2) values must be strings. (3) for email fields, only include if you find a real email address. (4) for phone fields, keep digits + '+' only. (5) never invent values — if the text doesn't clearly say it, skip the field. Example response: {\"Full Name\":\"John Smith\",\"Email\":\"john@acme.com\"}";
        $user   = "FIELDS:\n" . implode( "\n", array_slice( $labels, 0, 40 ) ) . "\n\nVISITOR TEXT:\n" . $text;
        $r = self::ask( $system, $user, 500 );
        if ( is_wp_error( $r ) ) return $r;
        $parsed = self::parse_json( $r );
        if ( ! is_array( $parsed ) ) return [];
        // Cast every value to string; drop empties.
        $out = [];
        foreach ( $parsed as $k => $v ) {
            if ( ! is_string( $k ) || $k === '' ) continue;
            if ( is_array( $v ) ) $v = implode( ', ', $v );
            $v = trim( (string) $v );
            if ( $v !== '' ) $out[ $k ] = $v;
        }
        return $out;
    }

    /**
     * 9) Smart Compose — Gmail-style inline completion.
     * Given the current field label and the prefix the visitor has typed,
     * return a short continuation (1–15 words, no repetition of prefix).
     * Returns empty string when nothing useful applies.
     */
    public static function smart_compose( $form_title, $field_label, $prefix ) {
        $prefix = (string) $prefix;
        // Only meaningful once the visitor has typed a real seed.
        if ( mb_strlen( trim( $prefix ) ) < 8 ) return '';
        if ( mb_strlen( $prefix ) > 400 ) $prefix = mb_substr( $prefix, -400 );
        $system = "You are a Gmail-Smart-Compose-style assistant for a WordPress form. The visitor is typing into a field. Return a SHORT continuation of their current sentence — 1 to 15 words, no more. Rules: (1) do NOT repeat any of the prefix; return ONLY the new text. (2) never start with punctuation. (3) prefer to complete the current sentence rather than start a new one. (4) plain text only, no quotes, no markdown, no explanations. (5) if you cannot confidently continue, respond with the single word NONE.";
        $user   = "FORM: {$form_title}\nFIELD: {$field_label}\nPREFIX: {$prefix}\n\nContinuation:";
        $r = self::ask( $system, $user, 60 );
        if ( is_wp_error( $r ) ) return '';
        $r = trim( (string) $r );
        if ( $r === '' || strcasecmp( $r, 'NONE' ) === 0 ) return '';
        // Strip quotes / trailing punctuation weirdness.
        $r = preg_replace( '/^["\'`]+|["\'`]+$/', '', $r );
        return mb_substr( $r, 0, 200 );
    }

    /**
     * 10) One-line submission summary.
     * "Enterprise lead from Acme, $50k budget, Q2 decision" — a single
     * sentence you can eyeball in the submissions list without opening.
     */
    public static function oneline_summary( $submission_data, $form_title = '' ) {
        $text = self::collect_text( $submission_data, 2000 );
        if ( $text === '' ) return '';
        $system = "Summarize this form submission in ONE sentence, under 120 characters. Focus on the WHO + INTENT + KEY DETAIL (e.g. 'Enterprise lead from Acme, $50k budget, Q2 decision'). No preamble, no 'This person...', just the sentence. Plain text only.";
        $user   = ( $form_title ? "FORM: {$form_title}\n\n" : '' ) . $text;
        $r = self::ask( $system, $user, 100 );
        if ( is_wp_error( $r ) ) return '';
        $r = trim( (string) $r );
        $r = preg_replace( '/^["\'`]+|["\'`]+$/', '', $r );
        return mb_substr( $r, 0, 160 );
    }

    /**
     * 11) AI lead scoring.
     * Returns [ 'score' => 0-100, 'tier' => 'hot'|'warm'|'cold',
     *           'reasoning' => short prose ].
     * Higher score = higher conversion likelihood.
     */
    public static function score_lead( $submission_data, $form_title = '' ) {
        $text = self::collect_text( $submission_data, 2000 );
        if ( $text === '' ) return [ 'score' => 0, 'tier' => 'cold', 'reasoning' => 'No content to score.' ];
        $system = "You are a B2B/B2C sales lead qualification engine. Score this form submission 0–100 for conversion likelihood based on: (a) real-looking name + business email vs. gmail/gibberish, (b) explicit intent signals ('interested', 'need', 'budget', deadline), (c) company/role indicators, (d) message specificity. Respond with STRICT JSON — no prose, no markdown fences — exactly like: {\"score\":78,\"tier\":\"warm\",\"reasoning\":\"Real business email at acme.com, mentions Q2 timeline, no explicit budget.\"} Tier rules: 70+ = hot, 40-69 = warm, below 40 = cold. Reasoning ≤ 140 chars.";
        $user   = ( $form_title ? "FORM: {$form_title}\n\n" : '' ) . $text;
        $r = self::ask( $system, $user, 250 );
        if ( is_wp_error( $r ) ) return [ 'score' => 0, 'tier' => 'cold', 'reasoning' => 'Scoring unavailable.' ];
        $parsed = self::parse_json( $r );
        if ( ! is_array( $parsed ) ) return [ 'score' => 0, 'tier' => 'cold', 'reasoning' => 'Model returned unparseable response.' ];
        $score = max( 0, min( 100, (int) ( $parsed['score'] ?? 0 ) ) );
        $tier  = $score >= 70 ? 'hot' : ( $score >= 40 ? 'warm' : 'cold' );
        $reason = trim( (string) ( $parsed['reasoning'] ?? '' ) );
        if ( $reason === '' ) $reason = 'Score computed from field content.';
        return [ 'score' => $score, 'tier' => $tier, 'reasoning' => mb_substr( $reason, 0, 200 ) ];
    }

    /**
     * 12) AI spam explanation.
     * Translates the machine-token $spam_reasons array + submission content
     * into human prose ("Message text is copy-pasted from a known spam
     * campaign; email uses a disposable domain (tempmail.com); no mouse
     * activity during fill.").
     */
    public static function explain_spam( $submission_data, $spam_reasons ) {
        $reasons = is_array( $spam_reasons ) ? array_map( 'strval', $spam_reasons ) : [];
        $text    = self::collect_text( $submission_data, 1500 );
        $system  = "You are a spam-classification explainer. Given the raw spam signal codes and the submission text, write ONE short paragraph (2-4 sentences) in plain English explaining WHY this submission was flagged as spam. Cite specific evidence from the data (e.g. disposable email domain, gibberish, no engagement). If the signals look weak or the data seems legitimate, say so honestly — the classifier can be wrong. No markdown, no headers, no bullet lists.";
        $user    = "SIGNAL CODES: " . ( $reasons ? implode( ', ', $reasons ) : '(none)' ) . "\n\nSUBMISSION:\n" . $text;
        $r = self::ask( $system, $user, 300 );
        if ( is_wp_error( $r ) ) return 'Explanation unavailable (AI request failed).';
        return trim( (string) $r );
    }
}
