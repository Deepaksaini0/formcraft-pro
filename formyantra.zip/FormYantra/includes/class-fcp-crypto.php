<?php
/**
 * FormYantra — symmetric encryption for field values.
 *
 * Used when a field is marked `access: "encrypted"` in the builder.
 * The visitor's submitted value is encrypted at REST-handler time before
 * the submission row is written, and decrypted at submission-detail
 * render time for authorized viewers only.
 *
 * Cipher: AES-256-CBC. Key derived from wp_salt('auth') so the cipher
 * key is bound to the site — if the DB is exfiltrated without
 * wp-config.php, the values stay unreadable.
 *
 * Encoding: ciphertext is base64'd with a 16-byte random IV prefix and
 * tagged with the constant prefix "fcpenc::" so the decryptor can
 * detect plaintext fields that were saved before the toggle was flipped.
 *
 * NOT for passwords. NOT for things that need to be searched/grouped on.
 * Just for one-time-write, occasionally-read sensitive PII.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_Crypto {

    const PREFIX = 'fcpenc::';
    const CIPHER = 'aes-256-cbc';

    private static function key() {
        return hash( 'sha256', wp_salt( 'auth' ) . '|fcp-crypto-v1', true );
    }

    public static function encrypt( $plain ) {
        if ( ! function_exists( 'openssl_encrypt' ) ) return $plain;
        if ( $plain === null || $plain === '' )       return $plain;
        // Idempotent — if it's already an fcpenc:: blob, don't double-encrypt.
        if ( is_string( $plain ) && strpos( $plain, self::PREFIX ) === 0 ) return $plain;
        $iv     = openssl_random_pseudo_bytes( 16 );
        $cipher = openssl_encrypt( (string) $plain, self::CIPHER, self::key(), OPENSSL_RAW_DATA, $iv );
        if ( $cipher === false ) return $plain;
        return self::PREFIX . base64_encode( $iv . $cipher );
    }

    public static function decrypt( $encoded ) {
        if ( ! is_string( $encoded ) )                            return $encoded;
        if ( strpos( $encoded, self::PREFIX ) !== 0 )             return $encoded;
        if ( ! function_exists( 'openssl_decrypt' ) )             return $encoded;
        $raw = base64_decode( substr( $encoded, strlen( self::PREFIX ) ), true );
        if ( $raw === false || strlen( $raw ) < 17 )              return $encoded;
        $iv     = substr( $raw, 0, 16 );
        $cipher = substr( $raw, 16 );
        $plain  = openssl_decrypt( $cipher, self::CIPHER, self::key(), OPENSSL_RAW_DATA, $iv );
        return $plain === false ? $encoded : $plain;
    }

    /**
     * Walks every field in a form, encrypting values whose corresponding
     * field has access="encrypted". Called from the submit handler
     * before persisting to the DB.
     */
    public static function encrypt_submission( $form, $data ) {
        $protected = self::collect_protected_field_names( $form );
        if ( ! $protected ) return $data;
        foreach ( $protected as $name ) {
            if ( isset( $data[ $name ] ) && is_string( $data[ $name ] ) ) {
                $data[ $name ] = self::encrypt( $data[ $name ] );
            }
        }
        return $data;
    }

    /**
     * Walks submission data + decrypts the access-controlled values for
     * display. Caller (REST or render path) must check viewer permission
     * BEFORE calling this — we don't gate here, we just transform.
     */
    public static function decrypt_submission( $form, $data ) {
        $protected = self::collect_protected_field_names( $form );
        if ( ! $protected ) return $data;
        foreach ( $protected as $name ) {
            if ( isset( $data[ $name ] ) && is_string( $data[ $name ] ) ) {
                $data[ $name ] = self::decrypt( $data[ $name ] );
            }
        }
        return $data;
    }

    /** Build a flat name→true map of every field with access=encrypted. */
    private static function collect_protected_field_names( $form ) {
        $out = [];
        $steps = isset( $form['steps'] ) && is_array( $form['steps'] ) ? $form['steps'] : [];
        foreach ( $steps as $step ) {
            foreach ( ( $step['fields'] ?? [] ) as $field ) {
                if ( isset( $field['access'] ) && $field['access'] === 'encrypted' && ! empty( $field['name'] ) ) {
                    $out[] = (string) $field['name'];
                } elseif ( isset( $field['access'] ) && $field['access'] === 'encrypted' && ! empty( $field['label'] ) ) {
                    // Fallback: data keys often match the label.
                    $out[] = (string) $field['label'];
                }
            }
        }
        return $out;
    }

    /**
     * Check whether the current user is allowed to VIEW a field with the
     * given access setting. Returns true for "all" + when user has cap.
     */
    public static function viewer_can_see( $access, $form ) {
        switch ( $access ) {
            case '':
            case 'all':        return current_user_can( 'edit_posts' );
            case 'manage':     return current_user_can( 'manage_options' );
            case 'editor':     return current_user_can( 'edit_others_posts' );
            case 'admin_only': return current_user_can( 'manage_options' );
            case 'owner':
                $owner = isset( $form['created_by'] ) ? (int) $form['created_by'] : 0;
                return $owner && $owner === get_current_user_id();
            case 'encrypted':  return current_user_can( 'manage_options' );
        }
        return false;
    }
}
