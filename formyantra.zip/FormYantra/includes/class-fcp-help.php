<?php
/**
 * FormYantra — Help / onboarding / diagnostics layer.
 *
 * Three server-side concerns live here:
 *
 *  1. Diagnostics — `run_diagnostics()` runs a list of checks against the
 *     environment (PHP version, WP version, required extensions, DB
 *     tables present, REST endpoints reachable, cron alive, file
 *     permissions) and returns a list of pass/warn/fail rows. Powers
 *     the Diagnostics tab in the Help admin page.
 *
 *  2. Tip catalog — `tips()` returns a curated list of "Did you know?"
 *     entries the front-end rotates through. Each tip has an id (used
 *     for dismissal), an icon, a title, a body, and an optional CTA.
 *     The catalog is editable here — adding a tip is a one-line array push.
 *
 *  3. Tutorials catalog — `tutorials()` returns the list of how-to videos
 *     surfaced on the Help page. We don't host the videos; we ship the
 *     IDs and lazily iframe-embed YouTube when the admin clicks Play.
 *
 * All three are read-only public endpoints under /help/* (no PII so they
 * don't need manage_options; we still gate behind `edit_posts` to keep
 * the routes invisible to anonymous traffic).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_Help {

    public static function bootstrap() {
        add_action( 'rest_api_init', [ __CLASS__, 'register_rest' ] );
    }

    public static function can_use() { return current_user_can( 'edit_posts' ); }

    /* -------------------------------------------------------------------
     * Diagnostics — a curated list of environment checks.
     * Each returns [ status: pass|warn|fail, label, detail, fix?: string ].
     * ----------------------------------------------------------------- */
    public static function run_diagnostics() {
        global $wpdb;
        $out = [];

        // 1. PHP version
        $php = PHP_VERSION;
        $out[] = [
            'group'  => 'Environment',
            'status' => version_compare( $php, '7.4', '>=' ) ? 'pass' : 'fail',
            'label'  => 'PHP version',
            'detail' => $php,
            'fix'    => 'Ask your host to upgrade to PHP 8.1+ — the plugin needs at least 7.4 and is tested up to 8.3.',
        ];

        // 2. WordPress version
        $wp = get_bloginfo( 'version' );
        $out[] = [
            'group'  => 'Environment',
            'status' => version_compare( $wp, '6.2', '>=' ) ? 'pass' : 'warn',
            'label'  => 'WordPress version',
            'detail' => $wp,
            'fix'    => 'Updating WP to the latest stable release fixes a class of REST + security issues.',
        ];

        // 3. Required PHP extensions
        foreach ( [ 'json', 'openssl', 'mbstring', 'curl' ] as $ext ) {
            $loaded = extension_loaded( $ext );
            $out[] = [
                'group'  => 'PHP extensions',
                'status' => $loaded ? 'pass' : 'fail',
                'label'  => 'PHP extension: ' . $ext,
                'detail' => $loaded ? 'loaded' : 'missing',
                'fix'    => $loaded ? null : 'Ask your host to enable the `' . $ext . '` PHP extension. Without it, ' . self::ext_consequence( $ext ),
            ];
        }

        // 4. Plugin DB tables
        $forms_tbl = FCP_DB::forms_table();
        $subs_tbl  = FCP_DB::subs_table();
        foreach ( [ 'forms' => $forms_tbl, 'submissions' => $subs_tbl ] as $name => $tbl ) {
            $exists = (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $tbl ) );
            $out[] = [
                'group'  => 'Database',
                'status' => $exists ? 'pass' : 'fail',
                'label'  => 'Table: ' . $name,
                'detail' => $exists ? $tbl : "missing ($tbl)",
                'fix'    => $exists ? null : 'Deactivate + reactivate the plugin to recreate the missing table.',
            ];
        }

        // 5. Optional tables that ship with newer features
        foreach ( [
            'tokens'  => $wpdb->prefix . 'fcp_api_tokens',
            '2FA'     => $wpdb->prefix . 'fcp_2fa',
            'audit'   => $wpdb->prefix . 'fcp_audit_log',
        ] as $name => $tbl ) {
            $exists = (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $tbl ) );
            $out[] = [
                'group'  => 'Database',
                'status' => $exists ? 'pass' : 'warn',
                'label'  => 'Optional table: ' . $name,
                'detail' => $exists ? $tbl : "not created yet",
                'fix'    => $exists ? null : 'Will be created automatically the first time the feature is used.',
            ];
        }

        // 6. Cron scheduler
        $cron_disabled = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;
        $out[] = [
            'group'  => 'Scheduling',
            'status' => $cron_disabled ? 'warn' : 'pass',
            'label'  => 'WordPress cron',
            'detail' => $cron_disabled ? 'DISABLE_WP_CRON is true — using a system cron?' : 'enabled',
            'fix'    => $cron_disabled ? 'If DISABLE_WP_CRON is set, make sure you have a system cron hitting wp-cron.php — otherwise digests + scheduled reports won\'t fire.' : null,
        ];

        // 7. REST API reachable from server itself
        $rest_url = rest_url( 'fcp/v1/health/ping' );
        $reach    = wp_remote_get( $rest_url, [ 'timeout' => 5 ] );
        $ok       = ! is_wp_error( $reach ) && wp_remote_retrieve_response_code( $reach ) === 200;
        $out[] = [
            'group'  => 'REST API',
            'status' => $ok ? 'pass' : 'warn',
            'label'  => 'Plugin REST namespace reachable',
            'detail' => $ok ? 'fcp/v1 is responding' : 'no response from ' . $rest_url,
            'fix'    => $ok ? null : 'Visit Settings → Permalinks → Save to flush rewrite rules. If still failing, your host\'s firewall may block /wp-json/.',
        ];

        // 8. wp-content/uploads writable
        $upload = wp_upload_dir();
        $write  = ! empty( $upload['basedir'] ) && wp_is_writable( $upload['basedir'] );
        $out[] = [
            'group'  => 'Filesystem',
            'status' => $write ? 'pass' : 'fail',
            'label'  => 'wp-content/uploads writable',
            'detail' => $upload['basedir'] ?? '(unknown)',
            'fix'    => $write ? null : 'File-upload fields will fail to save. Run `chmod 755 wp-content/uploads` or contact your host.',
        ];

        // 9. SSL — required by webhook integrations + most modern APIs
        $is_ssl = is_ssl();
        $out[] = [
            'group'  => 'Security',
            'status' => $is_ssl ? 'pass' : 'warn',
            'label'  => 'HTTPS / SSL',
            'detail' => $is_ssl ? 'site is served over HTTPS' : 'site is served over HTTP',
            'fix'    => $is_ssl ? null : 'Switch the site to HTTPS — Stripe, Razorpay, and most payment gateways will refuse to load on HTTP.',
        ];

        // 10. Memory limit
        $mem  = (int) wp_convert_hr_to_bytes( ini_get( 'memory_limit' ) );
        $mb   = $mem ? round( $mem / 1024 / 1024 ) . ' MB' : 'unknown';
        $out[] = [
            'group'  => 'Environment',
            'status' => $mem >= 128 * 1024 * 1024 ? 'pass' : 'warn',
            'label'  => 'PHP memory_limit',
            'detail' => $mb,
            'fix'    => $mem >= 128 * 1024 * 1024 ? null : 'Bump memory_limit to at least 256M in php.ini — large form imports + AI calls can spike memory.',
        ];

        // 11. Plugin version (for support tickets)
        $out[] = [
            'group'  => 'Plugin',
            'status' => 'pass',
            'label'  => 'Plugin version',
            'detail' => defined( 'FCP_VERSION' ) ? FCP_VERSION : 'unknown',
            'fix'    => null,
        ];

        // 12. Counts (always pass — informational)
        $form_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . FCP_DB::forms_table() );
        $sub_count  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . FCP_DB::subs_table() );
        $out[] = [
            'group'  => 'Plugin',
            'status' => 'pass',
            'label'  => 'Forms / submissions',
            'detail' => $form_count . ' forms · ' . $sub_count . ' submissions',
            'fix'    => null,
        ];

        return $out;
    }

    private static function ext_consequence( $ext ) {
        return [
            'json'     => 'every REST endpoint, every integration, every settings save will fail.',
            'openssl'  => 'AES-256 encrypted fields + license-server validation won\'t work.',
            'mbstring' => 'i18n auto-translate + non-ASCII field labels will corrupt.',
            'curl'     => 'every integration that hits an external API will fail.',
        ][ $ext ] ?? 'some plugin features will break.';
    }

    /* -------------------------------------------------------------------
     * Tip catalog — curated "Did you know?" rotation.
     * Adding a tip is one array push; the front-end picks at random.
     * ----------------------------------------------------------------- */
    public static function tips() {
        return [
            [ 'id' => 'cmd-k',       'icon' => '⌘',  'title' => 'Cmd-K command palette',     'body' => 'Press Ctrl+K (or Cmd+K on Mac) anywhere in the admin to jump-search every form, page, and action.', 'cta' => null ],
            [ 'id' => 'star-forms',  'icon' => '⭐', 'title' => 'Star your top forms',       'body' => 'Click the star icon on any form row to pin it. Starred forms sort to the top of the list.', 'cta' => 'forms.html' ],
            [ 'id' => 'ai-generate', 'icon' => '✨', 'title' => 'AI form generation',        'body' => 'Describe the form you want in plain English — AI builds the schema, fields, and validation for you.', 'cta' => 'templates.html' ],
            [ 'id' => 'lazy-fields', 'icon' => '🚀', 'title' => 'Lazy-loaded long forms',    'body' => 'Forms with > 15 fields auto-render in two passes — initial paint stays fast even on 50-field application forms.', 'cta' => null ],
            [ 'id' => 'audit-log',   'icon' => '📋', 'title' => 'Every admin action audited','body' => 'Who deleted that submission? Check 🔒 Security & Privacy → 📋 Audit log for a full history with user, IP, and before/after snapshots.', 'cta' => 'security.html?tab=audit' ],
            [ 'id' => 'rtbf',        'icon' => '🗑', 'title' => 'One-click GDPR forget',     'body' => 'Paste an email under 🔒 Security & Privacy → 🗑 RTBF to anonymize every submission from that visitor in one click.', 'cta' => 'security.html?tab=rtbf' ],
            [ 'id' => 'white-label', 'icon' => '🎨', 'title' => 'White-label the plugin',    'body' => 'Reselling FormYantra to agency clients? 🚀 SaaS → 🎨 White-label lets you replace the name, logo, and footer with your own brand.', 'cta' => 'saas.html?tab=brand' ],
            [ 'id' => 'a11y-audit',  'icon' => '♿', 'title' => 'WCAG 2.2 AA audit built-in','body' => 'Open any form → Settings → ♿ Accessibility → Run audit. 15 checks, generated statement, no Lighthouse needed.', 'cta' => null ],
            [ 'id' => 'i18n',        'icon' => '🌐', 'title' => '20 built-in languages',     'body' => 'Pick a language under Form Settings → 🌐 Language. Submit/Next/Previous/error messages auto-translate. Auto-translate handles your custom field labels too.', 'cta' => null ],
            [ 'id' => 'graphql',     'icon' => '◆',  'title' => 'GraphQL endpoint',          'body' => 'POST /wp-json/fcp/v1/graphql with `{ forms(limit:5) { id title submissions } }` — built-in mini-GraphQL for integrations.', 'cta' => null ],
            [ 'id' => 'service-wrk', 'icon' => '📶', 'title' => 'Offline submission queue',  'body' => 'Submissions made offline (e.g. on a phone in a tunnel) queue in IndexedDB + replay automatically when the visitor is back online.', 'cta' => null ],
            [ 'id' => 'embed-token', 'icon' => '🌍', 'title' => 'Hosted form URLs',          'body' => 'Generate a signed embed URL under 🚀 SaaS → 🌐 Hosted forms — share via email, iframe on any non-WP site, no shortcode needed.', 'cta' => 'saas.html?tab=hosted' ],
            [ 'id' => 'tokens',      'icon' => '🔑', 'title' => 'Scoped API tokens',         'body' => 'Build a Zapier/Make integration without sharing your WP password — POST /wp-json/fcp/v1/tokens to mint a scoped Bearer token.', 'cta' => null ],
            [ 'id' => 'undo-redo',   'icon' => '↶',  'title' => 'Undo / redo in builder',    'body' => 'Form builder tracks every edit — hit Ctrl+Z to undo, Ctrl+Y to redo. Visual history panel via the 🕐 icon.', 'cta' => null ],
            [ 'id' => 'logic',       'icon' => '⇄',  'title' => 'Show / hide via logic',     'body' => 'Add conditional rules to any field: "Show this field only if Country = United States". No code, drag-drop UI.', 'cta' => null ],
            [ 'id' => 'preview-dev', 'icon' => '📱', 'title' => 'Tablet + mobile preview',   'body' => 'Toggle between Desktop / Tablet / Mobile widths on the Preview page to spot responsive bugs before publishing.', 'cta' => null ],
            [ 'id' => 'templates',   'icon' => '📦', 'title' => '55 industry templates',     'body' => 'Templates page ships pre-built packs for Healthcare, Real Estate, Education, Restaurants, and 6 more industries. Install whole packs in one click.', 'cta' => 'templates.html' ],
            [ 'id' => '2fa',         'icon' => '🔐', 'title' => 'Two-factor for FormYantra',  'body' => 'Independent of WP 2FA — protects only the FormYantra admin pages so you can lock down sensitive submissions without site-wide 2FA rollout.', 'cta' => 'security.html?tab=2fa' ],
            [ 'id' => 'density',     'icon' => '☰',  'title' => 'Compact rows on Forms list','body' => 'Toggle to the ▤ density mode to fit 2× more rows per scroll. Choice persists across pages.', 'cta' => null ],
            [ 'id' => 'dashboard',   'icon' => '📊', 'title' => 'Sortable Top Forms widget', 'body' => 'Dashboard\'s Top Performing Forms widget sorts by Submissions / Views / Conversion / Recent — click the tabs in the card header.', 'cta' => null ],
        ];
    }

    /* -------------------------------------------------------------------
     * Tutorials catalog — YouTube IDs the Help page lazy-loads.
     * We ship the catalog; an admin with a video gallery extension
     * can swap in their own ids.
     * ----------------------------------------------------------------- */
    public static function tutorials() {
        return [
            [ 'id' => 'NULL', 'title' => 'Build your first form',                  'desc' => 'Drag-drop a contact form, configure validation, and publish.', 'duration' => '3:42' ],
            [ 'id' => 'NULL', 'title' => 'Multi-step forms with conditional logic','desc' => 'Build a step-based application form with branching logic.',     'duration' => '6:18' ],
            [ 'id' => 'NULL', 'title' => 'Connect to Zapier / Make / Pabbly',     'desc' => 'Push submissions into 5000+ apps via the webhook integration.','duration' => '4:01' ],
            [ 'id' => 'NULL', 'title' => 'Accept payments with UPI + Stripe',     'desc' => 'India-friendly UPI QR + global Stripe checkout in one form.',  'duration' => '5:24' ],
            [ 'id' => 'NULL', 'title' => 'AI form generation walkthrough',        'desc' => 'Type a description, watch AI build the form, customize.',      'duration' => '4:55' ],
            [ 'id' => 'NULL', 'title' => 'Audit log + GDPR right-to-forget',      'desc' => 'Run a privacy audit and process a deletion request in 60s.',   'duration' => '3:18' ],
            [ 'id' => 'NULL', 'title' => 'White-label for agencies',              'desc' => 'Replace the plugin\'s name, logo, and footer with your own.',  'duration' => '2:47' ],
            [ 'id' => 'NULL', 'title' => 'Multi-language + RTL forms',            'desc' => 'Auto-translate built-in labels to 20 languages, RTL support.', 'duration' => '4:12' ],
        ];
        // Admin can override: add_filter('fcp_help_tutorials', fn($list) => …);
    }

    /* -------------------------------------------------------------------
     * REST endpoints — one call per HTTP verb (proven pattern).
     * Bootstrap'd from formcraft-pro.php with a backstop add_action.
     * ----------------------------------------------------------------- */
    public static function register_rest() {
        // v2.72.19 — Namespace corrected to formcraft/v1 to match the bridge.
        $ns = 'formcraft/v1';
        register_rest_route( $ns, '/health/ping', [
            'methods'             => 'GET',
            'callback'            => function () { return rest_ensure_response( [ 'ok' => true, 'version' => defined( 'FCP_VERSION' ) ? FCP_VERSION : '' ] ); },
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( $ns, '/help/diagnostics', [
            'methods'             => 'GET',
            'callback'            => function () { return rest_ensure_response( self::run_diagnostics() ); },
            'permission_callback' => [ __CLASS__, 'can_use' ],
        ] );
        register_rest_route( $ns, '/help/tips', [
            'methods'             => 'GET',
            'callback'            => function () { return rest_ensure_response( self::tips() ); },
            'permission_callback' => [ __CLASS__, 'can_use' ],
        ] );
        register_rest_route( $ns, '/help/tutorials', [
            'methods'             => 'GET',
            'callback'            => function () { return rest_ensure_response( apply_filters( 'fcp_help_tutorials', self::tutorials() ) ); },
            'permission_callback' => [ __CLASS__, 'can_use' ],
        ] );
    }
}
