<?php
/**
 * FormYantra - Frontend shortcode.
 *
 * Usage:
 *   [formcraft id="1"]                 -- render a published form
 *   [formcraft id="1" preview="1"]     -- preview without saving submissions
 *
 * The shortcode enqueues the existing form-engine.js bundle so the same
 * multi-step renderer used in admin previews powers the public form.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_Shortcode {

    public function __construct() {
        // v2.72.39 — Primary shortcode is now [formyantra …]. The old
        // [formcraft] / [formcraft_pro] tags are kept as permanent aliases
        // so any pages / posts that already have the old shortcode embedded
        // keep rendering — no breakage for existing installs.
        add_shortcode( 'formyantra',           [ $this, 'render' ] );
        add_shortcode( 'formyantra_directory', [ $this, 'render_directory' ] );
        add_shortcode( 'formcraft',            [ $this, 'render' ] );            // legacy alias
        add_shortcode( 'formcraft_pro',        [ $this, 'render' ] );            // legacy alias
        add_shortcode( 'formcraft_directory',  [ $this, 'render_directory' ] );  // legacy alias
        add_shortcode( 'fcp_user_dashboard',   [ $this, 'render_user_dashboard' ] );
        add_action( 'wp_enqueue_scripts',  [ $this, 'register_assets' ] );
        // v2.60 — Serve the service worker file from the site root so its
        // scope can be `/`. Hooks `init` at priority 1 so it fires before
        // template_redirect — the browser request for the SW comes in as
        // a plain GET with ?fcp_sw=1.
        add_action( 'init',                [ $this, 'maybe_serve_service_worker' ], 1 );
        // Pretty-URL standalone form: yoursite.com/formcraft-pro/{form-slug}/
        add_action( 'init',                [ $this, 'register_pretty_url_route' ] );
        add_filter( 'query_vars',          [ $this, 'register_pretty_url_var' ] );
        add_action( 'template_redirect',   [ $this, 'maybe_render_pretty_url' ] );
    }

    /**
     * Map /formcraft-pro/{slug}/ to a custom query var so template_redirect
     * can intercept it before WP tries to find a matching page.
     */
    /**
     * v2.60 — Serve the service worker file from the site root when the
     * URL has ?fcp_sw=1. The file lives at assets/js/fcp-sw.js inside
     * the plugin — we read it + emit with the right headers:
     *   - Content-Type: application/javascript (browsers reject HTML)
     *   - Service-Worker-Allowed: /            (broaden scope to root)
     *   - Cache-Control: public, max-age=300   (5 min, balances SW
     *                                            updates with bandwidth)
     */
    public function maybe_serve_service_worker() {
        if ( empty( $_GET['fcp_sw'] ) ) return;
        $path = FCP_PATH . 'assets/js/fcp-sw.js';
        if ( ! is_readable( $path ) ) {
            status_header( 404 );
            exit;
        }
        nocache_headers();
        header( 'Content-Type: application/javascript; charset=utf-8' );
        header( 'Service-Worker-Allowed: /' );
        header( 'Cache-Control: public, max-age=300' );
        readfile( $path );
        exit;
    }

    public function register_pretty_url_route() {
        // v2.72.39 — Primary URL slug is now /formyantra/. The legacy
        // /formcraft-pro/ rewrite is kept alongside so old share links
        // (email blasts, saved landing pages, WhatsApp forwards) still work.
        add_rewrite_rule(
            '^formyantra/([^/]+)/?$',
            'index.php?fcp_form_slug=$matches[1]',
            'top'
        );
        add_rewrite_rule(
            '^formyantra/embed/?$',
            'index.php?fcp_embed=1',
            'top'
        );
        // ── Legacy aliases ──────────────────────────────────────────
        add_rewrite_rule(
            '^formcraft-pro/([^/]+)/?$',
            'index.php?fcp_form_slug=$matches[1]',
            'top'
        );
        add_rewrite_rule(
            '^formcraft-pro/embed/?$',
            'index.php?fcp_embed=1',
            'top'
        );
    }
    public function register_pretty_url_var( $vars ) {
        $vars[] = 'fcp_form_slug';
        $vars[] = 'fcp_embed';
        return $vars;
    }

    /**
     * When the visitor lands on /formcraft-pro/{slug}/, look up the form by
     * its slug and render a clean standalone HTML page that hosts ONLY the
     * form via shortcode. Bypasses the theme entirely so the form can be
     * used as a dedicated landing page / share link.
     */
    public function maybe_render_pretty_url() {
        // v2.64 — Hosted-SaaS embed route first. /formcraft-pro/embed/?t=…
        // serves a minimal HTML page that just mounts the form via JS, so
        // remote sites can embed without WP nonces or admin context.
        if ( get_query_var( 'fcp_embed' ) ) {
            $token = isset( $_GET['t'] ) ? sanitize_text_field( wp_unslash( $_GET['t'] ) ) : '';
            $info  = class_exists( 'FCP_SaaS' ) ? FCP_SaaS::verify_embed( $token ) : null;
            if ( ! $info ) {
                status_header( 403 );
                nocache_headers();
                echo '<!doctype html><meta charset="utf-8"><title>Invalid embed token</title>'
                   . '<div style="font-family:"Inter",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",sans-serif;padding:60px;text-align:center;color:#475569;">'
                   . '<h1 style="margin:0 0 8px;color:#0f172a;">Embed token invalid or expired</h1>'
                   . '<p>Generate a fresh token from the form\'s SaaS settings.</p>'
                   . '</div>';
                exit;
            }
            $form = FCP_DB::get_form( $info['form_id'] );
            if ( ! $form ) { status_header( 404 ); exit; }
            status_header( 200 );
            nocache_headers();
            header( 'X-Frame-Options: ALLOWALL' );  // designed to be iframed
            $brand = class_exists( 'FCP_SaaS' ) ? FCP_SaaS::brand() : [];
            $page_title = ! empty( $form['title'] ) ? esc_html( $form['title'] ) : 'Form';
            echo '<!doctype html><html lang="en"><head><meta charset="utf-8">';
            echo '<meta name="viewport" content="width=device-width,initial-scale=1">';
            echo '<title>' . $page_title . '</title>';
            echo '<style>body{margin:0;font-family:"Inter",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",sans-serif;background:transparent;padding:0;}</style>';
            wp_head();
            echo '</head><body>';
            echo do_shortcode( '[formyantra id="' . (int) $form['id'] . '"]' );
            wp_footer();
            echo '</body></html>';
            exit;
        }

        $slug = get_query_var( 'fcp_form_slug' );
        if ( ! $slug ) return;

        global $wpdb;
        $form_id = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM " . FCP_DB::forms_table() . " WHERE slug = %s LIMIT 1",
            $slug
        ) );

        if ( ! $form_id ) {
            status_header( 404 );
            nocache_headers();
            echo '<!doctype html><meta charset="utf-8"><title>Form not found</title>'
               . '<div style="font-family:"Inter",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",sans-serif;padding:60px;text-align:center;color:#475569;">'
               . '<h1 style="margin:0 0 8px;color:#0f172a;">Form not found</h1>'
               . '<p>The form you\'re looking for doesn\'t exist or has been removed.</p>'
               . '</div>';
            exit;
        }

        $form  = FCP_DB::get_form( $form_id );
        $title = ! empty( $form['title'] ) ? $form['title'] : 'Form';

        status_header( 200 );
        nocache_headers();
        header( 'Content-Type: text/html; charset=utf-8' );
        // v2.69.9 — The pretty-URL form is meant to be iframe-embeddable from
        // ANY origin (HTML editors, Wix, Shopify, static sites, w3schools
        // sandbox, CodePen). WordPress core, some themes, and most security
        // plugins add `X-Frame-Options: SAMEORIGIN` and CSP `frame-ancestors
        // 'self'` — either one blocks cross-origin embeds. Strip and replace:
        if ( function_exists( 'header_remove' ) ) {
            header_remove( 'X-Frame-Options' );
            header_remove( 'Content-Security-Policy' );
        }
        // Modern spec: `frame-ancestors *` explicitly allows all origins.
        // Browsers honour this over X-Frame-Options when both are present,
        // so this is our belt-and-braces guarantee against reintroduction
        // by any hook that fires after this one.
        header( 'Content-Security-Policy: frame-ancestors *;' );
        // Also intercept any late-firing `send_headers` action that would
        // re-add X-Frame-Options (e.g. Wordfence, iThemes Security).
        add_action( 'send_headers', function () {
            if ( function_exists( 'header_remove' ) ) {
                header_remove( 'X-Frame-Options' );
            }
        }, 999 );
        ?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo esc_html( $title ); ?> · <?php bloginfo( 'name' ); ?></title>
    <meta name="robots" content="noindex,follow">
    <!-- v2.72.43 — Load Inter for the standalone form page so the Inter
         stack we pin on .fc-form-public actually resolves. -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap">
    <style>
        body { margin:0; padding:40px 20px; background:#f1f5f9; font-family:"Inter",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",sans-serif; }
        .fcp-pretty-shell { max-width:760px; margin:0 auto; background:#fff; border-radius:16px; padding:40px; box-shadow:0 4px 30px rgba(15,23,42,.08); }
        .fcp-pretty-foot  { max-width:760px; margin:18px auto 0; text-align:center; font-size:12px; color:#94a3b8; }
        .fcp-pretty-foot a { color:#64748b; text-decoration:none; }
        @media (max-width:600px) { body { padding:20px 12px; } .fcp-pretty-shell { padding:24px; border-radius:12px; } }
    </style>
    <?php wp_head(); ?>
</head>
<body class="fcp-standalone-form">
    <div class="fcp-pretty-shell">
        <?php echo do_shortcode( '[formyantra id="' . (int) $form_id . '"]' ); ?>
    </div>
    <div class="fcp-pretty-foot">Powered by <strong>FormYantra</strong></div>
    <?php wp_footer(); ?>
</body>
</html>
        <?php
        exit;
    }

    /**
     * Produces a cache-bust string that changes whenever any of our
     * public assets are modified — even between releases without a
     * version bump. The returned string is used as the WP asset version
     * (the `?ver=` query string) so any CDN keyed on URL+query gets a
     * new URL the moment the file changes.
     */
    private static function asset_bust() {
        $files = [
            FCP_PATH . 'assets/css/style.css',
            FCP_PATH . 'assets/js/fields.js',
            FCP_PATH . 'assets/js/form-engine.js',
            FCP_PATH . 'assets/js/app.js',
            FCP_PATH . 'assets/js/data.js',
        ];
        $mtime = 0;
        foreach ( $files as $f ) {
            if ( file_exists( $f ) ) {
                $m = @filemtime( $f );
                if ( $m && $m > $mtime ) $mtime = $m;
            }
        }
        return FCP_VERSION . '.' . $mtime;
    }

    public function register_assets() {
        // CDN-resilient asset versioning. Some shared hosts (rf.gd / InfinityFree
        // / certain WP-Engine setups) serve a hard CDN cache on .js/.css that
        // ignores the `?ver=X` query string, so admins who upgrade the plugin
        // can still see stale code on the live form.
        //
        // We combine FCP_VERSION (plugin version) with the file's mtime (which
        // changes on every code edit) — so even an in-place file change forces a
        // new URL the CDN has never seen. We embed the combined string in the
        // FILENAME path (?fcp=) AND keep the standard ver= so both URL-keyed and
        // query-keyed CDN caches respect it.
        $bust = self::asset_bust();
        // v2.72.43 — Load Inter (Google Fonts) as a dependency of fcp-public
        // so every public form renders in Inter regardless of the host
        // theme's default font. Uses `display=swap` so slow font loads
        // don't block the form's first paint.
        wp_register_style(
            'fcp-public-inter',
            'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap',
            [],
            null
        );
        /* v2.72.66 — CDN-hosted runtime.
           When enabled in Settings → Performance, public form assets are
           served from an admin-supplied CDN base URL instead of the WP
           host. The CDN is expected to mirror the same path structure
           (assets/js/*, assets/css/style.css) — jsDelivr against the
           plugin's public repo works out of the box. Falls back to
           FCP_URL when CDN is off or the URL is empty. Version bust
           still uses FCP_VERSION so cache invalidates on each release. */
        $settings   = get_option( 'fcp_settings', [] );
        $cdn_cfg    = isset( $settings['cdn'] ) && is_array( $settings['cdn'] ) ? $settings['cdn'] : [];
        $cdn_on     = ! empty( $cdn_cfg['enabled'] ) && ! empty( $cdn_cfg['base_url'] );
        $asset_base = $cdn_on ? trailingslashit( esc_url_raw( (string) $cdn_cfg['base_url'] ) ) : FCP_URL;
        wp_register_style ( 'fcp-public', $asset_base . 'assets/css/style.css',      [ 'fcp-public-inter' ], $bust );
        wp_register_script( 'fcp-data',    $asset_base . 'assets/js/data.js',        [],                $bust, true );
        wp_register_script( 'fcp-app',     $asset_base . 'assets/js/app.js',         [ 'fcp-data' ],    $bust, true );
        wp_register_script( 'fcp-fields',  $asset_base . 'assets/js/fields.js',      [ 'fcp-app' ],     $bust, true );
        wp_register_script( 'fcp-engine',  $asset_base . 'assets/js/form-engine.js', [ 'fcp-fields' ],  $bust, true );
        // v2.60 — Service worker bootstrap. The SW URL we hand to JS is
        // the SITE ROOT URL with ?fcp_sw=1, NOT the plugin asset path.
        // A SW registered from a plugin sub-path can only have its own
        // sub-path as scope — but the form is rendered on pages under
        // the site root (e.g. /contact/). Serving the file from / lets
        // its scope cover the whole site so it can intercept the form's
        // POST + cache plugin assets. The actual serve handler is
        // hooked on `init` further down this class.
        wp_add_inline_script( 'fcp-engine',
            'window.FCP_SW_URL = ' . wp_json_encode( add_query_arg( 'fcp_sw', '1', home_url( '/' ) ) ) . ';',
            'before'
        );
        // User Journey tracker: enqueued on EVERY frontend page (not just
        // pages that contain a form). The tracker captures the path
        // visitors take BEFORE landing on the form, so it has to run
        // earlier than the shortcode. Lightweight (<3KB, localStorage only,
        // no network calls).
        wp_register_script( 'fcp-journey', FCP_URL . 'assets/js/journey-tracker.js', [], FCP_VERSION, true );
        if ( ! is_admin() ) {
            wp_enqueue_script( 'fcp-journey' );
        }
    }

    public function render( $atts ) {
        // v2.68.2 — Accept an optional `title` attribute so admins can
        // annotate embed shortcodes (e.g. [formcraft id="1" title="Contact"]).
        // The renderer only uses `id`; title is a self-documenting comment.
        $atts = shortcode_atts( [
            'id'      => 0,
            'preview' => 0,
            'title'   => '',
        ], $atts, 'formcraft' );

        $form = FCP_DB::get_form( $atts['id'] );
        if ( ! $form ) {
            return '<div class="fcp-error" style="padding:14px;border:1px solid #fee;background:#fef2f2;color:#b91c1c;border-radius:8px;">' .
                esc_html__( 'FormYantra: form not found.', 'formcraft-pro' ) .
                '</div>';
        }

        if ( $form['status'] !== 'active' && empty( $atts['preview'] ) ) {
            return '<div class="fcp-error" style="padding:14px;border:1px solid #fef3c7;background:#fffbeb;color:#92400e;border-radius:8px;">' .
                esc_html__( 'This form is not currently active.', 'formcraft-pro' ) .
                '</div>';
        }

        // Form Locker — check access-control gates BEFORE rendering the
        // form itself. Preview mode (?preview=1) bypasses all gates so
        // admins can still see / edit the form in the builder preview.
        if ( empty( $atts['preview'] ) ) {
            $locker_gate = self::check_locker_access( $form );
            if ( $locker_gate !== true ) return $locker_gate;
        }

        // Track view (best-effort, fire-and-forget)
        FCP_DB::bump_views( $form['id'] );

        wp_enqueue_style ( 'fcp-public' );
        wp_enqueue_script( 'fcp-engine' );

        $settings = get_option( 'fcp_settings', FCP_DB::default_settings() );
        // Provider-aware CAPTCHA bootstrap. We forward the chosen provider
        // (recaptcha | hcaptcha | turnstile) + the correct site key so the
        // field renderer can pick the right widget.
        $captcha_provider = $settings['recaptcha']['provider'] ?? 'recaptcha';
        $captcha_site_key = '';
        if ( $captcha_provider === 'hcaptcha' ) {
            $captcha_site_key = $settings['recaptcha']['hcaptcha']['site_key'] ?? '';
        } elseif ( $captcha_provider === 'turnstile' ) {
            $captcha_site_key = $settings['recaptcha']['turnstile']['site_key'] ?? '';
        } elseif ( $captcha_provider === 'math' ) {
            // v2.72.28 — Math captcha needs no site key; leave blank so the
            // "load external captcha JS" check below skips.
            $captcha_site_key = '';
        } else {
            $captcha_site_key = $settings['recaptcha']['site_key'] ?? '';
        }

        // Logged-in user context — exposed so hidden fields can use
        // {user_login} / {user_email} / {user_id} placeholders. Guests
        // see empty strings (their submissions stay anonymous).
        $current = wp_get_current_user();
        $user_ctx = [
            'id'    => $current && $current->ID ? (int) $current->ID : 0,
            'login' => $current && $current->ID ? (string) $current->user_login : '',
            'email' => $current && $current->ID ? (string) $current->user_email : '',
        ];

        // Per-form CSRF token — combines the standard WP REST nonce with a
        // form-specific nonce so a stale token captured from form A cannot
        // be replayed against form B. Validated in FCP_REST::submit_form().
        $form_nonce = wp_create_nonce( 'fcp_form_' . (int) $form['id'] );

        // v2.67.9 — Resolve the effective per-form CAPTCHA gate BEFORE
        // handing the schema to the client. The user's report: they
        // toggled "Enable reCAPTCHA protection" OFF on the integrations
        // page + auto-inject OFF, but the form still showed the "I'm not
        // a robot" widget because form-engine.js only checked the per-form
        // `form.settings.recaptcha` boolean (which defaults to true on
        // new forms) and never consulted the global setting.
        // Truth table:
        //   Global OFF                            → captcha off (whatever per-form says)
        //   Global ON  + auto-inject ON           → captcha on for every form
        //   Global ON  + auto-inject OFF          → per-form flag decides
        $captcha_global   = ! empty( $settings['recaptcha']['enabled'] );
        $captcha_auto_all = ! empty( $settings['recaptcha']['autoInject'] );
        $captcha_per_form = ! empty( $form['settings']['recaptcha'] );
        // v2.67.10 — Also detect an explicit captcha field on the form. When
        // one exists, the auto-inject widget at the bottom is redundant + it
        // fights with the explicit field for the single reCAPTCHA token that
        // the JS API allows per page. The explicit field wins.
        $captcha_field_present = false;
        foreach ( ( $form['steps'] ?? [] ) as $step ) {
            foreach ( ( $step['fields'] ?? [] ) as $fld ) {
                if ( ( $fld['type'] ?? '' ) === 'captcha' ) { $captcha_field_present = true; break 2; }
            }
        }
        $captcha_final = $captcha_global
                         && ( $captcha_auto_all || $captcha_per_form )
                         && ! $captcha_field_present;
        if ( ! isset( $form['settings'] ) || ! is_array( $form['settings'] ) ) $form['settings'] = [];
        $form['settings']['recaptcha'] = $captcha_final;

        $bootstrap = [
            'form'      => $form,
            'restUrl'   => esc_url_raw( rest_url( 'formcraft/v1/' ) ),
            'nonce'     => wp_create_nonce( 'wp_rest' ),
            'formNonce' => $form_nonce,
            'preview'   => (bool) $atts['preview'],
            'user'      => $user_ctx,
            'recaptcha' => [
                'enabled'  => ! empty( $settings['recaptcha']['enabled'] ),
                'provider' => $captcha_provider,
                'version'  => $settings['recaptcha']['version']  ?? 'v3',
                'site_key' => $captcha_site_key,
                // v2.72.28 — Math captcha needs no site key; ship difficulty
                // + prompt so the field renderer can build the challenge.
                'math'     => isset( $settings['recaptcha']['math'] ) && is_array( $settings['recaptcha']['math'] )
                    ? $settings['recaptcha']['math']
                    : [ 'difficulty' => 'easy', 'prompt' => "Solve this to prove you're human:" ],
            ],
            'maps'      => [
                'google_api_key' => $settings['maps']['google_api_key'] ?? '',
            ],
            'styling'   => $settings['styling'] ?? [],
            // Auto-currency: we ONLY emit the flag — the actual GeoIP
            // detection happens client-side after the form is visible, so
            // a slow GeoIP API call never blocks page render. The form
            // renders with its configured currency, then JS swaps in the
            // detected one ~1s later. Massive improvement for sites NOT
            // behind a CDN.
            'autoCurrencyEnabled' => ! empty( $form['settings']['auto_currency'] ),
        ];
        $instance_id = 'fcp_' . wp_generate_password( 6, false );

        // Load the script for the configured CAPTCHA provider:
        //   - reCAPTCHA v3 → ?render=<siteKey> (for grecaptcha.execute())
        //   - reCAPTCHA v2 → auto-renderer that scans .g-recaptcha divs
        //   - hCaptcha     → auto-renderer that scans .h-captcha divs
        //   - Turnstile    → auto-renderer that scans .cf-turnstile divs
        if ( $bootstrap['recaptcha']['enabled'] && ! empty( $bootstrap['recaptcha']['site_key'] ) ) {
            if ( $captcha_provider === 'hcaptcha' ) {
                wp_enqueue_script( 'fcp-hcaptcha', 'https://js.hcaptcha.com/1/api.js', [], null, true );
            } elseif ( $captcha_provider === 'turnstile' ) {
                wp_enqueue_script( 'fcp-turnstile', 'https://challenges.cloudflare.com/turnstile/v0/api.js', [], null, true );
            } else {
                $rc_src = $bootstrap['recaptcha']['version'] === 'v2'
                    ? 'https://www.google.com/recaptcha/api.js'
                    : 'https://www.google.com/recaptcha/api.js?render=' . urlencode( $bootstrap['recaptcha']['site_key'] );
                wp_enqueue_script( 'fcp-recaptcha', $rc_src, [], null, true );
            }
        }

        // Google Maps Places library — only loaded when the API key is set
        // AND the form contains an Address field (saves a 3rd-party hit on
        // forms that don't need it).
        $form_uses_address = false;
        foreach ( ( $form['steps'] ?? [] ) as $step ) {
            foreach ( ( $step['fields'] ?? [] ) as $fld ) {
                if ( ( $fld['type'] ?? '' ) === 'address' ) { $form_uses_address = true; break 2; }
            }
        }
        if ( $form_uses_address && ! empty( $bootstrap['maps']['google_api_key'] ) ) {
            wp_enqueue_script(
                'fcp-google-maps',
                'https://maps.googleapis.com/maps/api/js?key=' . urlencode( $bootstrap['maps']['google_api_key'] ) . '&libraries=places',
                [],
                null,
                true
            );
        }

        $custom_css = $form['settings']['customCSS'] ?? '';
        $primary    = $settings['styling']['primary_color'] ?? '#6366f1';

        ob_start();
        ?>
        <div id="<?php echo esc_attr( $instance_id ); ?>" class="fcp-shortcode-wrap" style="--brand-500:<?php echo esc_attr( $primary ); ?>;--brand-600:<?php echo esc_attr( $primary ); ?>;">
            <div class="fcp-mount"></div>
        </div>
        <style>
            .fcp-shortcode-wrap { max-width: 720px; margin: 24px auto; }
            <?php echo wp_strip_all_tags( $custom_css ); ?>
        </style>
        <script>
        (function () {
            // JSON_HEX_TAG hex-escapes < and > so any field value containing
            // a literal closing-script sequence cannot break the inline JS.
            var bootstrap = <?php echo wp_json_encode( $bootstrap, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES ); ?>;
            // v2.67.9 — Expose the resolved global settings so form-engine's
            // defence-in-depth captcha gate can consult them.
            window.FCP_BOOTSTRAP = bootstrap;
            function ready(fn){ if(document.readyState!=='loading'){fn();}else{document.addEventListener('DOMContentLoaded',fn);} }
            ready(function () {
                if (typeof window.FCForm === 'undefined') {
                    console.error('FormYantra engine not loaded');
                    return;
                }
                var wrap  = document.getElementById('<?php echo esc_js( $instance_id ); ?>');
                var mount = wrap.querySelector('.fcp-mount');
                window.FCFormConfig = {
                    rest:                bootstrap.restUrl,
                    nonce:                bootstrap.nonce,
                    formNonce:           bootstrap.formNonce,
                    formId:               bootstrap.form.id,
                    recaptcha:            bootstrap.recaptcha,
                    form:                 bootstrap.form,
                    user:                 bootstrap.user || { id: 0, login: '', email: '' },
                    autoCurrencyEnabled:  !!bootstrap.autoCurrencyEnabled
                };
                window.FCForm.renderPublicForm(mount, bootstrap.form, {
                    previewMode: bootstrap.preview,
                    onSubmit: function (data) {
                        // If the visitor applied a coupon on the form, hand the
                        // code (and the current priced-field amount) to the
                        // server so it can re-validate and bump usage.
                        var formEl = mount.querySelector('#fcForm');
                        var coupon = (formEl && formEl.dataset.fcpCouponCode) ? formEl.dataset.fcpCouponCode : '';
                        var amount = 0;
                        if (coupon) {
                            // Send the PRE-coupon amount so the server can re-apply
                            // and verify the discount instead of trusting whatever
                            // the client says the final total is.
                            var pay = mount.querySelector('[data-fcp-priced="payment"], [data-fcp-priced="upi"], [data-fcp-priced="bank"]');
                            if (pay) {
                                amount = pay.dataset.fcpPreCouponBase
                                    ? parseFloat(pay.dataset.fcpPreCouponBase)
                                    : parseFloat(pay.dataset.fcpBase || 0);
                            }
                            if (!amount) {
                                var picked = mount.querySelector('[data-fcp-priced="product"] input[type="radio"]:checked, [data-fcp-priced="pricing"] input[type="radio"]:checked');
                                if (picked) amount = parseFloat(picked.dataset.price || 0);
                            }
                        }
                        // Pull the reCAPTCHA token if the field set it.
                        var captchaInput = mount.querySelector('input[name="fcp_recaptcha_token"]');
                        var captchaToken = captchaInput ? captchaInput.value : '';
                        // v2.72.28 — Math captcha payload (a, b, op, answer).
                        // Surfaced on the top level so the server-side check
                        // can re-compute the expected answer without walking
                        // the whole submission body.
                        function mathVal(sel) {
                            var el = mount.querySelector(sel);
                            return el ? el.value : '';
                        }
                        var mathPayload = {
                            a:      mathVal('input[name="fcp_math_a"]'),
                            b:      mathVal('input[name="fcp_math_b"]'),
                            op:     mathVal('input[name="fcp_math_op"]'),
                            answer: mathVal('input[name="fcp_math_answer"]')
                        };
                        // Extract the OTP envelope set by the OTP field (JSON
                        // containing target+channel+code) and surface it on the
                        // top level so the server can verify before saving.
                        var otpEnv = null;
                        var otpKey = null;
                        Object.keys(data).forEach(function (k) {
                            if (otpEnv) return;
                            var v = data[k];
                            if (typeof v !== 'string') return;
                            if (v.charAt(0) !== '{') return;
                            try {
                                var parsed = JSON.parse(v);
                                if (parsed && parsed.channel && (parsed.target || parsed.code)) {
                                    otpEnv = parsed; otpKey = k;
                                }
                            } catch (e) { /* not OTP */ }
                        });
                        if (otpKey) {
                            // Replace the noisy JSON in the saved row with just
                            // the masked target so the submission is human-readable.
                            data[otpKey] = otpEnv.target ? maskOtpTarget(otpEnv.target, otpEnv.channel) : 'verified';
                        }
                        // Pull the abandonment session_id and the user
                        // journey out of the payload so they ride at the
                        // top level of the request — server promotes
                        // abandoned rows by session_id and stores the
                        // journey alongside the submission.
                        var sessionId = data._fcp_session_id || '';
                        var journey   = data._fcp_journey   || null;
                        delete data._fcp_session_id;
                        delete data._fcp_journey;
                        /* v2.72.58 — Submit fetch now has a 30 s AbortController
                           timeout. Previously a hung POST (blocked SMTP, slow
                           integration webhook) left the "Submitting…" button
                           stuck forever because the promise never settled.
                           A timed abort routes into .catch → button restores
                           and an inline error is shown. The submission row is
                           still saved server-side (insert happens first). */
                        var ctrl = ('AbortController' in window) ? new AbortController() : null;
                        var timeoutId = null;
                        if (ctrl) {
                            timeoutId = setTimeout(function () {
                                try { ctrl.abort(); } catch (e) {}
                            }, 30000);
                        }
                        return fetch(bootstrap.restUrl + 'forms/' + bootstrap.form.id + '/submit', {
                            method: 'POST',
                            headers: { 'Content-Type':'application/json', 'X-WP-Nonce': bootstrap.nonce },
                            body: JSON.stringify({ data: data, coupon_code: coupon, amount: amount, recaptcha_token: captchaToken, fcp_math_a: mathPayload.a, fcp_math_b: mathPayload.b, fcp_math_op: mathPayload.op, fcp_math_answer: mathPayload.answer, otp: otpEnv, session_id: sessionId, journey: journey }),
                            signal: ctrl ? ctrl.signal : undefined
                        }).then(function (r) {
                            if (timeoutId) clearTimeout(timeoutId);
                            // Surface WP REST errors (recaptcha failures, login
                            // failures, rate limits) through .catch so the
                            // form-engine renders an inline error instead of
                            // a misleading "Submission received" screen.
                            return r.json().then(function (body) {
                                return r.ok ? body : Promise.reject(body);
                            });
                        }).catch(function (err) {
                            if (timeoutId) clearTimeout(timeoutId);
                            // AbortError: request timed out. The row was almost
                            // certainly persisted by the server (insert runs
                            // before mail/integrations) so tell the user their
                            // submission went through but delivery is delayed.
                            if (err && err.name === 'AbortError') {
                                return Promise.reject({ code: 'fcp_submit_timeout', message: 'Your submission was saved, but confirmation is taking longer than expected. You can close this page — we\'ll process it in the background.' });
                            }
                            return Promise.reject(err);
                        });
                    }
                });
            });
            function maskOtpTarget(t, channel) {
                if (!t) return '';
                if (channel === 'email') {
                    var at = t.indexOf('@');
                    if (at < 1) return t;
                    return t.charAt(0) + '***' + t.slice(at - 1);
                }
                // phone — keep last 4
                return t.length > 4 ? '****' + t.slice(-4) : t;
            }
        })();
        </script>
        <?php
        // Ad-platform pixel snippets — Meta/TikTok/Google/LinkedIn/etc.
        // Each emits its <script> + listens for the `fcp:submitted` event
        // that form-engine.js dispatches on successful submit. The shortcode
        // appends these AFTER the form so they don't block the form render.
        if ( class_exists( 'FCP_Ad_Platforms' ) ) {
            echo FCP_Ad_Platforms::collect_pixel_snippets();
        }
        return ob_get_clean();
    }

    /**
     * Frontend submission directory — public-facing table of submissions for
     * a given form, with optional search + column whitelist. Use:
     *   [formcraft_directory id="3"]
     *   [formcraft_directory id="3" columns="Name,Email,City" search="1" approved_only="1" per_page="20"]
     *
     * Designed for GravityView-style public listings: vendor directories,
     * event attendee lists, classified ads. By default only the form fields
     * the admin explicitly lists are shown — to prevent accidentally
     * exposing private fields, columns="*" is NOT supported.
     */
    public function render_directory( $atts ) {
        $atts = shortcode_atts( [
            'id'            => 0,
            'columns'       => '',       // comma-separated field labels
            'search'        => '0',
            'approved_only' => '0',      // when true, only show approval_status=approved rows
            'per_page'      => '20',
        ], $atts, 'formcraft_directory' );

        $form_id = (int) $atts['id'];
        if ( ! $form_id ) return '<div style="padding:14px;border:1px dashed #e5e7eb;color:#94a3b8;">FormYantra directory: missing <code>id="<form-id>"</code>.</div>';
        $form = FCP_DB::get_form( $form_id );
        if ( ! $form ) return '<div style="padding:14px;border:1px dashed #e5e7eb;color:#94a3b8;">Form not found.</div>';

        $columns = array_filter( array_map( 'trim', explode( ',', (string) $atts['columns'] ) ) );
        if ( empty( $columns ) ) {
            return '<div style="padding:14px;border:1px dashed #e5e7eb;color:#94a3b8;">FormYantra directory: please specify <code>columns="Field A, Field B"</code> to control what visitors see (never exposed: emails, payment details, raw signatures).</div>';
        }
        $approved_only = $atts['approved_only'] === '1' || $atts['approved_only'] === 'true';
        $per_page      = max( 1, min( 100, (int) $atts['per_page'] ) );
        $q             = isset( $_GET['fcd_q'] ) ? sanitize_text_field( wp_unslash( $_GET['fcd_q'] ) ) : '';
        $page          = max( 1, isset( $_GET['fcd_p'] ) ? (int) $_GET['fcd_p'] : 1 );

        global $wpdb;
        $where = $wpdb->prepare( 'form_id = %d AND is_spam = 0', $form_id );
        if ( $approved_only ) $where .= " AND approval_status = 'approved'";
        $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . FCP_DB::subs_table() . " WHERE $where" );
        $offset = ( $page - 1 ) * $per_page;
        $rows   = $wpdb->get_results(
            "SELECT id, data, created_at FROM " . FCP_DB::subs_table() . " WHERE $where ORDER BY created_at DESC LIMIT $offset, $per_page",
            ARRAY_A
        );

        $instance_id = 'fcd_' . wp_generate_password( 6, false );
        ob_start();
        ?>
        <div id="<?php echo esc_attr( $instance_id ); ?>" class="fcp-directory" style="margin:24px auto;max-width:1100px;font-family:Inter,Arial,sans-serif;">
            <?php if ( $atts['search'] === '1' || $atts['search'] === 'true' ) : ?>
                <form method="GET" style="margin-bottom:14px;">
                    <input type="search" name="fcd_q" value="<?php echo esc_attr( $q ); ?>" placeholder="Search…" style="width:100%;max-width:320px;padding:8px 12px;border:1px solid #e5e7eb;border-radius:8px;">
                </form>
            <?php endif; ?>

            <div style="overflow-x:auto;border:1px solid #e5e7eb;border-radius:10px;">
                <table style="width:100%;border-collapse:collapse;font-size:14px;">
                    <thead>
                        <tr style="background:#f8fafc;">
                            <?php foreach ( $columns as $c ) : ?>
                                <th style="text-align:left;padding:10px 14px;border-bottom:1px solid #e5e7eb;font-weight:600;color:#475569;"><?php echo esc_html( $c ); ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $visible_rows = 0;
                    foreach ( $rows as $row ) {
                        $d = json_decode( $row['data'], true );
                        if ( ! is_array( $d ) ) continue;
                        // Client-side search: skip rows whose listed-column
                        // values don't contain the query.
                        if ( $q !== '' ) {
                            $match = false;
                            foreach ( $columns as $c ) {
                                $v = $d[ $c ] ?? '';
                                if ( is_array( $v ) ) $v = implode( ' ', $v );
                                if ( stripos( (string) $v, $q ) !== false ) { $match = true; break; }
                            }
                            if ( ! $match ) continue;
                        }
                        $visible_rows++;
                        echo '<tr style="border-bottom:1px solid #f1f5f9;">';
                        foreach ( $columns as $c ) {
                            $v = $d[ $c ] ?? '';
                            if ( is_array( $v ) ) $v = implode( ', ', array_map( 'strval', $v ) );
                            // Skip data: URL signatures + redact long upload URLs by filename only.
                            if ( is_string( $v ) && strpos( $v, 'data:image/' ) === 0 ) {
                                $v = '<img src="' . esc_attr( $v ) . '" style="max-width:80px;max-height:40px;border-radius:4px;background:#fff;">';
                            } elseif ( is_string( $v ) && preg_match( '#^https?://#', $v ) && preg_match( '#\.(jpe?g|png|gif|webp|svg)(\?|$)#i', $v ) ) {
                                $v = '<img src="' . esc_url( $v ) . '" style="max-width:80px;max-height:40px;border-radius:4px;background:#fff;">';
                            } else {
                                $v = esc_html( $v );
                            }
                            echo '<td style="padding:10px 14px;color:#0f172a;">' . $v . '</td>';
                        }
                        echo '</tr>';
                    }
                    if ( $visible_rows === 0 ) {
                        echo '<tr><td colspan="' . count( $columns ) . '" style="padding:30px;text-align:center;color:#94a3b8;">No entries match.</td></tr>';
                    }
                    ?>
                    </tbody>
                </table>
            </div>

            <?php
            $total_pages = max( 1, (int) ceil( $total / $per_page ) );
            if ( $total_pages > 1 ) :
                $base_url = strtok( $_SERVER['REQUEST_URI'] ?? '', '?' );
                $params   = $_GET; unset( $params['fcd_p'] );
                $base_qs  = http_build_query( $params );
                $prefix   = $base_url . '?' . ( $base_qs ? $base_qs . '&' : '' );
            ?>
                <div style="display:flex;justify-content:space-between;align-items:center;margin-top:14px;font-size:13px;color:#64748b;">
                    <div>Showing page <?php echo $page; ?> of <?php echo $total_pages; ?> · <?php echo $total; ?> total</div>
                    <div style="display:flex;gap:6px;">
                        <?php if ( $page > 1 ) : ?>
                            <a href="<?php echo esc_url( $prefix . 'fcd_p=' . ( $page - 1 ) ); ?>" style="padding:6px 12px;border:1px solid #e5e7eb;border-radius:6px;text-decoration:none;color:#0f172a;">←</a>
                        <?php endif; ?>
                        <?php if ( $page < $total_pages ) : ?>
                            <a href="<?php echo esc_url( $prefix . 'fcd_p=' . ( $page + 1 ) ); ?>" style="padding:6px 12px;border:1px solid #e5e7eb;border-radius:6px;text-decoration:none;color:#0f172a;">→</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Logged-in Form User dashboard. Used by the auto-created
     * "User Dashboard" page (slug: user-dashboard). Renders:
     *   - Guest state with a login prompt + link to the configured login form
     *   - Member state with profile card, account fields, and a logout button
     */
    public function render_user_dashboard( $atts ) {
        $atts = shortcode_atts( [
            'login_url'    => '',
            'redirect_url' => '',
        ], $atts, 'fcp_user_dashboard' );

        if ( ! class_exists( 'FCP_Users' ) ) {
            return '<div style="padding:14px;border:1px solid #fee;background:#fef2f2;color:#b91c1c;border-radius:8px;">FormYantra user module unavailable.</div>';
        }

        $user = FCP_Users::current_user();

        ob_start();

        // Resolve login URL: explicit attr → option → home.
        $login_url = $atts['login_url']
            ?: get_option( 'fcp_user_login_page_url', '' )
            ?: home_url( '/' );

        // Handle logout via ?fcp_logout=1
        if ( isset( $_GET['fcp_logout'] ) ) {
            FCP_Users::end_session();
            $back = remove_query_arg( 'fcp_logout' );
            echo '<script>location.replace(' . wp_json_encode( $back ) . ');</script>';
            return ob_get_clean();
        }

        if ( ! $user ) {
            ?>
            <div class="fcp-userdash-guest" style="max-width:520px;margin:40px auto;padding:32px;border:1px solid #e5e7eb;border-radius:14px;background:#fff;text-align:center;font-family:"Inter",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",sans-serif;">
                <div style="width:64px;height:64px;margin:0 auto 16px;border-radius:50%;background:linear-gradient(135deg,#6366f1,#8b5cf6);display:flex;align-items:center;justify-content:center;color:#fff;">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                </div>
                <h2 style="margin:0 0 6px;font-size:22px;color:#0f172a;">You are not logged in</h2>
                <p style="margin:0 0 22px;color:#64748b;">Please sign in to access your dashboard.</p>
                <a href="<?php echo esc_url( $login_url ); ?>" style="display:inline-block;padding:11px 24px;background:#6366f1;color:#fff;text-decoration:none;border-radius:8px;font-weight:600;">Go to Login</a>
            </div>
            <?php
            return ob_get_clean();
        }

        $meta = [];
        if ( ! empty( $user['meta'] ) ) {
            $decoded = json_decode( (string) $user['meta'], true );
            if ( is_array( $decoded ) ) $meta = $decoded;
        }
        $name = $user['display_name'] ?: $user['email'];
        $init = strtoupper( substr( preg_replace( '/[^A-Za-z]/', '', $name ), 0, 2 ) );
        if ( $init === '' ) $init = strtoupper( substr( $user['email'], 0, 2 ) );

        $logout_url = add_query_arg( 'fcp_logout', '1' );
        ?>
        <div class="fcp-userdash" style="max-width:880px;margin:32px auto;font-family:"Inter",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",sans-serif;color:#0f172a;">
            <div style="display:flex;align-items:center;gap:18px;padding:24px;background:linear-gradient(135deg,#eef2ff,#f5f3ff);border-radius:14px;margin-bottom:20px;">
                <div style="width:64px;height:64px;border-radius:50%;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:22px;">
                    <?php echo esc_html( $init ); ?>
                </div>
                <div style="flex:1;min-width:0;">
                    <div style="font-size:13px;color:#6366f1;font-weight:600;letter-spacing:.5px;text-transform:uppercase;">Welcome back</div>
                    <div style="font-size:22px;font-weight:700;margin-top:2px;">
                        <?php echo esc_html( $name ); ?>
                    </div>
                    <div style="color:#64748b;font-size:14px;margin-top:2px;">
                        <?php echo esc_html( $user['email'] ); ?>
                    </div>
                </div>
                <a href="<?php echo esc_url( $logout_url ); ?>" style="padding:10px 18px;border:1px solid #e2e8f0;border-radius:8px;color:#0f172a;text-decoration:none;font-weight:600;background:#fff;">Log out</a>
            </div>

            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;margin-bottom:20px;">
                <div style="padding:18px;background:#fff;border:1px solid #e5e7eb;border-radius:12px;">
                    <div style="font-size:12px;color:#64748b;text-transform:uppercase;letter-spacing:.5px;">Member Since</div>
                    <div style="font-size:18px;font-weight:700;margin-top:6px;">
                        <?php echo esc_html( date_i18n( 'M j, Y', strtotime( (string) $user['created_at'] ) ) ); ?>
                    </div>
                </div>
                <div style="padding:18px;background:#fff;border:1px solid #e5e7eb;border-radius:12px;">
                    <div style="font-size:12px;color:#64748b;text-transform:uppercase;letter-spacing:.5px;">Total Logins</div>
                    <div style="font-size:18px;font-weight:700;margin-top:6px;">
                        <?php echo (int) $user['login_count']; ?>
                    </div>
                </div>
                <div style="padding:18px;background:#fff;border:1px solid #e5e7eb;border-radius:12px;">
                    <div style="font-size:12px;color:#64748b;text-transform:uppercase;letter-spacing:.5px;">Last Login</div>
                    <div style="font-size:18px;font-weight:700;margin-top:6px;">
                        <?php echo ! empty( $user['last_login_at'] ) ? esc_html( date_i18n( 'M j, Y g:i a', strtotime( (string) $user['last_login_at'] ) ) ) : '—'; ?>
                    </div>
                </div>
            </div>

            <div style="padding:24px;background:#fff;border:1px solid #e5e7eb;border-radius:12px;">
                <h3 style="margin:0 0 16px;font-size:16px;color:#0f172a;">Your Profile</h3>
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;">
                    <div>
                        <div style="font-size:12px;color:#64748b;font-weight:600;text-transform:uppercase;letter-spacing:.5px;">Name</div>
                        <div style="margin-top:4px;font-size:15px;"><?php echo esc_html( $user['display_name'] ?: '—' ); ?></div>
                    </div>
                    <div>
                        <div style="font-size:12px;color:#64748b;font-weight:600;text-transform:uppercase;letter-spacing:.5px;">Email</div>
                        <div style="margin-top:4px;font-size:15px;"><?php echo esc_html( $user['email'] ); ?></div>
                    </div>
                    <div>
                        <div style="font-size:12px;color:#64748b;font-weight:600;text-transform:uppercase;letter-spacing:.5px;">Phone</div>
                        <div style="margin-top:4px;font-size:15px;"><?php echo esc_html( $user['phone'] ?: '—' ); ?></div>
                    </div>
                    <?php foreach ( $meta as $k => $v ) :
                        if ( $v === '' || $v === null ) continue;
                        if ( is_array( $v ) || is_object( $v ) ) $v = wp_json_encode( $v );
                        // Skip noisy fields that are already shown above or contain secrets.
                        $lk = strtolower( (string) $k );
                        if ( in_array( $lk, [ 'password', 'confirm password', 'email', 'name', 'phone' ], true ) ) continue;
                        ?>
                        <div>
                            <div style="font-size:12px;color:#64748b;font-weight:600;text-transform:uppercase;letter-spacing:.5px;"><?php echo esc_html( $k ); ?></div>
                            <div style="margin-top:4px;font-size:15px;word-break:break-word;"><?php echo esc_html( (string) $v ); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Single source of truth for the current membership state. Used by
     * both the REST GET and the forms-page admin toggle so the UI never
     * drifts from the database.
     */
    public static function membership_state() {
        $enabled         = (bool) get_option( 'fcp_membership_enabled', 0 );
        $login_form_id    = (int) get_option( 'fcp_login_form_id', 0 );
        $register_form_id = (int) get_option( 'fcp_register_form_id', 0 );
        $login_page_id    = (int) get_option( 'fcp_login_page_id', 0 );
        $register_page_id = (int) get_option( 'fcp_register_page_id', 0 );

        $login_form    = $login_form_id    ? FCP_DB::get_form( $login_form_id )    : null;
        $register_form = $register_form_id ? FCP_DB::get_form( $register_form_id ) : null;

        return [
            'enabled'              => $enabled,
            'login_form_id'        => $login_form_id,
            'login_form_status'    => $login_form    ? ( $login_form['status']    ?? 'draft' ) : 'missing',
            'register_form_id'     => $register_form_id,
            'register_form_status' => $register_form ? ( $register_form['status'] ?? 'draft' ) : 'missing',
            'login_page_id'        => $login_page_id,
            'login_page_status'    => $login_page_id    ? get_post_status( $login_page_id )    : 'missing',
            'register_page_id'     => $register_page_id,
            'register_page_status' => $register_page_id ? get_post_status( $register_page_id ) : 'missing',
            'login_page_url'       => $login_page_id    ? get_permalink( $login_page_id )     : '',
            'register_page_url'    => $register_page_id ? get_permalink( $register_page_id )  : '',
        ];
    }

    /**
     * Flip the membership toggle. When enabled=true we ensure the forms
     * and pages exist, set both forms to "active" status, and publish both
     * pages. When enabled=false we set forms to "draft" and switch pages
     * to "draft" too (we never delete them so re-enabling restores the
     * exact same forms and shortcode embeds).
     */
    public static function set_membership_enabled( $enabled ) {
        global $wpdb;
        $enabled = (bool) $enabled;
        update_option( 'fcp_membership_enabled', $enabled ? 1 : 0 );

        if ( $enabled ) {
            // ensure_auth_pages() will create the forms (as draft) + pages
            // (as published) if they're missing. We then bump the forms
            // to active and ensure both pages are published.
            self::ensure_auth_pages();
        }

        $ids = [
            'login_form_id'    => (int) get_option( 'fcp_login_form_id', 0 ),
            'register_form_id' => (int) get_option( 'fcp_register_form_id', 0 ),
            'login_page_id'    => (int) get_option( 'fcp_login_page_id', 0 ),
            'register_page_id' => (int) get_option( 'fcp_register_page_id', 0 ),
        ];

        $form_status = $enabled ? 'active' : 'draft';
        $page_status = $enabled ? 'publish' : 'draft';

        // Flip form statuses directly — avoid full update_form() because
        // that triggers a revision snapshot for what is just a status flip.
        $forms_table = FCP_DB::forms_table();
        foreach ( [ $ids['login_form_id'], $ids['register_form_id'] ] as $fid ) {
            if ( $fid ) {
                $wpdb->update( $forms_table,
                    [ 'status' => $form_status, 'updated_at' => current_time( 'mysql' ) ],
                    [ 'id' => $fid ]
                );
            }
        }

        foreach ( [ $ids['login_page_id'], $ids['register_page_id'] ] as $pid ) {
            if ( $pid && get_post_status( $pid ) !== false ) {
                wp_update_post( [ 'ID' => $pid, 'post_status' => $page_status ] );
            }
        }

        return self::membership_state();
    }

    /**
     * Ensure the auto-generated Login + Registration forms exist (status =
     * draft so the admin can review & edit before publishing), and that
     * each is paired with a published WordPress page that embeds it.
     *
     * Returns an associative array of { login_form_id, login_page_id,
     * register_form_id, register_page_id }.
     */
    public static function ensure_auth_pages() {
        $login_form_id = (int) get_option( 'fcp_login_form_id', 0 );
        if ( ! $login_form_id || ! FCP_DB::get_form( $login_form_id ) ) {
            $login_form_id = FCP_DB::insert_form( [
                'title'  => 'Member Login',
                'slug'   => 'fcp-member-login',
                'status' => 'draft',
                'steps'  => [[
                    'id'     => 'step_1',
                    'title'  => 'Sign in',
                    'fields' => [
                        [ 'id' => 'f_email', 'type' => 'email',    'label' => 'Email',    'required' => true ],
                        [ 'id' => 'f_pass',  'type' => 'password', 'label' => 'Password', 'required' => true ],
                    ],
                ]],
                'settings' => [
                    'submitText'     => 'Log in',
                    'successMessage' => 'Logged in. Redirecting…',
                    'recaptcha'      => false,
                    'afterSubmit'    => [
                        'formUser' => [
                            'mode'          => 'login',
                            'emailField'    => 'Email',
                            'passwordField' => 'Password',
                            'nameField'     => '',
                            'phoneField'    => '',
                            'redirectUrl'   => '',
                            'extraFields'   => [],
                        ],
                    ],
                ],
            ] );
            if ( $login_form_id ) update_option( 'fcp_login_form_id', $login_form_id );
        }

        $register_form_id = (int) get_option( 'fcp_register_form_id', 0 );
        if ( ! $register_form_id || ! FCP_DB::get_form( $register_form_id ) ) {
            $register_form_id = FCP_DB::insert_form( [
                'title'  => 'Member Registration',
                'slug'   => 'fcp-member-registration',
                'status' => 'draft',
                'steps'  => [[
                    'id'     => 'step_1',
                    'title'  => 'Create your account',
                    'fields' => [
                        [ 'id' => 'f_name',  'type' => 'name',     'label' => 'Full Name', 'required' => true ],
                        [ 'id' => 'f_email', 'type' => 'email',    'label' => 'Email',     'required' => true ],
                        [ 'id' => 'f_phone', 'type' => 'tel',      'label' => 'Phone',     'required' => false ],
                        [ 'id' => 'f_pass',  'type' => 'password', 'label' => 'Password',  'required' => true ],
                    ],
                ]],
                'settings' => [
                    'submitText'     => 'Create account',
                    'successMessage' => 'Account created. Redirecting…',
                    'recaptcha'      => false,
                    'afterSubmit'    => [
                        'formUser' => [
                            'mode'          => 'register',
                            'emailField'    => 'Email',
                            'passwordField' => 'Password',
                            'nameField'     => 'Full Name',
                            'phoneField'    => 'Phone',
                            'redirectUrl'   => '',
                            'extraFields'   => [],
                        ],
                    ],
                ],
            ] );
            if ( $register_form_id ) update_option( 'fcp_register_form_id', $register_form_id );
        }

        $login_page_id    = self::ensure_page( 'fcp_login_page_id',    'login',    'Login',    '[formyantra id="' . (int) $login_form_id . '"]' );
        $register_page_id = self::ensure_page( 'fcp_register_page_id', 'register', 'Register', '[formyantra id="' . (int) $register_form_id . '"]' );

        if ( $login_page_id ) {
            update_option( 'fcp_user_login_page_url', get_permalink( $login_page_id ) );
        }

        return [
            'login_form_id'    => (int) $login_form_id,
            'login_page_id'    => (int) $login_page_id,
            'register_form_id' => (int) $register_form_id,
            'register_page_id' => (int) $register_page_id,
        ];
    }

    /**
     * Generic helper: ensure a single published page with the given slug
     * exists. Re-creates it if the stored option points at a missing post.
     */
    private static function ensure_page( $option_key, $slug, $title, $content ) {
        $page_id = (int) get_option( $option_key, 0 );
        if ( $page_id && get_post_status( $page_id ) === 'publish' ) {
            return $page_id;
        }
        $existing = get_page_by_path( $slug );
        if ( $existing && $existing->post_status === 'publish' ) {
            update_option( $option_key, (int) $existing->ID );
            return (int) $existing->ID;
        }
        $new_id = wp_insert_post( [
            'post_title'     => $title,
            'post_name'      => $slug,
            'post_status'    => 'publish',
            'post_type'      => 'page',
            'post_author'    => 1,
            'post_content'   => $content,
            'comment_status' => 'closed',
            'ping_status'    => 'closed',
        ], true );
        if ( ! is_wp_error( $new_id ) ) {
            update_option( $option_key, (int) $new_id );
            return (int) $new_id;
        }
        return 0;
    }

    /**
     * Form Locker frontend gate. Runs before render() emits the form HTML.
     * Returns TRUE when the visitor is allowed through; otherwise returns
     * an HTML string (placeholder, password prompt, login wall, etc.) which
     * the caller emits in place of the form.
     *
     * Checks (in order):
     *   1. Password protection — show password prompt, accept POST + cookie
     *   2. Login required — show "please log in" wall
     *   3. Geo restriction — show "not available in your region"
     * One-per-user + per-field unique are enforced server-side at submit time
     * (they can't be checked frontend without leaking submission data).
     */
    public static function check_locker_access( $form ) {
        $locker = $form['settings']['locker'] ?? [];
        $form_id = (int) ( $form['id'] ?? 0 );

        // ---------- 1. Password gate ----------
        $pw = $locker['password'] ?? [];
        if ( ! empty( $pw['enabled'] ) && ! empty( $pw['password'] ) ) {
            $cookie_key  = 'fcp_form_pw_' . $form_id;
            $expect_hash = wp_hash( (string) $pw['password'] );
            $unlocked    = isset( $_COOKIE[ $cookie_key ] ) && hash_equals( $expect_hash, (string) $_COOKIE[ $cookie_key ] );

            // Handle a posted password attempt
            if ( ! $unlocked && isset( $_POST['fcp_form_pw_id'] ) && (int) $_POST['fcp_form_pw_id'] === $form_id ) {
                $given = (string) ( $_POST['fcp_form_pw'] ?? '' );
                if ( hash_equals( (string) $pw['password'], $given ) ) {
                    setcookie( $cookie_key, $expect_hash, time() + 6 * HOUR_IN_SECONDS, '/' );
                    $unlocked = true;
                } else {
                    return self::locker_panel(
                        self::locker_icon( 'lock' ) . ' Password Required',
                        $pw['prompt'] ?: 'This form is password-protected.',
                        '<form method="post" action="" style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin-top:14px;">'
                        . '<input type="hidden" name="fcp_form_pw_id" value="' . esc_attr( $form_id ) . '">'
                        . '<input type="password" name="fcp_form_pw" placeholder="Enter password" required style="flex:1;min-width:180px;padding:10px 14px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;">'
                        . '<button type="submit" style="padding:10px 22px;background:#6366f1;color:#fff;border:none;border-radius:8px;font-weight:600;cursor:pointer;">Unlock</button>'
                        . '</form>'
                        . '<div style="margin-top:10px;color:#dc2626;font-size:13px;">Incorrect password — please try again.</div>'
                    );
                }
            }
            if ( ! $unlocked ) {
                return self::locker_panel(
                    self::locker_icon( 'lock' ) . ' Password Required',
                    $pw['prompt'] ?: 'This form is password-protected. Enter the password to continue.',
                    '<form method="post" action="" style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin-top:14px;">'
                    . '<input type="hidden" name="fcp_form_pw_id" value="' . esc_attr( $form_id ) . '">'
                    . '<input type="password" name="fcp_form_pw" placeholder="Enter password" required autofocus style="flex:1;min-width:180px;padding:10px 14px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;">'
                    . '<button type="submit" style="padding:10px 22px;background:#6366f1;color:#fff;border:none;border-radius:8px;font-weight:600;cursor:pointer;">Unlock</button>'
                    . '</form>'
                );
            }
        }

        // ---------- 2. Login required gate ----------
        $login = $locker['login'] ?? [];
        if ( ! empty( $login['enabled'] ) ) {
            $type         = $login['type'] ?? 'wp';
            $is_wp_user   = is_user_logged_in();
            $is_form_user = class_exists( 'FCP_Users' ) && FCP_Users::current_user();
            $ok = ( $type === 'wp' && $is_wp_user )
                  || ( $type === 'form_users' && $is_form_user )
                  || ( $type === 'any' && ( $is_wp_user || $is_form_user ) );
            if ( $ok && $type === 'wp' && ! empty( $login['roles'] ) && is_array( $login['roles'] ) && $is_wp_user ) {
                $u = wp_get_current_user();
                $ok = (bool) array_intersect( $login['roles'], (array) $u->roles );
            }
            if ( ! $ok ) {
                $login_url = '';
                if ( $type === 'form_users' || $type === 'any' ) {
                    $login_url = (string) get_option( 'fcp_user_login_page_url', '' );
                }
                if ( ! $login_url ) $login_url = wp_login_url( get_permalink() );
                return self::locker_panel(
                    self::locker_icon( 'members' ) . ' Members Only',
                    $login['message'] ?: 'Please log in to access this form.',
                    '<a href="' . esc_url( $login_url ) . '" style="display:inline-block;margin-top:14px;padding:12px 28px;background:#6366f1;color:#fff;border-radius:8px;text-decoration:none;font-weight:600;">Log In →</a>'
                );
            }
        }

        // ---------- 3. Geo restriction gate ----------
        $geo = $locker['geo'] ?? [];
        if ( ! empty( $geo['enabled'] ) && ! empty( $geo['countries'] ) && is_array( $geo['countries'] ) ) {
            $country = class_exists( 'FCP_REST' ) ? FCP_REST::detect_country() : '';
            $mode    = ( $geo['mode'] ?? 'allow' ) === 'block' ? 'block' : 'allow';
            $list    = array_map( 'strtoupper', $geo['countries'] );
            $in_list = $country && in_array( strtoupper( $country ), $list, true );
            $denied  = ( $mode === 'allow' ) ? ! $in_list : $in_list;
            if ( $denied ) {
                return self::locker_panel(
                    self::locker_icon( 'globe' ) . ' Not Available in Your Region',
                    $geo['message'] ?: 'Sorry — this form is not available in your region.',
                    ''
                );
            }
        }

        return true;
    }

    /**
     * Inline SVG icons used in the locker placeholders. Returns an HTML
     * fragment ready to drop into the page title. Each is sized to sit
     * cleanly next to a heading.
     */
    private static function locker_icon( $kind ) {
        $svg = '';
        if ( $kind === 'lock' ) {
            $svg = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#6366f1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-7px;margin-right:6px;"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>';
        } elseif ( $kind === 'members' ) {
            $svg = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#6366f1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-7px;margin-right:6px;"><circle cx="12" cy="7" r="4"/><path d="M5 21v-1a7 7 0 0 1 7-7h0a7 7 0 0 1 4 1.2"/><rect x="14" y="15" width="8" height="6" rx="1"/><path d="M16 15v-2a2 2 0 0 1 4 0v2"/></svg>';
        } elseif ( $kind === 'globe' ) {
            $svg = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#6366f1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-7px;margin-right:6px;"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>';
        }
        return $svg;
    }

    /**
     * Helper: shared "blocked form" placeholder used by every gate. Keeps
     * the visual consistent regardless of which check denied access.
     */
    private static function locker_panel( $title, $message, $extra_html ) {
        // $title may contain HTML (the SVG icon fragment), so we DON'T
        // esc_html the whole string — only the message and extra_html.
        return '<div class="fcp-locker-wrap" style="max-width:520px;margin:30px auto;padding:34px 28px;background:#fff;border:1px solid #e2e8f0;border-radius:14px;box-shadow:0 4px 30px rgba(15,23,42,0.06);text-align:center;font-family:"Inter",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",sans-serif;">'
             . '<div style="font-size:22px;font-weight:700;color:#0f172a;margin-bottom:8px;">' . wp_kses_post( $title ) . '</div>'
             . '<p style="color:#64748b;font-size:15px;line-height:1.5;margin:0;">' . esc_html( $message ) . '</p>'
             . $extra_html
             . '</div>';
    }

    /**
     * Ensure the auto-generated "User Dashboard" WordPress page exists.
     * Returns the page ID. Called from plugin activation + on first read.
     */
    public static function ensure_user_dashboard_page() {
        $page_id = (int) get_option( 'fcp_user_dashboard_page_id', 0 );
        if ( $page_id && get_post_status( $page_id ) === 'publish' ) {
            return $page_id;
        }
        $existing = get_page_by_path( 'user-dashboard' );
        if ( $existing && $existing->post_status === 'publish' ) {
            update_option( 'fcp_user_dashboard_page_id', (int) $existing->ID );
            return (int) $existing->ID;
        }
        $page_id = wp_insert_post( [
            'post_title'   => 'User Dashboard',
            'post_name'    => 'user-dashboard',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
            'post_content' => '[fcp_user_dashboard]',
            'comment_status' => 'closed',
            'ping_status'  => 'closed',
        ], true );
        if ( ! is_wp_error( $page_id ) ) {
            update_option( 'fcp_user_dashboard_page_id', (int) $page_id );
            return (int) $page_id;
        }
        return 0;
    }
}
