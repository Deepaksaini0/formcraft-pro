<?php
/**
 * FormYantra — Advanced Analytics (v2.72.63).
 *
 * Ships four previously-missing analytics capabilities:
 *   1. Per-day view tracking — every view gets a timestamped row so we
 *      can graph views over time, not derive from a running INT.
 *   2. Field interaction heatmap — records focus/blur/change per field
 *      so admins see time-on-field + which fields get abandoned.
 *   3. Cohort analysis — conversion rate per UTM source/medium/campaign.
 *      Requires per-view UTM capture (this class handles it) + joins
 *      against submissions._meta.utm.
 *   4. Session replay — chronological event log per session (focus/blur/
 *      change/nav) that admins can play back as a timeline. Not a
 *      pixel-perfect DOM replay — a scoped, privacy-safe event list.
 *
 * Storage strategy: three narrow tables, indexed on form_id + ts.
 * Retention: default 90 days, configurable via option `fcp_analytics_pro`
 * (`retention_days`). A daily cron prunes rows older than that.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FCP_Analytics_Pro {

    const VIEWS_TABLE   = 'fcp_views_log';
    const FIELDS_TABLE  = 'fcp_field_events';
    const REPLAY_TABLE  = 'fcp_replay_events';
    const SCHEMA_OPT    = 'fcp_analytics_pro_schema';
    const SCHEMA_VER    = 1;
    const CRON_HOOK     = 'fcp_analytics_pro_prune';

    /* ─────────────────────────────────────────────────────────────
     * 0. Schema — created lazily on first request.
     * ───────────────────────────────────────────────────────────── */
    public static function ensure_schema() {
        if ( (int) get_option( self::SCHEMA_OPT, 0 ) === self::SCHEMA_VER ) return;
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $v = $wpdb->prefix . self::VIEWS_TABLE;
        $f = $wpdb->prefix . self::FIELDS_TABLE;
        $r = $wpdb->prefix . self::REPLAY_TABLE;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( "CREATE TABLE $v (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            form_id BIGINT UNSIGNED NOT NULL,
            ts BIGINT UNSIGNED NOT NULL,
            session_id VARCHAR(64) NOT NULL DEFAULT '',
            utm_source VARCHAR(120) NOT NULL DEFAULT '',
            utm_medium VARCHAR(120) NOT NULL DEFAULT '',
            utm_campaign VARCHAR(120) NOT NULL DEFAULT '',
            referrer VARCHAR(255) NOT NULL DEFAULT '',
            country VARCHAR(2) NOT NULL DEFAULT '',
            device VARCHAR(16) NOT NULL DEFAULT '',
            PRIMARY KEY (id),
            KEY form_ts (form_id, ts),
            KEY session_id (session_id)
        ) $charset;" );
        dbDelta( "CREATE TABLE $f (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            form_id BIGINT UNSIGNED NOT NULL,
            session_id VARCHAR(64) NOT NULL DEFAULT '',
            field_id VARCHAR(64) NOT NULL DEFAULT '',
            field_label VARCHAR(120) NOT NULL DEFAULT '',
            event_type VARCHAR(16) NOT NULL DEFAULT '',
            ts BIGINT UNSIGNED NOT NULL,
            duration_ms INT UNSIGNED NOT NULL DEFAULT 0,
            value_len INT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            KEY form_ts (form_id, ts),
            KEY session_field (session_id, field_id)
        ) $charset;" );
        dbDelta( "CREATE TABLE $r (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            form_id BIGINT UNSIGNED NOT NULL,
            session_id VARCHAR(64) NOT NULL,
            ts BIGINT UNSIGNED NOT NULL,
            event_type VARCHAR(24) NOT NULL,
            target VARCHAR(120) NOT NULL DEFAULT '',
            payload TEXT,
            PRIMARY KEY (id),
            KEY form_session (form_id, session_id),
            KEY ts (ts)
        ) $charset;" );
        update_option( self::SCHEMA_OPT, self::SCHEMA_VER, false );

        // Schedule daily pruning if not already.
        if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
            wp_schedule_event( time() + 3600, 'daily', self::CRON_HOOK );
        }
    }

    /* ─────────────────────────────────────────────────────────────
     * 1. Per-day view tracking.
     * ───────────────────────────────────────────────────────────── */
    public static function log_view( $form_id, $args = [] ) {
        self::ensure_schema();
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . self::VIEWS_TABLE, [
            'form_id'      => (int) $form_id,
            'ts'           => time(),
            'session_id'   => (string) ( $args['session_id']   ?? '' ),
            'utm_source'   => self::clip( $args['utm_source']   ?? '', 120 ),
            'utm_medium'   => self::clip( $args['utm_medium']   ?? '', 120 ),
            'utm_campaign' => self::clip( $args['utm_campaign'] ?? '', 120 ),
            'referrer'     => self::clip( $args['referrer']     ?? '', 255 ),
            'country'      => strtoupper( substr( (string) ( $args['country'] ?? '' ), 0, 2 ) ),
            'device'       => self::clip( $args['device'] ?? '', 16 ),
        ] );
    }

    /** Aggregate views per day for the last N days. Returns
     *  array of [ [ 'date' => 'YYYY-MM-DD', 'views' => N ] ]. */
    public static function views_daily( $form_id, $days = 30 ) {
        self::ensure_schema();
        global $wpdb;
        $days = max( 1, min( 365, (int) $days ) );
        $table = $wpdb->prefix . self::VIEWS_TABLE;
        $since = time() - ( $days * DAY_IN_SECONDS );
        $where = 'ts >= %d';
        $params = [ $since ];
        if ( $form_id ) { $where .= ' AND form_id = %d'; $params[] = (int) $form_id; }
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT DATE(FROM_UNIXTIME(ts)) AS d, COUNT(*) AS c FROM $table WHERE $where GROUP BY d ORDER BY d",
            $params
        ), ARRAY_A );
        // Fill zero-count days so the chart's x-axis is continuous.
        $by = [];
        foreach ( $rows as $r ) $by[ $r['d'] ] = (int) $r['c'];
        $out = [];
        for ( $i = $days - 1; $i >= 0; $i-- ) {
            $d = gmdate( 'Y-m-d', time() - ( $i * DAY_IN_SECONDS ) );
            $out[] = [ 'date' => $d, 'views' => (int) ( $by[ $d ] ?? 0 ) ];
        }
        return $out;
    }

    /* ─────────────────────────────────────────────────────────────
     * 2. Field interaction heatmap.
     * ───────────────────────────────────────────────────────────── */
    public static function log_field_events( $rows ) {
        if ( ! is_array( $rows ) || ! $rows ) return 0;
        self::ensure_schema();
        global $wpdb;
        $count = 0;
        $table = $wpdb->prefix . self::FIELDS_TABLE;
        foreach ( $rows as $r ) {
            $ok = $wpdb->insert( $table, [
                'form_id'     => (int) ( $r['form_id']     ?? 0 ),
                'session_id'  => self::clip( $r['session_id']  ?? '', 64 ),
                'field_id'    => self::clip( $r['field_id']    ?? '', 64 ),
                'field_label' => self::clip( $r['field_label'] ?? '', 120 ),
                'event_type'  => self::clip( $r['event_type']  ?? 'focus', 16 ),
                'ts'          => (int) ( $r['ts'] ?? time() ),
                'duration_ms' => max( 0, (int) ( $r['duration_ms'] ?? 0 ) ),
                'value_len'   => max( 0, (int) ( $r['value_len']   ?? 0 ) ),
            ] );
            if ( $ok ) $count++;
        }
        return $count;
    }

    /** Aggregate per-field metrics for the last N days.
     *  Returns [ { field_label, focuses, blurs, changes, avg_ms,
     *  abandoned_pct } ] where abandoned_pct = focused-but-never-changed. */
    public static function field_heatmap( $form_id, $days = 30 ) {
        self::ensure_schema();
        global $wpdb;
        $days  = max( 1, min( 365, (int) $days ) );
        $since = time() - ( $days * DAY_IN_SECONDS );
        $table = $wpdb->prefix . self::FIELDS_TABLE;
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT field_label, event_type, session_id, duration_ms
             FROM $table
             WHERE form_id = %d AND ts >= %d AND field_label <> ''
             LIMIT 50000",
            (int) $form_id, $since
        ), ARRAY_A );
        $by = [];
        foreach ( $rows as $r ) {
            $l = $r['field_label'];
            if ( ! isset( $by[ $l ] ) ) $by[ $l ] = [
                'field_label' => $l,
                'focuses' => 0, 'blurs' => 0, 'changes' => 0,
                'total_ms' => 0, 'blur_samples' => 0,
                '_focus_sessions' => [], '_change_sessions' => [],
            ];
            if ( $r['event_type'] === 'focus' ) {
                $by[ $l ]['focuses']++;
                $by[ $l ]['_focus_sessions'][ $r['session_id'] ] = 1;
            } elseif ( $r['event_type'] === 'blur' ) {
                $by[ $l ]['blurs']++;
                if ( (int) $r['duration_ms'] > 0 ) {
                    $by[ $l ]['total_ms'] += (int) $r['duration_ms'];
                    $by[ $l ]['blur_samples']++;
                }
            } elseif ( $r['event_type'] === 'change' ) {
                $by[ $l ]['changes']++;
                $by[ $l ]['_change_sessions'][ $r['session_id'] ] = 1;
            }
        }
        $out = [];
        foreach ( $by as $l => $stats ) {
            $focus_ct  = count( $stats['_focus_sessions'] );
            $change_ct = count( $stats['_change_sessions'] );
            $abandon   = $focus_ct > 0 ? round( ( ( $focus_ct - $change_ct ) / max( 1, $focus_ct ) ) * 100, 1 ) : 0;
            $out[] = [
                'field_label' => $l,
                'focuses'     => $stats['focuses'],
                'blurs'       => $stats['blurs'],
                'changes'     => $stats['changes'],
                'avg_ms'      => $stats['blur_samples'] ? (int) round( $stats['total_ms'] / $stats['blur_samples'] ) : 0,
                'abandoned_pct' => $abandon,
            ];
        }
        // Sort by focuses desc so hottest fields appear first.
        usort( $out, function( $a, $b ) { return $b['focuses'] - $a['focuses']; } );
        return $out;
    }

    /* ─────────────────────────────────────────────────────────────
     * 3. Cohort analysis (UTM conversion).
     * ───────────────────────────────────────────────────────────── */
    public static function cohorts( $form_id, $days = 30, $dimension = 'source' ) {
        self::ensure_schema();
        global $wpdb;
        $days  = max( 1, min( 365, (int) $days ) );
        $since = time() - ( $days * DAY_IN_SECONDS );
        $col   = ( $dimension === 'medium' ) ? 'utm_medium'
               : ( ( $dimension === 'campaign' ) ? 'utm_campaign' : 'utm_source' );
        $vt = $wpdb->prefix . self::VIEWS_TABLE;
        $views = $wpdb->get_results( $wpdb->prepare(
            "SELECT COALESCE(NULLIF($col,''), '(direct)') AS grp, COUNT(*) AS c
             FROM $vt WHERE ts >= %d AND form_id = %d GROUP BY grp",
            $since, (int) $form_id
        ), ARRAY_A );
        $view_by = [];
        foreach ( $views as $v ) $view_by[ $v['grp'] ] = (int) $v['c'];

        // Submissions — read from FCP_DB with _meta.utm.
        $subs_table = $wpdb->prefix . 'fcp_submissions';
        $subs = $wpdb->get_col( $wpdb->prepare(
            "SELECT data FROM $subs_table WHERE form_id = %d AND UNIX_TIMESTAMP(created_at) >= %d AND (is_spam IS NULL OR is_spam = 0) AND (is_abandoned IS NULL OR is_abandoned = 0)",
            (int) $form_id, $since
        ) );
        $sub_by = [];
        foreach ( (array) $subs as $raw ) {
            $decoded = json_decode( (string) $raw, true );
            $utm = ( is_array( $decoded ) && isset( $decoded['_meta']['utm'] ) ) ? $decoded['_meta']['utm'] : [];
            $key = $utm[ $col === 'utm_source' ? 'source' : ( $col === 'utm_medium' ? 'medium' : 'campaign' ) ] ?? '';
            if ( ! $key ) $key = '(direct)';
            $sub_by[ $key ] = ( $sub_by[ $key ] ?? 0 ) + 1;
        }
        // Union all keys.
        $keys = array_unique( array_merge( array_keys( $view_by ), array_keys( $sub_by ) ) );
        $out = [];
        foreach ( $keys as $k ) {
            $v = (int) ( $view_by[ $k ] ?? 0 );
            $s = (int) ( $sub_by[ $k ]  ?? 0 );
            $out[] = [
                'group'      => $k,
                'views'      => $v,
                'submissions'=> $s,
                'conversion' => $v > 0 ? round( ( $s / $v ) * 100, 2 ) : 0,
            ];
        }
        // Sort by views desc.
        usort( $out, function( $a, $b ) { return $b['views'] - $a['views']; } );
        return $out;
    }

    /* ─────────────────────────────────────────────────────────────
     * 4. Session replay — event log per session.
     * ───────────────────────────────────────────────────────────── */
    public static function log_replay_events( $rows ) {
        if ( ! is_array( $rows ) || ! $rows ) return 0;
        self::ensure_schema();
        global $wpdb;
        $count = 0;
        $table = $wpdb->prefix . self::REPLAY_TABLE;
        // Cap 200 events per single insert to prevent abuse.
        $rows = array_slice( $rows, 0, 200 );
        foreach ( $rows as $r ) {
            $payload = isset( $r['payload'] ) ? wp_json_encode( $r['payload'] ) : '';
            if ( strlen( $payload ) > 1000 ) $payload = substr( $payload, 0, 1000 );
            $ok = $wpdb->insert( $table, [
                'form_id'    => (int) ( $r['form_id'] ?? 0 ),
                'session_id' => self::clip( $r['session_id'] ?? '', 64 ),
                'ts'         => (int) ( $r['ts'] ?? time() ),
                'event_type' => self::clip( $r['event_type'] ?? '', 24 ),
                'target'     => self::clip( $r['target'] ?? '', 120 ),
                'payload'    => $payload,
            ] );
            if ( $ok ) $count++;
        }
        return $count;
    }

    /** List recent replay sessions (grouped by session_id). */
    public static function list_replays( $form_id, $limit = 50 ) {
        self::ensure_schema();
        global $wpdb;
        $table = $wpdb->prefix . self::REPLAY_TABLE;
        $limit = max( 1, min( 200, (int) $limit ) );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT session_id, MIN(ts) AS start_ts, MAX(ts) AS end_ts, COUNT(*) AS n_events
             FROM $table WHERE form_id = %d
             GROUP BY session_id
             ORDER BY start_ts DESC
             LIMIT %d",
            (int) $form_id, $limit
        ), ARRAY_A );
        foreach ( $rows as &$r ) {
            $r['duration_s'] = max( 0, (int) $r['end_ts'] - (int) $r['start_ts'] );
        }
        return $rows;
    }

    public static function get_replay( $session_id ) {
        self::ensure_schema();
        global $wpdb;
        $table = $wpdb->prefix . self::REPLAY_TABLE;
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT ts, event_type, target, payload FROM $table WHERE session_id = %s ORDER BY ts ASC LIMIT 5000",
            (string) $session_id
        ), ARRAY_A );
        foreach ( $rows as &$r ) {
            $r['payload'] = $r['payload'] ? json_decode( $r['payload'], true ) : null;
        }
        return $rows;
    }

    /* ─────────────────────────────────────────────────────────────
     * Retention prune.
     * ───────────────────────────────────────────────────────────── */
    public static function prune() {
        global $wpdb;
        $opt = get_option( 'fcp_analytics_pro', [] );
        $days = max( 7, min( 730, (int) ( $opt['retention_days'] ?? 90 ) ) );
        $cutoff = time() - ( $days * DAY_IN_SECONDS );
        foreach ( [ self::VIEWS_TABLE, self::FIELDS_TABLE, self::REPLAY_TABLE ] as $t ) {
            $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}$t WHERE ts < %d", $cutoff ) );
        }
    }

    private static function clip( $s, $max ) {
        return mb_substr( (string) $s, 0, $max );
    }
}

// Hook the prune cron.
add_action( FCP_Analytics_Pro::CRON_HOOK, [ 'FCP_Analytics_Pro', 'prune' ] );
