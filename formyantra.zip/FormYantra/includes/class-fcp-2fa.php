<?php
/**
 * FormYantra — Two-Factor Authentication (TOTP).
 *
 * Independent of any WP 2FA plugin. Gates FormYantra admin pages with a
 * 6-digit code from Google Authenticator / Authy / 1Password / Bitwarden
 * (any TOTP-compliant app).
 *
 * Why independent? Customers running this plugin on agency sites often
 * have admins who don't have WP 2FA set up at all — locking down ONLY
 * the form data without forcing a site-wide 2FA rollout. The verification
 * cookie is scoped to FormYantra pages only; it never gates wp-admin.
 *
 * Flow:
 *   1) Enrollment — admin scans QR (otpauth://) and types one code to confirm.
 *      We mark 2fa as enabled + generate 10 backup codes (single-use, hashed).
 *   2) Gate — on every FormYantra admin page load, FCP_Admin checks
 *      verify_session(). If 2FA is enabled + cookie is missing/expired,
 *      it redirects to a verify screen instead of the requested page.
 *   3) Verify — admin enters a TOTP code; we validate against the secret
 *      (allowing ±1 step for clock drift), set a signed cookie (8 hours),
 *      send them back to where they were going.
 *
 * Storage: fcp_2fa table. The secret is stored in PLAIN TEXT — the
 * threat model assumes DB compromise means the attacker already has
 * everything; the secret only protects against stolen-session attacks
 * where the attacker has the cookie but not the secret. Backup codes
 * are stored as SHA-256 hashes — they're write-once recovery tokens.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_2FA {

    const TABLE       = 'fcp_2fa';
    const COOKIE_NAME = 'fcp_2fa_verified';
    const COOKIE_TTL  = 8 * 3600;        // 8 hours
    const TOTP_PERIOD = 30;
    const TOTP_DIGITS = 6;
    const DRIFT       = 1;                // accept code ±DRIFT steps

    public static function bootstrap() {
        add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );
    }

    public static function table() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE;
    }

    public static function install_table() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $table   = self::table();
        $sql     = "CREATE TABLE $table (
            user_id BIGINT UNSIGNED PRIMARY KEY,
            secret VARCHAR(64) NOT NULL,
            backup_codes TEXT DEFAULT NULL,
            enabled_at DATETIME DEFAULT NULL,
            last_used_at DATETIME DEFAULT NULL
        ) $charset;";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    /* =================================================================
     * Public helpers used from FCP_Admin to gate page loads.
     * =================================================================*/

    /** True when the current user has 2FA enabled. */
    public static function is_enabled_for_current_user() {
        $u = get_current_user_id();
        if ( ! $u ) return false;
        return ! empty( self::get_row( $u )['enabled_at'] );
    }

    /** True when the current user has a valid verification cookie. */
    public static function verify_session() {
        $u = get_current_user_id();
        if ( ! $u ) return false;
        if ( empty( $_COOKIE[ self::COOKIE_NAME ] ) ) return false;
        $parts = explode( '.', (string) $_COOKIE[ self::COOKIE_NAME ] );
        if ( count( $parts ) !== 3 ) return false;
        [ $uid, $expires, $sig ] = $parts;
        if ( (int) $uid !== (int) $u ) return false;
        if ( (int) $expires < time() ) return false;
        $expected = hash_hmac( 'sha256', $uid . '.' . $expires, wp_salt( 'auth' ) );
        return hash_equals( $expected, $sig );
    }

    /** Drop a signed verification cookie after successful TOTP. */
    private static function set_session_cookie( $user_id ) {
        $expires = time() + self::COOKIE_TTL;
        $sig     = hash_hmac( 'sha256', $user_id . '.' . $expires, wp_salt( 'auth' ) );
        $value   = $user_id . '.' . $expires . '.' . $sig;
        $secure  = is_ssl();
        setcookie( self::COOKIE_NAME, $value, [
            'expires'  => $expires,
            'path'     => '/',
            'secure'   => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ] );
        $_COOKIE[ self::COOKIE_NAME ] = $value;
    }

    /* =================================================================
     * REST endpoints — enrollment + verify + disable.
     * /2fa/status   GET
     * /2fa/enroll   POST   → returns secret + otpauth_url + qr_url
     * /2fa/confirm  POST   { code } → marks enabled + returns backup codes
     * /2fa/verify   POST   { code | backup } → sets session cookie
     * /2fa/disable  POST   { code } → requires fresh code
     * =================================================================*/
    public static function register_routes() {
        // v2.72.17 — Routes moved to the main formcraft/v1 namespace to match
        // the client bridge. Prior fcp/v1 registration was orphaned — the
        // wp-bridge base URL is formcraft/v1, so every 2FA call 404'd with
        // "No route was found matching the URL and request method."
        $cap = function () { return is_user_logged_in(); };
        $ns  = 'formcraft/v1';
        register_rest_route( $ns, '/twofa/status',  [ 'methods' => WP_REST_Server::READABLE,   'callback' => [ __CLASS__, 'rest_status' ],  'permission_callback' => $cap ] );
        register_rest_route( $ns, '/twofa/enroll',  [ 'methods' => WP_REST_Server::CREATABLE,  'callback' => [ __CLASS__, 'rest_enroll' ],  'permission_callback' => $cap ] );
        register_rest_route( $ns, '/twofa/confirm', [ 'methods' => WP_REST_Server::CREATABLE,  'callback' => [ __CLASS__, 'rest_confirm' ], 'permission_callback' => $cap ] );
        register_rest_route( $ns, '/twofa/verify',  [ 'methods' => WP_REST_Server::CREATABLE,  'callback' => [ __CLASS__, 'rest_verify' ],  'permission_callback' => $cap ] );
        register_rest_route( $ns, '/twofa/disable', [ 'methods' => WP_REST_Server::CREATABLE,  'callback' => [ __CLASS__, 'rest_disable' ], 'permission_callback' => $cap ] );
    }

    public static function rest_status() {
        $u = get_current_user_id();
        $row = self::get_row( $u );
        return rest_ensure_response( [
            'enabled'   => ! empty( $row['enabled_at'] ),
            'verified'  => self::verify_session(),
            'enabled_at'=> $row['enabled_at'] ?? null,
        ] );
    }

    public static function rest_enroll() {
        $u = get_current_user_id();
        // Idempotent — re-enrolling rotates the secret. Old TOTPs stop working.
        $secret = self::base32_random( 32 );
        global $wpdb;
        $exists = self::get_row( $u );
        if ( $exists ) {
            $wpdb->update( self::table(), [ 'secret' => $secret, 'enabled_at' => null ], [ 'user_id' => $u ] );
        } else {
            $wpdb->insert( self::table(), [ 'user_id' => $u, 'secret' => $secret, 'enabled_at' => null ] );
        }
        $user  = wp_get_current_user();
        $issuer= 'FormYantra';
        $label = rawurlencode( $issuer ) . ':' . rawurlencode( $user->user_email );
        $url   = 'otpauth://totp/' . $label . '?secret=' . $secret . '&issuer=' . rawurlencode( $issuer ) . '&period=' . self::TOTP_PERIOD . '&digits=' . self::TOTP_DIGITS;
        return rest_ensure_response( [
            'secret'      => $secret,
            'otpauth_url' => $url,
            'qr_url'      => 'https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=2&data=' . rawurlencode( $url ),
        ] );
    }

    public static function rest_confirm( $req ) {
        $u    = get_current_user_id();
        // v2.61.1 — Parenthesize the (string)…?? to lock operator
        // precedence + null-safe the array access (PHP 8 fatals on
        // null['code'] otherwise).
        $body = $req->get_json_params();
        $code = preg_replace( '/\D/', '', (string) ( ( is_array( $body ) ? $body['code'] ?? '' : '' ) ) );
        $row  = self::get_row( $u );
        if ( ! $row || empty( $row['secret'] ) ) return new WP_Error( 'no_enrollment', 'Start enrollment first', [ 'status' => 400 ] );
        if ( ! self::verify_totp( $row['secret'], $code ) ) {
            return new WP_Error( 'bad_code', 'That code is invalid. Try again — your authenticator and server clocks may be out of sync.', [ 'status' => 400 ] );
        }
        // Mint 10 backup codes; store the SHA-256 hash, return the plaintext.
        $plain = [];
        for ( $i = 0; $i < 10; $i++ ) $plain[] = strtoupper( wp_generate_password( 10, false, false ) );
        $hashes = array_map( fn( $c ) => hash( 'sha256', $c ), $plain );
        global $wpdb;
        $wpdb->update( self::table(), [
            'enabled_at'   => current_time( 'mysql' ),
            'backup_codes' => implode( ',', $hashes ),
        ], [ 'user_id' => $u ] );
        self::set_session_cookie( $u );
        if ( class_exists( 'FCP_Audit' ) ) FCP_Audit::log( '2fa_enabled', 'user', $u, null, null );
        return rest_ensure_response( [ 'success' => true, 'backup_codes' => $plain ] );
    }

    public static function rest_verify( $req ) {
        $u    = get_current_user_id();
        $body = $req->get_json_params();
        $code = preg_replace( '/[^0-9A-Z]/i', '', (string) ( $body['code'] ?? '' ) );
        $row  = self::get_row( $u );
        if ( ! $row || empty( $row['enabled_at'] ) ) {
            return new WP_Error( 'not_enrolled', '2FA not enabled', [ 'status' => 400 ] );
        }
        // Backup code path (10 alphanumeric chars).
        if ( strlen( $code ) === 10 ) {
            $hash    = hash( 'sha256', strtoupper( $code ) );
            $current = array_filter( array_map( 'trim', explode( ',', (string) $row['backup_codes'] ) ) );
            if ( in_array( $hash, $current, true ) ) {
                $current = array_diff( $current, [ $hash ] );
                global $wpdb;
                $wpdb->update( self::table(), [
                    'backup_codes' => implode( ',', $current ),
                    'last_used_at' => current_time( 'mysql' ),
                ], [ 'user_id' => $u ] );
                self::set_session_cookie( $u );
                if ( class_exists( 'FCP_Audit' ) ) FCP_Audit::log( '2fa_backup_used', 'user', $u, null, [ 'remaining' => count( $current ) ] );
                return rest_ensure_response( [ 'success' => true, 'used_backup' => true, 'remaining_backups' => count( $current ) ] );
            }
        }
        // TOTP path.
        if ( strlen( $code ) === self::TOTP_DIGITS && self::verify_totp( $row['secret'], $code ) ) {
            global $wpdb;
            $wpdb->update( self::table(), [ 'last_used_at' => current_time( 'mysql' ) ], [ 'user_id' => $u ] );
            self::set_session_cookie( $u );
            return rest_ensure_response( [ 'success' => true ] );
        }
        if ( class_exists( 'FCP_Audit' ) ) FCP_Audit::log( '2fa_failed', 'user', $u, null, null );
        return new WP_Error( 'bad_code', 'Invalid code', [ 'status' => 401 ] );
    }

    public static function rest_disable( $req ) {
        $u    = get_current_user_id();
        $body = $req->get_json_params();
        $code = preg_replace( '/\D/', '', (string) ( is_array( $body ) ? $body['code'] ?? '' : '' ) );
        $row  = self::get_row( $u );
        if ( ! $row || empty( $row['enabled_at'] ) ) return new WP_Error( 'not_enrolled', '2FA not enabled', [ 'status' => 400 ] );
        if ( ! self::verify_totp( $row['secret'], $code ) ) {
            return new WP_Error( 'bad_code', 'A current 6-digit code is required to disable.', [ 'status' => 401 ] );
        }
        global $wpdb;
        $wpdb->delete( self::table(), [ 'user_id' => $u ] );
        setcookie( self::COOKIE_NAME, '', time() - 3600, '/' );
        if ( class_exists( 'FCP_Audit' ) ) FCP_Audit::log( '2fa_disabled', 'user', $u, null, null );
        return rest_ensure_response( [ 'success' => true ] );
    }

    /* =================================================================
     * RFC 6238 TOTP — own implementation, no external lib.
     * =================================================================*/

    /** base32 alphabet for compatibility with every authenticator app. */
    const B32_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

    private static function base32_random( $len ) {
        $out = '';
        for ( $i = 0; $i < $len; $i++ ) $out .= self::B32_CHARS[ random_int( 0, 31 ) ];
        return $out;
    }

    private static function base32_decode( $b32 ) {
        $b32 = strtoupper( preg_replace( '/[^A-Z2-7]/', '', $b32 ) );
        $bin = '';
        foreach ( str_split( $b32 ) as $c ) {
            $bin .= str_pad( decbin( strpos( self::B32_CHARS, $c ) ), 5, '0', STR_PAD_LEFT );
        }
        $bytes = '';
        foreach ( str_split( $bin, 8 ) as $byte ) {
            if ( strlen( $byte ) === 8 ) $bytes .= chr( bindec( $byte ) );
        }
        return $bytes;
    }

    /** Generate a single TOTP for a given counter (Unix time / period). */
    private static function totp_at( $secret, $counter ) {
        $key  = self::base32_decode( $secret );
        $bin  = pack( 'N*', 0 ) . pack( 'N*', $counter );  // 8-byte big-endian counter
        $hash = hash_hmac( 'sha1', $bin, $key, true );
        $off  = ord( $hash[ strlen( $hash ) - 1 ] ) & 0x0F;
        $code = ( ( ord( $hash[ $off ] )     & 0x7F ) << 24 )
              | ( ( ord( $hash[ $off + 1 ] ) & 0xFF ) << 16 )
              | ( ( ord( $hash[ $off + 2 ] ) & 0xFF ) <<  8 )
              |   ( ord( $hash[ $off + 3 ] ) & 0xFF );
        return str_pad( (string) ( $code % ( 10 ** self::TOTP_DIGITS ) ), self::TOTP_DIGITS, '0', STR_PAD_LEFT );
    }

    public static function verify_totp( $secret, $code ) {
        if ( strlen( $code ) !== self::TOTP_DIGITS ) return false;
        $now = (int) floor( time() / self::TOTP_PERIOD );
        for ( $i = -self::DRIFT; $i <= self::DRIFT; $i++ ) {
            if ( hash_equals( self::totp_at( $secret, $now + $i ), $code ) ) return true;
        }
        return false;
    }

    private static function get_row( $user_id ) {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . self::table() . " WHERE user_id = %d", $user_id ), ARRAY_A );
        return $row ?: null;
    }
}
