<?php
/**
 * FormYantra — GoHighLevel (GHL / LeadConnector) integration.
 *
 * Bi-directional bridge between FormYantra submissions and a GHL
 * sub-account. Uses the LeadConnector v2 API with a Private Integration
 * Token (PIT) — the token acts as a static bearer scoped to one Location.
 *
 * Outbound (Option A):
 *   Every submission (optionally gated by "paid only") is pushed to GHL
 *   as a Contact upsert. Auto-guessed field mapping (email/phone/name)
 *   with per-form override. Optional workflow trigger after upsert.
 *
 * Inbound (Option D):
 *   GHL fires webhooks to /wp-json/formcraft/v1/ghl/webhook for:
 *     - ContactUpdate       → mirror tags/customFields onto submission
 *     - OpportunityCreate   → note + auto-flip status → Reviewing
 *     - ContactDelete       → anonymize the matching FormYantra row
 *
 * Storage:
 *   Per-submission GHL state lives in three new columns on
 *   wp_fcp_submissions: ghl_contact_id, ghl_last_sync, ghl_status.
 *   Global config lives under wp_options.fcp_settings.ghl.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_GHL {

    const API_BASE  = 'https://services.leadconnectorhq.com';
    const API_VER   = '2021-07-28';

    /* -------- Settings helpers ----------------------------------- */

    public static function settings() {
        $all = get_option( 'fcp_settings', [] );
        $s   = isset( $all['ghl'] ) && is_array( $all['ghl'] ) ? $all['ghl'] : [];
        return wp_parse_args( $s, [
            'enabled'      => false,
            'token'        => '',
            'location_id'  => '',
            'default_tags' => '',
            'webhook_secret' => '',
        ] );
    }

    public static function is_configured() {
        $s = self::settings();
        return ! empty( $s['enabled'] ) && ! empty( $s['token'] ) && ! empty( $s['location_id'] );
    }

    /* -------- HTTP client ---------------------------------------- */

    private static function request( $method, $path, $body = null ) {
        $s = self::settings();
        if ( empty( $s['token'] ) ) {
            return new WP_Error( 'ghl_no_token', 'GHL Private Integration Token is not set.' );
        }
        $args = [
            'method'  => strtoupper( $method ),
            'timeout' => 15,
            'headers' => [
                'Authorization' => 'Bearer ' . $s['token'],
                'Version'       => self::API_VER,
                'Accept'        => 'application/json',
                'Content-Type'  => 'application/json',
            ],
        ];
        if ( $body !== null ) {
            $args['body'] = wp_json_encode( $body );
        }
        $r = wp_remote_request( self::API_BASE . $path, $args );
        if ( is_wp_error( $r ) ) return $r;
        $code = (int) wp_remote_retrieve_response_code( $r );
        $json = json_decode( wp_remote_retrieve_body( $r ), true );
        if ( $code >= 400 ) {
            $msg = isset( $json['message'] ) ? $json['message']
                 : ( isset( $json['error'] ) ? (string) $json['error'] : 'GHL API returned HTTP ' . $code );
            return new WP_Error( 'ghl_http_' . $code, $msg, [ 'status' => $code, 'body' => $json ] );
        }
        return $json ?: [];
    }

    /* -------- Test connection (used by the settings UI) ---------- */

    public static function test_connection() {
        $s = self::settings();
        if ( empty( $s['location_id'] ) ) {
            return new WP_Error( 'ghl_no_location', 'Location ID is required.' );
        }
        $r = self::request( 'GET', '/locations/' . rawurlencode( $s['location_id'] ) );
        if ( is_wp_error( $r ) ) return $r;
        return [
            'ok'      => true,
            'name'    => isset( $r['location']['name'] ) ? $r['location']['name'] : ( $r['name'] ?? '' ),
            'email'   => isset( $r['location']['email'] ) ? $r['location']['email'] : '',
            'country' => isset( $r['location']['country'] ) ? $r['location']['country'] : '',
        ];
    }

    /* -------- List workflows (populates the per-form dropdown) --- */

    public static function list_workflows() {
        $s = self::settings();
        if ( empty( $s['location_id'] ) ) return [];
        $r = self::request( 'GET', '/workflows/?locationId=' . rawurlencode( $s['location_id'] ) );
        if ( is_wp_error( $r ) ) return [];
        $rows = $r['workflows'] ?? ( $r['data'] ?? [] );
        $out  = [];
        foreach ( (array) $rows as $w ) {
            $out[] = [
                'id'   => (string) ( $w['id'] ?? '' ),
                'name' => (string) ( $w['name'] ?? '' ),
            ];
        }
        return $out;
    }

    /* -------- Auto-map FormYantra field → GHL contact field ------ */

    /**
     * Best-effort field-name → GHL-key mapping. Recognises common label
     * variants ("Full Name", "Your Email", "Work Phone" …). Anything not
     * matched falls into GHL's customFields bucket keyed by the label.
     */
    private static function auto_map_key( $label ) {
        $l = strtolower( trim( (string) $label ) );
        if ( $l === '' ) return null;
        if ( in_array( $l, [ 'email', 'e-mail', 'your email', 'work email', 'email address' ], true ) )   return 'email';
        if ( in_array( $l, [ 'phone', 'mobile', 'phone number', 'mobile number', 'work phone', 'tel', 'contact number' ], true ) ) return 'phone';
        if ( in_array( $l, [ 'first name', 'firstname', 'given name' ], true ) )                          return 'firstName';
        if ( in_array( $l, [ 'last name', 'lastname', 'surname', 'family name' ], true ) )               return 'lastName';
        if ( in_array( $l, [ 'name', 'full name', 'your name', 'contact name' ], true ) )                return 'fullName';
        if ( in_array( $l, [ 'company', 'company name', 'organization', 'organisation' ], true ) )       return 'companyName';
        if ( in_array( $l, [ 'address', 'street address', 'street', 'address 1' ], true ) )              return 'address1';
        if ( in_array( $l, [ 'city' ], true ) )                                                          return 'city';
        if ( in_array( $l, [ 'state', 'region', 'state / region' ], true ) )                             return 'state';
        if ( in_array( $l, [ 'country' ], true ) )                                                       return 'country';
        if ( in_array( $l, [ 'zip', 'postal', 'postal code', 'zip code', 'postcode' ], true ) )          return 'postalCode';
        if ( in_array( $l, [ 'website', 'url' ], true ) )                                                return 'website';
        return null; // will land in customField
    }

    /* -------- Outbound: push a submission to GHL ----------------- */

    /**
     * Build the GHL contact payload from a submission + form definition,
     * upsert to /contacts/upsert, and optionally trigger a workflow.
     *
     * Returns array [ 'contact_id' => …, 'status' => 'created'|'updated' ]
     * or WP_Error on failure. Non-fatal — caller ignores errors so a
     * failing GHL push never aborts the submission save.
     */
    public static function push_contact( $submission, $form, $per_form_cfg = [] ) {
        if ( ! self::is_configured() ) {
            return new WP_Error( 'ghl_not_configured', 'GHL integration is not enabled.' );
        }
        $s = self::settings();
        $data = is_string( $submission['data'] ) ? json_decode( $submission['data'], true ) : $submission['data'];
        if ( ! is_array( $data ) ) $data = [];

        // Walk fields, applying admin's mapping overrides first, then auto-guess.
        $overrides = isset( $per_form_cfg['mapping'] ) && is_array( $per_form_cfg['mapping'] )
            ? $per_form_cfg['mapping'] : [];
        $contact   = [ 'locationId' => $s['location_id'], 'source' => 'FormYantra' ];
        $custom    = [];

        // v2.72.40 BUG FIX #6 — customField keys are sanitize_key(label),
        // so two labels that differ only in punctuation ("Project #" and
        // "Project ?") both collapse to "project" and the second overwrote
        // the first. Track which slugs we've used and disambiguate collisions
        // with a numeric suffix keyed by the label's index in the data array.
        $used_slugs = [];
        $idx = 0;
        foreach ( $data as $label => $value ) {
            $idx++;
            if ( strpos( (string) $label, '_' ) === 0 ) continue; // internal (_fcp_*)
            $val = is_array( $value ) ? implode( ', ', array_map( 'strval', $value ) ) : (string) $value;
            if ( $val === '' ) continue;

            $key = isset( $overrides[ $label ] ) ? $overrides[ $label ] : self::auto_map_key( $label );
            if ( $key === 'fullName' ) {
                $parts = preg_split( '/\s+/', $val, 2 );
                $contact['firstName'] = $parts[0];
                if ( isset( $parts[1] ) ) $contact['lastName'] = $parts[1];
            } elseif ( $key && $key !== 'custom' ) {
                $contact[ $key ] = $val;
            } else {
                $slug = sanitize_key( $label );
                if ( $slug === '' ) $slug = 'field';
                if ( isset( $used_slugs[ $slug ] ) ) {
                    $slug = $slug . '_' . $idx;
                }
                $used_slugs[ $slug ] = true;
                $custom[] = [ 'key' => $slug, 'field_value' => $val ];
            }
        }
        if ( $custom ) $contact['customFields'] = $custom;

        // Merge global + per-form tags. Always include a "formyantra:<form-slug>" tag.
        $tags = array_filter( array_map( 'trim',
            explode( ',', trim( ( $s['default_tags'] ?? '' ) . ',' . ( $per_form_cfg['extra_tags'] ?? '' ), ',' ) )
        ) );
        $slug = isset( $form['slug'] ) ? $form['slug'] : ( 'form-' . ( $form['id'] ?? 0 ) );
        $tags[] = 'formyantra:' . $slug;
        $contact['tags'] = array_values( array_unique( $tags ) );

        $r = self::request( 'POST', '/contacts/upsert', $contact );
        if ( is_wp_error( $r ) ) return $r;

        $contact_id = isset( $r['contact']['id'] ) ? (string) $r['contact']['id']
                    : ( isset( $r['id'] ) ? (string) $r['id'] : '' );
        $created    = ! empty( $r['new'] ) ? 'created' : 'updated';

        // Optional workflow trigger.
        $workflow_id = isset( $per_form_cfg['workflow_id'] ) ? (string) $per_form_cfg['workflow_id'] : '';
        if ( $contact_id && $workflow_id ) {
            self::request( 'POST', '/contacts/' . rawurlencode( $contact_id ) . '/workflow/' . rawurlencode( $workflow_id ), [] );
        }

        // Persist the GHL contact id + timestamp on the submission row.
        if ( $contact_id && ! empty( $submission['id'] ) ) {
            global $wpdb;
            $wpdb->update(
                $wpdb->prefix . FCP_TABLE_SUBS,
                [
                    'ghl_contact_id' => $contact_id,
                    'ghl_last_sync'  => current_time( 'mysql' ),
                    'ghl_status'     => 'contact_' . $created,
                ],
                [ 'id' => (int) $submission['id'] ]
            );
        }

        return [ 'contact_id' => $contact_id, 'status' => $created ];
    }

    /* -------- Inbound: webhook handler --------------------------- */

    /**
     * Handle inbound webhook POSTs from GHL. Signature verification uses
     * the shared secret the admin set in Settings (GHL sends it in an
     * X-Signature header when the admin configures it on the webhook).
     *
     * v2.72.40 SECURITY FIX — Previously accepted-any when webhook_secret
     * was empty. Combined with `apply_contact_delete()` which anonymizes
     * submissions, that meant an unauthenticated attacker could POST a
     * forged {"type":"ContactDelete","contactId":"…"} for any guessable
     * ghl_contact_id and wipe the matching submission's name + email.
     * Now: the request is REJECTED with 401 when no secret is configured,
     * so the endpoint is closed by default. Admin must set a signing
     * secret (and configure GHL to sign with it) before it accepts events.
     */
    public static function handle_webhook( WP_REST_Request $req ) {
        $body_raw = $req->get_body();
        $s        = self::settings();
        if ( empty( $s['webhook_secret'] ) ) {
            return new WP_Error(
                'ghl_secret_missing',
                'GHL webhook rejected: no Webhook Signing Secret configured. Set one under Integrations → GoHighLevel and configure the same value on GHL\'s webhook action.',
                [ 'status' => 401 ]
            );
        }
        $sig = $req->get_header( 'x_signature' );
        if ( ! $sig ) $sig = $req->get_header( 'x_wh_signature' );
        $expected = hash_hmac( 'sha256', (string) $body_raw, (string) $s['webhook_secret'] );
        if ( ! $sig || ! hash_equals( $expected, (string) $sig ) ) {
            return new WP_Error( 'ghl_bad_signature', 'Invalid webhook signature.', [ 'status' => 401 ] );
        }
        $body = json_decode( $body_raw, true );
        if ( ! is_array( $body ) ) return new WP_Error( 'ghl_bad_body', 'Body is not JSON.', [ 'status' => 400 ] );

        $type = (string) ( $body['type'] ?? ( $body['event'] ?? '' ) );
        switch ( $type ) {
            case 'ContactUpdate':
            case 'contact_update':
                self::apply_contact_update( $body );
                break;
            case 'OpportunityCreate':
            case 'opportunity_create':
                self::apply_opportunity_create( $body );
                break;
            case 'ContactDelete':
            case 'contact_delete':
                self::apply_contact_delete( $body );
                break;
        }
        return [ 'ok' => true, 'type' => $type ];
    }

    private static function apply_contact_update( $body ) {
        $cid = (string) ( $body['contactId'] ?? ( $body['id'] ?? '' ) );
        if ( ! $cid ) return;
        $subs = self::find_submissions_by_contact( $cid );
        if ( ! $subs ) return;
        global $wpdb;
        $tags = isset( $body['tags'] ) && is_array( $body['tags'] ) ? implode( ', ', $body['tags'] ) : '';
        foreach ( $subs as $sub_id ) {
            self::append_activity( $sub_id, 'ghl_contact_update', 'GHL contact updated' . ( $tags ? " · tags: $tags" : '' ) );
            $wpdb->update(
                $wpdb->prefix . FCP_TABLE_SUBS,
                [ 'ghl_last_sync' => current_time( 'mysql' ), 'ghl_status' => 'contact_updated' ],
                [ 'id' => $sub_id ]
            );
        }
    }

    private static function apply_opportunity_create( $body ) {
        $cid = (string) ( $body['contactId'] ?? '' );
        if ( ! $cid ) return;
        $subs = self::find_submissions_by_contact( $cid );
        if ( ! $subs ) return;
        global $wpdb;
        $pipe  = (string) ( $body['pipelineName'] ?? ( $body['pipeline'] ?? '' ) );
        $stage = (string) ( $body['pipelineStageName'] ?? ( $body['stage'] ?? '' ) );
        $name  = (string) ( $body['name'] ?? '' );
        $note  = 'Opportunity created in GHL' . ( $pipe ? " · pipeline: $pipe" : '' ) . ( $stage ? " · stage: $stage" : '' ) . ( $name ? " · $name" : '' );
        foreach ( $subs as $sub_id ) {
            self::append_activity( $sub_id, 'ghl_opportunity_created', $note );
            $wpdb->update(
                $wpdb->prefix . FCP_TABLE_SUBS,
                [ 'ghl_last_sync' => current_time( 'mysql' ), 'ghl_status' => 'opportunity_created' ],
                [ 'id' => $sub_id ]
            );
        }
    }

    private static function apply_contact_delete( $body ) {
        $cid = (string) ( $body['contactId'] ?? ( $body['id'] ?? '' ) );
        if ( ! $cid ) return;
        $subs = self::find_submissions_by_contact( $cid );
        if ( ! $subs ) return;
        global $wpdb;
        // Anonymize rather than hard-delete — preserves reporting counters.
        foreach ( $subs as $sub_id ) {
            $wpdb->update(
                $wpdb->prefix . FCP_TABLE_SUBS,
                [
                    'submitter_name'  => '[deleted via GHL]',
                    'submitter_email' => '',
                    'ghl_status'      => 'contact_deleted',
                    'ghl_last_sync'   => current_time( 'mysql' ),
                ],
                [ 'id' => $sub_id ]
            );
            self::append_activity( $sub_id, 'ghl_contact_deleted', 'Contact deleted in GHL — submission anonymized' );
        }
    }

    private static function find_submissions_by_contact( $contact_id ) {
        global $wpdb;
        $ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}" . FCP_TABLE_SUBS . " WHERE ghl_contact_id = %s",
            $contact_id
        ) );
        return array_map( 'intval', (array) $ids );
    }

    /**
     * v2.72.40 BUG FIX #5 — Race-safe activity append.
     * Previously two near-simultaneous webhooks (e.g. ContactUpdate +
     * OpportunityCreate firing ~ms apart from the same GHL workflow)
     * would both read the same baseline `data`, each append one entry,
     * and the second write would clobber the first — losing an entry.
     * Fixed by wrapping the read + write in a transaction with
     * SELECT ... FOR UPDATE so concurrent handlers serialize on the row.
     */
    private static function append_activity( $sub_id, $type, $text ) {
        global $wpdb;
        $table = $wpdb->prefix . FCP_TABLE_SUBS;
        // Best-effort row-level lock. Skip the transaction if the caller
        // doesn't have InnoDB (very rare on modern WP hosts); the append
        // still succeeds, just without concurrency protection.
        $wpdb->query( 'START TRANSACTION' );
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT data FROM $table WHERE id = %d FOR UPDATE",
            $sub_id
        ), ARRAY_A );
        if ( ! $row ) {
            $wpdb->query( 'ROLLBACK' );
            return;
        }
        $data = json_decode( $row['data'], true );
        if ( ! is_array( $data ) ) $data = [];
        if ( ! isset( $data['_meta'] ) || ! is_array( $data['_meta'] ) ) $data['_meta'] = [];
        if ( ! isset( $data['_meta']['activity'] ) || ! is_array( $data['_meta']['activity'] ) ) $data['_meta']['activity'] = [];
        $data['_meta']['activity'][] = [
            'type'    => $type,
            'text'    => $text,
            'by_name' => 'GHL',
            'at'      => current_time( 'mysql' ),
        ];
        $wpdb->update(
            $table,
            [ 'data' => wp_json_encode( $data ) ],
            [ 'id' => $sub_id ]
        );
        $wpdb->query( 'COMMIT' );
    }
}
