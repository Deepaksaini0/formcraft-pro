<?php
/**
 * Cashfree payment gateway adapter (Orders API v3).
 *
 * Flow:
 *   1) create_order() - POST /orders → returns payment_session_id
 *   2) Front-end opens Cashfree SDK with payment_session_id
 *   3) verify_payment() - GET /orders/{order_id} → confirms status === 'PAID'
 *
 * Required $cfg fields:
 *   app_id          - Cashfree app id (test prefix: TEST, live: production app id)
 *   secret_key      - Cashfree secret key
 *   webhook_secret  - for webhook signature verification
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FCP_Gateway_Cashfree extends FCP_Gateway_Base {

    public function slug() { return 'cashfree'; }

    private function base_url() {
        return $this->test_mode
            ? 'https://sandbox.cashfree.com/pg'
            : 'https://api.cashfree.com/pg';
    }
    private function auth_headers() {
        return [
            'x-api-version' => '2023-08-01',
            'x-client-id'   => $this->cfg['app_id'],
            'x-client-secret' => $this->cfg['secret_key'],
            'Content-Type'  => 'application/json',
        ];
    }

    public function create_order( $args ) {
        if ( empty( $this->cfg['app_id'] ) || empty( $this->cfg['secret_key'] ) ) {
            return new WP_Error( 'config', 'Cashfree credentials are not set in Payment Gateway settings.' );
        }
        $amount   = (float) ( $args['amount'] ?? 0 );
        $currency = isset( $args['currency'] ) ? strtoupper( $args['currency'] ) : 'INR';
        if ( $amount <= 0 ) return new WP_Error( 'bad_amount', 'Payment amount must be greater than zero.' );

        $order_id = $this->gen_ref();
        $prefill  = isset( $args['prefill'] ) ? (array) $args['prefill'] : [];

        $payload = [
            'order_id'      => $order_id,
            'order_amount'  => $amount,
            'order_currency'=> $currency,
            'customer_details' => [
                'customer_id'    => 'cust_' . wp_generate_password( 8, false ),
                'customer_name'  => $prefill['name']  ?? 'Customer',
                'customer_email' => $prefill['email'] ?? '',
                'customer_phone' => $prefill['contact'] ?? '0000000000',
            ],
            'order_meta'    => [
                'return_url' => isset( $args['return_url'] ) ? $args['return_url'] : home_url( '/' ),
            ],
        ];

        $res = $this->http( $this->base_url() . '/orders', [
            'method'  => 'POST',
            'headers' => $this->auth_headers(),
            'body'    => wp_json_encode( $payload ),
        ] );
        if ( is_wp_error( $res ) ) return $res;

        return [
            'provider'  => 'cashfree',
            'order_id'  => $order_id,
            'amount'    => $amount,
            'currency'  => $currency,
            'checkout'  => [
                'payment_session_id' => isset( $res['payment_session_id'] ) ? $res['payment_session_id'] : '',
                'app_id'             => $this->cfg['app_id'],
                'mode'               => $this->test_mode ? 'sandbox' : 'production',
                'name'               => isset( $args['name'] ) ? $args['name'] : get_bloginfo( 'name' ),
            ],
        ];
    }

    public function verify_payment( $args ) {
        $order_id = isset( $args['order_id'] ) ? $args['order_id'] : ( isset( $args['cashfree_order_id'] ) ? $args['cashfree_order_id'] : '' );
        if ( ! $order_id ) return new WP_Error( 'bad_request', 'Missing Cashfree order id.' );

        $res = $this->http( $this->base_url() . '/orders/' . urlencode( $order_id ), [
            'method'  => 'GET',
            'headers' => $this->auth_headers(),
        ] );
        if ( is_wp_error( $res ) ) return $res;

        if ( ( $res['order_status'] ?? '' ) !== 'PAID' ) {
            return new WP_Error( 'payment_not_complete', 'Cashfree order_status = ' . ( $res['order_status'] ?? 'unknown' ) );
        }
        return [
            'verified'   => true,
            'payment_id' => $order_id,
            'order_id'   => $order_id,
            'amount'     => $res['order_amount'] ?? 0,
            'currency'   => $res['order_currency'] ?? 'INR',
            'method'     => 'cashfree',
            'email'      => $res['customer_details']['customer_email'] ?? '',
            'contact'    => $res['customer_details']['customer_phone'] ?? '',
        ];
    }

    public function handle_webhook( $body, $headers ) {
        $secret = isset( $this->cfg['webhook_secret'] ) ? $this->cfg['webhook_secret'] : '';
        if ( ! $secret ) return new WP_Error( 'config', 'Cashfree webhook secret not configured.' );

        $timestamp = '';
        $sig       = '';
        foreach ( $headers as $k => $v ) {
            $kl = strtolower( $k ); $val = is_array( $v ) ? $v[0] : $v;
            if ( $kl === 'x-webhook-timestamp' ) $timestamp = $val;
            if ( $kl === 'x-webhook-signature' ) $sig       = $val;
        }
        if ( ! $timestamp || ! $sig ) return new WP_Error( 'no_signature', 'Missing Cashfree webhook signature headers.' );

        $expected = base64_encode( hash_hmac( 'sha256', $timestamp . $body, $secret, true ) );
        if ( ! hash_equals( $expected, $sig ) ) {
            return new WP_Error( 'signature_mismatch', 'Cashfree webhook signature mismatch.' );
        }
        $payload = json_decode( $body, true );
        return [ 'event' => $payload['type'] ?? '', 'payload' => $payload ];
    }

    /**
     * v2.72 — Cashfree refund. $payment_id here is our order_id
     * (Cashfree refunds a full order, not a single txn). The `refund_id`
     * we generate is a plugin-scoped unique ref that Cashfree requires.
     */
    public function refund( $payment_id, $amount = null ) {
        $host = $this->test_mode ? 'https://sandbox.cashfree.com' : 'https://api.cashfree.com';
        $body = [
            'refund_id'     => 'fcp_' . wp_generate_password( 12, false, false ),
            'refund_amount' => number_format( (float) $amount, 2, '.', '' ),
            'refund_note'   => 'Refund via FormYantra',
        ];
        $res = $this->http( $host . '/pg/orders/' . rawurlencode( $payment_id ) . '/refunds', [
            'method'  => 'POST',
            'headers' => [
                'x-client-id'     => $this->cfg['app_id'] ?? '',
                'x-client-secret' => $this->cfg['secret_key'] ?? '',
                'x-api-version'   => '2023-08-01',
                'Content-Type'    => 'application/json',
            ],
            'body'    => wp_json_encode( $body ),
        ] );
        if ( is_wp_error( $res ) ) return $res;
        return [
            'refund_id' => $res['refund_id'] ?? $body['refund_id'],
            'status'    => $res['refund_status'] ?? 'PENDING',
        ];
    }
}
