<?php
/**
 * Stripe payment gateway adapter (Checkout Sessions — redirect flow).
 *
 * Flow:
 *   1) create_order() - POST to /checkout/sessions → returns hosted checkout URL
 *   2) Front-end redirects browser to that URL
 *   3) On success, Stripe redirects back to your success_url with ?session_id={CHECKOUT_SESSION_ID}
 *   4) verify_payment() - GETs that session and confirms payment_status === 'paid'
 *   5) Webhook handles async payment_intent.succeeded events as a backup
 *
 * Required $cfg fields:
 *   secret_key       - sk_test_… / sk_live_…
 *   publishable_key  - pk_test_… (not used server-side, but exposed to front)
 *   webhook_secret   - whsec_… for webhook signature verification
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FCP_Gateway_Stripe extends FCP_Gateway_Base {

    public function slug() { return 'stripe'; }

    private function api( $path, $method = 'GET', $body = [] ) {
        $url     = 'https://api.stripe.com/v1' . $path;
        $headers = [
            'Authorization' => 'Bearer ' . $this->cfg['secret_key'],
            'Content-Type'  => 'application/x-www-form-urlencoded',
        ];
        $args = [ 'method' => $method, 'headers' => $headers, 'timeout' => 30 ];
        if ( $body ) $args['body'] = http_build_query( $body, '', '&' );
        return $this->http( $url, $args );
    }

    public function create_order( $args ) {
        if ( empty( $this->cfg['secret_key'] ) ) {
            return new WP_Error( 'config', 'Stripe secret key is not set in Payment Gateway settings.' );
        }
        $amount   = (float) ( $args['amount'] ?? 0 );
        $currency = isset( $args['currency'] ) ? strtolower( $args['currency'] ) : 'usd';
        if ( $amount <= 0 ) return new WP_Error( 'bad_amount', 'Payment amount must be greater than zero.' );

        // Stripe wants amount in smallest currency unit (cents).
        $name        = isset( $args['name'] )        ? $args['name']        : ( get_bloginfo( 'name' ) . ' — Form payment' );
        $description = isset( $args['description'] ) ? $args['description'] : '';
        $return_url  = isset( $args['return_url'] )  ? $args['return_url']  : home_url( '/' );

        $body = [
            'mode'                 => 'payment',
            'payment_method_types[0]' => 'card',
            'line_items[0][quantity]' => 1,
            'line_items[0][price_data][currency]'      => $currency,
            'line_items[0][price_data][unit_amount]'   => (int) round( $amount * 100 ),
            'line_items[0][price_data][product_data][name]' => $name,
            'success_url'          => add_query_arg( [ 'session_id' => '{CHECKOUT_SESSION_ID}', 'fcp_payment' => 'success' ], $return_url ),
            'cancel_url'           => add_query_arg( [ 'fcp_payment' => 'cancel' ], $return_url ),
        ];
        if ( $description ) $body['line_items[0][price_data][product_data][description]'] = $description;
        /* v2.72.73 — Saved-cards wiring. When the caller (payment_create_order)
           passes stripe_customer_id, attach the Customer to the Checkout Session
           so Stripe's UI shows the visitor's saved cards, AND set
           setup_future_usage so any new card is saved to the Customer for
           the next payment. */
        if ( ! empty( $args['stripe_customer_id'] ) ) {
            $body['customer'] = $args['stripe_customer_id'];
            $body['payment_intent_data[setup_future_usage]'] = 'on_session';
        } elseif ( ! empty( $args['prefill']['email'] ) && is_email( $args['prefill']['email'] ) ) {
            $body['customer_email'] = $args['prefill']['email'];
        }

        $res = $this->api( '/checkout/sessions', 'POST', $body );
        if ( is_wp_error( $res ) ) return $res;

        return [
            'provider'  => 'stripe',
            'order_id'  => $res['id'],
            'amount'    => $amount,
            'currency'  => strtoupper( $currency ),
            // Front-end will redirect to this URL.
            'checkout'  => [
                'redirect_url' => $res['url'],
                'session_id'   => $res['id'],
                'publishable_key' => isset( $this->cfg['publishable_key'] ) ? $this->cfg['publishable_key'] : '',
            ],
        ];
    }

    public function verify_payment( $args ) {
        /* v2.72.94 — Two verification paths:
         *   1) Checkout Session (redirect flow) — reads session_id from return URL.
         *   2) Payment Intent (inline Elements flow) — client passes payment_intent_id
         *      after stripe.confirmCardPayment() succeeds in the browser; server
         *      re-fetches the PI and confirms status=succeeded before marking
         *      the submission paid. Never trust the client's success flag alone. */
        $payment_intent_id = isset( $args['payment_intent_id'] ) ? $args['payment_intent_id'] : '';
        if ( $payment_intent_id ) {
            /* v2.72.101 — Expand latest_charge. Since Stripe API 2022-11-15
             * PaymentIntent no longer inlines `charges` — accessing
             * $pi['charges']['data'][0] silently returned empty and every
             * receipt lost the buyer's billing email + phone. The `expand`
             * query param brings the charge back inline. */
            $pi = $this->api( '/payment_intents/' . urlencode( $payment_intent_id ) . '?expand[]=latest_charge' );
            if ( is_wp_error( $pi ) ) return $pi;
            if ( ( $pi['status'] ?? '' ) !== 'succeeded' ) {
                return new WP_Error( 'payment_not_complete', 'Stripe reports status = ' . ( $pi['status'] ?? 'unknown' ) );
            }
            // Prefer the new latest_charge; fall back to legacy charges[] for
            // very old accounts still on the pre-2022-11-15 API version.
            $charge = [];
            if ( is_array( $pi['latest_charge'] ?? null ) )         $charge = $pi['latest_charge'];
            elseif ( ! empty( $pi['charges']['data'][0] ) )         $charge = $pi['charges']['data'][0];
            return [
                'verified'  => true,
                'payment_id'=> $pi['id'],
                'order_id'  => $pi['id'],
                'amount'    => ( $pi['amount_received'] ?? $pi['amount'] ?? 0 ) / 100,
                'currency'  => strtoupper( $pi['currency'] ?? '' ),
                'method'    => 'card',
                'email'     => $charge['billing_details']['email']   ?? ( $pi['receipt_email'] ?? '' ),
                'contact'   => $charge['billing_details']['phone']   ?? '',
            ];
        }

        $session_id = isset( $args['session_id'] ) ? $args['session_id']
                    : ( isset( $args['stripe_session_id'] ) ? $args['stripe_session_id'] : '' );
        if ( ! $session_id ) return new WP_Error( 'bad_request', 'Missing Stripe session id or payment_intent_id.' );

        $session = $this->api( '/checkout/sessions/' . urlencode( $session_id ) );
        if ( is_wp_error( $session ) ) return $session;

        if ( ( $session['payment_status'] ?? '' ) !== 'paid' ) {
            return new WP_Error( 'payment_not_complete', 'Stripe reports payment_status = ' . ( $session['payment_status'] ?? 'unknown' ) );
        }
        return [
            'verified'  => true,
            'payment_id'=> isset( $session['payment_intent'] ) ? $session['payment_intent'] : $session_id,
            'order_id'  => $session_id,
            'amount'    => ( $session['amount_total'] ?? 0 ) / 100,
            'currency'  => strtoupper( $session['currency'] ?? '' ),
            'method'    => 'card',
            'email'     => $session['customer_details']['email']   ?? '',
            'contact'   => $session['customer_details']['phone']   ?? '',
        ];
    }

    /**
     * v2.72.94 — Payment Intent for inline Stripe Elements checkout.
     * Called when the form uses inline card entry (Stripe Elements on the
     * page) instead of the hosted Checkout Session redirect. Returns
     * client_secret so the browser can call stripe.confirmCardPayment().
     */
    public function create_payment_intent( $args ) {
        if ( empty( $this->cfg['secret_key'] ) ) return new WP_Error( 'config', 'Stripe secret key not set.' );
        $amount   = isset( $args['amount'] )   ? (float) $args['amount']   : 0.0;
        $currency = isset( $args['currency'] ) ? strtolower( $args['currency'] ) : 'usd';
        if ( $amount <= 0 ) return new WP_Error( 'bad_amount', 'Payment amount must be greater than zero.' );

        $body = [
            'amount'                    => (int) round( $amount * 100 ),
            'currency'                  => $currency,
            'payment_method_types[0]'   => 'card',
            'description'               => isset( $args['description'] ) ? $args['description'] : ( get_bloginfo( 'name' ) . ' — Form payment' ),
        ];
        if ( ! empty( $args['prefill']['email'] ) && is_email( $args['prefill']['email'] ) ) {
            $body['receipt_email'] = $args['prefill']['email'];
        }
        if ( ! empty( $args['stripe_customer_id'] ) ) {
            $body['customer']            = $args['stripe_customer_id'];
            $body['setup_future_usage']  = 'on_session';
        }
        $res = $this->api( '/payment_intents', 'POST', $body );
        if ( is_wp_error( $res ) ) return $res;

        return [
            'provider'         => 'stripe',
            'order_id'         => $res['id'],
            'amount'           => $amount,
            'currency'         => strtoupper( $currency ),
            'client_secret'    => $res['client_secret'],
            'publishable_key'  => isset( $this->cfg['publishable_key'] ) ? $this->cfg['publishable_key'] : '',
            'mode'             => 'inline',
        ];
    }

    public function handle_webhook( $body, $headers ) {
        $secret = isset( $this->cfg['webhook_secret'] ) ? $this->cfg['webhook_secret'] : '';
        if ( ! $secret ) return new WP_Error( 'config', 'Stripe webhook secret not configured.' );

        // Stripe-Signature: t=…,v1=…
        $sig_header = '';
        foreach ( $headers as $k => $v ) {
            if ( strtolower( $k ) === 'stripe-signature' ) { $sig_header = is_array( $v ) ? $v[0] : $v; break; }
        }
        if ( ! $sig_header ) return new WP_Error( 'no_signature', 'No Stripe-Signature header.' );

        $parts = []; foreach ( explode( ',', $sig_header ) as $part ) {
            list( $k, $v ) = array_pad( explode( '=', $part, 2 ), 2, '' );
            $parts[ trim( $k ) ] = trim( $v );
        }
        if ( empty( $parts['t'] ) || empty( $parts['v1'] ) ) {
            return new WP_Error( 'bad_signature', 'Malformed Stripe-Signature header.' );
        }
        $expected = hash_hmac( 'sha256', $parts['t'] . '.' . $body, $secret );
        if ( ! hash_equals( $expected, $parts['v1'] ) ) {
            return new WP_Error( 'signature_mismatch', 'Stripe webhook signature mismatch.' );
        }

        $payload = json_decode( $body, true );
        return [
            'event'   => isset( $payload['type'] ) ? $payload['type'] : '',
            'payload' => $payload,
        ];
    }

    public function refund( $payment_id, $amount = null ) {
        $body = [ 'payment_intent' => $payment_id ];
        if ( $amount !== null ) $body['amount'] = (int) round( ( (float) $amount ) * 100 );
        $res = $this->api( '/refunds', 'POST', $body );
        if ( is_wp_error( $res ) ) return $res;
        return [
            'refund_id' => $res['id'],
            'amount'    => $res['amount'] / 100,
            'status'    => $res['status'],
        ];
    }

    /* ═══════════════════════════════════════════════════════════════════
     * v2.72.62 — Advanced payment methods.
     * ═══════════════════════════════════════════════════════════════════ */

    /**
     * Create a Stripe Checkout Session in subscription mode.
     * $plan = [ 'name' => 'Pro Monthly', 'amount' => 29.00, 'currency' => 'usd',
     *           'interval' => 'month'|'year'|'week'|'day', 'interval_count' => 1,
     *           'trial_days' => 7 ]
     */
    public function create_subscription( $args ) {
        if ( empty( $this->cfg['secret_key'] ) ) return new WP_Error( 'config', 'Stripe secret key not set.' );
        $plan = isset( $args['plan'] ) && is_array( $args['plan'] ) ? $args['plan'] : [];
        $amount   = (float) ( $plan['amount'] ?? 0 );
        $currency = strtolower( $plan['currency'] ?? ( $args['currency'] ?? 'usd' ) );
        $interval = in_array( ( $plan['interval'] ?? 'month' ), [ 'day','week','month','year' ], true )
                    ? $plan['interval'] : 'month';
        $count    = max( 1, (int) ( $plan['interval_count'] ?? 1 ) );
        $name     = $plan['name'] ?? 'Subscription';
        if ( $amount <= 0 ) return new WP_Error( 'bad_amount', 'Subscription amount must be > 0.' );

        $return_url = $args['return_url'] ?? home_url( '/' );
        $body = [
            'mode' => 'subscription',
            'line_items[0][quantity]' => 1,
            'line_items[0][price_data][currency]'          => $currency,
            'line_items[0][price_data][unit_amount]'       => (int) round( $amount * 100 ),
            'line_items[0][price_data][product_data][name]'=> $name,
            'line_items[0][price_data][recurring][interval]'       => $interval,
            'line_items[0][price_data][recurring][interval_count]' => $count,
            'success_url' => add_query_arg( [ 'session_id' => '{CHECKOUT_SESSION_ID}', 'fcp_payment' => 'success' ], $return_url ),
            'cancel_url'  => add_query_arg( [ 'fcp_payment' => 'cancel' ], $return_url ),
        ];
        if ( ! empty( $plan['trial_days'] ) ) {
            $body['subscription_data[trial_period_days]'] = (int) $plan['trial_days'];
        }
        // Auto-attach Stripe Customer when a WP user is logged in — enables
        // "saved payment methods" (feature #5). Falls back to email-only.
        if ( ! empty( $args['stripe_customer_id'] ) ) {
            $body['customer'] = $args['stripe_customer_id'];
        } elseif ( ! empty( $args['prefill']['email'] ) && is_email( $args['prefill']['email'] ) ) {
            $body['customer_email'] = $args['prefill']['email'];
        }
        // Global tax engine (feature #2) — Stripe Tax auto-computes based on address.
        if ( ! empty( $args['stripe_tax'] ) ) {
            $body['automatic_tax[enabled]'] = 'true';
            $body['customer_update[address]'] = 'auto';
        }
        $res = $this->api( '/checkout/sessions', 'POST', $body );
        if ( is_wp_error( $res ) ) return $res;
        return [
            'provider'  => 'stripe',
            'order_id'  => $res['id'],
            'amount'    => $amount,
            'currency'  => strtoupper( $currency ),
            'mode'      => 'subscription',
            'plan'      => [ 'interval' => $interval, 'interval_count' => $count ],
            'checkout'  => [
                'redirect_url'    => $res['url'],
                'session_id'      => $res['id'],
                'publishable_key' => $this->cfg['publishable_key'] ?? '',
            ],
        ];
    }

    /**
     * Get or create a Stripe Customer for a WP user (feature #5 — saved cards).
     * Persists the Stripe customer id in WP user meta so subsequent checkouts
     * pass `customer=<id>`, which lets Stripe show the visitor their saved
     * payment methods automatically.
     */
    public function ensure_customer( $wp_user_id, $email = '', $name = '' ) {
        if ( empty( $this->cfg['secret_key'] ) ) return new WP_Error( 'config', 'Stripe secret key not set.' );
        $wp_user_id = (int) $wp_user_id;
        if ( ! $wp_user_id ) return new WP_Error( 'no_user', 'ensure_customer requires a WP user id.' );
        $existing = get_user_meta( $wp_user_id, '_fcp_stripe_customer_id', true );
        if ( $existing && is_string( $existing ) ) return $existing;
        $body = [];
        if ( $email && is_email( $email ) ) $body['email'] = $email;
        if ( $name )  $body['name']  = $name;
        $body['metadata[wp_user_id]'] = $wp_user_id;
        $res = $this->api( '/customers', 'POST', $body );
        if ( is_wp_error( $res ) ) return $res;
        if ( ! empty( $res['id'] ) ) {
            update_user_meta( $wp_user_id, '_fcp_stripe_customer_id', $res['id'] );
            return $res['id'];
        }
        return new WP_Error( 'no_customer', 'Stripe did not return a customer id.' );
    }

    /**
     * List saved payment methods (cards) for a Stripe customer.
     * Returns array of [ { id, brand, last4, exp_month, exp_year } ].
     */
    public function list_saved_cards( $stripe_customer_id ) {
        if ( ! $stripe_customer_id ) return [];
        $res = $this->api( '/payment_methods?customer=' . urlencode( $stripe_customer_id ) . '&type=card' );
        if ( is_wp_error( $res ) || empty( $res['data'] ) ) return [];
        $out = [];
        foreach ( $res['data'] as $pm ) {
            $card = $pm['card'] ?? [];
            $out[] = [
                'id'        => $pm['id'] ?? '',
                'brand'     => $card['brand']     ?? '',
                'last4'     => $card['last4']     ?? '',
                'exp_month' => $card['exp_month'] ?? '',
                'exp_year'  => $card['exp_year']  ?? '',
            ];
        }
        return $out;
    }

    /**
     * Cancel a Stripe subscription (immediate or at period end).
     */
    public function cancel_subscription( $subscription_id, $at_period_end = true ) {
        if ( ! $subscription_id ) return new WP_Error( 'bad_request', 'Missing subscription id.' );
        if ( $at_period_end ) {
            $res = $this->api( '/subscriptions/' . urlencode( $subscription_id ), 'POST', [ 'cancel_at_period_end' => 'true' ] );
        } else {
            $res = $this->api( '/subscriptions/' . urlencode( $subscription_id ), 'DELETE' );
        }
        if ( is_wp_error( $res ) ) return $res;
        return [
            'id'                   => $res['id']                   ?? '',
            'status'               => $res['status']               ?? '',
            'cancel_at_period_end' => $res['cancel_at_period_end'] ?? false,
            'current_period_end'   => $res['current_period_end']   ?? 0,
        ];
    }

    /**
     * v2.72.62 — Extend create_order to support saved-customer and Stripe Tax.
     * Backwards-compatible: existing callers work unchanged. New optional
     * $args: stripe_customer_id, stripe_tax (bool), tax_rate_ids.
     */
    public function create_order_ex( $args ) {
        if ( empty( $this->cfg['secret_key'] ) ) {
            return new WP_Error( 'config', 'Stripe secret key is not set in Payment Gateway settings.' );
        }
        $amount   = (float) ( $args['amount'] ?? 0 );
        $currency = isset( $args['currency'] ) ? strtolower( $args['currency'] ) : 'usd';
        if ( $amount <= 0 ) return new WP_Error( 'bad_amount', 'Payment amount must be greater than zero.' );

        $name        = $args['name']        ?? ( get_bloginfo( 'name' ) . ' — Form payment' );
        $description = $args['description'] ?? '';
        $return_url  = $args['return_url']  ?? home_url( '/' );

        $body = [
            'mode'                    => 'payment',
            'payment_method_types[0]' => 'card',
            'line_items[0][quantity]' => 1,
            'line_items[0][price_data][currency]'      => $currency,
            'line_items[0][price_data][unit_amount]'   => (int) round( $amount * 100 ),
            'line_items[0][price_data][product_data][name]' => $name,
            'success_url' => add_query_arg( [ 'session_id' => '{CHECKOUT_SESSION_ID}', 'fcp_payment' => 'success' ], $return_url ),
            'cancel_url'  => add_query_arg( [ 'fcp_payment' => 'cancel' ], $return_url ),
        ];
        if ( $description ) $body['line_items[0][price_data][product_data][description]'] = $description;
        if ( ! empty( $args['stripe_customer_id'] ) ) {
            $body['customer'] = $args['stripe_customer_id'];
            // Save card for future — enables saved-cards feature on next visit.
            $body['payment_intent_data[setup_future_usage]'] = 'on_session';
        } elseif ( ! empty( $args['prefill']['email'] ) && is_email( $args['prefill']['email'] ) ) {
            $body['customer_email'] = $args['prefill']['email'];
        }
        if ( ! empty( $args['stripe_tax'] ) ) {
            $body['automatic_tax[enabled]'] = 'true';
            if ( ! empty( $args['stripe_customer_id'] ) ) {
                $body['customer_update[address]'] = 'auto';
            }
        }
        $res = $this->api( '/checkout/sessions', 'POST', $body );
        if ( is_wp_error( $res ) ) return $res;
        return [
            'provider' => 'stripe',
            'order_id' => $res['id'],
            'amount'   => $amount,
            'currency' => strtoupper( $currency ),
            'checkout' => [
                'redirect_url'    => $res['url'],
                'session_id'      => $res['id'],
                'publishable_key' => $this->cfg['publishable_key'] ?? '',
            ],
        ];
    }
}
