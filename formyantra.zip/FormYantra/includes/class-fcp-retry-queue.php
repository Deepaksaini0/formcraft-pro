<?php
/**
 * FormYantra - Integration Retry Queue.
 *
 * Outbound integrations (Mailchimp, HubSpot, Slack, Meta CAPI, ...) fire
 * with `blocking => false` so a slow third-party API never blocks the
 * visitor's submit response. That speed win used to come at the cost of
 * "if it fails we never know" — this class wires a best-effort retry
 * layer on top of the existing dispatchers.
 *
 * Design:
 *   1. The integration dispatcher (FCP_Integrations / FCP_Ad_Platforms)
 *      wraps every outbound POST so a 4xx / 5xx / network error queues
 *      a row into wp_fcp_retry_queue.
 *   2. WP-Cron tick fires `fcp_retry_tick` every 5 minutes.
 *   3. We claim up to 50 due rows, replay each one with the same payload,
 *      and either mark `done` (2xx) or increment `attempts`.
 *   4. After 3 attempts we mark `failed` and stop. Admin can re-queue
 *      manually from the Integrations page.
 *
 * Backoff schedule: 5 min, 30 min, 6 hours (cumulative ~7 hours), then dead.
 *
 * NB: this queue is *opt-in per integration* — we only queue retries for
 * integrations where the admin is most likely to want them (webhooks,
 * critical CRM pushes). Pixel beacons are fire-and-forget on purpose
 * (the ad platform itself dedupes by event_id).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FCP_Retry_Queue {

    const HOOK_TICK    = 'fcp_retry_tick';
    const MAX_ATTEMPTS = 3;
    const TICK_LIMIT   = 50;   // rows processed per cron tick

    /* Backoff in seconds: attempt 1 fails → wait 300s, attempt 2 → 1800s,
       attempt 3 → 21600s, then mark failed. */
    const BACKOFF = [ 300, 1800, 21600 ];

    public static function table() {
        global $wpdb;
        return $wpdb->prefix . 'fcp_retry_queue';
    }

    public static function ensure_table() {
        global $wpdb;
        $table = self::table();
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            integration_key VARCHAR(60) NOT NULL,
            method VARCHAR(8) NOT NULL DEFAULT 'POST',
            url TEXT NOT NULL,
            headers LONGTEXT NULL,
            body LONGTEXT NULL,
            attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
            status VARCHAR(12) NOT NULL DEFAULT 'pending',
            last_error TEXT NULL,
            next_attempt_at DATETIME NOT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY status_due (status, next_attempt_at),
            KEY integration_key (integration_key)
        ) $charset;";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    /**
     * Schedule the recurring cron event on plugin activation / version
     * upgrade. Safe to call repeatedly.
     */
    public static function schedule_cron() {
        if ( ! wp_next_scheduled( self::HOOK_TICK ) ) {
            wp_schedule_event( time() + 300, 'fcp_5min', self::HOOK_TICK );
        }
    }

    public static function unschedule_cron() {
        $ts = wp_next_scheduled( self::HOOK_TICK );
        if ( $ts ) wp_unschedule_event( $ts, self::HOOK_TICK );
    }

    /**
     * Add the custom 5-minute cron interval the queue ticks on. Hooked
     * onto `cron_schedules` from formcraft-pro.php at boot.
     */
    public static function filter_cron_schedules( $schedules ) {
        if ( ! isset( $schedules['fcp_5min'] ) ) {
            $schedules['fcp_5min'] = [
                'interval' => 300,
                'display'  => __( 'Every 5 minutes (FormCraft retry queue)', 'formcraft-pro' ),
            ];
        }
        return $schedules;
    }

    /**
     * Queue a single outbound HTTP request for retry. Call this from
     * integration adapters when wp_remote_post comes back with WP_Error
     * or non-2xx.
     *
     * @param string $key      integration key (e.g. "mailchimp", "slack").
     * @param string $method   HTTP method.
     * @param string $url      Target URL.
     * @param array  $args     Same shape passed to wp_remote_request: headers, body.
     * @param string $error    Optional error message to record on attempt 0.
     */
    public static function enqueue( $key, $method, $url, $args = [], $error = '' ) {
        global $wpdb;
        self::ensure_table();
        $now = current_time( 'mysql' );
        $wpdb->insert( self::table(), [
            'integration_key' => substr( (string) $key, 0, 60 ),
            'method'          => strtoupper( substr( (string) $method, 0, 8 ) ),
            'url'             => (string) $url,
            'headers'         => wp_json_encode( $args['headers'] ?? [] ),
            'body'            => (string) ( $args['body'] ?? '' ),
            'attempts'        => 0,
            'status'          => 'pending',
            'last_error'      => substr( (string) $error, 0, 1000 ),
            'next_attempt_at' => $now,
            'created_at'      => $now,
            'updated_at'      => $now,
        ] );
        return (int) $wpdb->insert_id;
    }

    /**
     * Cron callback. Claims up to TICK_LIMIT due rows and retries each.
     */
    public static function tick() {
        global $wpdb;
        self::ensure_table();
        $now = current_time( 'mysql' );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . self::table() . "
             WHERE status = 'pending' AND next_attempt_at <= %s
             ORDER BY next_attempt_at ASC
             LIMIT %d",
            $now, self::TICK_LIMIT
        ), ARRAY_A );
        if ( ! $rows ) return 0;

        $done = 0;
        foreach ( $rows as $row ) {
            $ok = self::replay( $row );
            if ( $ok ) {
                $done++;
            }
        }
        return $done;
    }

    private static function replay( $row ) {
        global $wpdb;
        $headers = json_decode( (string) $row['headers'], true );
        $args = [
            'method'    => $row['method'],
            'timeout'   => 8,           // bigger than fire-and-forget — we WANT the result here
            'blocking'  => true,
            'sslverify' => true,
            'headers'   => is_array( $headers ) ? $headers : [],
            'body'      => $row['body'],
        ];
        $resp = wp_remote_request( $row['url'], $args );

        $next_status = 'pending';
        $error_msg   = '';
        $code        = 0;

        if ( is_wp_error( $resp ) ) {
            $error_msg = $resp->get_error_message();
        } else {
            $code = (int) wp_remote_retrieve_response_code( $resp );
            if ( $code >= 200 && $code < 300 ) {
                $next_status = 'done';
            } else {
                $error_msg = 'HTTP ' . $code . ' — ' . substr( (string) wp_remote_retrieve_body( $resp ), 0, 400 );
            }
        }

        $attempts = (int) $row['attempts'] + 1;

        if ( $next_status !== 'done' ) {
            if ( $attempts >= self::MAX_ATTEMPTS ) {
                $next_status = 'failed';
                error_log( '[FormYantra] retry queue exhausted for ' . $row['integration_key'] . ' (id=' . (int) $row['id'] . '): ' . $error_msg );
            }
        }

        $next_at = ( $next_status === 'pending' && isset( self::BACKOFF[ $attempts - 1 ] ) )
            ? gmdate( 'Y-m-d H:i:s', time() + self::BACKOFF[ $attempts - 1 ] )
            : current_time( 'mysql' );

        $wpdb->update( self::table(), [
            'attempts'        => $attempts,
            'status'          => $next_status,
            'last_error'      => substr( $error_msg, 0, 1000 ),
            'next_attempt_at' => $next_at,
            'updated_at'      => current_time( 'mysql' ),
        ], [ 'id' => (int) $row['id'] ] );

        return $next_status === 'done';
    }

    /**
     * Helper for integration adapters: do a blocking POST + if it fails,
     * enqueue for retry. Returns true on 2xx, false otherwise.
     */
    public static function post_with_retry( $key, $url, $args ) {
        $sync_args = array_replace_recursive( [
            'timeout'   => 4,
            'blocking'  => true,        // we WANT the result so we know whether to enqueue
            'sslverify' => true,
        ], $args );
        $resp = wp_remote_post( $url, $sync_args );

        if ( is_wp_error( $resp ) ) {
            self::enqueue( $key, 'POST', $url, $args, $resp->get_error_message() );
            return false;
        }
        $code = (int) wp_remote_retrieve_response_code( $resp );
        if ( $code >= 200 && $code < 300 ) {
            return true;
        }
        self::enqueue( $key, 'POST', $url, $args, 'HTTP ' . $code );
        return false;
    }

    /**
     * Admin-facing stats for the Integrations page.
     */
    public static function stats() {
        global $wpdb;
        self::ensure_table();
        $rows = $wpdb->get_results(
            "SELECT status, COUNT(*) AS n FROM " . self::table() . " GROUP BY status",
            ARRAY_A
        );
        $out = [ 'pending' => 0, 'done' => 0, 'failed' => 0 ];
        foreach ( $rows as $r ) {
            $out[ $r['status'] ] = (int) $r['n'];
        }
        return $out;
    }
}
