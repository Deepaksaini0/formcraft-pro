<?php
/**
 * FormYantra - Scheduled Email Digest (v2.54)
 *
 * Sends a periodic summary email to the configured recipient:
 *   - Total submissions in the period (and % change vs previous)
 *   - Top 5 forms by submission count
 *   - Top 5 acquisition sources (UTM source)
 *   - Top 5 countries
 *   - Notable items (forms behind their goal, new spam patterns learned)
 *
 * Cron hooks:
 *   fcp_digest_daily    → runs once per day
 *   fcp_digest_weekly   → runs once per week
 *   fcp_digest_monthly  → runs once per month
 *
 * Only the hook matching the admin's configured frequency emits a real
 * email. The other two no-op. Switching frequency at runtime takes
 * effect on the next scheduled tick — we don't re-register cron.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class FCP_Digest {

    const HOOK_DAILY   = 'fcp_digest_daily';
    const HOOK_WEEKLY  = 'fcp_digest_weekly';
    const HOOK_MONTHLY = 'fcp_digest_monthly';

    public static function schedule_all() {
        if ( ! wp_next_scheduled( self::HOOK_DAILY ) )   wp_schedule_event( time() + 3600,  'daily',   self::HOOK_DAILY );
        if ( ! wp_next_scheduled( self::HOOK_WEEKLY ) )  wp_schedule_event( time() + 3600,  'weekly',  self::HOOK_WEEKLY );
        if ( ! wp_next_scheduled( self::HOOK_MONTHLY ) ) wp_schedule_event( time() + 3600,  'monthly', self::HOOK_MONTHLY );
    }
    public static function unschedule_all() {
        foreach ( [ self::HOOK_DAILY, self::HOOK_WEEKLY, self::HOOK_MONTHLY ] as $hook ) {
            $ts = wp_next_scheduled( $hook );
            if ( $ts ) wp_unschedule_event( $ts, $hook );
        }
    }

    public static function tick_daily()   { self::maybe_send( 'daily',   86400 ); }
    public static function tick_weekly()  { self::maybe_send( 'weekly',  7 * 86400 ); }
    public static function tick_monthly() { self::maybe_send( 'monthly', 30 * 86400 ); }

    /**
     * Only runs the digest if the admin's configured frequency matches the
     * tick that fired. Idempotent — won't double-send if cron retriggers.
     */
    private static function maybe_send( $freq, $window_sec ) {
        $settings = get_option( 'fcp_settings', [] );
        $cfg = isset( $settings['scheduled_reports'] ) && is_array( $settings['scheduled_reports'] )
            ? $settings['scheduled_reports']
            : [];
        if ( empty( $cfg['enabled'] ) ) return;
        if ( ( $cfg['frequency'] ?? 'weekly' ) !== $freq ) return;
        $to = ! empty( $cfg['recipient'] ) && is_email( $cfg['recipient'] ) ? $cfg['recipient'] : get_option( 'admin_email' );
        if ( ! $to ) return;

        $report = self::build_report( $window_sec );
        $sent = wp_mail(
            $to,
            sprintf( '[%s] %s · FormYantra digest', get_bloginfo( 'name' ), ucfirst( $freq ) ),
            $report,
            [ 'Content-Type: text/html; charset=UTF-8' ]
        );
        $settings['scheduled_reports']['last_sent'] = current_time( 'mysql' );
        update_option( 'fcp_settings', $settings );
        return $sent;
    }

    public static function build_report( $window_sec ) {
        global $wpdb;
        $cutoff   = gmdate( 'Y-m-d H:i:s', time() - $window_sec );
        $prev_cut = gmdate( 'Y-m-d H:i:s', time() - 2 * $window_sec );
        $subs_t   = FCP_DB::subs_table();
        $forms_t  = FCP_DB::forms_table();

        $total   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $subs_t WHERE is_spam = 0 AND is_abandoned = 0 AND created_at >= %s", $cutoff ) );
        $prev    = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $subs_t WHERE is_spam = 0 AND is_abandoned = 0 AND created_at >= %s AND created_at < %s", $prev_cut, $cutoff ) );
        $spam    = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $subs_t WHERE is_spam = 1 AND created_at >= %s", $cutoff ) );
        $delta   = $prev > 0 ? round( ( ( $total - $prev ) / $prev ) * 100 ) : ( $total > 0 ? 100 : 0 );
        $arrow   = $delta > 0 ? '▲' : ( $delta < 0 ? '▼' : '–' );
        $arrowCl = $delta > 0 ? '#16a34a' : ( $delta < 0 ? '#dc2626' : '#64748b' );

        $top_forms = $wpdb->get_results( $wpdb->prepare(
            "SELECT s.form_id, COUNT(*) AS n, f.title
             FROM $subs_t s LEFT JOIN $forms_t f ON f.id = s.form_id
             WHERE s.is_spam = 0 AND s.is_abandoned = 0 AND s.created_at >= %s
             GROUP BY s.form_id ORDER BY n DESC LIMIT 5",
            $cutoff
        ), ARRAY_A );

        $top_countries = $wpdb->get_results( $wpdb->prepare(
            "SELECT country, COUNT(*) AS n FROM $subs_t
             WHERE is_spam = 0 AND is_abandoned = 0 AND country <> '' AND created_at >= %s
             GROUP BY country ORDER BY n DESC LIMIT 5",
            $cutoff
        ), ARRAY_A );

        // UTM sources — pulled from data JSON, summed across rows
        $rows = $wpdb->get_col( $wpdb->prepare(
            "SELECT data FROM $subs_t WHERE is_spam = 0 AND is_abandoned = 0 AND created_at >= %s AND data LIKE %s LIMIT 1000",
            $cutoff, '%utm%'
        ) );
        $utm_count = [];
        foreach ( $rows as $r ) {
            $p = json_decode( $r, true );
            if ( ! is_array( $p ) ) continue;
            $src = $p['_meta']['utm']['utm_source'] ?? '';
            if ( $src ) $utm_count[ $src ] = ( $utm_count[ $src ] ?? 0 ) + 1;
        }
        arsort( $utm_count );
        $top_utm = array_slice( $utm_count, 0, 5, true );

        // Build the HTML
        $site = get_bloginfo( 'name' );
        $link = admin_url( 'admin.php?page=formcraft-pro-analytics' );
        $h    = '';
        $h .= '<div style="font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;max-width:640px;margin:0 auto;color:#0f172a;">';
        $h .= '<h1 style="font-size:22px;margin:0 0 4px;">📊 FormYantra digest</h1>';
        $h .= '<p style="color:#64748b;margin:0 0 24px;">' . esc_html( $site ) . '</p>';

        $h .= '<div style="background:linear-gradient(135deg,#eef2ff,#f5f3ff);border:1px solid #c7d2fe;border-radius:12px;padding:18px 22px;margin-bottom:18px;">';
        $h .= '<div style="font-size:11px;font-weight:800;color:#3730a3;letter-spacing:0.05em;text-transform:uppercase;">Submissions in period</div>';
        $h .= '<div style="font-size:36px;font-weight:800;color:#0f172a;margin-top:4px;">' . $total . '</div>';
        $h .= '<div style="margin-top:4px;color:' . $arrowCl . ';font-weight:700;font-size:13px;">' . $arrow . ' ' . abs( $delta ) . '% vs previous period</div>';
        if ( $spam ) $h .= '<div style="margin-top:6px;color:#dc2626;font-size:12px;">+ ' . $spam . ' spam blocked</div>';
        $h .= '</div>';

        // Top forms
        $h .= '<h2 style="font-size:14px;color:#0f172a;margin:18px 0 8px;">📋 Top forms</h2>';
        if ( ! $top_forms ) {
            $h .= '<p style="color:#64748b;font-size:13px;">No submissions yet.</p>';
        } else {
            $max = max( array_column( $top_forms, 'n' ) );
            $h  .= '<table style="width:100%;border-collapse:collapse;font-size:13px;">';
            foreach ( $top_forms as $r ) {
                $w = round( ( $r['n'] / $max ) * 100 );
                $h .= '<tr><td style="padding:6px 0;font-weight:600;width:50%;">' . esc_html( $r['title'] ?: ('Form #' . $r['form_id']) ) . '</td>';
                $h .= '<td style="padding:6px 0;"><div style="background:#eef2ff;border-radius:4px;height:8px;width:80%;"><div style="background:linear-gradient(90deg,#6366f1,#8b5cf6);height:100%;width:' . $w . '%;border-radius:4px;"></div></div></td>';
                $h .= '<td style="padding:6px 0;text-align:right;font-weight:700;width:60px;">' . (int) $r['n'] . '</td></tr>';
            }
            $h .= '</table>';
        }

        // Top sources
        if ( $top_utm ) {
            $h .= '<h2 style="font-size:14px;color:#0f172a;margin:18px 0 8px;">📣 Top traffic sources</h2><ul style="margin:0;padding-left:18px;font-size:13px;">';
            foreach ( $top_utm as $src => $n ) {
                $h .= '<li><strong>' . esc_html( $src ) . '</strong> · ' . (int) $n . ' submissions</li>';
            }
            $h .= '</ul>';
        }

        // Top countries
        if ( $top_countries ) {
            $h .= '<h2 style="font-size:14px;color:#0f172a;margin:18px 0 8px;">🌍 Top countries</h2><ul style="margin:0;padding-left:18px;font-size:13px;">';
            foreach ( $top_countries as $r ) {
                $h .= '<li><strong>' . esc_html( $r['country'] ) . '</strong> · ' . (int) $r['n'] . ' submissions</li>';
            }
            $h .= '</ul>';
        }

        $h .= '<div style="margin-top:24px;padding-top:14px;border-top:1px solid #e2e8f0;font-size:12px;color:#64748b;">';
        $h .= 'Open the full dashboard: <a href="' . esc_url( $link ) . '" style="color:#6366f1;">' . esc_html( $link ) . '</a><br>';
        $h .= 'To change frequency or stop these emails, visit Settings → Scheduled reports.';
        $h .= '</div></div>';
        return $h;
    }
}
