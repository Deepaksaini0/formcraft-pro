<?php
/**
 * Compile every .po file in this folder to a matching .mo binary that
 * WordPress can load for translations. Pure PHP — no gettext binary
 * needed. Idempotent.
 *
 * Usage: run from WP-CLI or visit the URL once after upload:
 *   php wp-content/plugins/formcraft-pro/languages/compile-mo.php
 * Or run via WP-CLI:
 *   wp eval-file wp-content/plugins/formcraft-pro/languages/compile-mo.php
 *
 * Built once, ship the .mo files inside the plugin ZIP forever after.
 *
 * @package FormYantra
 */

if ( ! defined( 'ABSPATH' ) ) {
    // Allow direct CLI execution for build-time compilation.
    if ( php_sapi_name() !== 'cli' ) {
        die( 'Run from WP-CLI or CLI only.' );
    }
}

/**
 * Minimal .po → .mo compiler. Parses msgid/msgstr pairs and emits a
 * gettext .mo file matching the Uniforum standard layout.
 */
function fcp_compile_po_to_mo( $po_path, $mo_path ) {
    if ( ! is_readable( $po_path ) ) return false;
    $contents = file_get_contents( $po_path );
    if ( $contents === false ) return false;

    // Strip BOM if present
    if ( substr( $contents, 0, 3 ) === "\xEF\xBB\xBF" ) {
        $contents = substr( $contents, 3 );
    }

    // Parse msgid / msgstr pairs.
    $messages = [];
    $current_id  = null;
    $current_str = null;
    $mode = null; // 'id' or 'str'

    foreach ( preg_split( "/\r?\n/", $contents ) as $line ) {
        $line = trim( $line );
        if ( $line === '' || $line[0] === '#' ) {
            // Flush on blank line
            if ( $current_id !== null && $current_str !== null ) {
                $messages[ $current_id ] = $current_str;
            }
            $current_id = null; $current_str = null; $mode = null;
            continue;
        }
        if ( strpos( $line, 'msgid ' ) === 0 ) {
            if ( $current_id !== null && $current_str !== null ) {
                $messages[ $current_id ] = $current_str;
            }
            $current_id = fcp_unquote( substr( $line, 6 ) );
            $current_str = null;
            $mode = 'id';
            continue;
        }
        if ( strpos( $line, 'msgstr ' ) === 0 ) {
            $current_str = fcp_unquote( substr( $line, 7 ) );
            $mode = 'str';
            continue;
        }
        if ( $line[0] === '"' ) {
            $chunk = fcp_unquote( $line );
            if ( $mode === 'id' )  $current_id  .= $chunk;
            if ( $mode === 'str' ) $current_str .= $chunk;
        }
    }
    if ( $current_id !== null && $current_str !== null ) {
        $messages[ $current_id ] = $current_str;
    }

    // Drop empty translations + ensure the "" header msgid is first.
    $header = isset( $messages[''] ) ? $messages[''] : '';
    unset( $messages[''] );
    $clean = [ '' => $header ];
    foreach ( $messages as $k => $v ) {
        if ( $v === '' ) continue;
        $clean[ $k ] = $v;
    }
    $messages = $clean;
    ksort( $messages );

    // Build .mo binary (gettext format).
    $count = count( $messages );
    $offsets = [];
    $ids = '';
    $strs = '';
    $key_offsets = [];
    $val_offsets = [];

    foreach ( $messages as $id => $str ) {
        $key_offsets[] = [ strlen( $id ), strlen( $ids ) ];
        $ids .= $id . "\0";
        $val_offsets[] = [ strlen( $str ), strlen( $strs ) ];
        $strs .= $str . "\0";
    }

    $key_start = 7 * 4 + $count * 4 * 4;
    $val_start = $key_start + strlen( $ids );

    foreach ( $key_offsets as &$o ) { $o[1] += $key_start; }
    foreach ( $val_offsets as &$o ) { $o[1] += $val_start; }

    $mo  = pack( 'Iiiiiii',
        0x950412de,   // magic
        0,            // version
        $count,
        7 * 4,        // offset of original-string table
        7 * 4 + $count * 8, // offset of translation table
        0, 0
    );
    foreach ( $key_offsets as $o ) $mo .= pack( 'ii', $o[0], $o[1] );
    foreach ( $val_offsets as $o ) $mo .= pack( 'ii', $o[0], $o[1] );
    $mo .= $ids . $strs;

    return file_put_contents( $mo_path, $mo ) !== false;
}

function fcp_unquote( $s ) {
    $s = trim( $s );
    if ( $s === '' || $s[0] !== '"' ) return '';
    $s = substr( $s, 1, -1 );
    return str_replace(
        [ '\\\\', '\\"', '\\n', '\\t', '\\r' ],
        [ '\\',  '"',   "\n",  "\t",  "\r" ],
        $s
    );
}

$dir = __DIR__;
$files = glob( $dir . '/*.po' );
$results = [];
foreach ( (array) $files as $po ) {
    $mo = preg_replace( '/\.po$/', '.mo', $po );
    $ok = fcp_compile_po_to_mo( $po, $mo );
    $results[] = ( $ok ? '✓ ' : '✗ ' ) . basename( $mo );
}
echo "FormYantra translation compile:\n" . implode( "\n", $results ) . "\n";
